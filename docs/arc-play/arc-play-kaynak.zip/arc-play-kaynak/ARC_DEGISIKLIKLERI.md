# ARC Play: WestPlay'den yapılan değişiklikler

ARC Play, **enes-less**'in [WestPlay](https://github.com/enes-less/WestPlay) projesinin (sürüm 2.0.3,
GPL-3.0-or-later) ARC Studio tarafından uyarlanmış hâlidir. GPL-3.0'ın 5(a) maddesi gereği değişiklikler ve
tarihleri aşağıdadır. Orijinal telif bildirimleri (LICENSE, THIRD_PARTY_*) değiştirilmemiştir. ARC Play de
GPL-3.0-or-later lisanslıdır ve kaynak koduyla birlikte dağıtılır.

Orijinal kaynak bu deponun ilk commit'idir (`WestPlay 2.0.3 ... orijinal kaynak, değiştirilmemiş`); her değişiklik
ayrı commit olarak görülebilir.

## 2026-11-04 (ARC Studio)

- **Ad:** "WestPlay" adı ARC Play olarak değiştirildi (arayüz metinleri, pencere başlıkları, crate / DLL / dosya
  adları, sabitler). Değişiklik `tools/arc_rebrand.py` ile yapıldı; orijinal depo ve yazar bağlantıları korundu.
  Harita yönü olan "west" kelimeleri değişmedi.
- **Güncelleme:** ARC Play kendi güncellemesini aramaz (`app/src/update.rs`, `ARC_GUNCELLEME_KAPALI`); ARC'ın
  kurulumu ve uygulama içi güncellemesiyle gelir. `tauri.conf.json` güncelleme adresi boş, güncelleme dosyası üretilmez.
- **Destek sayfası:** orijinal yazarın bağış (Kreosus) sayfası menüden kaldırıldı (`ui/src/companion/Companion.tsx`).
- **Hakkında:** orijinal proje ve yazarı anan "Lisans" bölümü eklendi (`ui/src/companion/pages/About.tsx`).
- **Kimlik:** Tauri kimliği `studio.arc.arcplay`, yayıncı ARC Studio; telif satırı orijinal yazarı korur.

Kod içindeki ARC'a özel yerler `ARC ÖZELLEŞTİRME` yorumuyla işaretlidir.
