/** ARC Play's version, from the workspace's Cargo.toml (vite.config.ts `define`). */
declare const __ARCPLAY_VERSION__: string
