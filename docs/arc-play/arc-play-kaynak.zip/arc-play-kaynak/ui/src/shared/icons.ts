/**
 * App icons by role. The UI only ever asks for a role (and a look, light or dark), so replacing the icon set
 * means changing this file.
 *
 * ARC Play's own icons (public/icons/arcplay), each in a light and a dark look.
 * ARC ÖZELLEŞTİRME: ikonların hepsi ARC'ın mor / turkuaz tarzında, tools/arc_gorseller.py ile sıfırdan çizilir
 * (WestPlay'in ikonları ve şirket logoları kullanılmaz; müzik / video hizmetleri yalnız renk ipucuyla ayrılır).
 * İkonu değiştirmek için o betikteki GLIFLER'i düzenleyip yeniden çalıştır.
 */
export type AppIconRole =
  'maps' | 'music' | 'spotify' | 'podcasts' | 'messages' | 'phone' | 'settings' | 'weather' | 'youtube' | 'youtubeMusic'

/** Each role's files' name. */
const FILES: Record<AppIconRole, string> = {
  maps: 'maps',
  music: 'music',
  spotify: 'spotify',
  podcasts: 'podcasts',
  messages: 'messages',
  phone: 'phone',
  settings: 'settings',
  weather: 'weather',
  youtube: 'youtube',
  youtubeMusic: 'youtube-music',
}

/** ARC Play's own icon for `role`, for a light or a dark screen. */
export function appIcon(role: AppIconRole, look: 'light' | 'dark' = 'light'): string {
  return `/icons/arcplay/${FILES[role]}.${look}.svg`
}
