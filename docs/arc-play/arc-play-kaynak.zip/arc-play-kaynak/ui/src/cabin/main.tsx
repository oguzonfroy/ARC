import '@fontsource-variable/instrument-sans'
import '@fontsource-variable/inter'
// The YouTube app's type, as YouTube's own.
import '@fontsource-variable/roboto'
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { CabinApp } from './CabinApp'
import { installDemo } from './demo'
import { Recovery } from './shell/Recovery'
import { useCabin, useLive } from './state/store'
import './shell/shell.css'
import './shell/apple.css'
// ARC ÖZELLEŞTİRME: ARC renk / yazı teması; yukarıdakilerin üstüne yazdığı için en sonda
import '../shared/arc-tema.css'
// ARC Kokpit: ARC Play'in tırın ekranındaki kendi görünümü (CarPlay görünümünün yerine)
import './shell/arc-kokpit.css'

// Development builds expose the stores for console debugging and browser previews (`arcplay.cabin`).
if (import.meta.env.DEV) {
  Object.assign(window, { arcplay: { cabin: useCabin, live: useLive } })
}

installDemo()

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Recovery>
      <CabinApp />
    </Recovery>
  </StrictMode>,
)
