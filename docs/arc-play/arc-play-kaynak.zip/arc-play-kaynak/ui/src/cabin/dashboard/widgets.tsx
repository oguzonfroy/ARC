import { useEffect, useState } from 'react'
import { Crossfade } from '../apps/music/Crossfade'
import { VideoWidget } from '../apps/youtube/VideoWidget'
import { NextGlyph, NoteGlyph, PauseGlyph, PlayGlyph, PreviousGlyph } from '../apps/music/glyphs'
import { TrackSlide } from '../apps/music/TrackSlide'
import { useTrackTransition } from '../apps/music/useTrackTransition'
import { logIn, playOrPause, skip, useAccount, useSpotify, useSpotifySource } from '../apps/spotify/spotify'
import {
  playOrPause as playOrPauseAppleMusic,
  skip as skipAppleMusic,
  useAppleMusic,
  useAppleMusicSource,
} from '../apps/music/appleMusic'
import {
  playOrPause as playOrPauseYouTubeMusic,
  skip as skipYouTubeMusic,
  useYouTubeMusic,
  useYouTubeMusicSource,
} from '../apps/youtubeMusic/youtubeMusic'
import type { MediaAction, MediaSource } from '../../shared/media'
import { go, useCabin } from '../state/store'
import { useMapData } from '../maps/mapData'
import { useLive } from '../state/store'
import { useText } from '../state/text'
import { nearestCity } from './destination'
import { useNowPlaying } from './useNowPlaying'
import { weatherView } from './weather'
import { WeatherGlyph } from './WeatherGlyph'
import { EMPTY, useDestinationView, useGuided } from './widgetState'
import { cabClock } from '../../shared/host'

/**
 * Now Playing: what plays, the video YouTube plays first (VideoWidget), then the Spotify app's music, then
 * Apple Music's (the Music app), then YouTube Music's; nothing playing, what played last (nowPlaying.ts); none
 * of them with anything, Not Playing. Turned off in Settings, its room goes to the others.
 */
export function NowPlayingWidget() {
  const shown = useCabin((state) => state.dashboardWidgets.nowPlaying)
  const { showing, spotify, appleMusic, youtubeMusic } = useNowPlaying()
  return (
    <div className={`widget-slot${shown ? ' open' : ''}`}>
      {shown && showing === 'video' && <VideoWidget />}
      {shown && showing === 'spotify' && spotify && <SpotifyWidget spotify={spotify} />}
      {shown && showing === 'appleMusic' && appleMusic && <AppleMusicWidget appleMusic={appleMusic} />}
      {shown && showing === 'youtubeMusic' && youtubeMusic && <YouTubeMusicWidget youtubeMusic={youtubeMusic} />}
      {shown && showing === null && <MusicWidget source={null} artwork={null} onControl={() => {}} spotifySignIn />}
    </div>
  )
}

/** Apple Music's music (the Music app's): what plays, its controls, opening Music on Now Playing. */
function AppleMusicWidget({ appleMusic }: { appleMusic: NonNullable<ReturnType<typeof useAppleMusicSource>> }) {
  return (
    <MusicWidget
      source={appleMusic.source}
      artwork={appleMusic.artwork}
      onOpen={() => {
        useAppleMusic.setState({ nowPlaying: true })
        go({ type: 'openApp', app: 'music' })
      }}
      onControl={(action) => {
        if (action === 'playPause') playOrPauseAppleMusic()
        else if (action === 'next') skipAppleMusic(1)
        else if (action === 'previous') skipAppleMusic(-1)
      }}
    />
  )
}

/** YouTube Music's music: what plays, its controls, opening YouTube Music on Now Playing. */
function YouTubeMusicWidget({ youtubeMusic }: { youtubeMusic: NonNullable<ReturnType<typeof useYouTubeMusicSource>> }) {
  return (
    <MusicWidget
      source={youtubeMusic.source}
      artwork={youtubeMusic.artwork}
      onOpen={() => {
        useYouTubeMusic.setState({ nowPlaying: true })
        go({ type: 'openApp', app: 'youtubeMusic' })
      }}
      onControl={(action) => {
        if (action === 'playPause') playOrPauseYouTubeMusic()
        else if (action === 'next') skipYouTubeMusic(1)
        else if (action === 'previous') skipYouTubeMusic(-1)
      }}
    />
  )
}

/** The Spotify app's music: what Spotify plays, its controls, opening the Spotify app on Now Playing. */
function SpotifyWidget({ spotify }: { spotify: NonNullable<ReturnType<typeof useSpotifySource>> }) {
  return (
    <MusicWidget
      source={spotify.source}
      artwork={spotify.artwork}
      onOpen={() => {
        useSpotify.setState({ nowPlaying: true })
        go({ type: 'openApp', app: 'spotify' })
      }}
      onControl={(action) => {
        if (action === 'playPause') playOrPause()
        else if (action === 'next') skip(1)
        else if (action === 'previous') skip(-1)
      }}
    />
  )
}

/**
 * Now Playing's music: a source's track, tinted by its album art (a blurred copy behind the glass). Track
 * changes animate (the new cover waited for, the text sliding, cover and tint crossfading). The track opens
 * its app (if ARC Play has one for it); the controls work in place, on what's playing now.
 */
function MusicWidget({
  source,
  artwork,
  onOpen,
  onControl,
  spotifySignIn = false,
}: {
  source: MediaSource | null
  artwork: string | null
  onOpen?(): void
  onControl(action: MediaAction): void
  /** ARC: nothing plays: signed out of Spotify, its sign-in instead of empty controls. */
  spotifySignIn?: boolean
}) {
  const account = useAccount()
  const signingIn = useSpotify((state) => state.signingIn)
  if (spotifySignIn && account === 'out') return <SpotifySignIn signingIn={signingIn} />
  return <MusicCard source={source} artwork={artwork} onOpen={onOpen} onControl={onControl} />
}

/** ARC: Spotify's sign-in on the Dashboard: Spotify's own sign-in opens on the PC (spotify.ts `logIn`). */
function SpotifySignIn({ signingIn }: { signingIn: boolean }) {
  const text = useText()
  return (
    <article className="widget glass now-playing np-giris">
      <span className="np-giris-logo" aria-hidden>
        <svg viewBox="0 0 24 24" width="56" height="56" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
          <circle cx="12" cy="12" r="9.5" />
          <path d="M7.3 9.4c3.1-1 6.7-.7 9.4.9M7.9 12.6c2.6-.7 5.5-.4 7.7.8M8.6 15.6c2.1-.5 4.2-.3 5.9.6" />
        </svg>
      </span>
      <div className="np-giris-metin">
        <b>{text.spotifySignIn}</b>
        <span>{signingIn ? text.spotify.finishOnPc : text.spotifySignInText}</span>
      </div>
      <button type="button" className="np-giris-dugme" disabled={signingIn} onClick={logIn}>
        {text.spotifySignIn}
      </button>
    </article>
  )
}

function MusicCard({
  source,
  artwork,
  onOpen,
  onControl,
}: {
  source: MediaSource | null
  artwork: string | null
  onOpen?(): void
  onControl(action: MediaAction): void
}) {
  const transition = useTrackTransition(source, artwork)
  const albumArt = useCabin((state) => state.albumArt)
  const cover = albumArt ? (transition.shown?.artwork ?? null) : null
  const controls = source?.controls
  const playing = source?.status === 'playing'
  const text = useText()

  return (
    <article className="widget glass now-playing">
      <Crossfade value={cover} className="np-tint" render={(url) => url && <img src={url} alt="" aria-hidden />} />
      <button type="button" className="np-top" onClick={onOpen} disabled={!onOpen}>
        <Crossfade
          value={cover}
          className="art"
          render={(url) =>
            url ? (
              <img src={url} alt="" />
            ) : (
              <span className="art-placeholder" aria-hidden>
                <NoteGlyph size={36} />
              </span>
            )
          }
        />
        <TrackSlide
          transition={transition}
          className="track"
          layerClassName="track-lines"
          render={(track) => (
            <>
              <span className="title">{track?.source.title ?? text.notPlaying}</span>
              {track && <span className="artist">{track.source.artist}</span>}
            </>
          )}
        />
      </button>
      {/* ARC: how far into the track, a thin line under it (moving on while it plays). */}
      <TrackProgress source={source} />
      <div className="controls">
        <button
          type="button"
          aria-label={text.previous}
          disabled={!controls?.previous}
          onClick={() => onControl('previous')}
        >
          <PreviousGlyph size={34} />
        </button>
        <button
          type="button"
          className="np-play"
          aria-label={playing ? text.pause : text.play}
          disabled={!controls?.playPause}
          onClick={() => onControl('playPause')}
        >
          {playing ? <PauseGlyph size={40} /> : <PlayGlyph size={40} />}
        </button>
        <button type="button" aria-label={text.next} disabled={!controls?.next} onClick={() => onControl('next')}>
          <NextGlyph size={34} />
        </button>
      </div>
    </article>
  )
}

/** ARC: the track's progress, 0 to 1, moving on each second while it plays (no line without a length). */
function TrackProgress({ source }: { source: MediaSource | null }) {
  const [now, setNow] = useState(() => Date.now())
  const playing = source?.status === 'playing'
  useEffect(() => {
    if (!playing) return
    const timer = setInterval(() => setNow(Date.now()), 1000)
    return () => clearInterval(timer)
  }, [playing])
  if (!source || source.durationMs <= 0) return <div className="np-progress empty" aria-hidden />
  const at = source.positionMs + (playing ? Math.max(0, now - source.positionAt) : 0)
  const done = Math.min(1, Math.max(0, at / source.durationMs))
  return (
    <div className="np-progress" aria-hidden>
      <div style={{ width: `${done * 100}%` }} />
    </div>
  )
}

/**
 * Where the truck is headed, our "live activity" (destination.ts): the job's pickup and then its delivery
 * (deadline and distance left), or where the game's route ends; folded away without either, as the
 * guidance card comes and goes.
 */
export function DestinationWidget() {
  const view = useDestinationView()
  const shown = useCabin((state) => state.dashboardWidgets.destination) && view !== EMPTY
  return (
    <div className={`widget-slot${shown ? ' open' : ''}`}>
      {shown && (
        <article className="widget glass job">
          <div className="kicker">{view.kicker}</div>
          <div className="destination">{view.title}</div>
          {view.subtitle && <div className="place">{view.subtitle}</div>}
          <div className={`deadline${view.late ? ' late' : ''}`}>{view.detail}</div>
        </article>
      )}
    </div>
  )
}

/** How many widgets the column holds at most: the weather comes in only where there's room. */
const COLUMN = 3

/**
 * The weather where the truck is, as CarPlay's weather widget (weather.ts): the nearest city, the weather
 * and its symbol. The column holds three widgets: it comes in where there's room (turn-by-turn, Now Playing
 * or the destination not showing: no route, no job, or turned off in Settings), as they come and go; and
 * not without the weather (no game, or one whose weather isn't read), or turned off itself.
 */
export function WeatherWidget() {
  const text = useText()
  const labels = useMapData()?.labels
  const widgets = useCabin((state) => state.dashboardWidgets)
  const guided = useGuided()
  const destination = useDestinationView()
  const others = [guided, widgets.nowPlaying, widgets.destination && destination !== EMPTY].filter(Boolean).length
  const room = widgets.weather && others < COLUMN
  const weather = useLive((state) => state.weather)
  const gameTime = useLive((state) => (state.telemetry ? cabClock(state.telemetry, state.clockShift) : 0))
  const place = useLive((state) => {
    const t = state.telemetry
    return t && labels ? nearestCity([t.x, t.z], labels) : null
  })
  const view = weather ? weatherView(weather, gameTime, place, text) : null
  return (
    <div className={`widget-slot${room && view ? ' open' : ''}`}>
      {view && (
        <article className="widget glass weather" aria-label={[view.place, view.condition].filter(Boolean).join(', ')}>
          <div className="weather-text">
            {view.place && <div className="place">{view.place}</div>}
            <div className="condition">{view.condition}</div>
          </div>
          <WeatherGlyph symbol={view.symbol} size={84} />
        </article>
      )}
    </div>
  )
}
