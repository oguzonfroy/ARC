import { type CSSProperties, useState } from 'react'
import { useAppIcon } from '../state/hooks'
import { type AppId, APPS, RELEASED_APP_IDS } from '../state/apps'
import { useLaunchStyle } from '../state/launch'
import { go, useCabin } from '../state/store'
import { useText } from '../state/text'
import './home.css'

/** How far each place from the middle sits: across (share of half the width) and down (px), its size. */
const PLACES = [
  { x: 0, y: 0, scale: 1 },
  { x: 0.38, y: 70, scale: 0.62 },
  { x: 0.66, y: 125, scale: 0.52 },
  { x: 0.9, y: 190, scale: 0.44 },
]

/**
 * ARC Play Horizon's Home (ARC Studio, 2026-11-05): the apps on a dial. The chosen one is large in the middle
 * with its name; the others step down either side along an arc, smaller and fainter. Touching one beside it
 * turns the dial to it; touching the middle one opens it. It opens on the app used last.
 */
export function Home() {
  const apps = RELEASED_APP_IDS
  const last = useCabin((state) => state.navigation.recents[0])
  const [chosen, setChosen] = useState(() => Math.max(0, apps.indexOf(last as AppId)))

  return (
    <section className="screen home kadran" aria-label="Home">
      {apps.map((app, index) => {
        const away = index - chosen
        const place = PLACES[Math.abs(away)]
        return (
          <DialApp
            key={app}
            app={app}
            chosen={away === 0}
            hidden={!place}
            style={
              place
                ? {
                    left: `calc(50% + ${Math.sign(away) * place.x * 50}%)`,
                    top: `calc(42% + ${place.y}px)`,
                    scale: String(place.scale),
                    opacity: String(1 - Math.abs(away) * 0.2),
                    zIndex: 10 - Math.abs(away),
                  }
                : { left: `calc(50% + ${Math.sign(away) * 60}%)`, top: '70%', scale: '0.3', opacity: '0' }
            }
            onPress={() => (away === 0 ? go({ type: 'openApp', app }, 'home') : setChosen(index))}
          />
        )
      })}
      <div className="kadran-noktalar" aria-hidden>
        {apps.map((app, index) => (
          <i key={app} className={index === chosen ? 'secili' : undefined} />
        ))}
      </div>
    </section>
  )
}

/** An app on the dial. Its icon is what the app grows out of when it opens, and shrinks back into. */
function DialApp({
  app,
  chosen,
  hidden,
  style,
  onPress,
}: {
  app: AppId
  chosen: boolean
  hidden: boolean
  style: CSSProperties
  onPress(): void
}) {
  const launch = useLaunchStyle(app, { kind: 'icon', origin: 'home' })
  const text = useText()
  const icon = useAppIcon(APPS[app].icon)
  return (
    <button
      type="button"
      className={chosen ? 'app secili' : 'app'}
      data-app={app}
      style={style}
      tabIndex={hidden ? -1 : 0}
      aria-hidden={hidden}
      aria-label={text.apps[app]}
      onClick={onPress}
    >
      <span className="kadran-ikon">
        <img src={icon} alt="" style={launch} />
      </span>
      <span className="label">{text.apps[app]}</span>
    </button>
  )
}
