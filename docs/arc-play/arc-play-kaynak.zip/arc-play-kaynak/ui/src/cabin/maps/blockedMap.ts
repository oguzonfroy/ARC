/**
 * What the Maps app says instead of the map when the player plays on a map ARC Play doesn't allow (the host
 * tells: a map by HVT, Heavy Vehicles Turkey), in the game's language: every language the game has, by
 * its own codes (`locale/<code>` in its archives). HVT and ARC Play are names, the same in every language.
 * The game shows Silesian players Polish (pl_si), and so does this.
 */
export const HVT_MAP_MESSAGES: Record<string, string> = {
  bg_bg: 'Картите от HVT не са разрешени в ARC Play. Свържете се с ARC Play, за да научите повече.',
  ca_es: "Els mapes d'HVT no estan permesos a ARC Play. Contacta amb ARC Play per saber-ne més.",
  cs_cz: 'Mapy od HVT nejsou ve ARC Play povoleny. Pro více informací kontaktujte ARC Play.',
  da_dk: 'Kort fra HVT er ikke tilladt i ARC Play. Kontakt ARC Play for at få mere at vide.',
  de_de: 'Karten von HVT sind in ARC Play nicht erlaubt. Kontaktiere ARC Play, um mehr zu erfahren.',
  el_gr: 'Οι χάρτες της HVT δεν επιτρέπονται στο ARC Play. Επικοινωνήστε με το ARC Play για να μάθετε περισσότερα.',
  en_gb: 'Maps by HVT are not allowed in ARC Play. Contact ARC Play to learn more.',
  en_us: 'Maps by HVT are not allowed in ARC Play. Contact ARC Play to learn more.',
  es_es: 'Los mapas de HVT no están permitidos en ARC Play. Contacta con ARC Play para saber más.',
  es_la: 'Los mapas de HVT no están permitidos en ARC Play. Comunícate con ARC Play para saber más.',
  et_ee: 'HVT kaardid ei ole ARC Plays lubatud. Lisateabe saamiseks võta ühendust ARC Playga.',
  eu_es: 'HVTren mapak ez daude baimenduta ARC Playn. Jarri harremanetan ARC Playrekin gehiago jakiteko.',
  fi_fi: 'HVT:n kartat eivät ole sallittuja ARC Playssa. Ota yhteyttä ARC Playhin saadaksesi lisätietoja.',
  fr_ca: 'Les cartes de HVT ne sont pas permises dans ARC Play. Communiquez avec ARC Play pour en savoir plus.',
  fr_fr: 'Les cartes de HVT ne sont pas autorisées dans ARC Play. Contactez ARC Play pour en savoir plus.',
  gl_es: 'Os mapas de HVT non están permitidos en ARC Play. Contacta con ARC Play para saber máis.',
  hr_hr: 'Karte od HVT-a nisu dopuštene u ARC Playu. Za više informacija obratite se ARC Playu.',
  hu_hu: 'A HVT térképei nem engedélyezettek a ARC Playben. További információért lépj kapcsolatba a ARC Playjel.',
  it_it: 'Le mappe di HVT non sono consentite in ARC Play. Contatta ARC Play per saperne di più.',
  ja_jp: 'HVTのマップはARC Playでは使用できません。詳しくはARC Playにお問い合わせください。',
  ka_ge: 'HVT-ის რუკები ARC Play-ში დაშვებული არ არის. მეტის გასაგებად დაუკავშირდით ARC Play-ს.',
  ko_kr: 'HVT의 지도는 ARC Play에서 허용되지 않습니다. 자세한 내용은 ARC Play에 문의하세요.',
  lt_lt: 'HVT žemėlapiai ARC Play neleidžiami. Norėdami sužinoti daugiau, susisiekite su ARC Play.',
  lv_lv: 'HVT kartes ARC Play nav atļautas. Lai uzzinātu vairāk, sazinieties ar ARC Play.',
  mk_mk: 'Мапите од HVT не се дозволени во ARC Play. Контактирајте го ARC Play за да дознаете повеќе.',
  nl_nl: 'Kaarten van HVT zijn niet toegestaan in ARC Play. Neem contact op met ARC Play voor meer informatie.',
  no_no: 'Kart fra HVT er ikke tillatt i ARC Play. Kontakt ARC Play for å finne ut mer.',
  pl_pl: 'Mapy od HVT nie są dozwolone w ARC Play. Skontaktuj się z ARC Play, aby dowiedzieć się więcej.',
  pl_si: 'Mapy od HVT nie są dozwolone w ARC Play. Skontaktuj się z ARC Play, aby dowiedzieć się więcej.',
  pt_br: 'Mapas da HVT não são permitidos no ARC Play. Entre em contato com o ARC Play para saber mais.',
  pt_pt: 'Os mapas da HVT não são permitidos no ARC Play. Contacte o ARC Play para saber mais.',
  ro_ro: 'Hărțile HVT nu sunt permise în ARC Play. Contactează ARC Play pentru a afla mai multe.',
  ru_ru: 'Карты от HVT не разрешены в ARC Play. Свяжитесь с ARC Play, чтобы узнать больше.',
  sk_sk: 'Mapy od HVT nie sú vo ARC Play povolené. Pre viac informácií kontaktujte ARC Play.',
  sl_sl: 'Zemljevidi HVT v ARC Playu niso dovoljeni. Za več informacij se obrnite na ARC Play.',
  sr_sp: 'Mape od HVT-a nisu dozvoljene u ARC Play-u. Kontaktirajte ARC Play da saznate više.',
  sr_sr: 'Мапе од HVT-а нису дозвољене у ARC Play-у. Контактирајте ARC Play да сазнате више.',
  sv_se: 'Kartor från HVT är inte tillåtna i ARC Play. Kontakta ARC Play för att få veta mer.',
  tr_tr: "HVT haritalarına ARC Play'de izin verilmiyor. Daha fazla bilgi için ARC Play ile iletişime geçin.",
  uk_uk: "Карти від HVT не дозволені у ARC Play. Зв'яжіться з ARC Play, щоб дізнатися більше.",
  vi_vn: 'Bản đồ của HVT không được phép sử dụng trong ARC Play. Liên hệ ARC Play để tìm hiểu thêm.',
  zh_cn: 'ARC Play 不允许使用 HVT 的地图。如需了解详情，请联系 ARC Play。',
  zh_tw: 'ARC Play 不允許使用 HVT 的地圖。如需瞭解詳情，請聯絡 ARC Play。',
}

/** The message in the game's `language`, or English for one not listed (a mod's). */
export function hvtMapMessage(language: string | null): string {
  return HVT_MAP_MESSAGES[language ?? ''] ?? HVT_MAP_MESSAGES.en_us
}
