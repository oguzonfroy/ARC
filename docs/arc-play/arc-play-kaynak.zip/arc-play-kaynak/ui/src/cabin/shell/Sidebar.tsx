import type { ReactNode } from 'react'
import { formatGameTime } from '../../shared/format'
import type { AppId } from '../state/apps'
import { LAUNCH_STYLE, useCarriesLaunch } from '../state/launch'
import { homeButtonTarget } from '../state/navigation'
import { go, useCabin, useLive } from '../state/store'
import { useText } from '../state/text'
import { cabClock } from '../../shared/host'

/** The music apps: the dock's Music button opens the one used last (Spotify when none was). */
const MUSIC_APPS: AppId[] = ['spotify', 'music', 'youtubeMusic']

/**
 * ARC Play Horizon (ARC Studio, 2026-11-05): instead of CarPlay's sidebar, a status line across the top (the ARC
 * mark, the game's clock, whether the game is there) and the ARC command arc at the bottom: Maps, Music, the
 * big ARC button (Home or the Dashboard, as CarPlay's Home button), Video and the truck's own screen. The dock
 * keeps the `sidebar` class: launches, click-through and the video player's peek find it by it.
 */
export function Sidebar() {
  return (
    <>
      <TopBar />
      <Dock />
    </>
  )
}

function TopBar() {
  const gameTime = useLive((state) => (state.telemetry ? cabClock(state.telemetry, state.clockShift) : null))
  const connected = useLive((state) => state.telemetry !== null)
  return (
    <header className="arc-ust" style={{ viewTransitionName: 'arc-ust' }}>
      <div className="arc-ust-marka">
        <img src="/arcplay.png" alt="" />
        <span>
          <b>ARC</b>
          <small>PLAY</small>
        </span>
      </div>
      <div className="arc-ust-saat">{gameTime === null ? '--:--' : formatGameTime(gameTime)}</div>
      <div className="arc-ust-durum">
        <span className={connected ? 'arc-cip bagli' : 'arc-cip'}>
          <i aria-hidden />
          {connected ? 'ETS2 / ATS' : '—'}
        </span>
      </div>
    </header>
  )
}

function Dock() {
  const text = useText()
  const route = useCabin((state) => state.navigation.route)
  const recents = useCabin((state) => state.navigation.recents)
  const homeTarget = useCabin((state) => homeButtonTarget(state.navigation))
  const open = route.kind === 'app' ? route.app : null
  const music = recents.find((app) => MUSIC_APPS.includes(app)) ?? 'spotify'
  const onMusic = open !== null && MUSIC_APPS.includes(open)

  return (
    <nav className="sidebar arc-yay" aria-label="ARC" style={{ viewTransitionName: 'sidebar' }}>
      <svg className="arc-yay-govde" viewBox="0 0 1000 150" preserveAspectRatio="none" aria-hidden>
        <defs>
          <linearGradient id="arcYayKenar" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#a78bfa" stopOpacity="0" />
            <stop offset=".5" stopColor="#a78bfa" stopOpacity=".75" />
            <stop offset="1" stopColor="#a78bfa" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path className="arc-yay-dolgu" d="M0 150 C 160 52 340 30 500 30 S 840 52 1000 150 Z" />
        <path d="M0 150 C 160 52 340 30 500 30 S 840 52 1000 150" fill="none" stroke="url(#arcYayKenar)" strokeWidth="2" />
      </svg>
      <div className="arc-yay-dugmeler">
        <DockApp app="maps" label={text.apps.maps} current={open === 'maps'}>
          <MapGlyph />
        </DockApp>
        <DockApp app={music} label={text.apps.music} current={onMusic}>
          <MusicGlyph />
        </DockApp>
        {/* Its mark is where it goes: the app grid (Home) or the Dashboard. */}
        <button
          type="button"
          className="arc-yay-merkez home-button"
          aria-label={homeTarget === 'home' ? 'Home' : 'Dashboard'}
          onClick={() => go({ type: 'pressHome' })}
        >
          <ArcGlyph />
        </button>
        <DockApp app="youtube" label={text.apps.youtube} current={open === 'youtube'}>
          <VideoGlyph />
        </DockApp>
        <button
          type="button"
          className="arc-yay-dugme"
          aria-label="Truck screen"
          onClick={() => useCabin.getState().setTruckScreen(true)}
        >
          <span className="arc-yay-ikon">
            <TruckGlyph />
          </span>
          <span className="arc-yay-ad">{text.truckScreen}</span>
        </button>
      </div>
    </nav>
  )
}

/** A dock button opening an app. Its icon box is what the app grows out of and shrinks back into. */
function DockApp({ app, label, current, children }: { app: AppId; label: string; current: boolean; children: ReactNode }) {
  const launching = useCarriesLaunch(app, { kind: 'icon', origin: 'sidebar' })
  return (
    <button
      type="button"
      className="arc-yay-dugme"
      aria-current={current ? 'page' : undefined}
      aria-label={label}
      onClick={() => go({ type: 'openApp', app }, 'sidebar')}
    >
      <span className="arc-yay-ikon" style={launching ? LAUNCH_STYLE : undefined}>
        {children}
      </span>
      <span className="arc-yay-ad">{label}</span>
    </button>
  )
}

const glyph = { viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.9, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true } as const

function MapGlyph() {
  return (
    <svg {...glyph}>
      <path d="M12 21s-6-5.6-6-11a6 6 0 0 1 12 0c0 5.4-6 11-6 11z" />
      <circle cx="12" cy="10" r="2.2" />
    </svg>
  )
}

function MusicGlyph() {
  return (
    <svg {...glyph}>
      <path d="M9 18V6l10-2v12" />
      <circle cx="6.5" cy="18" r="2.5" />
      <circle cx="16.5" cy="16" r="2.5" />
    </svg>
  )
}

function VideoGlyph() {
  return (
    <svg {...glyph}>
      <rect x="3" y="6" width="18" height="12" rx="3.5" />
      <path d="M10.5 9.5l4 2.5-4 2.5z" fill="currentColor" />
    </svg>
  )
}

/** ARC's own mark: the A of the logo. */
function ArcGlyph() {
  return (
    // `shown`: shell.css hides the Home button's glyphs that aren't (CarPlay's two-glyph button).
    <svg {...glyph} strokeWidth={2.2} className="shown">
      <path d="M12 3 4 20h4l4-9 4 9h4z" />
    </svg>
  )
}

/** Back to the truck: the front of a truck cab. */
function TruckGlyph() {
  return (
    <svg {...glyph}>
      <path d="M6.5 3.5h11a2 2 0 0 1 2 2V17h-15V5.5a2 2 0 0 1 2-2Z" />
      <path d="M7 6.5h10v4.5H7Z" />
      <path d="M7.5 14h1.5M15 14h1.5" />
      <path d="M6 17v2.5h2.5V17M15.5 17v2.5H18V17" />
    </svg>
  )
}
