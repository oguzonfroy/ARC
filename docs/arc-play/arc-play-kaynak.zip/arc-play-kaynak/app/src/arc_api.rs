//! ARC ÖZELLEŞTİRME: yerel kontrol arayüzü. ARC Play'in yardımcı penceresi gösterilmez; ETS2 Auto Drive, ARC Play'i
//! (Özelleştir, Hesaplar, ekranın açılıp kapanması, otomatik kurulumun durumu) buradan yönetir.
//!
//! Güvenlik: yalnız 127.0.0.1'i dinler (ağdan erişilemez); her açılışta rastgele bir port ve 256 bitlik bir anahtar
//! seçer ve bunları yalnız bu kullanıcının okuyabildiği %LOCALAPPDATA%\ARC Studio\arc_play_api.json dosyasına yazar.
//! Anahtarı (X-ARC-Anahtar başlığı) tutmayan istek reddedilir. Gövde en çok 1 MB.
//!
//! Uçlar (JSON):
//!   GET  /durum                         sürüm, otomatik kurulum, ARC Play'in son durumu (oyun, ekran, hesaplar, harita)
//!   GET  /ayarlar          POST /ayarlar ayarların tamamı (görünüm: duvar kâğıdı, ikon seti, ikon tarzı...)
//!   GET  /ozellestir                    oyuncunun duvar kâğıtları ve ikon setleri
//!   POST /ozellestir/duvar-kagidi       {"dosyalar": ["C:\\...jpg"]}       ekle
//!   POST /ozellestir/ikon               {"yol": "C:\\...zip" | klasör}     ekle
//!   POST /ozellestir/duvar-kagidi-sil   {"id": "custom:..."}
//!   POST /ozellestir/ikon-sil           {"ad": "..."}
//!   POST /hesap                         {"servis": "youtube|spotify|appleMusic", "islem": "giris|cikis|kontrol"}
//!   POST /ekran                         {"acik": true}     ARC Play'i tırın ekranında aç / kapat
//!   POST /kurulum                       otomatik kurulumu şimdi yeniden dene (ör. Windows izni reddedildikten sonra)
//!   POST /kapat                         ARC Play'i kapat

use std::io::{BufRead, BufReader, Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Duration;

use serde_json::{Value, json};
use tauri::{AppHandle, Emitter, Listener, Manager};
use arcplay_host::settings::Settings;
use arcplay_host::{AccountAction, log};

use crate::customize::Customize;
use crate::setup::OtoDurum;
use crate::{Accounts, ArcplayOpen, SettingsStore};

const EN_COK_GOVDE: usize = 1 << 20;

/// Kontrol arayüzünün paylaştığı durum.
pub struct Paylasim {
    pub oto: Arc<Mutex<OtoDurum>>,
    pub yeniden: Arc<AtomicBool>,
    son_durum: Arc<Mutex<Value>>,
}

impl Paylasim {
    pub fn new() -> Self {
        Self { oto: Arc::default(), yeniden: Arc::default(), son_durum: Arc::new(Mutex::new(Value::Null)) }
    }
}

/// Bağlantı bilgisinin dosyası: ETS2 Auto Drive buradan okur.
pub fn bilgi_dosyasi() -> Option<PathBuf> {
    Some(PathBuf::from(std::env::var_os("LOCALAPPDATA")?).join("ARC Studio").join("arc_play_api.json"))
}

/// 256 bitlik rastgele anahtar (Windows'un kriptografik üreteci).
fn rastgele_anahtar() -> String {
    let mut bayt = [0u8; 32];
    // SAFETY: BCryptGenRandom bayt dizisinin tamamını doldurur; sistemin varsayılan RNG'si (algoritma tutamacı yok).
    let tamam = unsafe {
        windows::Win32::Security::Cryptography::BCryptGenRandom(
            None,
            &mut bayt,
            windows::Win32::Security::Cryptography::BCRYPT_USE_SYSTEM_PREFERRED_RNG,
        )
    };
    assert!(tamam.is_ok(), "rastgele anahtar üretilemedi");
    bayt.iter().map(|b| format!("{b:02x}")).collect()
}

/// Dinlemeye başlar ve bağlantı bilgisini yazar.
pub fn baslat(app: &AppHandle, paylasim: &Paylasim) {
    // ARC Play'in son durumu (host her saniye bildirir): /durum'da verilir
    let son = paylasim.son_durum.clone();
    app.listen_any("host-status", move |olay| {
        if let Ok(deger) = serde_json::from_str::<Value>(olay.payload()) {
            *son.lock().unwrap_or_else(|e| e.into_inner()) = deger;
        }
    });
    let dinleyici = match TcpListener::bind("127.0.0.1:0") {
        Ok(d) => d,
        Err(error) => return log!("[arc_api] dinlenemedi: {error}"),
    };
    let port = dinleyici.local_addr().map(|a| a.port()).unwrap_or(0);
    let anahtar = rastgele_anahtar();
    if let Some(dosya) = bilgi_dosyasi() {
        let _ = std::fs::create_dir_all(dosya.parent().unwrap_or(&dosya));
        let icerik = json!({ "port": port, "anahtar": anahtar, "pid": std::process::id() }).to_string();
        if let Err(error) = std::fs::write(&dosya, icerik) {
            log!("[arc_api] bağlantı bilgisi yazılamadı: {error}");
        }
    }
    log!("[arc_api] 127.0.0.1:{port} dinleniyor");
    let app = app.clone();
    let (oto, yeniden, son_durum) = (paylasim.oto.clone(), paylasim.yeniden.clone(), paylasim.son_durum.clone());
    let _ = std::thread::Builder::new().name("arc-api".into()).spawn(move || {
        for baglanti in dinleyici.incoming().flatten() {
            let (app, anahtar) = (app.clone(), anahtar.clone());
            let (oto, yeniden, son_durum) = (oto.clone(), yeniden.clone(), son_durum.clone());
            let _ = std::thread::Builder::new().name("arc-api-istek".into()).spawn(move || {
                let ortam = Ortam { app: &app, oto: &oto, yeniden: &yeniden, son_durum: &son_durum };
                if let Err(error) = istek(baglanti, &anahtar, &ortam) {
                    log!("[arc_api] istek okunamadı: {error}");
                }
            });
        }
    });
}

/// Çıkarken bağlantı bilgisini siler (eski bir port denenmesin).
pub fn bitir() {
    if let Some(dosya) = bilgi_dosyasi() {
        let _ = std::fs::remove_file(dosya);
    }
}

struct Ortam<'a> {
    app: &'a AppHandle,
    oto: &'a Mutex<OtoDurum>,
    yeniden: &'a AtomicBool,
    son_durum: &'a Mutex<Value>,
}

fn istek(akis: TcpStream, anahtar: &str, ortam: &Ortam) -> std::io::Result<()> {
    akis.set_read_timeout(Some(Duration::from_secs(10)))?;
    let mut okuyucu = BufReader::new(akis.try_clone()?);
    let mut satir = String::new();
    okuyucu.read_line(&mut satir)?;
    let mut parca = satir.split_whitespace();
    let (yontem, yol) = (parca.next().unwrap_or("").to_owned(), parca.next().unwrap_or("").to_owned());
    let (mut uzunluk, mut gelen_anahtar) = (0usize, String::new());
    loop {
        let mut baslik = String::new();
        if okuyucu.read_line(&mut baslik)? == 0 || baslik.trim().is_empty() {
            break;
        }
        if let Some((ad, deger)) = baslik.split_once(':') {
            match ad.trim().to_ascii_lowercase().as_str() {
                "content-length" => uzunluk = deger.trim().parse().unwrap_or(0),
                "x-arc-anahtar" => gelen_anahtar = deger.trim().to_owned(),
                _ => {}
            }
        }
    }
    let (kod, cevap, kapat) = if uzunluk > EN_COK_GOVDE {
        (413, json!({ "hata": "gövde çok büyük" }), false)
    } else if !sabit_zamanli_esit(gelen_anahtar.as_bytes(), anahtar.as_bytes()) {
        (403, json!({ "hata": "anahtar tutmadı" }), false)
    } else {
        let mut govde = vec![0u8; uzunluk];
        okuyucu.read_exact(&mut govde)?;
        let girdi: Value = if govde.is_empty() { Value::Null } else { serde_json::from_slice(&govde).unwrap_or(Value::Null) };
        match yonlendir(&yontem, &yol, &girdi, &govde, ortam) {
            Ok(deger) => (200, deger, yontem == "POST" && yol == "/kapat"),
            Err(hata) => (400, json!({ "hata": hata }), false),
        }
    };
    let metin = cevap.to_string();
    let mut yazici = akis;
    write!(
        yazici,
        "HTTP/1.1 {kod} {}\r\nContent-Type: application/json; charset=utf-8\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{metin}",
        if kod == 200 { "OK" } else { "Error" },
        metin.len()
    )?;
    yazici.flush()?;
    if kapat {
        ortam.app.exit(0);
    }
    Ok(())
}

fn sabit_zamanli_esit(a: &[u8], b: &[u8]) -> bool {
    a.len() == b.len() && a.iter().zip(b).fold(0u8, |fark, (x, y)| fark | (x ^ y)) == 0
}

fn metin<'a>(girdi: &'a Value, ad: &str) -> Result<&'a str, String> {
    girdi.get(ad).and_then(Value::as_str).ok_or_else(|| format!("'{ad}' eksik"))
}

fn yonlendir(yontem: &str, yol: &str, girdi: &Value, govde: &[u8], ortam: &Ortam) -> Result<Value, String> {
    let app = ortam.app;
    let ozellestir = app.state::<Customize>();
    match (yontem, yol) {
        ("GET", "/durum") => Ok(json!({
            "surum": env!("CARGO_PKG_VERSION"),
            "kurulum": *ortam.oto.lock().unwrap_or_else(|e| e.into_inner()),
            "durum": *ortam.son_durum.lock().unwrap_or_else(|e| e.into_inner()),
        })),
        ("GET", "/ayarlar") => serde_json::to_value(app.state::<SettingsStore>().shared.get()).map_err(|e| e.to_string()),
        ("POST", "/ayarlar") => {
            let ayarlar: Settings = serde_json::from_slice(govde).map_err(|e| format!("ayarlar okunamadı: {e}"))?;
            let store = app.state::<SettingsStore>();
            store.file.save(&ayarlar).map_err(|e| format!("ayarlar kaydedilemedi: {e}"))?;
            store.shared.set(ayarlar.clone());
            let _ = app.emit("settings-changed", &ayarlar);
            serde_json::to_value(ayarlar).map_err(|e| e.to_string())
        }
        ("GET", "/ozellestir") => {
            serde_json::to_value(arcplay_host::customize::list(&ozellestir.dir)).map_err(|e| e.to_string())
        }
        ("POST", "/ozellestir/duvar-kagidi") => {
            let dosyalar: Vec<PathBuf> = girdi
                .get("dosyalar")
                .and_then(Value::as_array)
                .ok_or("'dosyalar' eksik")?
                .iter()
                .filter_map(Value::as_str)
                .map(PathBuf::from)
                .collect();
            let eklenen = arcplay_host::customize::add_wallpapers(&ozellestir.dir, &dosyalar).map_err(|e| e.to_string())?;
            ozellestir.changed();
            serde_json::to_value(eklenen).map_err(|e| e.to_string())
        }
        ("POST", "/ozellestir/ikon") => {
            let kaynak = PathBuf::from(metin(girdi, "yol")?);
            let eklenen = if kaynak.extension().is_some_and(|u| u.eq_ignore_ascii_case("zip")) {
                arcplay_host::customize::add_icon_set_from_zip(&ozellestir.dir, &kaynak)
            } else {
                arcplay_host::customize::add_icon_set_from_folder(&ozellestir.dir, &kaynak)
            }
            .map_err(|e| e.to_string())?;
            ozellestir.changed();
            serde_json::to_value(eklenen).map_err(|e| e.to_string())
        }
        ("POST", "/ozellestir/duvar-kagidi-sil") => {
            let id = metin(girdi, "id")?.to_owned();
            arcplay_host::customize::remove_wallpaper(&ozellestir.dir, &id).map_err(|e| e.to_string())?;
            ozellestir.changed();
            crate::customize::forget(&app.state::<SettingsStore>(), app, |look| {
                if look.wallpaper.as_deref() == Some(id.as_str()) {
                    look.wallpaper = None;
                }
            })?;
            Ok(json!({ "tamam": true }))
        }
        ("POST", "/ozellestir/ikon-sil") => {
            let ad = metin(girdi, "ad")?.to_owned();
            arcplay_host::customize::remove_icon_set(&ozellestir.dir, &ad).map_err(|e| e.to_string())?;
            ozellestir.changed();
            crate::customize::forget(&app.state::<SettingsStore>(), app, |look| {
                if look.icon_set.as_deref() == Some(ad.as_str()) {
                    look.icon_set = None;
                }
            })?;
            Ok(json!({ "tamam": true }))
        }
        ("POST", "/hesap") => {
            let hesaplar = app.state::<Accounts>();
            let servis = match metin(girdi, "servis")? {
                "youtube" => &hesaplar.0.youtube,
                "spotify" => &hesaplar.0.spotify,
                "appleMusic" => &hesaplar.0.apple_music,
                diger => return Err(format!("bilinmeyen servis: {diger}")),
            };
            servis.request(match metin(girdi, "islem")? {
                "giris" => AccountAction::SignIn,
                "cikis" => AccountAction::SignOut,
                "kontrol" => AccountAction::Check,
                diger => return Err(format!("bilinmeyen işlem: {diger}")),
            });
            Ok(json!({ "tamam": true }))
        }
        ("POST", "/ekran") => {
            let acik = girdi.get("acik").and_then(Value::as_bool).ok_or("'acik' eksik")?;
            app.state::<ArcplayOpen>().0.request(acik);
            Ok(json!({ "tamam": true }))
        }
        ("POST", "/kurulum") => {
            ortam.yeniden.store(true, Ordering::Release);
            Ok(json!({ "tamam": true }))
        }
        ("POST", "/kapat") => Ok(json!({ "tamam": true })),
        _ => Err(format!("bilinmeyen uç: {yontem} {yol}")),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn anahtar_karsilastirmasi() {
        assert!(sabit_zamanli_esit(b"abc", b"abc"));
        assert!(!sabit_zamanli_esit(b"abc", b"abd"));
        assert!(!sabit_zamanli_esit(b"abc", b"abcd"));
        assert!(!sabit_zamanli_esit(b"", b"x"));
    }

    #[test]
    fn rastgele_anahtar_256_bit_ve_her_seferinde_farkli() {
        let (a, b) = (rastgele_anahtar(), rastgele_anahtar());
        assert_eq!(a.len(), 64);
        assert_ne!(a, b);
    }
}
