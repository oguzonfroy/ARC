"""ARC Play'in kendi görselleri (ARC ÖZELLEŞTİRME): uygulama ikonları ve duvar kâğıtları sıfırdan, kodla çizilir.
WestPlay'in ikon ve duvar kâğıtlarının yerine geçer; ARC'ın mor / turkuaz kimliği.

Çalıştırma: python tools/arc_gorseller.py   (depo kökünden; Pillow ve numpy gerekir)
Çıktı: ui/public/icons/arcplay/<rol>.<light|dark>.svg, ui/public/wallpapers/arc.jpg, arc.dark.jpg
"""
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

KOK = Path(__file__).resolve().parent.parent
IKON = KOK / "ui/public/icons/arcplay"
DUVAR = KOK / "ui/public/wallpapers"

MOR, MOR_KOYU, TURKUAZ, MURDUM = "#8b5cf6", "#5b2be0", "#2dd4bf", "#15101f"

# Her rolün çizgisi (1024'lük alanda). "c" = çizgi (stroke), "d" = dolu şekil.
GLIFLER = {
    "maps": [("c", "M300 730 C 380 560 520 650 560 500 S 690 330 724 330"), ("d", "M724 248 a82 82 0 1 1 -0.1 0 Z M724 300 a30 30 0 1 0 0.1 0 Z"),
             ("d", "M300 730 m-46 0 a46 46 0 1 0 92 0 a46 46 0 1 0 -92 0")],
    "music": [("c", "M432 700 V352 L700 300 V640"), ("d", "M432 700 m-86 0 a86 70 -18 1 0 172 0 a86 70 -18 1 0 -172 0"),
              ("d", "M700 640 m-86 0 a86 70 -18 1 0 172 0 a86 70 -18 1 0 -172 0")],
    "podcasts": [("d", "M432 300 a80 80 0 0 1 160 0 V520 a80 80 0 0 1 -160 0 Z"), ("c", "M330 500 a182 182 0 0 0 364 0"),
                 ("c", "M512 684 V770 M420 770 H604")],
    "messages": [("d", "M300 300 H724 a70 70 0 0 1 70 70 V600 a70 70 0 0 1 -70 70 H500 L380 760 V670 H300 a70 70 0 0 1 -70 -70 V370 a70 70 0 0 1 70 -70 Z"),
                 ("k", "M412 485 a34 34 0 1 0 0.1 0 Z M512 485 a34 34 0 1 0 0.1 0 Z M612 485 a34 34 0 1 0 0.1 0 Z")],
    "phone": [("d", "M380 280 C 330 280 296 318 304 372 C 334 566 470 704 664 734 C 716 742 748 706 748 660 L 748 600 "
                    "C 748 580 736 566 718 560 L 640 534 C 620 528 600 534 588 550 L 556 590 C 484 556 426 498 392 426 "
                    "L 432 394 C 448 382 454 362 448 342 L 422 304 C 414 288 398 280 380 280 Z")],
    # dişli: kalın halka + kalın, kısa, köşeli dişler (güneşle karışmasın)
    "settings": [("c", "M512 512 m-185 0 a185 185 0 1 0 370 0 a185 185 0 1 0 -370 0", 104, "butt"),
                 ("c", " ".join(f"M{512 + 220 * np.cos(a):.0f} {512 + 220 * np.sin(a):.0f} L{512 + 318 * np.cos(a):.0f} {512 + 318 * np.sin(a):.0f}"
                                for a in np.linspace(0, 2 * np.pi, 8, endpoint=False) + np.pi / 8), 96, "butt")],
    # hava: dolu güneş bulutun arkasından çıkar
    "weather": [("d", "M410 420 m-130 0 a130 130 0 1 0 260 0 a130 130 0 1 0 -260 0"),
                ("c", "M410 220 V200 M250 286 L236 272 M210 420 H190 M570 286 L584 272", 44, "round"),
                ("k", "M398 742 H700 a118 118 0 0 0 12 -235 a172 172 0 0 0 -322 42 a98 98 0 0 0 8 193 Z"),
                ("d", "M398 720 H690 a110 110 0 0 0 10 -219 a160 160 0 0 0 -300 40 a92 92 0 0 0 0 179 Z")],
    "youtube": [("d", "M300 340 H724 a90 90 0 0 1 90 90 V594 a90 90 0 0 1 -90 90 H300 a90 90 0 0 1 -90 -90 V430 a90 90 0 0 1 90 -90 Z"),
                ("k", "M462 430 L612 512 L462 594 Z")],
    "youtube-music": [("c", "M512 512 m-230 0 a230 230 0 1 0 460 0 a230 230 0 1 0 -460 0"), ("d", "M452 400 L620 512 L452 624 Z")],
    "spotify": [("c", "M512 512 m-250 0 a250 250 0 1 0 500 0 a250 250 0 1 0 -500 0"),
                ("c", "M370 430 Q 512 380 660 450 M392 520 Q 512 480 630 536 M414 604 Q 512 576 600 614")],
}
# Hizmetlerin tanınması için renk ipucu (kendi çizimimizle; şirket logoları kullanılmaz)
VURGU = {"youtube": ("#ff3d5a", "#c8102e"), "youtube-music": ("#ff3d5a", "#c8102e"), "spotify": ("#2ee87a", "#119944")}


def ikon(rol, gorunum):
    a, b = VURGU.get(rol, (MOR, MOR_KOYU))
    if gorunum == "light":   # renkli yüz, beyaz çizgi
        yuz = f'<linearGradient id="y" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{a}"/><stop offset="1" stop-color="{b}"/></linearGradient>'
        dolgu, cizgi, ic = "url(#y)", "#ffffff", "#ffffff"
        kenar = ""
    else:                    # koyu cam yüz, renkli (mor→turkuaz ya da hizmet rengi) çizgi
        ikinci = TURKUAZ if rol not in VURGU else b
        yuz = (f'<linearGradient id="y" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#241a38"/><stop offset="1" stop-color="{MURDUM}"/></linearGradient>'
               f'<linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{a}"/><stop offset="1" stop-color="{ikinci}"/></linearGradient>'
               f'<linearGradient id="r" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{a}" stop-opacity=".9"/><stop offset="1" stop-color="{a}" stop-opacity=".15"/></linearGradient>')
        dolgu, cizgi, ic = "url(#y)", "url(#g)", "url(#g)"
        kenar = '<rect x="58" y="58" width="908" height="908" rx="236" fill="none" stroke="url(#r)" stroke-width="10"/>'
    parcalar = []
    for tur, yol, *ayar in GLIFLER[rol]:
        if tur == "c":
            kalinlik, uc = (ayar + [58, "round"])[:2] if ayar else (58, "round")
            parcalar.append(f'<path d="{yol}" fill="none" stroke="{cizgi}" stroke-width="{kalinlik}" stroke-linecap="{uc}" stroke-linejoin="round"/>')
        elif tur == "d":
            parcalar.append(f'<path d="{yol}" fill="{ic}" fill-rule="evenodd"/>')
        else:  # "k": yüzün renginde delik / iç işaret
            parcalar.append(f'<path d="{yol}" fill="{"#7a3ff0" if gorunum == "light" and rol not in VURGU else (b if gorunum == "light" else MURDUM)}"/>')
    parlak = '<path d="M60 300 Q 60 60 300 60 H724 Q 964 60 964 300 V340 Q 512 250 60 400 Z" fill="#ffffff" opacity=".07"/>'
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024"><defs>{yuz}</defs>'
            f'<rect x="56" y="56" width="912" height="912" rx="238" fill="{dolgu}"/>{parlak}{kenar}{"".join(parcalar)}</svg>\n')


def isik(boyut, cx, cy, r, renk, guc):
    """Yumuşak renk ışığı katmanı (RGB float)."""
    h, w = boyut
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    k = np.exp(-(((x - cx) / r) ** 2 + ((y - cy) / (r * 0.62)) ** 2)) * guc
    return k[..., None] * np.array(renk, dtype=np.float32)[None, None, :]


def duvar(koyu):
    w, h = 2560, 1440
    taban = np.array([10, 7, 18] if koyu else [238, 234, 247], dtype=np.float32)
    a = np.ones((h, w, 3), np.float32) * taban
    isiklar = [(w * 0.18, h * 0.22, 900, (139, 92, 246), 0.85), (w * 0.86, h * 0.78, 1000, (45, 212, 191), 0.55),
               (w * 0.62, h * 0.12, 700, (91, 43, 224), 0.6), (w * 0.3, h * 0.95, 800, (236, 72, 153), 0.25)]
    for cx, cy, r, renk, guc in isiklar:
        katman = isik((h, w), cx, cy, r, renk, guc if koyu else guc * 0.8)
        a = a + katman if koyu else a - (255 - np.array(renk, np.float32)) * (katman / 255) * 1.35
    # ARC'ın imzası: ufka akan yol çizgileri (perspektif)
    y, x = np.mgrid[0:h, 0:w].astype(np.float32)
    ufuk = h * 0.42
    alt = np.clip((y - ufuk) / (h - ufuk), 0, 1)
    for s in (-1.6, -0.55, 0.55, 1.6):
        cizgi_x = w / 2 + s * 520 * alt
        yakin = np.exp(-((x - cizgi_x) / (2 + 6 * alt)) ** 2) * alt ** 1.4
        a += yakin[..., None] * (np.array([196, 168, 255], np.float32) if koyu else -np.array([90, 110, 40], np.float32)) * 0.55
    # ince ızgara, alta doğru sönen
    izgara = ((x % 96 < 1.2) | (y % 96 < 1.2)).astype(np.float32) * np.clip(1 - y / h, 0, 1) * (10 if koyu else -8)
    a += izgara[..., None]
    a += np.random.default_rng(7).normal(0, 2.2, a.shape).astype(np.float32)  # hafif kumlanma, bant oluşmasın
    img = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(0.6))
    img.save(DUVAR / ("arc.dark.jpg" if koyu else "arc.jpg"), quality=90, optimize=True)


if __name__ == "__main__":
    for rol in GLIFLER:
        for gorunum in ("light", "dark"):
            (IKON / f"{rol}.{gorunum}.svg").write_text(ikon(rol, gorunum), encoding="utf-8")
    duvar(True)
    duvar(False)
    print("ikonlar ve duvar kâğıtları üretildi")
