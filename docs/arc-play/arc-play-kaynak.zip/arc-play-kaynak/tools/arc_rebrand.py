"""ARC Play: WestPlay 2.0.3 (enes-less, GPL-3.0-or-later) kaynağını ARC adına çevirir.

Kurallar (yalnız bütün adlar değişir; harita yönü olan "west" / "Western" / "Westbound" dokunulmaz):
  WESTPLAY -> ARCPLAY, Westplay -> Arcplay, westplay -> arcplay      (sabitler, crate / dosya / dll adları)
  WestPlayXxx / xxxWestPlay                -> ArcPlay...             (kod tanımlayıcıları)
  WestPlay (tek başına)                    -> "ARC Play"             (kullanıcının gördüğü ad)
Korunanlar: orijinal deponun ve yazarın bağlantıları (github.com/enes-less/WestPlay, kreosus.com/enes-less),
LICENSE ve üçüncü taraf lisans dosyaları (GPL: telif bildirimleri değiştirilmez).
Çalıştırma: python tools/arc_rebrand.py   (depo kökünden). İkinci kez çalıştırmak bir şey değiştirmez.
"""
import re
import sys
from pathlib import Path

KOK = Path(__file__).resolve().parent.parent
ATLA_KLASOR = {".git", "node_modules", "target", "dist"}
ATLA_DOSYA = {"LICENSE", "THIRD_PARTY_LICENSES.md", "THIRD_PARTY_NOTICES.md", "arc_rebrand.py", "sdk_license.txt"}
KORU = re.compile(r"github\.com/enes-less/WestPlay[^\s\"')\]>]*|kreosus\.com/enes-less")


def cevir(metin):
    korunan = []

    def sakla(m):
        korunan.append(m.group(0))
        return f"\x00{len(korunan) - 1}\x00"

    metin = KORU.sub(sakla, metin)
    metin = metin.replace("WESTPLAY", "ARCPLAY").replace("Westplay", "Arcplay").replace("westplay", "arcplay")
    metin = re.sub(r"(?<=[A-Za-z0-9_])WestPlay|WestPlay(?=[A-Z0-9_])", "ArcPlay", metin)
    metin = metin.replace("WestPlay", "ARC Play")
    return re.sub(r"\x00(\d+)\x00", lambda m: korunan[int(m.group(1))], metin)


def main():
    degisen = 0
    for yol in KOK.rglob("*"):
        if not yol.is_file() or ATLA_KLASOR & set(yol.relative_to(KOK).parts) or yol.name in ATLA_DOSYA:
            continue
        try:
            eski = yol.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue  # ikili dosya
        yeni = cevir(eski)
        if yeni != eski:
            yol.write_text(yeni, encoding="utf-8", newline="")
            degisen += 1
    # dosya / klasör adları (derinden yüzeye)
    for yol in sorted(KOK.rglob("*"), key=lambda p: -len(p.parts)):
        if ATLA_KLASOR & set(yol.relative_to(KOK).parts) or "west" not in yol.name.lower():
            continue
        yeni_ad = cevir(yol.name)
        if yeni_ad != yol.name:
            yol.rename(yol.with_name(yeni_ad))
            print("yeniden adlandırıldı:", yol.relative_to(KOK), "->", yeni_ad)
    print(f"{degisen} dosyanın içeriği değişti")


if __name__ == "__main__":
    assert cevir("WestPlay'e github.com/enes-less/WestPlay/releases") == "ARC Play'e github.com/enes-less/WestPlay/releases"
    assert cevir("westplay_host WestPlayIntro WESTPLAY_UI setWestplayOpen is_westplay") == \
        "arcplay_host ArcPlayIntro ARCPLAY_UI setArcplayOpen is_arcplay"
    assert cevir("north-west Western Westbound west") == "north-west Western Westbound west"
    sys.exit(main())
