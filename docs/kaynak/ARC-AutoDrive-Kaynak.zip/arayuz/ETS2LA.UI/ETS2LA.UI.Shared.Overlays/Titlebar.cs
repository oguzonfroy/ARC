using System;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using ETS2LA.Game.Telemetry;
using ETS2LA.State;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;

namespace ETS2LA.UI.Shared.Overlays;

public class Titlebar : ComponentBase, IDisposable
{
	private ElementReference titlebarRef;

	private Timer? zamanlayici;

	private string onceki = "";

	private static readonly string Surum = "v" + (Assembly.GetEntryAssembly()?.GetName().Version?.ToString(3) ?? "?");

	private static bool OyunBagli
	{
		get
		{
			if (ApplicationState.Current.IsGameRunning)
			{
				return GameTelemetry.Current.GetCurrentData().sdkActive;
			}
			return false;
		}
	}

	private static string OyunAdi
	{
		get
		{
			string text = ApplicationState.Current.RunningGameType?.ToString();
			if (text == null)
			{
				return "Oyun";
			}
			if (!text.Contains("American", StringComparison.OrdinalIgnoreCase))
			{
				return "ETS2";
			}
			return "ATS";
		}
	}

	[Inject]
	private IJSRuntime JS { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "header");
		__builder.AddAttribute(1, "class", "kp-ust select-none");
		__builder.AddElementReferenceCapture(2, (ElementReference __value) =>
		{
			titlebarRef = __value;
		});
		__builder.OpenElement(3, "div");
		__builder.AddAttribute(4, "class", "kp-marka");
		__builder.AddMarkupContent(5, "<div class=\"kp-logo\"><img src=\"arc-logo.png\" alt=\"ARC\"></div>\r\n        ");
		__builder.OpenElement(6, "div");
		__builder.AddAttribute(7, "class", "flex flex-col min-w-0");
		__builder.AddMarkupContent(8, "<span class=\"kp-marka-ad\">ARC</span>\r\n            ");
		__builder.OpenElement(9, "span");
		__builder.AddAttribute(10, "class", "kp-marka-alt");
		__builder.AddMarkupContent(11, "ETS2 Auto Drive · ");
		__builder.AddContent(12, Surum);
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(13, "\r\n\r\n    ");
		__builder.OpenElement(14, "div");
		__builder.AddAttribute(15, "class", "kp-durumlar");
		__builder.OpenElement(16, "span");
		__builder.AddAttribute(17, "class", "kp-hap");
		__builder.AddAttribute(18, "title", "Oyun bağlantısı");
		__builder.OpenElement(19, "span");
		__builder.AddAttribute(20, "class", "kp-nokta" + (OyunBagli ? " iyi" : " uyari"));
		__builder.CloseElement();
		__builder.AddMarkupContent(21, "\r\n            ");
		__builder.AddContent(22, OyunBagli ? (OyunAdi + " bağlı") : "Oyun bekleniyor");
		__builder.CloseElement();
		__builder.AddMarkupContent(23, "\r\n        ");
		__builder.OpenElement(24, "span");
		__builder.AddAttribute(25, "class", "kp-hap");
		__builder.AddAttribute(26, "title", "Otonom sürüş");
		__builder.OpenElement(27, "span");
		__builder.AddAttribute(28, "class", "kp-nokta" + (ApplicationState.Current.EnableAssists ? " iyi canli" : ""));
		__builder.CloseElement();
		__builder.AddMarkupContent(29, "\r\n            Otopilot ");
		__builder.AddContent(30, ApplicationState.Current.EnableAssists ? "aktif" : "hazır");
		__builder.CloseElement();
		__builder.AddMarkupContent(31, "\r\n        ");
		__builder.OpenElement(32, "span");
		__builder.AddAttribute(33, "class", "kp-hap kp-saat");
		__builder.AddContent(34, DateTime.Now.ToString("HH:mm"));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(35, "\r\n\r\n    ");
		__builder.OpenElement(36, "div");
		__builder.AddAttribute(37, "class", "kp-pencere-dugmeleri titlebar-no-drag");
		__builder.OpenElement(38, "button");
		__builder.AddAttribute(39, "class", "kp-pd");
		__builder.AddAttribute(40, "title", "Küçült");
		__builder.AddAttribute(41, "aria-label", "Küçült");
		__builder.AddAttribute(42, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () => SendMessage("window:minimize")));
		__builder.AddMarkupContent(43, "<svg width=\"14\" height=\"14\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"><path d=\"M6 12h12\"></path></svg>");
		__builder.CloseElement();
		__builder.AddMarkupContent(44, "\r\n        ");
		__builder.OpenElement(45, "button");
		__builder.AddAttribute(46, "class", "kp-pd");
		__builder.AddAttribute(47, "title", "Büyüt");
		__builder.AddAttribute(48, "aria-label", "Büyüt");
		__builder.AddAttribute(49, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () => SendMessage("window:maximize")));
		__builder.AddMarkupContent(50, "<svg width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"><rect x=\"5\" y=\"5\" width=\"14\" height=\"14\" rx=\"3\"></rect></svg>");
		__builder.CloseElement();
		__builder.AddMarkupContent(51, "\r\n        ");
		__builder.OpenElement(52, "button");
		__builder.AddAttribute(53, "class", "kp-pd kapat");
		__builder.AddAttribute(54, "title", "Kapat");
		__builder.AddAttribute(55, "aria-label", "Kapat");
		__builder.AddAttribute(56, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () => SendMessage("window:close")));
		__builder.AddMarkupContent(57, "<svg width=\"14\" height=\"14\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"><path d=\"M7 7l10 10M17 7L7 17\"></path></svg>");
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		zamanlayici = new Timer((object? _) =>
		{
			string text = $"{DateTime.Now:HH:mm}|{OyunBagli}|{ApplicationState.Current.EnableAssists}";
			if (!(text == onceki))
			{
				onceki = text;
				InvokeAsync((Action)StateHasChanged);
			}
		}, null, 0, 1000);
	}

	protected override async Task OnAfterRenderAsync(bool firstRender)
	{
		if (firstRender)
		{
			await JS.InvokeVoidAsync("initTitlebarDrag", titlebarRef);
		}
	}

	private async Task SendMessage(string msg)
	{
		await JS.InvokeVoidAsync("sendIPCMessage", msg);
	}

	public void Dispose()
	{
		zamanlayici?.Dispose();
	}
}
