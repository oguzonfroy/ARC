using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ETS2LA.Notifications;
using ETS2LA.UI.Shared.Components;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.JSInterop;

namespace ETS2LA.UI.Shared.Overlays;

public class Notifications : ComponentBase
{
	private List<ETS2LA.Notifications.Notification> notifications = new List<ETS2LA.Notifications.Notification>();

	private Dictionary<string, bool> notificationExitingStates = new Dictionary<string, bool>();

	[Inject]
	private IJSRuntime JS { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "fixed bottom-4 right-4 z-[9999] flex flex-col w-[300px] max-h-[calc(100vh-20px)] overflow-y-auto overflow-x-hidden pointer-events-none");
		foreach (ETS2LA.Notifications.Notification notification in notifications)
		{
			bool flag = notificationExitingStates.TryGetValue(notification.Id, out var value) & value;
			__builder.OpenElement(2, "div");
			__builder.AddAttribute(3, "class", "notification-anim-wrapper pointer-events-none justify-items-end justify-end " + (flag ? "exiting" : ""));
			__builder.SetKey(notification.Id);
			__builder.OpenElement(4, "div");
			__builder.AddAttribute(5, "class", "pointer-events-none");
			__builder.OpenElement(6, "div");
			__builder.AddAttribute(7, "class", "notification-anim-content pointer-events-none");
			__builder.OpenComponent<ETS2LA.UI.Shared.Components.Notification>(8);
			__builder.AddComponentParameter(9, "Id", RuntimeHelpers.TypeCheck(notification.Id));
			__builder.AddComponentParameter(10, "Title", RuntimeHelpers.TypeCheck(notification.Title));
			__builder.AddComponentParameter(11, "Content", RuntimeHelpers.TypeCheck(notification.Content));
			__builder.AddComponentParameter(12, "Level", RuntimeHelpers.TypeCheck(notification.Level));
			__builder.AddComponentParameter(13, "Progress", RuntimeHelpers.TypeCheck(notification.Progress));
			__builder.AddComponentParameter(14, "Indeterminate", RuntimeHelpers.TypeCheck(notification.IsProgressIndeterminate));
			__builder.AddComponentParameter(15, "Actions", RuntimeHelpers.TypeCheck(notification.Actions));
			__builder.AddComponentParameter(16, "IsExiting", RuntimeHelpers.TypeCheck(flag));
			__builder.CloseComponent();
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.CloseElement();
		}
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		NotificationHandler.Current.OnNotificationAdded += HandleNotificationAdded;
		NotificationHandler.Current.OnNotificationRemoved += HandleNotificationRemoved;
		NotificationHandler.Current.OnNotificationUpdated += HandleNotificationUpdated;
	}

	protected override async Task OnAfterRenderAsync(bool firstRender)
	{
		if (firstRender)
		{
			await JS.InvokeVoidAsync("initNotificationHover");
		}
	}

	private void HandleNotificationAdded(object? sender, ETS2LA.Notifications.Notification notification)
	{
		InvokeAsync(() =>
		{
			if (notifications.Any((ETS2LA.Notifications.Notification n) => n.Id == notification.Id))
			{
				HandleNotificationUpdated(sender, notification);
			}
			else
			{
				notificationExitingStates[notification.Id] = false;
				notifications.Insert(0, notification);
				StateHasChanged();
			}
		});
	}

	private void HandleNotificationRemoved(object? sender, string notificationId)
	{
		InvokeAsync(() =>
		{
			ETS2LA.Notifications.Notification notification = notifications.FirstOrDefault((ETS2LA.Notifications.Notification n) => n.Id == notificationId);
			if (notification != null)
			{
				notificationExitingStates[notificationId] = true;
				StateHasChanged();
				Task.Delay(300).ContinueWith((Task _) =>
				{
					InvokeAsync(() =>
					{
						notifications.Remove(notification);
						notificationExitingStates.Remove(notificationId);
						StateHasChanged();
					});
				});
			}
		});
	}

	private void HandleNotificationUpdated(object? sender, ETS2LA.Notifications.Notification notification)
	{
		InvokeAsync(() =>
		{
			int num = notifications.FindIndex((ETS2LA.Notifications.Notification n) => n.Id == notification.Id);
			if (num != -1)
			{
				notifications[num] = notification;
				StateHasChanged();
			}
			else
			{
				notificationExitingStates[notification.Id] = false;
				notifications.Insert(0, notification);
				StateHasChanged();
			}
		});
	}

	public void Dispose()
	{
		NotificationHandler.Current.OnNotificationAdded -= HandleNotificationAdded;
		NotificationHandler.Current.OnNotificationRemoved -= HandleNotificationRemoved;
		NotificationHandler.Current.OnNotificationUpdated -= HandleNotificationUpdated;
	}
}
