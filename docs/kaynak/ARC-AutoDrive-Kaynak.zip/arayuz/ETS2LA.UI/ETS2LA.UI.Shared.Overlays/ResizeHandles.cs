using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.JSInterop;

namespace ETS2LA.UI.Shared.Overlays;

public class ResizeHandles : ComponentBase
{
	[Inject]
	private IJSRuntime JS { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.AddMarkupContent(0, "<div class=\"resize-handle e\" onmousedown=\"window.startResize(event, 'e')\"></div>\n<div class=\"resize-handle s\" onmousedown=\"window.startResize(event, 's')\"></div>\n<div class=\"resize-handle se\" onmousedown=\"window.startResize(event, 'se')\"></div>\n\n");
		__builder.AddMarkupContent(1, "<style>\n  .resize-handle {\n    position: fixed;\n    z-index: 9999;\n  }\n\n  .e {\n    top: 36px;\n    right: 0;\n    width: 6px;\n    height: 100%;\n    cursor: e-resize;\n  }\n\n  .s {\n    bottom: 0;\n    left: 0;\n    width: 100%;\n    height: 6px;\n    cursor: s-resize;\n  }\n\n  .se {\n    bottom: 0;\n    right: 0;\n    width: 12px;\n    height: 12px;\n    cursor: se-resize;\n  }\n</style>");
	}

	protected override async Task OnAfterRenderAsync(bool firstRender)
	{
		if (firstRender)
		{
			await JS.InvokeVoidAsync("initResizing", null);
		}
	}
}
