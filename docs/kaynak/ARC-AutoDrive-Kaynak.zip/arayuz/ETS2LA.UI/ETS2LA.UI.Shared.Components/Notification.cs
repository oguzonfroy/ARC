using System.Collections.Generic;
using ETS2LA.Notifications;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Shared.Components;

public class Notification : ComponentBase
{
	[Parameter]
	public string Id { get; set; } = string.Empty;

	[Parameter]
	public string Title { get; set; } = string.Empty;

	[Parameter]
	public string Content { get; set; } = string.Empty;

	[Parameter]
	public NotificationLevel Level { get; set; }

	[Parameter]
	public float Progress { get; set; }

	[Parameter]
	public bool Indeterminate { get; set; }

	[Parameter]
	public List<NotificationAction> Actions { get; set; } = new List<NotificationAction>();

	[Parameter]
	public bool IsExiting { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "key", Id);
		__builder.AddAttribute(2, "data-notification-hover-target");
		__builder.AddAttribute(3, "class", "pointer-events-auto flex flex-col w-fit min-w-60 max-w-[300px] gap-0 rounded-md shadow-md bg-control-bg-dark border border-border text-text transition-all duration-300 " + (IsExiting ? "animate-out fade-out slide-out-to-right-5" : "animate-in fade-in slide-in-from-right-10 zoom-in-80"));
		__builder.OpenElement(4, "div");
		__builder.AddAttribute(5, "class", "flex flex-col gap-1 p-3");
		__builder.OpenElement(6, "div");
		__builder.AddAttribute(7, "class", "flex items-center justify-between gap-2.5");
		__builder.OpenElement(8, "div");
		__builder.AddAttribute(9, "class", "flex items-center gap-2");
		if (Level == NotificationLevel.Success)
		{
			__builder.AddMarkupContent(10, "<div class=\"text-[16px]\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1em\" height=\"1em\" viewBox=\"0 0 24 24\"><path d=\"M0 0h24v24H0z\" fill=\"none\"></path>\n                            <path fill=\"none\" stroke=\"currentColor\" stroke-dasharray=\"26\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M5 11l6 6l10 -10\"><animate fill=\"freeze\" attributeName=\"stroke-dashoffset\" dur=\"0.6s\" values=\"26;0\"></animate></path></svg></div>");
		}
		if (Level == NotificationLevel.Warning)
		{
			__builder.AddMarkupContent(11, "<div class=\"text-[16px]\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1em\" height=\"1em\" viewBox=\"0 0 24 24\"><path d=\"M0 0h24v24H0z\" fill=\"none\"></path>\n                            <g fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\"><path stroke-dasharray=\"60\" d=\"M12 3l9 17h-18l9 -17Z\"><animate fill=\"freeze\" attributeName=\"stroke-dashoffset\" dur=\"0.6s\" values=\"60;0\"></animate></path>\n                                <path stroke-dasharray=\"6\" stroke-dashoffset=\"6\" d=\"M12 10v4\"><animate fill=\"freeze\" attributeName=\"stroke-dashoffset\" begin=\"0.7s\" dur=\"0.2s\" to=\"0\"></animate></path>\n                                <path stroke-dasharray=\"4\" stroke-dashoffset=\"4\" d=\"M12 17v0.01\"><animate fill=\"freeze\" attributeName=\"stroke-dashoffset\" begin=\"0.7s\" dur=\"0.2s\" to=\"0\"></animate></path></g></svg></div>");
		}
		if (Level == NotificationLevel.Danger)
		{
			__builder.AddMarkupContent(12, "<div class=\"text-[16px]\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1em\" height=\"1em\" viewBox=\"0 0 24 24\"><path d=\"M0 0h24v24H0z\" fill=\"none\"></path>\n                            <path fill=\"none\" stroke=\"currentColor\" stroke-dasharray=\"12\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M12 12l7 7M12 12l-7 -7M12 12l-7 7M12 12l7 -7\"><animate fill=\"freeze\" attributeName=\"stroke-dashoffset\" dur=\"0.4s\" values=\"12;0\"></animate></path></svg></div>");
		}
		__builder.OpenElement(13, "p");
		__builder.AddAttribute(14, "class", "font-semibold");
		__builder.AddContent(15, T.L(Title));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(16, "\n        ");
		__builder.OpenElement(17, "p");
		__builder.AddAttribute(18, "class", "description");
		__builder.AddContent(19, T.L(Content));
		__builder.CloseElement();
		__builder.CloseElement();
		if (Actions != null && Actions.Count > 0)
		{
			__builder.OpenElement(20, "div");
			__builder.AddAttribute(21, "class", "flex flex-col gap-1 -mt-1");
			foreach (NotificationAction action in Actions)
			{
				__builder.OpenElement(22, "button");
				__builder.AddAttribute(23, "type", "button button-small");
				__builder.AddAttribute(24, "class", "w-full px-3 py-1.5 text-left description hover:bg-control/50 hover:text-text transition-colors cursor-pointer");
				__builder.AddAttribute(25, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
				{
					action.Action?.Invoke();
					NotificationHandler.Current.CloseNotification(Title);
				}));
				__builder.AddContent(26, action.Label);
				__builder.CloseElement();
			}
			if (Progress <= 0f && !Indeterminate)
			{
				__builder.AddMarkupContent(27, "<div class=\"h-1\"><p></p></div>");
			}
			__builder.CloseElement();
		}
		if (Progress > 0f || Indeterminate)
		{
			__builder.OpenElement(28, "div");
			__builder.AddAttribute(29, "class", "relative w-full h-1 overflow-hidden rounded-b-md border-l border-r border-border");
			if (Indeterminate)
			{
				__builder.AddMarkupContent(30, "<div class=\"absolute inset-y-0 bg-accent-dark w-1/3 animate-indeterminate rounded-sm\"></div>");
			}
			else
			{
				__builder.OpenElement(31, "div");
				__builder.AddAttribute(32, "class", "h-full bg-accent transition-all duration-300 ease-in-out");
				__builder.AddAttribute(33, "style", $"width: {Progress}%;");
				__builder.CloseElement();
			}
			__builder.CloseElement();
		}
		__builder.CloseElement();
	}
}
