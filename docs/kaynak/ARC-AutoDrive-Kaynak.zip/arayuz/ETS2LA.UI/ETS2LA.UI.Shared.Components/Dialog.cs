using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Shared.Components;

public class Dialog : ComponentBase
{
	[Parameter]
	public bool Open { get; set; }

	[Parameter]
	public EventCallback<bool> OpenChanged { get; set; }

	[Parameter]
	public RenderFragment? ChildContent { get; set; }

	[Parameter]
	public string Class { get; set; } = string.Empty;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		if (Open)
		{
			__builder.OpenElement(0, "div");
			__builder.AddAttribute(1, "class", "fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4");
			__builder.AddAttribute(2, "role", "presentation");
			__builder.AddAttribute(3, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Func<Task>)Close));
			__builder.OpenElement(4, "div");
			__builder.AddAttribute(5, "class", "w-full max-w-lg rounded-md border border-border bg-bg p-4 shadow-lg " + Class);
			__builder.AddAttribute(6, "role", "dialog");
			__builder.AddAttribute(7, "aria-modal", "true");
			__builder.AddEventStopPropagationAttribute(8, "onclick", value: true);
			__builder.AddContent(9, ChildContent);
			__builder.CloseElement();
			__builder.CloseElement();
		}
	}

	private async Task Close()
	{
		if (OpenChanged.HasDelegate)
		{
			await OpenChanged.InvokeAsync(arg: false);
		}
		else
		{
			Open = false;
		}
	}
}
