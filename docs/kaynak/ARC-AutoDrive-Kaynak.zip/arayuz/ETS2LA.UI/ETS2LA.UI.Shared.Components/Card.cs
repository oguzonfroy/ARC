using System;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Shared.Components;

public class Card : ComponentBase
{
	[Parameter]
	public string? Title { get; set; } = string.Empty;

	[Parameter]
	public string? Subtitle { get; set; } = string.Empty;

	[Parameter]
	public EventCallback? OnSubtitleClick { get; set; }

	[Parameter]
	public RenderFragment? ChildContent { get; set; }

	[Parameter]
	public string Class { get; set; } = string.Empty;

	[Parameter]
	public string ContainerClass { get; set; } = string.Empty;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full gap-2 " + ContainerClass);
		if (!string.IsNullOrEmpty(Title) || !string.IsNullOrEmpty(Subtitle))
		{
			__builder.OpenElement(2, "div");
			__builder.AddAttribute(3, "class", "flex mx-4 justify-between items-center");
			__builder.OpenElement(4, "div");
			__builder.AddAttribute(5, "class", "flex flex-col gap-1");
			if (!string.IsNullOrEmpty(Title))
			{
				__builder.OpenElement(6, "p");
				__builder.AddAttribute(7, "class", "font-semibold description");
				__builder.AddContent(8, T.L(Title));
				__builder.CloseElement();
			}
			if (!string.IsNullOrEmpty(Subtitle))
			{
				__builder.OpenElement(9, "p");
				__builder.AddAttribute(10, "class", "font-semibold description transition-colors " + (OnSubtitleClick.HasValue ? "hover:text-text-l hover:underline" : ""));
				__builder.AddAttribute(11, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)OnSubtitleClickInvoke));
				__builder.AddContent(12, Subtitle);
				__builder.CloseElement();
			}
			__builder.CloseElement();
			__builder.CloseElement();
		}
		__builder.OpenElement(13, "div");
		__builder.AddAttribute(14, "class", "flex flex-col w-full bg-control-bg-dark border p-4 gap-6 transition-all border-bg-darker rounded-sm " + Class);
		__builder.AddContent(15, ChildContent);
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private void OnSubtitleClickInvoke()
	{
		if (OnSubtitleClick.HasValue)
		{
			OnSubtitleClick.Value.InvokeAsync();
		}
	}
}
