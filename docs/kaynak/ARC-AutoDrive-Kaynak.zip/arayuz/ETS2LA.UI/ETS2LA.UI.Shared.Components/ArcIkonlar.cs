using System.Collections.Generic;
using Microsoft.AspNetCore.Components;

namespace ETS2LA.UI.Shared.Components;

public static class ArcIkonlar
{
	private static readonly Dictionary<string, string> Yollar = new Dictionary<string, string>
	{
		["gosterge"] = "<path d='M4 17a8 8 0 1 1 16 0'/><path d='M12 17l4.2-5.2'/><circle cx='12' cy='17' r='1.4'/>",
		["gorsel"] = "<path d='M4 8V5.5A1.5 1.5 0 0 1 5.5 4H8M16 4h2.5A1.5 1.5 0 0 1 20 5.5V8M20 16v2.5a1.5 1.5 0 0 1-1.5 1.5H16M8 20H5.5A1.5 1.5 0 0 1 4 18.5V16'/><path d='M10 16.5l1-9M14 16.5l-1-9'/>",
		["baslat"] = "<circle cx='12' cy='12' r='8.5'/><path d='M10.2 8.8l5 3.2-5 3.2z'/>",
		["kurulum"] = "<path d='M12 6.5C10 5 7 4.5 4 5v13c3-.5 6 0 8 1.5 2-1.5 5-2 8-1.5V5c-3-.5-6 0-8 1.5z'/><path d='M12 6.5v13'/>",
		["iletisim"] = "<path d='M5 5h14a1.5 1.5 0 0 1 1.5 1.5v8A1.5 1.5 0 0 1 19 16h-7l-4 3.5V16H5a1.5 1.5 0 0 1-1.5-1.5v-8A1.5 1.5 0 0 1 5 5z'/>",
		["ayarlar"] = "<path d='M4 7h9M17 7h3M4 17h3M11 17h9'/><circle cx='15' cy='7' r='2'/><circle cx='9' cy='17' r='2'/>",
		["degistir"] = "<path d='M5 9h13l-3.5-3.5M19 15H6l3.5 3.5'/>"
	};

	public static MarkupString Svg(string anahtar)
	{
		return new MarkupString("<svg viewBox='0 0 24 24' width='18' height='18' fill='none' stroke='currentColor' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round' aria-hidden='true'>" + Yollar.GetValueOrDefault(anahtar, "") + "</svg>");
	}
}
