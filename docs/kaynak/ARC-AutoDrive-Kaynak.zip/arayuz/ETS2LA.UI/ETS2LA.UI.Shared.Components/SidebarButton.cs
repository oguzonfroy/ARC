using System;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Routing;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Shared.Components;

public class SidebarButton : ComponentBase, IDisposable
{
	[Parameter]
	[EditorRequired]
	public string Name { get; set; } = string.Empty;

	[Parameter]
	[EditorRequired]
	public string Path { get; set; } = string.Empty;

	[Parameter]
	public NavLinkMatch Match { get; set; }

	[Parameter]
	public bool PreventDefault { get; set; } = true;

	[Parameter]
	public string Icon { get; set; } = string.Empty;

	[Inject]
	private NavigationManager Navigation { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenComponent<NavLink>(0);
		__builder.AddComponentParameter(1, "href", Path);
		__builder.AddComponentParameter(2, "class", GetButtonClass());
		__builder.AddComponentParameter(3, "Match", RuntimeHelpers.TypeCheck(Match));
		__builder.AddComponentParameter(4, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)Navigate));
		__builder.AddAttribute(5, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder) =>
		{
			if (!string.IsNullOrEmpty(Icon))
			{
				renderTreeBuilder.OpenElement(6, "span");
				renderTreeBuilder.AddAttribute(7, "class", "arc-nav-ikon");
				renderTreeBuilder.AddContent(8, ArcIkonlar.Svg(Icon));
				renderTreeBuilder.CloseElement();
			}
			renderTreeBuilder.OpenElement(9, "span");
			renderTreeBuilder.AddAttribute(10, "class", "arc-nav-ad");
			renderTreeBuilder.AddContent(11, Name);
			renderTreeBuilder.CloseElement();
		}));
		__builder.CloseComponent();
	}

	protected override void OnInitialized()
	{
		Navigation.LocationChanged += OnLocationChanged;
	}

	private void OnLocationChanged(object? sender, LocationChangedEventArgs e)
	{
		InvokeAsync((Action)StateHasChanged);
	}

	private void Navigate()
	{
		Navigation.NavigateTo(Path);
	}

	private string GetButtonClass()
	{
		string text = "arc-nav";
		string text2 = Navigation.ToBaseRelativePath(Navigation.Uri);
		string text3 = Path.TrimStart('/');
		bool flag = false;
		bool num;
		if (string.IsNullOrEmpty(text3))
		{
			num = string.IsNullOrEmpty(text2);
		}
		else
		{
			if (text2.Equals(text3, StringComparison.OrdinalIgnoreCase))
			{
				goto IL_0060;
			}
			num = text2.StartsWith(text3 + "/", StringComparison.OrdinalIgnoreCase);
		}
		if (!num)
		{
			return text;
		}
		goto IL_0060;
		IL_0060:
		return text + " aktif";
	}

	public void Dispose()
	{
		Navigation.LocationChanged -= OnLocationChanged;
	}
}
