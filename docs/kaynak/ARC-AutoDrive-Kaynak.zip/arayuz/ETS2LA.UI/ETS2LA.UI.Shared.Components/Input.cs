using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Shared.Components;

public class Input : ComponentBase
{
	[Parameter]
	[EditorRequired]
	public string Title { get; set; } = string.Empty;

	[Parameter]
	[EditorRequired]
	public string Description { get; set; } = string.Empty;

	[Parameter]
	public string Value { get; set; } = string.Empty;

	[Parameter]
	public EventCallback<string> ValueChanged { get; set; }

	[Parameter]
	public string Type { get; set; } = "text";

	[Parameter]
	public string Placeholder { get; set; } = string.Empty;

	[Parameter]
	public bool Disabled { get; set; }

	[Parameter]
	public string Class { get; set; } = string.Empty;

	[Parameter(CaptureUnmatchedValues = true)]
	public IReadOnlyDictionary<string, object> AdditionalAttributes { get; set; } = new Dictionary<string, object>();

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col gap-2 " + Class);
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex flex-col");
		__builder.OpenElement(4, "p");
		__builder.AddContent(5, T.L(Title));
		__builder.CloseElement();
		__builder.AddMarkupContent(6, "\n        ");
		__builder.OpenElement(7, "p");
		__builder.AddAttribute(8, "class", "description");
		__builder.AddContent(9, T.L(Description));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(10, "\n\n    ");
		__builder.OpenElement(11, "input");
		__builder.AddAttribute(12, "type", Type);
		__builder.AddAttribute(13, "value", Value);
		__builder.AddAttribute(14, "placeholder", Placeholder);
		__builder.AddAttribute(15, "disabled", Disabled);
		__builder.AddAttribute(16, "class", "w-full h-11 px-4 rounded-md bg-control-bg border border-control-bg focus:outline-none focus:ring-1 focus:ring-accent focus:ring-offset-1 focus:ring-offset-control");
		__builder.AddAttribute(17, "oninput", EventCallback.Factory.Create((object)this, (Func<ChangeEventArgs, Task>)UpdateValue));
		__builder.AddMultipleAttributes(18, RuntimeHelpers.TypeCheck((IEnumerable<KeyValuePair<string, object>>)AdditionalAttributes));
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private async Task UpdateValue(ChangeEventArgs args)
	{
		if (!Disabled)
		{
			Value = args.Value?.ToString() ?? string.Empty;
			await ValueChanged.InvokeAsync(Value);
		}
	}
}
