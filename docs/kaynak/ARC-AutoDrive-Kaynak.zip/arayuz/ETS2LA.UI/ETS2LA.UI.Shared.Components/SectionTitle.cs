using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Shared.Components;

public class SectionTitle : ComponentBase
{
	[Parameter]
	public string Class { get; set; } = string.Empty;

	[Parameter]
	public string Title { get; set; } = string.Empty;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "p");
		__builder.AddAttribute(1, "class", "description flex items-center gap-2 after:flex-1 after:h-[2px] after:content-[''] after:opacity-20 after:bg-[radial-gradient(circle_at_center,var(--color-description)_1px,transparent_1px)] after:bg-[length:16px_2px] " + Class);
		__builder.AddContent(2, T.L(Title));
		__builder.CloseElement();
	}
}
