using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Shared.Components;

public class OTP : ComponentBase
{
	private readonly List<ElementReference> inputReferences = new List<ElementReference>();

	[Parameter]
	[EditorRequired]
	public string Title { get; set; } = string.Empty;

	[Parameter]
	[EditorRequired]
	public string Description { get; set; } = string.Empty;

	[Parameter]
	public int Length { get; set; } = 6;

	[Parameter]
	public int DashIndex { get; set; } = -1;

	[Parameter]
	public string Value { get; set; } = string.Empty;

	[Parameter]
	public EventCallback<string> ValueChanged { get; set; }

	[Parameter]
	public EventCallback<string> OnComplete { get; set; }

	[Parameter]
	public bool Disabled { get; set; }

	[Parameter]
	public string Class { get; set; } = string.Empty;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col gap-2 " + Class);
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex flex-col");
		__builder.OpenElement(4, "p");
		__builder.AddContent(5, Title);
		__builder.CloseElement();
		__builder.AddMarkupContent(6, "\n        ");
		__builder.OpenElement(7, "p");
		__builder.AddAttribute(8, "class", "description");
		__builder.AddContent(9, Description);
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(10, "\n\n    ");
		__builder.OpenElement(11, "div");
		__builder.AddAttribute(12, "class", "flex gap-2 items-center");
		for (int i = 0; i < Length; i++)
		{
			int index = i;
			if (DashIndex >= 0 && index == DashIndex)
			{
				__builder.AddMarkupContent(13, "<div class=\"size-1.5 mx-1 rounded-xs bg-control-bg\"></div>");
			}
			__builder.OpenElement(14, "input");
			__builder.AddAttribute(15, "type", "text");
			__builder.AddAttribute(16, "inputmode", "numeric");
			__builder.AddAttribute(17, "pattern", "[0-9]*");
			__builder.AddAttribute(18, "maxlength", "1");
			__builder.AddAttribute(19, "autocomplete", (index == 0) ? "one-time-code" : "off");
			__builder.AddAttribute(20, "value", GetDigit(index));
			__builder.AddAttribute(21, "disabled", Disabled);
			__builder.AddAttribute(22, "class", "w-11 h-11 rounded-md bg-control-bg border border-control-bg text-center focus:outline-none focus:ring-1 focus:ring-accent focus:ring-offset-1 focus:ring-offset-control");
			__builder.AddAttribute(23, "oninput", EventCallback.Factory.Create(this, (ChangeEventArgs args) => UpdateValue(index, args)));
			__builder.AddAttribute(24, "onkeydown", EventCallback.Factory.Create(this, (KeyboardEventArgs args) => HandleKeyDown(index, args)));
			__builder.AddElementReferenceCapture(25, (ElementReference __value) =>
			{
				inputReferences[index] = __value;
			});
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.CloseElement();
	}

	public OTP()
	{
		for (int i = 0; i < Length; i++)
		{
			inputReferences.Add(default);
		}
	}

	protected override void OnParametersSet()
	{
		Length = Math.Max(1, Length);
		Value = GetDigits(Value).Substring(0, Math.Min(Value.Length, Length));
	}

	private string GetDigits(string value)
	{
		return new string(value.Where(char.IsDigit).ToArray());
	}

	private string GetDigit(int index)
	{
		if (index >= Value.Length)
		{
			return string.Empty;
		}
		return Value[index].ToString();
	}

	private async Task UpdateValue(int index, ChangeEventArgs args)
	{
		if (!Disabled)
		{
			string digit = GetDigits(args.Value?.ToString() ?? string.Empty);
			string text = Value.PadRight(Length).Substring(0, Length);
			if (digit.Length > 0)
			{
				text = text.Remove(index, 1).Insert(index, digit.Substring(0, 1));
				text = text.TrimEnd();
			}
			else
			{
				text = text.Remove(index, 1).TrimEnd();
			}
			Value = text;
			await ValueChanged.InvokeAsync(Value);
			if (digit.Length > 0 && index < Length - 1)
			{
				await inputReferences[index + 1].FocusAsync();
			}
			if (Value.Length == Length)
			{
				await OnComplete.InvokeAsync(Value);
			}
		}
	}

	private async Task HandleKeyDown(int index, KeyboardEventArgs args)
	{
		if (!Disabled && !(args.Key != "Backspace") && index != 0 && GetDigit(index).Length <= 0)
		{
			await inputReferences[index - 1].FocusAsync();
		}
	}
}
