using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Shared.Components;

public class Listbox : ComponentBase
{
	[Parameter]
	[EditorRequired]
	public string Title { get; set; } = string.Empty;

	[Parameter]
	[EditorRequired]
	public string Description { get; set; } = string.Empty;

	[Parameter]
	public IReadOnlyList<string> Options { get; set; } = Array.Empty<string>();

	[Parameter]
	public int SelectedIndex { get; set; }

	[Parameter]
	public EventCallback<int> SelectedIndexChanged { get; set; }

	[Parameter]
	public EventCallback<int> OnSelect { get; set; }

	[Parameter]
	public bool Disabled { get; set; }

	[Parameter]
	public string Class { get; set; } = string.Empty;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex justify-between w-full items-center hover:bg-control-bg-dark " + Class);
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex gap-2 items-center");
		__builder.OpenElement(4, "p");
		__builder.AddContent(5, T.L(Title));
		__builder.CloseElement();
		if (!string.IsNullOrEmpty(Description))
		{
			__builder.OpenComponent<TooltipIcon>(6);
			__builder.AddComponentParameter(7, "Content", RuntimeHelpers.TypeCheck(Description));
			__builder.CloseComponent();
		}
		__builder.CloseElement();
		__builder.AddMarkupContent(8, "\n    ");
		__builder.OpenElement(9, "div");
		__builder.AddAttribute(10, "class", "flex gap-2 min-w-80");
		for (int i = 0; i < Options.Count; i++)
		{
			int index = i;
			bool flag = index == SelectedIndex;
			__builder.OpenElement(11, "button");
			__builder.AddAttribute(12, "type", "button");
			__builder.AddAttribute(13, "disabled", Disabled);
			__builder.AddAttribute(14, "class", "px-4 py-2 w-full cursor-pointer rounded-sm bg-control-bg description hover:bg-control/50 hover:text-text text-[14px] transition-colors " + (flag ? "text-text bg-accent-dark!" : ""));
			__builder.AddAttribute(15, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () => SelectOption(index)));
			__builder.AddContent(16, UserInterfaceUtils.ClassnameWithSpaces(Options[index]));
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private async Task SelectOption(int index)
	{
		if (!Disabled)
		{
			SelectedIndex = index;
			await SelectedIndexChanged.InvokeAsync(SelectedIndex);
			await OnSelect.InvokeAsync(SelectedIndex);
		}
	}
}
