using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Shared.Components;

public class SidebarGroupLabel : ComponentBase
{
	[Parameter]
	[EditorRequired]
	public string Title { get; set; } = string.Empty;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "p");
		__builder.AddAttribute(1, "class", "arc-grup");
		__builder.AddContent(2, Title);
		__builder.CloseElement();
	}
}
