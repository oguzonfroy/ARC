using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Shared.Components;

public class Dropdown : ComponentBase
{
	private bool isOpen;

	[Parameter]
	[EditorRequired]
	public string Title { get; set; } = string.Empty;

	[Parameter]
	[EditorRequired]
	public string Description { get; set; } = string.Empty;

	[Parameter]
	public IReadOnlyList<string> Options { get; set; } = Array.Empty<string>();

	[Parameter]
	public int SelectedIndex { get; set; }

	[Parameter]
	public EventCallback<int> SelectedIndexChanged { get; set; }

	[Parameter]
	public EventCallback<int> OnSelect { get; set; }

	[Parameter]
	public bool Multiple { get; set; }

	[Parameter]
	public IReadOnlyList<int> SelectedIndices { get; set; } = Array.Empty<int>();

	[Parameter]
	public EventCallback<IReadOnlyList<int>> SelectedIndicesChanged { get; set; }

	[Parameter]
	public EventCallback<IReadOnlyList<int>> OnMultiple { get; set; }

	[Parameter]
	public bool Disabled { get; set; }

	[Parameter]
	public string Class { get; set; } = string.Empty;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex justify-between w-full h-full hover:bg-control-bg-dark items-center " + Class);
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex gap-2 items-center");
		__builder.OpenElement(4, "p");
		__builder.AddContent(5, T.L(Title));
		__builder.CloseElement();
		if (!string.IsNullOrEmpty(Description))
		{
			__builder.OpenComponent<TooltipIcon>(6);
			__builder.AddComponentParameter(7, "Content", RuntimeHelpers.TypeCheck(Description));
			__builder.CloseComponent();
		}
		__builder.CloseElement();
		__builder.AddMarkupContent(8, "\n\n    ");
		__builder.OpenElement(9, "div");
		__builder.AddAttribute(10, "class", "flex gap-4 relative " + ((Title == "") ? "w-full h-full" : ""));
		__builder.OpenElement(11, "button");
		__builder.AddAttribute(12, "type", "button");
		__builder.AddAttribute(13, "disabled", Disabled);
		__builder.AddAttribute(14, "class", "w-full cursor-pointer border border-control-bg bg-control-bg rounded-md items-center flex " + ((Title != "") ? "h-11 px-4 min-w-80" : "h-full w-full px-2") + " justify-between " + (isOpen ? "border-accent-dark!" : ""));
		__builder.AddAttribute(15, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)ToggleOpen));
		__builder.OpenElement(16, "p");
		__builder.AddContent(17, GetSelectedOptionText());
		__builder.CloseElement();
		__builder.AddMarkupContent(18, "\n            ");
		__builder.OpenElement(19, "svg");
		__builder.AddAttribute(20, "class", "description transition-transform duration-200 " + (isOpen ? "rotate-180" : ""));
		__builder.AddAttribute(21, "xmlns", "http://www.w3.org/2000/svg");
		__builder.AddAttribute(22, "width", "1.5em");
		__builder.AddAttribute(23, "height", "1.5em");
		__builder.AddAttribute(24, "viewBox", "0 0 24 24");
		__builder.AddMarkupContent(25, "<path d=\"M0 0h24v24H0z\" fill=\"none\"></path>\n                <path fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"m6 9l6 6l6-6\"></path>");
		__builder.CloseElement();
		__builder.CloseElement();
		if (isOpen)
		{
			__builder.OpenElement(26, "div");
			__builder.AddAttribute(27, "class", "absolute top-full left-0 mt-1 w-full min-w-24 max-h-48 bg-control-bg-dark rounded-md z-50 overflow-y-auto flex flex-col shadow-lg");
			__builder.AddAttribute(28, "onmouseleave", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
			{
				isOpen = false;
			}));
			for (int num = 0; num < Options.Count; num++)
			{
				int index = num;
				bool flag = (Multiple ? SelectedIndices.Contains(index) : (index == SelectedIndex));
				__builder.OpenElement(29, "button");
				__builder.AddAttribute(30, "type", "button");
				__builder.AddAttribute(31, "class", "w-full min-w-24 px-4 py-2 text-left description hover:bg-control/50 hover:text-text text-[14px] transition-colors cursor-pointer " + (flag ? "text-text bg-accent-dark!" : ""));
				__builder.AddAttribute(32, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () => SelectOption(index)));
				__builder.AddContent(33, Options[index]);
				__builder.CloseElement();
			}
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private void ToggleOpen()
	{
		if (!Disabled)
		{
			isOpen = !isOpen;
		}
	}

	private async Task SelectOption(int index)
	{
		if (Multiple)
		{
			int[] selectedIndices = (SelectedIndices.Contains(index) ? SelectedIndices.Where((int selectedIndex) => selectedIndex != index).ToArray() : SelectedIndices.Append(index).ToArray());
			SelectedIndices = selectedIndices;
			await SelectedIndicesChanged.InvokeAsync(SelectedIndices);
			await OnMultiple.InvokeAsync(SelectedIndices);
		}
		else
		{
			SelectedIndex = index;
			await SelectedIndexChanged.InvokeAsync(SelectedIndex);
			await OnSelect.InvokeAsync(SelectedIndex);
			isOpen = false;
		}
	}

	private string GetSelectedOptionText()
	{
		if (Multiple)
		{
			return string.Join(", ", from index in SelectedIndices
				where index >= 0 && index < Options.Count
				select Options[index]);
		}
		if (Options.Count > 0 && SelectedIndex >= 0 && SelectedIndex < Options.Count)
		{
			return Options[SelectedIndex];
		}
		return string.Empty;
	}
}
