using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.JSInterop;

namespace ETS2LA.UI.Shared.Components;

public class TooltipIcon : ComponentBase
{
	[Parameter]
	public string Content { get; set; } = string.Empty;

	[Parameter]
	public int Delay { get; set; }

	[Parameter]
	public string Origin { get; set; } = "cursor";

	[Parameter]
	public string Class { get; set; } = string.Empty;

	[Inject]
	private IJSRuntime JSRuntime { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenComponent<Tooltip>(0);
		__builder.AddComponentParameter(1, "Content", RuntimeHelpers.TypeCheck(T.L(Content)));
		__builder.AddComponentParameter(2, "Delay", RuntimeHelpers.TypeCheck(Delay));
		__builder.AddComponentParameter(3, "Origin", RuntimeHelpers.TypeCheck(Origin));
		__builder.AddComponentParameter(4, "Class", RuntimeHelpers.TypeCheck(Class));
		__builder.AddAttribute(5, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder) =>
		{
			renderTreeBuilder.AddMarkupContent(6, "<svg class=\"description text-[14px]\" xmlns=\"http://www.w3.org/2000/svg\" width=\"1em\" height=\"1em\" viewBox=\"0 0 1024 1024\" aria-hidden=\"true\"><path d=\"M0 0h1024v1024H0z\" fill=\"none\"></path>\n        <path fill=\"currentColor\" d=\"M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448s448-200.6 448-448S759.4 64 512 64m0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372s372 166.6 372 372s-166.6 372-372 372\"></path>\n        <path fill=\"currentColor\" d=\"M464 336a48 48 0 1 0 96 0a48 48 0 1 0-96 0m72 112h-48c-4.4 0-8 3.6-8 8v272c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V456c0-4.4-3.6-8-8-8\"></path></svg>");
		}));
		__builder.CloseComponent();
	}
}
