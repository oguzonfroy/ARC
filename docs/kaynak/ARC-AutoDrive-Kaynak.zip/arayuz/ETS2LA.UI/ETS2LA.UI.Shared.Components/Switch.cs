using System;
using System.Threading.Tasks;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Shared.Components;

public class Switch : ComponentBase
{
	[Parameter]
	[EditorRequired]
	public string Title { get; set; } = string.Empty;

	[Parameter]
	[EditorRequired]
	public string Description { get; set; } = string.Empty;

	[Parameter]
	public bool Value { get; set; }

	[Parameter]
	public string? Class { get; set; }

	[Parameter]
	public EventCallback<bool> ValueChanged { get; set; }

	[Parameter]
	public EventCallback<bool> OnToggle { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex justify-between w-full items-center hover:bg-control-bg-dark min-h-[32px] cursor-pointer " + Class);
		__builder.AddAttribute(2, "role", "switch");
		__builder.AddAttribute(3, "aria-checked", Value);
		__builder.AddAttribute(4, "tabindex", "0");
		__builder.AddAttribute(5, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Func<Task>)Toggle));
		__builder.OpenElement(6, "div");
		__builder.AddAttribute(7, "class", "flex gap-2 items-center");
		__builder.OpenElement(8, "p");
		__builder.AddContent(9, T.L(Title));
		__builder.CloseElement();
		if (!string.IsNullOrEmpty(Description))
		{
			__builder.OpenComponent<TooltipIcon>(10);
			__builder.AddComponentParameter(11, "Content", RuntimeHelpers.TypeCheck(Description));
			__builder.CloseComponent();
		}
		__builder.CloseElement();
		__builder.AddMarkupContent(12, "\n    \n    \n    ");
		__builder.OpenElement(13, "div");
		__builder.AddAttribute(14, "class", "relative flex items-center justify-between px-[7px] w-[63px] h-[27px] bg-control rounded-lg text-[12px] font-medium " + (Value ? "bg-accent-border!" : ""));
		__builder.OpenElement(15, "span");
		__builder.AddAttribute(16, "class", "transition-opacity " + (Value ? "opacity-70" : "opacity-0"));
		__builder.AddContent(17, "ON");
		__builder.CloseElement();
		__builder.AddMarkupContent(18, "\n        ");
		__builder.OpenElement(19, "span");
		__builder.AddAttribute(20, "class", "transition-opacity " + (Value ? "opacity-0" : "opacity-40"));
		__builder.AddContent(21, "OFF");
		__builder.CloseElement();
		__builder.AddMarkupContent(22, "\n        ");
		__builder.OpenElement(23, "div");
		__builder.AddAttribute(24, "class", "absolute left-[3.5px] size-[21px] bg-text-l/80 rounded-md transition-transform duration-200 " + (Value ? "translate-x-[35px] bg-text-l!" : ""));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private async Task Toggle()
	{
		Value = !Value;
		await ValueChanged.InvokeAsync(Value);
		await OnToggle.InvokeAsync(Value);
	}
}
