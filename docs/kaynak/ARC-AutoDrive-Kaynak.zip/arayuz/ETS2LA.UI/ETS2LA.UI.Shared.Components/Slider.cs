using System;
using System.Threading.Tasks;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;

namespace ETS2LA.UI.Shared.Components;

public class Slider : ComponentBase
{
	private ElementReference sliderInput;

	private long lastPreviewUpdate;

	private double pendingPreviewClientX;

	private bool previewFlushScheduled;

	private long previewGeneration;

	private double? highlightPosition;

	private const long PreviewUpdateIntervalMs = 33L;

	[Parameter]
	[EditorRequired]
	public string Title { get; set; } = string.Empty;

	[Parameter]
	[EditorRequired]
	public string Description { get; set; } = string.Empty;

	[Parameter]
	public string Suffix { get; set; } = string.Empty;

	[Parameter]
	public float Min { get; set; }

	[Parameter]
	public float Max { get; set; } = 100f;

	[Parameter]
	public float Step { get; set; } = 1f;

	[Parameter]
	public float Value { get; set; }

	[Parameter]
	public float? HighlightValue { get; set; }

	[Parameter]
	public EventCallback<float> ValueChanged { get; set; }

	[Parameter]
	public EventCallback<float> ValueSubmitted { get; set; }

	[Parameter]
	public bool Disabled { get; set; }

	[Parameter]
	public string Class { get; set; } = string.Empty;

	private float? PreviewValue { get; set; }

	private double PreviewPosition { get; set; }

	private bool IsDragging { get; set; }

	[Inject]
	private IJSRuntime JSRuntime { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex justify-between w-full items-center hover:bg-control-bg-dark gap-8 min-h-[35px] " + Class);
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex items-center");
		__builder.OpenElement(4, "p");
		__builder.AddContent(5, T.L(Title));
		__builder.CloseElement();
		__builder.AddMarkupContent(6, "\n        ");
		__builder.OpenElement(7, "input");
		__builder.AddAttribute(8, "type", "text");
		__builder.AddAttribute(9, "value", Value);
		__builder.AddAttribute(10, "disabled", Disabled);
		__builder.AddAttribute(11, "class", "w-12 ml-2 mr-1 px-1 py-0.5 rounded-md bg-control-bg text-center text-sm focus:outline-none focus:ring-1 focus:ring-accent focus:ring-offset-1 focus:ring-offset-control");
		__builder.AddAttribute(12, "onchange", EventCallback.Factory.Create(this, async (ChangeEventArgs e) =>
		{
			await UpdateValue(e.Value?.ToString() ?? "0");
		}));
		__builder.AddAttribute(13, "onfocusout", EventCallback.Factory.Create(this, async (FocusEventArgs e) =>
		{
			await SubmitValue();
		}));
		__builder.AddAttribute(14, "onpointerleave", EventCallback.Factory.Create(this, async (PointerEventArgs e) =>
		{
			await SubmitValue();
		}));
		__builder.AddAttribute(15, "onsubmit", EventCallback.Factory.Create(this, async (EventArgs e) =>
		{
			await SubmitValue();
		}));
		__builder.CloseElement();
		__builder.AddMarkupContent(16, "\n        ");
		__builder.OpenElement(17, "p");
		__builder.AddAttribute(18, "class", "ml-1");
		__builder.AddContent(19, Suffix);
		__builder.CloseElement();
		__builder.AddMarkupContent(20, "\n        ");
		__builder.OpenComponent<TooltipIcon>(21);
		__builder.AddComponentParameter(22, "Class", "ml-2");
		__builder.AddComponentParameter(23, "Content", RuntimeHelpers.TypeCheck(Description));
		__builder.CloseComponent();
		__builder.CloseElement();
		__builder.AddMarkupContent(24, "\n    ");
		__builder.OpenElement(25, "div");
		__builder.AddAttribute(26, "class", "relative flex gap-4 w-full max-w-80");
		if (PreviewValue.HasValue)
		{
			__builder.OpenElement(27, "span");
			__builder.AddAttribute(28, "class", "absolute top-1/2 h-4 w-px -translate-x-1/2 -translate-y-1/2 bg-accent/70 " + ((IsDragging || PreviewValue == Value) ? "opacity-0" : "transition-[left] duration-150 ease-out") + " pointer-events-none");
			__builder.AddAttribute(29, "style", "left: " + PreviewPosition + "%");
			__builder.CloseElement();
			__builder.AddMarkupContent(30, "\n            ");
			__builder.OpenElement(31, "span");
			__builder.AddAttribute(32, "class", "absolute bottom-full mb-1 -translate-x-1/2 border border-control-bg rounded-md bg-control-bg px-1.5 py-0.5 text-xs text-text-h " + (IsDragging ? "border-accent-border!" : "transition-[left] duration-150 ease-out") + " pointer-events-none");
			__builder.AddAttribute(33, "style", "left: " + PreviewPosition + "%");
			__builder.AddContent(34, PreviewValue.Value);
			__builder.AddContent(35, Suffix);
			__builder.CloseElement();
		}
		if (HighlightValue.HasValue)
		{
			__builder.OpenElement(36, "span");
			__builder.AddAttribute(37, "class", "absolute top-1/2 h-4 w-px -translate-x-1/2 -translate-y-1/2 bg-accent/50 pointer-events-none transition-[left] duration-333 ease-out");
			double? num = highlightPosition;
			double? num2 = num;
			__builder.AddAttribute(38, "style", "left: " + num2 + "%");
			__builder.CloseElement();
		}
		__builder.OpenElement(39, "input");
		__builder.AddAttribute(40, "type", "range");
		__builder.AddAttribute(41, "min", Min);
		__builder.AddAttribute(42, "max", Max);
		__builder.AddAttribute(43, "step", Step);
		__builder.AddAttribute(44, "value", Value);
		__builder.AddAttribute(45, "disabled", Disabled);
		__builder.AddAttribute(46, "class", "slider w-full cursor-pointer transition-colors duration-150 appearance-none bg-transparent");
		__builder.AddAttribute(47, "oninput", EventCallback.Factory.Create(this, async (ChangeEventArgs e) =>
		{
			await UpdateValue(e.Value?.ToString() ?? "0");
		}));
		__builder.AddAttribute(48, "onpointerdown", EventCallback.Factory.Create<PointerEventArgs>((object)this, (Action)BeginDrag));
		__builder.AddAttribute(49, "onpointerup", EventCallback.Factory.Create<PointerEventArgs>((object)this, (Action)EndDrag));
		__builder.AddAttribute(50, "onpointercancel", EventCallback.Factory.Create<PointerEventArgs>((object)this, (Action)EndDrag));
		__builder.AddAttribute(51, "onpointermove", EventCallback.Factory.Create((object)this, (Func<PointerEventArgs, Task>)UpdatePreview));
		__builder.AddAttribute(52, "onpointerleave", EventCallback.Factory.Create<PointerEventArgs>((object)this, (Func<Task>)HandlePointerLeave));
		__builder.AddAttribute(53, "onfocusout", EventCallback.Factory.Create(this, async (FocusEventArgs e) =>
		{
			await SubmitValue();
		}));
		__builder.AddAttribute(54, "onsubmit", EventCallback.Factory.Create(this, async (EventArgs e) =>
		{
			await SubmitValue();
		}));
		__builder.AddElementReferenceCapture(55, (ElementReference __value) =>
		{
			sliderInput = __value;
		});
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private async Task UpdateValue(string newValue)
	{
		if (!Disabled)
		{
			Value = (float.TryParse(newValue, out var result) ? result : Value);
			if (Value < Min)
			{
				Value = Min;
			}
			if (Value > Max)
			{
				Value = Max;
			}
			await ValueChanged.InvokeAsync(Value);
		}
	}

	private async Task SubmitValue()
	{
		if (!Disabled)
		{
			await ValueSubmitted.InvokeAsync(Value);
		}
	}

	private async Task UpdatePreview(PointerEventArgs e)
	{
		if (Disabled)
		{
			return;
		}
		pendingPreviewClientX = e.ClientX;
		long num = Environment.TickCount64 - lastPreviewUpdate;
		if (num < 33)
		{
			if (!previewFlushScheduled)
			{
				previewFlushScheduled = true;
				FlushPendingPreview(33 - num, previewGeneration);
			}
		}
		else
		{
			await ApplyPreview(pendingPreviewClientX, previewGeneration);
		}
	}

	private async Task FlushPendingPreview(long delay, long generation)
	{
		await Task.Delay((int)delay);
		await InvokeAsync(async () =>
		{
			previewFlushScheduled = false;
			if (!Disabled && generation == previewGeneration)
			{
				await ApplyPreview(pendingPreviewClientX, generation);
			}
		});
	}

	private async Task ApplyPreview(double clientX, long generation)
	{
		lastPreviewUpdate = Environment.TickCount64;
		double num = await JSRuntimeExtensions.InvokeAsync<double>(JSRuntime, "getSliderPointerPercentage", new object[2] { sliderInput, clientX });
		if (generation == previewGeneration)
		{
			float num2 = Min + (float)(num / 100.0) * (Max - Min);
			PreviewValue = Math.Clamp(MathF.Round((num2 - Min) / Step) * Step + Min, Min, Max);
			float num3 = ((Max > Min) ? ((PreviewValue.Value - Min) / (Max - Min) * 100f) : 0f);
			PreviewPosition = await JSRuntimeExtensions.InvokeAsync<double>(JSRuntime, "getSliderValuePosition", new object[2] { sliderInput, num3 });
			if (generation != previewGeneration)
			{
				PreviewValue = null;
			}
		}
	}

	private async Task HandlePointerLeave()
	{
		previewGeneration++;
		previewFlushScheduled = false;
		IsDragging = false;
		PreviewValue = null;
		await SubmitValue();
	}

	private void BeginDrag()
	{
		IsDragging = true;
	}

	private void EndDrag()
	{
		IsDragging = false;
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		if (!HighlightValue.HasValue)
		{
			return;
		}
		Task.Run(async () =>
		{
			while (true)
			{
				await Task.Delay(333);
				float num = ((Max > Min) ? ((HighlightValue.Value - Min) / (Max - Min) * 100f) : 0f);
				highlightPosition = await JSRuntimeExtensions.InvokeAsync<double>(JSRuntime, "getSliderValuePosition", new object[2] { sliderInput, num });
				await InvokeAsync((Action)StateHasChanged);
			}
		});
	}
}
