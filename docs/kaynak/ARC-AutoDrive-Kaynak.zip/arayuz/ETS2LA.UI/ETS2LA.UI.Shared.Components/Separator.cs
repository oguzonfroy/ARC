using System;
using System.Globalization;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Shared.Components;

public class Separator : ComponentBase
{
	[Parameter]
	public string Class { get; set; } = string.Empty;

	[Parameter]
	public string Orientation { get; set; } = "horizontal";

	[Parameter]
	public string Label { get; set; } = string.Empty;

	[Parameter]
	public float LabelPosition { get; set; } = 0.5f;

	[Parameter]
	public string Anchor { get; set; } = "center";

	private string LineClass
	{
		get
		{
			if (!(Orientation == "horizontal"))
			{
				return "border-l border-description/30 border-[1px]";
			}
			return "border-t border-description/30 border-[1px]";
		}
	}

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex " + ((Orientation == "horizontal") ? "flex-row" : "flex-col") + " description items-center " + Class);
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", LineClass);
		__builder.AddAttribute(4, "style", GetFirstLineStyle());
		__builder.CloseElement();
		if (!string.IsNullOrEmpty(Label))
		{
			__builder.OpenElement(5, "span");
			__builder.AddAttribute(6, "class", ((Orientation == "horizontal") ? "px-2" : "py-2") + " whitespace-nowrap");
			__builder.AddContent(7, Label);
			__builder.CloseElement();
		}
		__builder.OpenElement(8, "div");
		__builder.AddAttribute(9, "class", LineClass);
		__builder.AddAttribute(10, "style", GetSecondLineStyle());
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private string GetFirstLineStyle()
	{
		float num = Math.Clamp(LabelPosition, 0f, 1f);
		string text = (num * 100f).ToString(CultureInfo.InvariantCulture);
		string anchor = Anchor;
		if (!(anchor == "left"))
		{
			if (anchor == "right")
			{
				return "flex: 1 1 0%;";
			}
			return "flex: " + num.ToString(CultureInfo.InvariantCulture) + " 1 0%;";
		}
		return "flex: 0 0 " + text + "%;";
	}

	private string GetSecondLineStyle()
	{
		float num = Math.Clamp(LabelPosition, 0f, 1f);
		string text = ((1f - num) * 100f).ToString(CultureInfo.InvariantCulture);
		string anchor = Anchor;
		if (!(anchor == "left"))
		{
			if (anchor == "right")
			{
				return "flex: 0 0 " + text + "%;";
			}
			return "flex: " + (1f - num).ToString(CultureInfo.InvariantCulture) + " 1 0%;";
		}
		return "flex: 1 1 0%;";
	}
}
