using System;
using System.Threading;
using System.Threading.Tasks;
using Markdig;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;

namespace ETS2LA.UI.Shared.Components;

public class Tooltip : ComponentBase
{
	private static readonly MarkdownPipeline Pipeline = new MarkdownPipelineBuilder().UseAdvancedExtensions().Build();

	private ElementReference tooltipElement;

	private bool isHovered;

	private double x;

	private double y;

	private string autoOrigin = "cursor";

	private CancellationTokenSource? cts;

	[Parameter]
	public string Content { get; set; } = string.Empty;

	[Parameter]
	public int Delay { get; set; }

	[Parameter]
	public string Origin { get; set; } = "cursor";

	[Parameter]
	public string Class { get; set; } = string.Empty;

	[Parameter]
	public RenderFragment? ChildContent { get; set; }

	private MarkupString RenderedContent => new MarkupString(Markdown.ToHtml(Content ?? string.Empty, Pipeline));

	private string PositionClasses => autoOrigin switch
	{
		"top" => "bottom-full left-1/2 -translate-x-1/2 mb-2", 
		"bottom" => "top-full left-1/2 -translate-x-1/2 mt-2", 
		"left" => "right-full top-1/2 -translate-y-1/2 mr-2", 
		"right" => "left-full top-1/2 -translate-y-1/2 ml-2", 
		_ => "", 
	};

	[Inject]
	private IJSRuntime JSRuntime { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "relative inline-block " + Class);
		__builder.AddAttribute(2, "onmouseenter", EventCallback.Factory.Create((object)this, (Func<MouseEventArgs, Task>)HandleMouseEnter));
		__builder.AddAttribute(3, "onmouseleave", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)HandleMouseLeave));
		__builder.AddAttribute(4, "onmousemove", EventCallback.Factory.Create((object)this, (Action<MouseEventArgs>)HandleMouseMove));
		__builder.AddElementReferenceCapture(5, (ElementReference __value) =>
		{
			tooltipElement = __value;
		});
		__builder.AddContent(6, ChildContent);
		if (isHovered && !string.IsNullOrEmpty(Content))
		{
			__builder.OpenElement(7, "div");
			__builder.AddAttribute(8, "style", (autoOrigin == "cursor") ? $"top: {y}px; left: {x}px;" : "");
			__builder.AddAttribute(9, "class", ((autoOrigin == "cursor") ? "fixed" : "absolute") + " " + PositionClasses + " p-1 px-1.5 rounded-sm bg-control-bg border border-border z-50 pointer-events-none text-[13px] [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:list-decimal [&_ol]:pl-5 whitespace-normal max-w-sm");
			__builder.AddContent(10, RenderedContent);
			__builder.CloseElement();
		}
		__builder.CloseElement();
	}

	private async Task HandleMouseEnter(MouseEventArgs e)
	{
		UpdatePosition(e);
		string text = Origin.ToLowerInvariant();
		if (text.Contains("auto"))
		{
			try
			{
				autoOrigin = await JSRuntimeExtensions.InvokeAsync<string>(JSRuntime, "getTooltipAutoPosition", new object[1] { tooltipElement });
			}
			catch
			{
				autoOrigin = "top";
			}
		}
		else
		{
			autoOrigin = text;
		}
		cts?.Cancel();
		cts = new CancellationTokenSource();
		CancellationToken token = cts.Token;
		Task.Run(async () =>
		{
			_ = 1;
			try
			{
				if (Delay > 0)
				{
					await Task.Delay(Delay, token);
				}
				if (!token.IsCancellationRequested)
				{
					isHovered = true;
					await InvokeAsync((Action)StateHasChanged);
				}
			}
			catch (TaskCanceledException)
			{
			}
		});
	}

	private void HandleMouseMove(MouseEventArgs e)
	{
		if (Origin == "cursor")
		{
			UpdatePosition(e);
			if (isHovered)
			{
				StateHasChanged();
			}
		}
	}

	private void HandleMouseLeave()
	{
		cts?.Cancel();
		isHovered = false;
	}

	private void UpdatePosition(MouseEventArgs e)
	{
		if (Origin == "cursor")
		{
			x = e.ClientX + 10.0;
			y = e.ClientY + 10.0;
		}
	}
}
