using System.Threading.Tasks;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.JSInterop;

namespace ETS2LA.UI.Shared.Layouts;

[Layout(typeof(MainLayout))]
public class SettingsLayout : LayoutComponentBase
{
	private ElementReference scrollArea;

	private ElementReference bottomButtons;

	[Inject]
	private IJSRuntime JS { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "main");
		__builder.AddAttribute(1, "class", "flex h-full w-full flex-col bg-bg-dark");
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex p-1.5 h-full w-full");
		__builder.OpenElement(4, "div");
		__builder.AddAttribute(5, "class", "w-[230px] pl-2 pr-3 pt-2 flex flex-col h-full");
		__builder.OpenElement(6, "div");
		__builder.AddAttribute(7, "class", "flex flex-col gap-6.5 flex-1 min-h-0 overflow-y-auto overflow-x-hidden");
		__builder.AddElementReferenceCapture(8, (ElementReference __value) =>
		{
			scrollArea = __value;
		});
		// ARC: ayar menüsü sadeleştirildi (2026-11-13). Gruplar: Sürüş (en çok kullanılan), Görünüm ve Ses, Gelişmiş
		// (oyun bağlantısı, harita verisi, deneysel). Eskiden içi boş bir "Ağ" başlığı vardı, "Veri Ayrıştırma" da
		// sürüş ayarlarının yanındaydı.
		__builder.OpenElement(9, "div");
		__builder.AddAttribute(10, "class", "flex flex-col gap-0");
		__builder.OpenComponent<SidebarGroupLabel>(11);
		__builder.AddComponentParameter(12, "Title", "Sürüş");
		__builder.CloseComponent();
		__builder.OpenComponent<SidebarButton>(14);
		__builder.AddComponentParameter(15, "Name", "Sürüş Yardımları");
		__builder.AddComponentParameter(16, "Path", "/settings/assists");
		__builder.CloseComponent();
		__builder.OpenComponent<SidebarButton>(35);
		__builder.AddComponentParameter(36, "Name", "Klavye Kısayolları");
		__builder.AddComponentParameter(37, "Path", "/settings/controls");
		__builder.CloseComponent();
		__builder.CloseElement();
		__builder.OpenElement(22, "div");
		__builder.AddAttribute(23, "class", "flex flex-col gap-0");
		__builder.OpenComponent<SidebarGroupLabel>(24);
		__builder.AddComponentParameter(25, "Title", "Görünüm ve Ses");
		__builder.CloseComponent();
		__builder.OpenComponent<SidebarButton>(27);
		__builder.AddComponentParameter(28, "Name", "Görüntü");
		__builder.AddComponentParameter(29, "Path", "/settings/display");
		__builder.CloseComponent();
		__builder.OpenComponent<SidebarButton>(31);
		__builder.AddComponentParameter(32, "Name", "Ses");
		__builder.AddComponentParameter(33, "Path", "/settings/audio");
		__builder.CloseComponent();
		__builder.CloseElement();
		__builder.OpenElement(39, "div");
		__builder.AddAttribute(40, "class", "flex flex-col gap-0");
		__builder.OpenComponent<SidebarGroupLabel>(41);
		__builder.AddComponentParameter(42, "Title", "Gelişmiş");
		__builder.CloseComponent();
		__builder.OpenComponent<SidebarButton>(44);
		__builder.AddComponentParameter(45, "Name", "Oyun Bağlantısı");
		__builder.AddComponentParameter(46, "Path", "/settings/sdk");
		__builder.CloseComponent();
		__builder.OpenComponent<SidebarButton>(18);
		__builder.AddComponentParameter(19, "Name", "Harita Verisi");
		__builder.AddComponentParameter(20, "Path", "/settings/data");
		__builder.CloseComponent();
		__builder.OpenComponent<SidebarButton>(48);
		__builder.AddComponentParameter(49, "Name", "Deneysel");
		__builder.AddComponentParameter(50, "Path", "/settings/experiments");
		__builder.CloseComponent();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(56, "\n\n      ");
		__builder.OpenElement(57, "div");
		__builder.AddAttribute(58, "class", "flex flex-col w-full gap-0 mb-4 pt-2 border-t border-border");
		__builder.AddElementReferenceCapture(59, (ElementReference __value) =>
		{
			bottomButtons = __value;
		});
		__builder.OpenComponent<SidebarButton>(60);
		__builder.AddComponentParameter(61, "Name", "Açık Kaynak");
		__builder.AddComponentParameter(62, "Path", "/settings/opensource");
		__builder.CloseComponent();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(63, "\n\n    <div class=\"mt-3 mb-3 bg-control-bg w-0.5 rounded-md\"></div>\n\n    \n    ");
		__builder.OpenElement(64, "div");
		__builder.AddAttribute(65, "class", "w-full h-full bg-bg-dark rounded-md rounded-l-lg overflow-y-auto");
		__builder.AddContent(66, Body);
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}

	protected override async Task OnAfterRenderAsync(bool firstRender)
	{
		if (firstRender)
		{
			await JS.InvokeVoidAsync("initScrollDivider", scrollArea, bottomButtons);
		}
	}
}
