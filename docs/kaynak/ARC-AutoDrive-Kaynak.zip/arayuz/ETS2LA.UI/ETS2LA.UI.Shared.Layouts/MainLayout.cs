using System;
using System.Diagnostics;
using System.Threading.Tasks;
using ETS2LA.Backend;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using ETS2LA.UI.Shared.Overlays;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Routing;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;

namespace ETS2LA.UI.Shared.Layouts;

public class MainLayout : LayoutComponentBase
{
	private ElementReference scrollArea;

	private ElementReference bottomButtons;

	[Inject]
	private NavigationManager Navigation { get; set; }

	[Inject]
	private IJSRuntime JS { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "main");
		__builder.AddAttribute(1, "class", "relative flex h-screen w-screen flex-col kp-pencere arc-zemin");
		__builder.AddMarkupContent(2, "<div class=\"arc-ust-cizgi\"></div>\r\n  ");
		__builder.OpenComponent<ResizeHandles>(3);
		__builder.CloseComponent();
		__builder.AddMarkupContent(4, "\r\n  ");
		__builder.OpenComponent<Titlebar>(5);
		__builder.CloseComponent();
		__builder.AddMarkupContent(6, "\r\n  ");
		__builder.OpenComponent<ETS2LA.UI.Shared.Overlays.Notifications>(7);
		__builder.CloseComponent();
		if (ArcLisans.Kilitli)
		{
			__builder.OpenElement(8, "div");
			__builder.AddAttribute(9, "style", "position:absolute;inset:48px 0 0 0;z-index:40;display:flex;align-items:center;justify-content:center;background:rgba(7,6,11,.86);backdrop-filter:blur(6px)");
			__builder.OpenElement(10, "div");
			__builder.AddAttribute(11, "style", "width:420px;max-width:90%;text-align:center;padding:30px 28px;border-radius:18px;background:#13111a;border:1px solid #ef4444;box-shadow:0 0 60px rgba(239,68,68,.22)");
			__builder.AddMarkupContent(12, "<div style=\"font-size:34px\">\ud83d\udd12</div>\r\n        ");
			__builder.AddMarkupContent(13, "<p style=\"margin:6px 0 0;font-size:20px;font-weight:700;color:#fff\">Lisans kilidi</p>\r\n        ");
			__builder.OpenElement(14, "p");
			__builder.AddAttribute(15, "style", "margin:10px 0 0;font-size:14px;line-height:1.5;color:#c4bdd8");
			__builder.AddContent(16, ArcLisans.Mesaj);
			__builder.CloseElement();
			__builder.AddMarkupContent(17, "\r\n        ");
			__builder.AddMarkupContent(18, "<p style=\"margin:10px 0 0;font-size:12px;color:#8a83a0\">Otonom sürüş durduruldu. Lisansın yenilenince her şey kendiliğinden açılır.</p>\r\n        ");
			__builder.OpenElement(19, "button");
			__builder.AddAttribute(20, "class", "kp-ana-dugme");
			__builder.AddAttribute(21, "style", "margin-top:20px;height:42px");
			__builder.AddAttribute(22, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)DiscordAc));
			__builder.AddMarkupContent(23, "Lisansı yenile (Discord)");
			__builder.CloseElement();
			if (ArcHub.HubKomutu != null)
			{
				__builder.OpenElement(24, "button");
				__builder.AddAttribute(25, "class", "button w-full! mt-2");
				__builder.AddAttribute(26, "style", "height:42px");
				__builder.AddAttribute(27, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)ArcHub.OyunDegistir));
				__builder.AddMarkupContent(28, "Yeni anahtar gir (ARC'a dön)");
				__builder.CloseElement();
			}
			__builder.CloseElement();
			__builder.CloseElement();
		}
		__builder.OpenElement(29, "div");
		__builder.AddAttribute(30, "class", "kp-govde");
		__builder.OpenElement(31, "aside");
		__builder.AddAttribute(32, "class", "arc-sidebar");
		__builder.AddAttribute(33, "style", WindowState.Current.IsSidebarOpen ? "" : "display:none");
		__builder.OpenElement(34, "div");
		__builder.AddAttribute(35, "class", "flex flex-col items-center gap-1 flex-1 min-h-0 w-full overflow-y-auto overflow-x-hidden");
		__builder.AddElementReferenceCapture(36, (ElementReference __value) =>
		{
			scrollArea = __value;
		});
		__builder.OpenComponent<SidebarGroupLabel>(37);
		__builder.AddComponentParameter(38, "Title", RuntimeHelpers.TypeCheck(T._("Main")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(39, "\r\n          ");
		__builder.OpenComponent<SidebarButton>(40);
		__builder.AddComponentParameter(41, "Name", "Gösterge");
		__builder.AddComponentParameter(42, "Path", "/");
		__builder.AddComponentParameter(43, "Match", RuntimeHelpers.TypeCheck(NavLinkMatch.All));
		__builder.AddComponentParameter(44, "Icon", "gosterge");
		__builder.CloseComponent();
		__builder.AddMarkupContent(45, "\r\n          ");
		__builder.OpenComponent<SidebarButton>(46);
		__builder.AddComponentParameter(47, "Name", RuntimeHelpers.TypeCheck(T._("Visualization")));
		__builder.AddComponentParameter(48, "Path", "/visualization");
		__builder.AddComponentParameter(49, "Icon", "gorsel");
		__builder.CloseComponent();
		__builder.AddMarkupContent(50, "\r\n          ");
		__builder.OpenComponent<SidebarButton>(51);
		__builder.AddComponentParameter(52, "Name", RuntimeHelpers.TypeCheck(T._("Start Game")));
		__builder.AddComponentParameter(53, "Path", "/start");
		__builder.AddComponentParameter(54, "Icon", "baslat");
		__builder.CloseComponent();
		__builder.AddMarkupContent(55, "\r\n          ");
		__builder.OpenComponent<SidebarGroupLabel>(56);
		__builder.AddComponentParameter(57, "Title", RuntimeHelpers.TypeCheck(T._("Help")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(58, "\r\n          ");
		__builder.OpenComponent<SidebarButton>(59);
		__builder.AddComponentParameter(60, "Name", "Nasıl Kurulur");
		__builder.AddComponentParameter(61, "Path", "/nasil-kurulur");
		__builder.AddComponentParameter(62, "Icon", "kurulum");
		__builder.CloseComponent();
		__builder.AddMarkupContent(63, "\r\n          ");
		__builder.OpenComponent<SidebarButton>(64);
		__builder.AddComponentParameter(65, "Name", RuntimeHelpers.TypeCheck(T._("Contact Us")));
		__builder.AddComponentParameter(66, "Path", "/help/contact");
		__builder.AddComponentParameter(67, "Icon", "iletisim");
		__builder.CloseComponent();
		__builder.CloseElement();
		__builder.AddMarkupContent(68, "\r\n\r\n        ");
		__builder.OpenElement(69, "div");
		__builder.AddAttribute(70, "class", "arc-sidebar-alt");
		__builder.AddElementReferenceCapture(71, (ElementReference __value) =>
		{
			bottomButtons = __value;
		});
		__builder.OpenComponent<SidebarButton>(72);
		__builder.AddComponentParameter(73, "Name", RuntimeHelpers.TypeCheck(T._("Settings")));
		__builder.AddComponentParameter(74, "Path", "/settings");
		__builder.AddComponentParameter(75, "Icon", "ayarlar");
		__builder.CloseComponent();
		if (ArcHub.HubKomutu != null)
		{
			__builder.OpenElement(76, "button");
			__builder.AddAttribute(77, "class", "arc-nav");
			__builder.AddAttribute(78, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)ArcHub.OyunDegistir));
			__builder.OpenElement(79, "span");
			__builder.AddAttribute(80, "class", "arc-nav-ikon");
			__builder.AddContent(81, ArcIkonlar.Svg("degistir"));
			__builder.CloseElement();
			__builder.AddMarkupContent(82, "\r\n              ");
			__builder.AddMarkupContent(83, "<span class=\"arc-nav-ad\">Oyun Değiştir</span>");
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.CloseElement();
		if (!WindowState.Current.IsSidebarOpen)
		{
			__builder.OpenElement(84, "button");
			__builder.AddAttribute(85, "class", "arc-ac");
			__builder.AddAttribute(86, "title", "Menüyü aç");
			__builder.AddAttribute(87, "aria-label", "Menüyü aç");
			__builder.AddAttribute(88, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
			{
				WindowState.Current.IsSidebarOpen = true;
				WindowState.Current.RequestFullReload();
			}));
			__builder.AddMarkupContent(89, "<svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"><path d=\"M4 7h16M4 12h16M4 17h16\"></path></svg>");
			__builder.CloseElement();
		}
		__builder.OpenElement(90, "div");
		__builder.AddAttribute(91, "class", "flex-1 min-w-0 h-full arc-icerik overflow-y-auto");
		__builder.OpenElement(92, "div");
		__builder.AddAttribute(93, "class", "arc-sayfa h-full");
		__builder.SetKey(Navigation.Uri);
		__builder.AddContent(94, Body);
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		WindowState.Current.NeedsFullReload += (object? sender, EventArgs e) =>
		{
			InvokeAsync((Action)StateHasChanged);
		};
		ArcLisans.Degisti += () =>
		{
			InvokeAsync((Action)StateHasChanged);
		};
	}

	private static void DiscordAc()
	{
		Process.Start(new ProcessStartInfo("https://discord.gg/n9tyDcqwbA")
		{
			UseShellExecute = true
		});
	}

	protected override async Task OnAfterRenderAsync(bool firstRender)
	{
		if (firstRender)
		{
			await JS.InvokeVoidAsync("initScrollDivider", scrollArea, bottomButtons);
			await JS.InvokeVoidAsync("arcTikSesiAyarla", WindowSettings.Current.ClickSound);
		}
	}
}
