using System;
using Microsoft.CodeAnalysis;

namespace Microsoft.Extensions.Validation.Embedded;

[Embedded]
[AttributeUsage(AttributeTargets.Class)]
internal sealed class ValidatableTypeAttribute : Attribute
{
}
