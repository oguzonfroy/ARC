using System;
using System.Threading.Tasks;
using ETS2LA.Logging;
using ETS2LA.Networking;
using ETS2LA.Networking.Settings;
using ETS2LA.Networking.Users;
using ETS2LA.Notifications;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using ETS2LA.UI.Shared.Layouts;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;

namespace ETS2LA.UI.Pages.Settings.Account;

[Layout(typeof(SettingsLayout))]
[Route("/settings/account")]
public class Account : ComponentBase
{
	private User? CurrentUser => NetworkingSettings.Current.CurrentUser;

	private string Username { get; set; } = string.Empty;

	private string OtpCode { get; set; } = string.Empty;

	private bool WantsToRemoveAccount { get; set; }

	private bool WantsToDisplayJwtToken { get; set; }

	private bool DisplayJwtToken { get; set; }

	private bool JwtTokenCopied { get; set; }

	[Inject]
	private IJSRuntime JS { get; set; }

	[Inject]
	private NavigationManager Navigation { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full p-5 px-8 gap-3");
		if (CurrentUser != null && CurrentUser.JwtToken != null && DateTime.UtcNow < CurrentUser.Expiry)
		{
			__builder.OpenElement(2, "p");
			__builder.AddAttribute(3, "class", "description");
			__builder.AddContent(4, (MarkupString)T._("You are currently logged in as <span class=\"text-text-l\">{0}</span>. [{1}]", CurrentUser.Username, CurrentUser.Role.ToString()));
			__builder.CloseElement();
			__builder.AddMarkupContent(5, "\n        ");
			__builder.OpenElement(6, "p");
			__builder.AddAttribute(7, "class", "description");
			__builder.AddContent(8, (MarkupString)T._("Your token will expire on <span class=\"text-text-l\">{0}</span>, you'll be asked to login again then.", CurrentUser.Expiry.ToLocalTime().ToString("f")));
			__builder.CloseElement();
			__builder.AddMarkupContent(9, "\n        ");
			__builder.OpenElement(10, "button");
			__builder.AddAttribute(11, "class", "button mt-2");
			__builder.AddAttribute(12, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
			{
				WantsToRemoveAccount = true;
			}));
			__builder.AddContent(13, T._("Remove Account"));
			__builder.CloseElement();
			__builder.AddMarkupContent(14, "\n        ");
			__builder.OpenElement(15, "button");
			__builder.AddAttribute(16, "class", "button");
			__builder.AddAttribute(17, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Func<Task>)Logout));
			__builder.AddContent(18, T._("Logout"));
			__builder.CloseElement();
			__builder.OpenElement(19, "p");
			__builder.AddAttribute(20, "class", "description mt-4");
			__builder.AddContent(21, (MarkupString)T._("Some 3rd party websites might want access to your account.<br/>You can press the button below to display your JWT token."));
			__builder.CloseElement();
			__builder.AddMarkupContent(22, "\n        ");
			__builder.OpenElement(23, "button");
			__builder.AddAttribute(24, "class", "button");
			__builder.AddAttribute(25, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
			{
				WantsToDisplayJwtToken = true;
			}));
			__builder.AddContent(26, T._("Display JWT Token"));
			__builder.CloseElement();
			if (DisplayJwtToken)
			{
				__builder.OpenElement(27, "p");
				__builder.AddAttribute(28, "class", "description text-text-accent mt-2");
				__builder.AddContent(29, (MarkupString)T._("Only copy this to trusted websites, it can do ANYTHING on your behalf."));
				__builder.CloseElement();
				__builder.AddMarkupContent(30, "\n            ");
				__builder.OpenElement(31, "div");
				__builder.AddAttribute(32, "class", "bg-bg-dark border border-border rounded-md p-2 mt-1 flex items-start gap-2");
				__builder.OpenElement(33, "p");
				__builder.AddAttribute(34, "class", "text-[12px] break-all flex-1");
				__builder.AddContent(35, CurrentUser.JwtToken);
				__builder.CloseElement();
				__builder.AddMarkupContent(36, "\n                ");
				__builder.OpenElement(37, "button");
				__builder.AddAttribute(38, "class", "button shrink-0");
				__builder.AddAttribute(39, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Func<Task>)CopyJwtToken));
				__builder.AddAttribute(40, "title", T._("Copy to clipboard"));
				if (JwtTokenCopied)
				{
					__builder.AddMarkupContent(41, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1em\" height=\"1em\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M20 6 9 17l-5-5\"></path></svg>");
				}
				else
				{
					__builder.AddMarkupContent(42, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1em\" height=\"1em\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><rect width=\"14\" height=\"14\" x=\"8\" y=\"8\" rx=\"2\" ry=\"2\"></rect>\n                            <path d=\"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2\"></path></svg>");
				}
				__builder.CloseElement();
				__builder.CloseElement();
			}
			__builder.OpenComponent<Dialog>(43);
			__builder.AddComponentParameter(44, "Open", RuntimeHelpers.TypeCheck(WantsToRemoveAccount));
			__builder.AddComponentParameter(45, "OpenChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
			{
				DialogClosed(value);
			})));
			__builder.AddComponentParameter(46, "Class", "w-full max-w-md");
			__builder.AddAttribute(47, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder) =>
			{
				renderTreeBuilder.OpenElement(48, "p");
				renderTreeBuilder.AddContent(49, T._("Removing your account will delete all your data from our servers. This action cannot be undone."));
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.AddMarkupContent(50, "\n            ");
				renderTreeBuilder.OpenElement(51, "button");
				renderTreeBuilder.AddAttribute(52, "class", "button button-accent w-full! mt-3");
				renderTreeBuilder.AddAttribute(53, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Func<Task>)RemoveAccount));
				renderTreeBuilder.AddContent(54, T._("Confirm Account Removal"));
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.AddMarkupContent(55, "\n            ");
				renderTreeBuilder.OpenElement(56, "p");
				renderTreeBuilder.AddAttribute(57, "class", "description mt-2");
				renderTreeBuilder.AddContent(58, T._("Press anywhere outside the dialog to close it."));
				renderTreeBuilder.CloseElement();
			}));
			__builder.CloseComponent();
			__builder.OpenComponent<Dialog>(59);
			__builder.AddComponentParameter(60, "Open", RuntimeHelpers.TypeCheck(WantsToDisplayJwtToken));
			__builder.AddComponentParameter(61, "OpenChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
			{
				WantsToDisplayJwtToken = value;
				DisplayJwtToken = true;
			})));
			__builder.AddComponentParameter(62, "Class", "w-full max-w-md");
			__builder.AddAttribute(63, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder) =>
			{
				renderTreeBuilder.OpenElement(64, "p");
				renderTreeBuilder.AddContent(65, T._("If you're streaming or recording, now's the time to hide this window."));
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.AddMarkupContent(66, "\n            ");
				renderTreeBuilder.OpenElement(67, "p");
				renderTreeBuilder.AddAttribute(68, "class", "description mt-2");
				renderTreeBuilder.AddContent(69, T._("Press anywhere outside the dialog to close it."));
				renderTreeBuilder.CloseElement();
			}));
			__builder.CloseComponent();
		}
		else
		{
			__builder.OpenElement(70, "p");
			__builder.AddAttribute(71, "class", "description");
			__builder.AddContent(72, T._("You are not logged in. Open this page again to login."));
			__builder.CloseElement();
		}
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		if (CurrentUser == null || CurrentUser.JwtToken == null || DateTime.UtcNow >= CurrentUser.Expiry)
		{
			Navigation.NavigateTo("/settings/account/login");
		}
	}

	private async Task Logout()
	{
		try
		{
			if (!(await NetworkingClient.Current.UserClient.Logout(NetworkingSettings.Current.CurrentUser)))
			{
				Logger.Warn("Logout failed for user " + CurrentUser?.Username + ". Server did not acknowledge logout.", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Account\\Account.razor", 39);
				NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
				{
					Id = Guid.NewGuid().ToString(),
					Title = T._("Logout Failed"),
					Content = T._("Failed to log out. Please try again."),
					Level = NotificationLevel.Warning
				});
			}
			else
			{
				Logger.Info("User " + CurrentUser?.Username + " logged out successfully.", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Account\\Account.razor", 50);
				NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
				{
					Id = Guid.NewGuid().ToString(),
					Title = T._("Logout Successful"),
					Content = T._("You have successfully logged out."),
					Level = NotificationLevel.Success
				});
				NetworkingSettings.Current.CurrentUser = new User();
				NetworkingSettings.Current.Save();
			}
		}
		catch (Exception ex)
		{
			Logger.Error("An error occurred during logout for user " + CurrentUser?.Username + ": " + ex.Message, "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Account\\Account.razor", 64);
			NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
			{
				Id = Guid.NewGuid().ToString(),
				Title = T._("Logout Error"),
				Content = T._("An error occurred while trying to log out. Please try again later. Error: ") + ex.Message,
				Level = NotificationLevel.Danger
			});
		}
	}

	private async Task RemoveAccount()
	{
		try
		{
			if (!(await NetworkingClient.Current.UserClient.RemoveAccount(NetworkingSettings.Current.CurrentUser)))
			{
				Logger.Warn("Account removal failed for user " + CurrentUser?.Username + ". Server did not acknowledge removal.", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Account\\Account.razor", 83);
				NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
				{
					Id = Guid.NewGuid().ToString(),
					Title = T._("Account Removal Failed"),
					Content = T._("Failed to remove account. Please try again."),
					Level = NotificationLevel.Warning
				});
			}
			else
			{
				Logger.Info("User " + CurrentUser?.Username + " account removed successfully.", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Account\\Account.razor", 94);
				NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
				{
					Id = Guid.NewGuid().ToString(),
					Title = T._("Account Removed"),
					Content = T._("Your account has been successfully removed."),
					Level = NotificationLevel.Success
				});
				NetworkingSettings.Current.CurrentUser = new User();
				NetworkingSettings.Current.Save();
			}
		}
		catch (Exception ex)
		{
			Logger.Error("An error occurred during account removal for user " + CurrentUser?.Username + ": " + ex.Message, "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Account\\Account.razor", 108);
			NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
			{
				Id = Guid.NewGuid().ToString(),
				Title = T._("Account Removal Error"),
				Content = T._("An error occurred while trying to remove your account. Please try again later. Error: ") + ex.Message,
				Level = NotificationLevel.Danger
			});
		}
	}

	private void DialogClosed(bool value)
	{
		if (!value)
		{
			WantsToRemoveAccount = false;
		}
	}

	private async Task CopyJwtToken()
	{
		if (CurrentUser?.JwtToken == null)
		{
			return;
		}
		try
		{
			if (await JSRuntimeExtensions.InvokeAsync<bool>(JS, "copyToClipboard", new object[1] { CurrentUser.JwtToken }))
			{
				JwtTokenCopied = true;
				StateHasChanged();
				await Task.Delay(2000);
				JwtTokenCopied = false;
				StateHasChanged();
			}
		}
		catch (Exception ex)
		{
			Logger.Error("Failed to copy JWT token to clipboard: " + ex.Message, "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Account\\Account.razor", 148);
		}
	}
}
