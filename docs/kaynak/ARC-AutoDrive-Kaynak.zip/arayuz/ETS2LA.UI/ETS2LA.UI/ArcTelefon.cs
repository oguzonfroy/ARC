using System;
using System.Diagnostics;
using System.IO;

namespace ETS2LA.UI;

public static class ArcTelefon
{
	private const string Ad = "ARC Truck Phone";

	private static string Exe => Path.Combine(AppContext.BaseDirectory, "Telefon", "ARC Truck Phone.exe");

	public static bool Kurulu => File.Exists(Exe);

	public static bool Acik => Process.GetProcessesByName("ARC Truck Phone").Length != 0;

	public static bool Istek => ArcSurusAyar.TelefonAcilsin;

	public static void Degistir()
	{
		ArcSurusAyar.TelefonAcilsin = !ArcSurusAyar.TelefonAcilsin;
	}
}
