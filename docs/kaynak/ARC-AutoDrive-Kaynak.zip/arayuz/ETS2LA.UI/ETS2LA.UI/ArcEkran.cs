using System.Runtime.InteropServices;

namespace ETS2LA.UI;

internal static class ArcEkran
{
	[DllImport("user32.dll")]
	public static extern int GetSystemMetrics(int nIndex);
}
