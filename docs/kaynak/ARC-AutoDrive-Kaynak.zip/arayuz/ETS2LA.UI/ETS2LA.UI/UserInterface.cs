using System;
using System.Drawing;
using Photino.Blazor;
using Photino.NET;

namespace ETS2LA.UI;

public class UserInterface
{
	private static readonly Lazy<UserInterface> _instance = new Lazy<UserInterface>(() => new UserInterface());

	public static UserInterface Current => _instance.Value;

	public PhotinoWindow Window { get; private set; }

	[STAThread]
	public static void Start(string[] args)
	{
		string iconFile = "wwwroot/favicon.ico";
		if (!WindowSettings.Current.ArcBoyutV3 || WindowSettings.Current.Width < 800 || WindowSettings.Current.Height < 600)
		{
			int systemMetrics = ArcEkran.GetSystemMetrics(16);
			int systemMetrics2 = ArcEkran.GetSystemMetrics(17);
			int num = 1528;
			int num2 = 818;
			if (systemMetrics > 0 && num > systemMetrics - 40)
			{
				num = Math.Max(800, systemMetrics - 40);
			}
			if (systemMetrics2 > 0 && num2 > systemMetrics2 - 40)
			{
				num2 = Math.Max(600, systemMetrics2 - 40);
			}
			WindowSettings.Current.Width = num;
			WindowSettings.Current.Height = num2;
			WindowSettings.Current.ArcBoyutV3 = true;
			WindowSettings.Current.Save();
		}
		PhotinoBlazorAppBuilder photinoBlazorAppBuilder = PhotinoBlazorAppBuilder.CreateDefault(args);
		photinoBlazorAppBuilder.RootComponents.Add<App>("#app");
		PhotinoBlazorApp app = photinoBlazorAppBuilder.Build();
		app.MainWindow.SetTitle("ARC ETS2 Auto Drive").SetUserAgent("ETS2LA/3.X.X").SetIconFile(iconFile)
			.SetUseOsDefaultSize(useOsDefault: false)
			.SetUseOsDefaultLocation(useOsDefault: false)
			.SetMinSize(800, 600)
			.SetSize(WindowSettings.Current.Width, WindowSettings.Current.Height)
			.SetLogVerbosity(0)
			.SetZoom(WindowSettings.Current.Zoom)
			.RegisterWebMessageReceivedHandler((object? sender, string e) =>
			{
				IPC.HandleMessage(e, sender, app);
			})
			.SetChromeless(chromeless: true);
		app.MainWindow.Center();
		app.MainWindow.SetTopMost(WindowSettings.Current.StayOnTop);
		Current.Window = app.MainWindow;
		Current.Window.WindowSizeChanged += (object? sender, Size e) =>
		{
			if (e.Width >= 800 && e.Height >= 600)
			{
				WindowSettings.Current.Width = e.Width;
				WindowSettings.Current.Height = e.Height;
			}
		};
		Current.Window.WindowLocationChanged += (object? sender, Point e) =>
		{
			if (e.X > -10000 && e.Y > -10000)
			{
				WindowSettings.Current.X = e.X;
				WindowSettings.Current.Y = e.Y;
			}
		};
		app.Run();
		WindowSettings.Current.Save();
	}
}
