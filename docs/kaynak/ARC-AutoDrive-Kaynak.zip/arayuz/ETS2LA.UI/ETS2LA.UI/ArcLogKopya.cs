using System;
using System.Text.RegularExpressions;

namespace ETS2LA.UI;

/// <summary>Gösterge'deki "Log kopyala": üyenin Discord'a yapıştıracağı log metni. Kullanıcı adı gizlenir, çok uzunsa
/// en yeni kısmı kalır (sorun genelde sondadır).</summary>
public static class ArcLogKopya
{
	public const int EnFazla = 150_000;

	public static string Hazirla(string log, string kullaniciKlasoru, string kullaniciAdi, DateTime zaman)
	{
		log ??= string.Empty;
		bool kesildi = log.Length > EnFazla;
		if (kesildi)  // gizlemeden önce kes: uzun oturumda bütün dosya işlenmesin (gizleme metni yalnız kısaltır)
		{
			log = log.Substring(log.Length - EnFazla);
			int satir = log.IndexOf('\n');
			if (satir >= 0)
			{
				log = log.Substring(satir + 1);  // yarım satırla başlamasın
			}
		}
		if (!string.IsNullOrEmpty(kullaniciKlasoru))
		{
			log = log.Replace(kullaniciKlasoru, "~", StringComparison.OrdinalIgnoreCase);
		}
		log = Regex.Replace(log, "(?i)([A-Z]:[\\\\/]+Users[\\\\/]+)[^\\\\/\\r\\n\"']+", "$1<user>");
		// D:\AliVeli\SteamLibrary gibi başka yerlerdeki ad; kısa adlar (ör. "ali") sıradan kelimeleri bozmasın
		if (kullaniciAdi != null && kullaniciAdi.Length >= 3)
		{
			log = Regex.Replace(log, "(?<![\\w])" + Regex.Escape(kullaniciAdi) + "(?![\\w])", "<user>", RegexOptions.IgnoreCase);
		}
		return $"ARC ETS2 Auto Drive log | {zaman:yyyy-MM-dd HH:mm:ss}{(kesildi ? " | yalnız son kısım" : "")}\n" + log;
	}
}
