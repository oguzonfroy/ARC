using System;
using ETS2LA.Settings;

namespace ETS2LA.UI;

[Serializable]
public class WindowSettings
{
	public int X;

	public int Y;

	public int Width = 1280;

	public int Height = 720;

	public int Zoom = 100;

	public bool StayOnTop = true;

	public bool AllowWayland;

	public int OnboardingStep;

	public bool HasCompletedOnboarding;

	public bool ShowPluginUpdates = true;

	public bool OnlyFromOfficialUsers = true;

	public bool TranslateNews = true;

	public bool ClickSound = true;

	public bool ArcIntroSeen;

	public bool ArcBoyutV2;

	public bool ArcBoyutV3;

	public string TruckersMPPath = "";

	[NonSerialized]
	private static readonly Lazy<WindowSettings> _instance = new Lazy<WindowSettings>(() => new WindowSettings(loadSettings: true));

	[NonSerialized]
	private SettingsHandler? _settingsHandler;

	public static WindowSettings Current => _instance.Value;

	public WindowSettings(bool loadSettings = false)
	{
		if (!loadSettings)
		{
			return;
		}
		_settingsHandler = new SettingsHandler();
		WindowSettings windowSettings = _settingsHandler.Load<WindowSettings>("WindowSettings.json");
		if (windowSettings != null)
		{
			X = windowSettings.X;
			Y = windowSettings.Y;
			if (X < 0 || Y < 0)
			{
				X = 0;
				Y = 0;
			}
			Width = windowSettings.Width;
			Height = windowSettings.Height;
			Zoom = windowSettings.Zoom;
			StayOnTop = windowSettings.StayOnTop;
			AllowWayland = windowSettings.AllowWayland;
			OnboardingStep = windowSettings.OnboardingStep;
			HasCompletedOnboarding = windowSettings.HasCompletedOnboarding;
			ShowPluginUpdates = windowSettings.ShowPluginUpdates;
			OnlyFromOfficialUsers = windowSettings.OnlyFromOfficialUsers;
			TranslateNews = windowSettings.TranslateNews;
			ClickSound = windowSettings.ClickSound;
			ArcIntroSeen = windowSettings.ArcIntroSeen;
			ArcBoyutV2 = windowSettings.ArcBoyutV2;
			ArcBoyutV3 = windowSettings.ArcBoyutV3;
			TruckersMPPath = windowSettings.TruckersMPPath;
		}
		_settingsHandler.RegisterListener<WindowSettings>("WindowSettings.json", OnSettingsChanged);
	}

	public WindowSettings()
	{
	}

	public void Save()
	{
		_settingsHandler?.Save("WindowSettings.json", this);
	}

	public void OnSettingsChanged(WindowSettings newSettings)
	{
		X = newSettings.X;
		Y = newSettings.Y;
		Width = newSettings.Width;
		Height = newSettings.Height;
		Zoom = newSettings.Zoom;
		StayOnTop = newSettings.StayOnTop;
		AllowWayland = newSettings.AllowWayland;
		OnboardingStep = newSettings.OnboardingStep;
		HasCompletedOnboarding = newSettings.HasCompletedOnboarding;
		ShowPluginUpdates = newSettings.ShowPluginUpdates;
		OnlyFromOfficialUsers = newSettings.OnlyFromOfficialUsers;
		TranslateNews = newSettings.TranslateNews;
		ClickSound = newSettings.ClickSound;
		ArcIntroSeen = newSettings.ArcIntroSeen;
		ArcBoyutV2 = newSettings.ArcBoyutV2;
		ArcBoyutV3 = newSettings.ArcBoyutV3;
		TruckersMPPath = newSettings.TruckersMPPath;
	}
}
