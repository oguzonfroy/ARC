using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using ETS2LA.Backend;
using ETS2LA.Controls;
using ETS2LA.Logging;
using ETS2LA.Notifications;
using ETS2LA.Shared;
using ETS2LA.State;
using Microsoft.Win32;
using Photino.NET;

namespace ETS2LA.UI;

public static class ArcHub
{
	private record LisansCevabi(string? status, DateTimeOffset? expires_at, DateTimeOffset now);

	private static readonly string OturumDosyasi = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ARC Studio", "ets2_oturum.key");

	private static readonly string[] LauncherAdlari = new string[2] { "TruckersMP-Launcher.exe", "Launcher.exe" };

	private const string LisansAdresi = "https://vzibpccxwknhakzgmxfy.supabase.co/rest/v1/rpc/license_status";

	private const string LisansApiAnahtari = "<ANAHTAR>";

	private const int LisansKontrolMs = 60000;

	private const int LisansKilitliKontrolMs = 15000;

	private const long LisansCevrimdisiMs = 1800000L;

	private static List<IPlugin> kilitteKapatilan = new List<IPlugin>();

	public static string[]? HubKomutu { get; } = KomutuOku();

	public static ControlDefinition Menu { get; } = new ControlDefinition
	{
		Id = "ARC.Menu",
		Name = "ARC Menü",
		Description = "Oyun içindeyken ETS2 Auto Drive penceresini gösterir ve gizler.",
		DefaultKeybind = "Insert",
		Type = ControlType.Boolean
	};

	private static string[]? KomutuOku()
	{
		try
		{
			return JsonSerializer.Deserialize<string[]>(Environment.GetEnvironmentVariable("ARC_HUB_KOMUTU") ?? "");
		}
		catch
		{
			return null;
		}
	}

	public static string? TruckersMpBul()
	{
		List<string> list = new List<string> { Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TruckersMP") };
		RegistryKey[] array = new RegistryKey[2]
		{
			Registry.CurrentUser,
			Registry.LocalMachine
		};
		RegistryKey[] array2 = array;
		foreach (RegistryKey registryKey in array2)
		{
			string[] array3 = new string[2] { "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall", "Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall" };
			string[] array4 = array3;
			foreach (string name in array4)
			{
				using RegistryKey registryKey2 = registryKey.OpenSubKey(name);
				string[] array5 = registryKey2?.GetSubKeyNames() ?? Array.Empty<string>();
				string[] array6 = array5;
				foreach (string name2 in array6)
				{
					using RegistryKey registryKey3 = registryKey2.OpenSubKey(name2);
					if (registryKey3?.GetValue("DisplayName") is string text && text.Contains("TruckersMP", StringComparison.OrdinalIgnoreCase) && registryKey3.GetValue("InstallLocation") is string { Length: >0 } text2)
					{
						list.Add(text2);
					}
				}
			}
		}
		Environment.SpecialFolder[] array7 = new Environment.SpecialFolder[2]
		{
			Environment.SpecialFolder.ProgramFiles,
			Environment.SpecialFolder.ProgramFilesX86
		};
		Environment.SpecialFolder[] array8 = array7;
		foreach (Environment.SpecialFolder folder in array8)
		{
			list.Add(Path.Combine(Environment.GetFolderPath(folder), "TruckersMP Launcher"));
		}
		string truckersMPPath = WindowSettings.Current.TruckersMPPath;
		if (File.Exists(truckersMPPath))
		{
			return truckersMPPath;
		}
		return list.SelectMany((string path) => LauncherAdlari.Select((string a) => Path.Combine(path, a))).FirstOrDefault(File.Exists);
	}

	public static bool HubdanAcildi()
	{
		string environmentVariable = Environment.GetEnvironmentVariable("ARC_OTURUM");
		try
		{
			return !string.IsNullOrEmpty(environmentVariable) && File.ReadAllText(OturumDosyasi).Trim() == environmentVariable;
		}
		catch
		{
			return false;
		}
	}

	public static void OyunDegistir()
	{
		string[] hubKomutu = HubKomutu;
		if (hubKomutu == null || hubKomutu.Length == 0)
		{
			return;
		}
		ProcessStartInfo processStartInfo = new ProcessStartInfo(HubKomutu[0])
		{
			UseShellExecute = false
		};
		foreach (string item in HubKomutu.Skip(1))
		{
			processStartInfo.ArgumentList.Add(item);
		}
		processStartInfo.ArgumentList.Add("--hub");
		Process.Start(processStartInfo);
		PhotinoWindow pencere = UserInterface.Current.Window;
		pencere?.Invoke(() =>
		{
			pencere.Close();
		});
	}

	public static void LisansIzlemeyiBaslat()
	{
		string key = Environment.GetEnvironmentVariable("ARC_LISANS");
		string cihaz = Environment.GetEnvironmentVariable("ARC_CIHAZ");
		if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(cihaz))
		{
			ArcLisans.Ayarla(kilitli: true, "invalid");
			Thread thread = new Thread(KilitUygula);
			thread.IsBackground = true;
			thread.Start();
		}
		else
		{
			Task.Factory.StartNew(() =>
			{
				LisansIzle(key, cihaz);
			}, TaskCreationOptions.LongRunning);
		}
	}

	private static void LisansIzle(string key, string cihaz)
	{
		using HttpClient httpClient = new HttpClient
		{
			Timeout = TimeSpan.FromSeconds(10L)
		};
		string content = JsonSerializer.Serialize(new
		{
			p_key = key,
			p_hwid = cihaz
		});
		long? bitis = null;
		string sunucuSebebi = null;
		long sonDogrulama = Environment.TickCount64;
		long num = 0L;
		while (true)
		{
			long tickCount = Environment.TickCount64;
			if (tickCount >= num)
			{
				try
				{
					using HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, "https://vzibpccxwknhakzgmxfy.supabase.co/rest/v1/rpc/license_status")
					{
						Content = new StringContent(content, Encoding.UTF8, "application/json")
					};
					httpRequestMessage.Headers.Add("apikey", "<ANAHTAR>");
					using HttpResponseMessage httpResponseMessage = httpClient.Send(httpRequestMessage);
					httpResponseMessage.EnsureSuccessStatusCode();
					using Stream utf8Json = httpResponseMessage.Content.ReadAsStream();
					LisansCevabi lisansCevabi = JsonSerializer.Deserialize<LisansCevabi>(utf8Json) ?? throw new JsonException("boş cevap");
					tickCount = Environment.TickCount64;
					sonDogrulama = tickCount;
					if (lisansCevabi.status == "ok")
					{
						sunucuSebebi = null;
						DateTimeOffset? expires_at = lisansCevabi.expires_at;
						long? num2;
						if (expires_at.HasValue)
						{
							DateTimeOffset valueOrDefault = expires_at.GetValueOrDefault();
							num2 = tickCount + (long)(valueOrDefault - lisansCevabi.now).TotalMilliseconds;
						}
						else
						{
							num2 = null;
						}
						bitis = num2;
					}
					else
					{
						string status = lisansCevabi.status;
						if (status == "expired" || status == "invalid")
						{
							sunucuSebebi = lisansCevabi.status;
							bitis = tickCount;
						}
					}
				}
				catch (Exception ex) when (((ex is HttpRequestException || ex is TaskCanceledException || ex is JsonException || ex is InvalidOperationException) ? 1 : 0) != 0)
				{
				}
				num = Environment.TickCount64 + (ArcLisans.Kilitli ? 15000 : 60000);
			}
			tickCount = Environment.TickCount64;
			string text = ArcLisans.Karar(tickCount, bitis, sunucuSebebi, sonDogrulama, 1800000L);
			bool kilitli = ArcLisans.Kilitli;
			ArcLisans.Ayarla(text != null, text);
			if (!kilitli && ArcLisans.Kilitli)
			{
				KilitUygula();
			}
			else if (kilitli && !ArcLisans.Kilitli)
			{
				KilidiAc();
			}
			Thread.Sleep(1000);
		}
	}

	private static void KilitUygula()
	{
		try
		{
			ApplicationState.Current.SetAssistsEnabled(enabled: false);
		}
		catch (Exception ex)
		{
			Logger.Error("ARC lisans: otonom kapatılamadı: " + ex.Message, "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\ArcHub.cs", 167);
		}
		PluginHandler pluginHandler = PluginBackend.Current.PluginHandler;
		if (pluginHandler != null)
		{
			kilitteKapatilan = pluginHandler.LoadedPlugins.Where((IPlugin p) => p._IsRunning && !p.Info.HideEnableDisableButton).ToList();
			foreach (IPlugin item in kilitteKapatilan)
			{
				pluginHandler.DisablePlugin(item, null, kaydet: false);
			}
		}
		Logger.Warn($"ARC lisans kilitlendi ({ArcLisans.Sebep}); {kilitteKapatilan.Count} özellik kapatıldı.", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\ArcHub.cs", 175);
		NotificationHandler.Current.SendNotification(new Notification
		{
			Id = "ARC.Lisans",
			Title = "Lisans kilidi",
			Content = ArcLisans.Mesaj,
			Level = NotificationLevel.Danger,
			CloseAfter = 0f
		});
	}

	private static void KilidiAc()
	{
		PluginHandler pluginHandler = PluginBackend.Current.PluginHandler;
		foreach (IPlugin item in kilitteKapatilan)
		{
			pluginHandler?.EnablePlugin(item, null, kaydet: false);
		}
		kilitteKapatilan = new List<IPlugin>();
		Logger.Info("ARC lisans kilidi açıldı.", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\ArcHub.cs", 192);
		NotificationHandler.Current.CloseNotification("ARC.Lisans");
		NotificationHandler.Current.SendNotification(new Notification
		{
			Id = "ARC.Lisans.Acildi",
			Title = "Lisans yenilendi",
			Content = "Tüm özellikler yeniden açıldı. İyi yolculuklar!",
			Level = NotificationLevel.Success,
			CloseAfter = 6f
		});
	}

	[DllImport("user32.dll")]
	private static extern bool SetForegroundWindow(nint hWnd);

	public static void MenuTusunuBagla()
	{
		ControlsBackend.Current.RegisterControl(Menu);
		ControlsBackend.Current.On(Menu.Id, (object? _, ControlChangeEventArgs e) =>
		{
			if ((bool)e.NewValue)
			{
				PhotinoWindow pencere = UserInterface.Current.Window;
				pencere?.Invoke(() =>
				{
					if (pencere.Minimized)
					{
						pencere.SetMinimized(minimized: false);
						pencere.SetTopMost(topMost: true);
						SetForegroundWindow(pencere.WindowHandle);
					}
					else
					{
						pencere.SetTopMost(WindowSettings.Current.StayOnTop);
						pencere.SetMinimized(minimized: true);
					}
				});
			}
		});
	}
}
