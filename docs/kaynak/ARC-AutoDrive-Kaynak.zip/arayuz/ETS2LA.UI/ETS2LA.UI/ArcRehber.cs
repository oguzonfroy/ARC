namespace ETS2LA.UI;

public static class ArcRehber
{
	public record Adim(string Baslik, string Aciklama, string[] Maddeler, string? Yol, string? Dugme);

	public static readonly Adim[] Adimlar = new Adim[5]
	{
		new Adim("Hoş geldin!", "ETS2 Auto Drive tırını senin yerine sürer: şeridi takip eder, hızı ayarlar ve rotana göre döner. Başlamadan önce birkaç şeyi bir kez kurman gerekiyor, 2 dakikanı alır.", new string[2] { "Bu tanıtımı istediğin an \"Atla\" ile geçebilirsin.", "Adımları sonra yan menüdeki \"Nasıl Kurulur\" sayfasında da bulursun." }, null, null),
		new Adim("1. Oyun eklentisini kur", "Program oyunla bu eklenti sayesinde konuşur. Oyun kapalıyken bir kez kurman yeterli.", new string[4] { "Oyunu (ETS2 / ATS) kapat.", "Ayarlar → Oyun SDK'sı sayfasını aç.", "Oyununun yanındaki \"SDK'ları Kur\" düğmesine bas.", "Oyun güncellenirse bu adımı tekrarla." }, "/settings/sdk", "Oyun SDK'sını aç"),
		new Adim("2. Sürüş bileşenleri kendiliğinden hazırlanır", "Direksiyonu, hızı ve rotayı yöneten parçaları ARC ilk açılışta kendisi indirir ve açar. Senin bir şey yapman gerekmez.", new string[3] { "İlk açılışta sağ altta \"Sürüş bileşenleri hazırlanıyor\" bildirimi çıkar, birkaç saniye bekle.", "\"Sürüş bileşenleri hazır\" yazınca bu adım tamamdır.", "\"Bazı bileşenler indirilemedi\" derse internet bağlantını kontrol edip ETS2 Auto Drive'ı yeniden başlat." }, "/", "Gösterge Paneli'ne git"),
		new Adim("3. Özellikleri istediğin gibi aç", "ARC Vision, yol yönlendirme okları ve Discord durumu Gösterge Paneli'nden açılıp kapanır; seçimin hatırlanır.", new string[2] { "Gösterge Paneli > Sürüş bölümündeki düğmelerle her özelliği ayrı aç ya da kapat.", "Ayarlar > Klavye Kısayolları'ndan tuşlarını değiştirebilirsin: F6 otonom sürüş, F7 ARC Vision, F8 yol okları, F10 acil durdurma." }, "/settings/controls", "Klavye kısayollarını aç"),
		new Adim("4. Yola çık", "Her şey hazır. Oyunda sürüşü şöyle başlatırsın:", new string[4] { "Oyunu aç, haritadan (M) gideceğin yere rota ver.", "Tırı bir şeridin ortasına al.", "Gösterge Paneli'nden sürüş modunu seç ve \"Sürüşü başlat\"a bas (ya da oyunda ↓).", "Durdurmak için ← tuşu. Insert ile bu pencereyi oyunun içinde gösterip gizlersin." }, "/", "Gösterge Paneli'ne git")
	};
}
