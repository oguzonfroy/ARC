namespace ETS2LA.UI;

public class _Imports
{
	protected void Execute()
	{
	}
}
