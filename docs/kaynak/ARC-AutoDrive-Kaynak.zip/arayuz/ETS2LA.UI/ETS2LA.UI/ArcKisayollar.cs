using System.Linq;
using ETS2LA.Backend;
using ETS2LA.Controls;
using ETS2LA.Notifications;
using ETS2LA.Overlay;
using ETS2LA.Shared;
using ETS2LA.State;

namespace ETS2LA.UI;

public static class ArcKisayollar
{
	public const string ArcVisionEklentisi = "tumppi066.internalvisualization";

	public static ControlDefinition AcilDurdur { get; } = new ControlDefinition
	{
		Id = "ARC.Shortcut.EmergencyStop",
		Name = "Acil Durdurma",
		Description = "Otonom sürüşü anında kapatır; direksiyon, gaz ve fren kontrolü hemen sana geçer. Diğer kısayollardan önce ve her durumda çalışır.",
		DefaultKeybind = "F10"
	};

	public static ControlDefinition OtonomSurus { get; } = new ControlDefinition
	{
		Id = "ARC.Shortcut.Autopilot",
		Name = "Otonom Sürüş",
		Description = "Otonom sürüşü açar ya da kapatır. Gösterge Paneli'nde seçili sürüş modu kullanılır.",
		DefaultKeybind = "F6"
	};

	public static ControlDefinition ArcVision { get; } = new ControlDefinition
	{
		Id = "ARC.Shortcut.ArcVision",
		Name = "ARC Vision",
		Description = "Yol geometrisini, şeritleri ve tırın konumunu canlı gösteren ARC Vision penceresini açar ya da kapatır. Otonom sürüşü başlatmaz.",
		DefaultKeybind = "F7"
	};

	public static ControlDefinition YolOklari { get; } = new ControlDefinition
	{
		Id = "ARC.Shortcut.RoadArrows",
		Name = "Yol Yönlendirme Okları",
		Description = "GPS rotasını yolun üstünde gösteren okları açar ya da kapatır. Yalnız görseldir, otonom sürüşü başlatmaz.",
		DefaultKeybind = "F8"
	};

	public static void Bagla()
	{
		ControlsBackend current = ControlsBackend.Current;
		current.RegisterControl(AcilDurdur);
		current.On(AcilDurdur.Id, (object? _, ControlChangeEventArgs e) =>
		{
			if ((bool)e.NewValue && ApplicationState.Current.EnableAssists)
			{
				ApplicationState.Current.SetAssistsEnabled(enabled: false);
				Bildir("Acil durdurma", "Otonom sürüş kapatıldı, kontrol sende.", NotificationLevel.Warning);
			}
		});
		current.RegisterControl(OtonomSurus);
		current.On(OtonomSurus.Id, (object? _, ControlChangeEventArgs e) =>
		{
			if ((bool)e.NewValue)
			{
				bool flag = !ApplicationState.Current.EnableAssists;
				ApplicationState.Current.SetAssistsEnabled(flag);
				Bildir("Otonom sürüş", flag ? "Açıldı." : "Kapatıldı, kontrol sende.");
			}
		});
		current.RegisterControl(ArcVision);
		current.On(ArcVision.Id, (object? _, ControlChangeEventArgs e) =>
		{
			if ((bool)e.NewValue)
			{
				PluginHandler pluginHandler = PluginBackend.Current.PluginHandler;
				IPlugin plugin = pluginHandler?.LoadedPlugins.FirstOrDefault((IPlugin p) => p.Info.Id == "tumppi066.internalvisualization");
				if (pluginHandler == null || plugin == null)
				{
					Bildir("ARC Vision", "ARC Vision yüklenemedi. ETS2 Auto Drive'ı yeniden başlatmayı dene.", NotificationLevel.Danger);
				}
				else
				{
					bool flag = !plugin._IsRunning;
					if (flag ? pluginHandler.EnablePlugin(plugin) : pluginHandler.DisablePlugin(plugin))
					{
						Bildir("ARC Vision", flag ? "Açıldı." : "Kapatıldı.");
					}
				}
			}
		});
		current.RegisterControl(YolOklari);
		current.On(YolOklari.Id, (object? _, ControlChangeEventArgs e) =>
		{
			if ((bool)e.NewValue)
			{
				OverlaySettings settings = OverlaySettingsHandler.Current.GetSettings();
				settings.ShowRoadArrows = !settings.ShowRoadArrows;
				OverlaySettingsHandler.Current.Save();
				Bildir("Yol yönlendirme okları", settings.ShowRoadArrows ? "Açıldı." : "Kapatıldı.");
			}
		});
	}

	private static void Bildir(string baslik, string icerik, NotificationLevel seviye = NotificationLevel.Information)
	{
		NotificationHandler.Current.SendNotification(new Notification
		{
			Id = "ARC.Shortcut." + baslik,
			Title = baslik,
			Content = icerik,
			Level = seviye,
			CloseAfter = 2f
		});
	}
}
