using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ETS2LA.Backend;
using ETS2LA.Backend.Plugins;
using ETS2LA.Logging;
using ETS2LA.Networking;
using ETS2LA.Networking.Plugins;
using ETS2LA.Notifications;
using ETS2LA.Shared;

namespace ETS2LA.UI;

public static class ArcOtomatikKurulum
{
	public static readonly string[] Gerekli = new string[5] { "tumppi066.pathfinding", "tumppi066.laneassist", "tumppi066.adaptivecruisecontrol", "tumppi066.visualizationsockets", "tumppi066.internalvisualization" };

	private const string BildirimId = "ARC.AutoInstall";

	public static void Baslat()
	{
		Task.Run(async () =>
		{
			try
			{
				await Calistir();
			}
			catch (Exception value)
			{
				Logger.Error($"ARC otomatik kurulum: {value}", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\ArcOtomatikKurulum.cs", 32);
				Bildir("Sürüş bileşenleri kurulamadı", "Beklenmeyen bir hata oldu. ETS2 Auto Drive'ı yeniden başlat; sorun sürerse bize ulaş.", NotificationLevel.Danger, 12f);
			}
		});
	}

	private static async Task Calistir()
	{
		for (int i = 0; i < 180; i++)
		{
			PluginHandler pluginHandler = PluginBackend.Current.PluginHandler;
			if (PluginBackend.Current.IsLoaded && pluginHandler != null && !pluginHandler.loading)
			{
				break;
			}
			await Task.Delay(1000);
		}
		PluginHandler handler = PluginBackend.Current.PluginHandler;
		if (handler == null)
		{
			return;
		}
		List<string> eksik = Gerekli.Where((string text3) => !handler.LoadedPlugins.Any((IPlugin p) => p.Info.Id == text3)).ToList();
		if (eksik.Count == 0)
		{
			return;
		}
		Logger.Info("ARC otomatik kurulum: eksik bileşenler indiriliyor: " + string.Join(", ", eksik), "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\ArcOtomatikKurulum.cs", 52);
		Bildir("Sürüş bileşenleri hazırlanıyor", "Gerekli parçalar indiriliyor, bu bir kez yapılır. Birkaç saniye sürebilir.", NotificationLevel.Information, 0f, ilerleme: true);
		PluginApiClient ag = NetworkingClient.Current.Plugins;
		if (ag.AvailablePlugins.Count == 0)
		{
			await ag.FetchAvailablePluginsAsync();
		}
		HashSet<string> onceki = InstalledPluginManifest.Current.InstalledPlugins.Select((InstalledPlugin p) => p.DllPath).ToHashSet(StringComparer.OrdinalIgnoreCase);
		List<string> list = new List<string>();
		foreach (string id in eksik)
		{
			if (!InstalledPluginManifest.Current.InstalledPlugins.Any((InstalledPlugin p) => p.Id == id) && !ag.InstallPlugin(id))
			{
				list.Add(id);
			}
		}
		foreach (string item in eksik)
		{
			string path = Path.Combine(AppContext.BaseDirectory, "ArcYamalari", item);
			string text = Path.Combine(AppContext.BaseDirectory, "Plugins", item);
			if (Directory.Exists(path) && Directory.Exists(text))
			{
				string[] files = Directory.GetFiles(path);
				foreach (string text2 in files)
				{
					File.Copy(text2, Path.Combine(text, Path.GetFileName(text2)), overwrite: true);
				}
			}
		}
		List<InstalledPlugin> source = InstalledPluginManifest.Current.InstalledPlugins.Where((InstalledPlugin p) => !onceki.Contains(p.DllPath)).ToList();
		foreach (InstalledPlugin item2 in source.Where((InstalledPlugin p) => p.Type == PluginType.Library))
		{
			handler.LoadLibraryFile(item2.DllPath);
		}
		foreach (InstalledPlugin item3 in source.Where((InstalledPlugin p) => p.Type == PluginType.Plugin))
		{
			handler.LoadPluginFile(item3.DllPath);
		}
		handler.EnableRememberedPlugins();
		NotificationHandler.Current.CloseNotification("ARC.AutoInstall");
		if (list.Count == 0)
		{
			Bildir("Sürüş bileşenleri hazır", "Gerekli parçalar kuruldu ve açıldı. Sürüşü Gösterge Paneli'nden başlatabilirsin.", NotificationLevel.Success, 6f);
			return;
		}
		Logger.Warn("ARC otomatik kurulum: indirilemedi: " + string.Join(", ", list), "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\ArcOtomatikKurulum.cs", 83);
		Bildir("Bazı bileşenler indirilemedi", "İnternet bağlantını kontrol edip ETS2 Auto Drive'ı yeniden başlat; eksikler kendiliğinden tekrar indirilir.", NotificationLevel.Warning, 15f);
	}

	private static void Bildir(string baslik, string icerik, NotificationLevel seviye, float kapanma, bool ilerleme = false)
	{
		NotificationHandler.Current.SendNotification(new Notification
		{
			Id = "ARC.AutoInstall",
			Title = baslik,
			Content = icerik,
			Level = seviye,
			CloseAfter = kapanma,
			IsProgressIndeterminate = ilerleme
		});
	}
}
