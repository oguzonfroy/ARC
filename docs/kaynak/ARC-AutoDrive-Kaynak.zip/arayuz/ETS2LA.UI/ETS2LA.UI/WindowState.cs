using System;

namespace ETS2LA.UI;

public class WindowState
{
	private static readonly Lazy<WindowState> _instance = new Lazy<WindowState>(() => new WindowState());

	public static WindowState Current => _instance.Value;

	public bool IsSidebarOpen { get; set; } = true;

	public event EventHandler? NeedsFullReload;

	public void RequestFullReload()
	{
		NeedsFullReload?.Invoke(this, EventArgs.Empty);
	}
}
