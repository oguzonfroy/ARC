using System;
using System.Globalization;
using System.Threading.Tasks;
using ETS2LA.Backend;
using ETS2LA.Backend.Events;
using ETS2LA.UI.Pages;
using ETS2LA.UI.Shared.Layouts;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Routing;
using Microsoft.JSInterop;

namespace ETS2LA.UI;

public class App : ComponentBase
{
	private int key;

	private string currentLang = CultureInfo.CurrentCulture.Name;

	[Inject]
	private NavigationManager NavigationManager { get; set; }

	[Inject]
	private IJSRuntime JSRuntime { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenComponent<Router>(0);
		__builder.AddComponentParameter(1, "AppAssembly", RuntimeHelpers.TypeCheck(typeof(App).Assembly));
		__builder.AddComponentParameter(2, "AdditionalAssemblies", RuntimeHelpers.TypeCheck(PluginBackend.Current.PluginHandler?.PluginAssemblies));
		__builder.AddAttribute(3, "Found", (RenderFragment<RouteData>)((RouteData routeData) => (RenderTreeBuilder renderTreeBuilder) =>
		{
			renderTreeBuilder.OpenComponent<RouteView>(4);
			renderTreeBuilder.AddComponentParameter(5, "RouteData", RuntimeHelpers.TypeCheck(routeData));
			renderTreeBuilder.AddComponentParameter(6, "DefaultLayout", RuntimeHelpers.TypeCheck(typeof(MainLayout)));
			renderTreeBuilder.CloseComponent();
		}));
		__builder.AddAttribute(7, "NotFound", (RenderFragment)((RenderTreeBuilder renderTreeBuilder) =>
		{
			renderTreeBuilder.OpenComponent<LayoutView>(8);
			renderTreeBuilder.AddComponentParameter(9, "Layout", RuntimeHelpers.TypeCheck(typeof(MainLayout)));
			renderTreeBuilder.AddAttribute(10, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder2) =>
			{
				renderTreeBuilder2.OpenComponent<Error>(11);
				renderTreeBuilder2.AddComponentParameter(12, "StatusCode", RuntimeHelpers.TypeCheck(404));
				renderTreeBuilder2.AddComponentParameter(13, "Message", "Not Found");
				renderTreeBuilder2.CloseComponent();
			}));
			renderTreeBuilder.CloseComponent();
		}));
		__builder.SetKey(key);
		__builder.CloseComponent();
	}

	protected override void OnInitialized()
	{
		PluginBackend current = PluginBackend.Current;
		current.OnBackendLoaded = (Action)Delegate.Combine(current.OnBackendLoaded, new Action(HandlePluginsReloaded));
		Events.Current.Subscribe("ETS2LA.UI.Navigate", (string data) =>
		{
			InvokeAsync(() =>
			{
				NavigationManager.NavigateTo(data);
			});
		});
	}

	protected override async Task OnAfterRenderAsync(bool firstRender)
	{
		await JSRuntime.InvokeVoidAsync("eval", "document.documentElement.lang = '" + currentLang + "'");
	}

	private void HandlePluginsReloaded()
	{
		key++;
		InvokeAsync((Action)StateHasChanged);
	}

	public void Dispose()
	{
		PluginBackend current = PluginBackend.Current;
		current.OnBackendLoaded = (Action)Delegate.Remove(current.OnBackendLoaded, new Action(HandlePluginsReloaded));
	}
}
