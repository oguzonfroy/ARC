using System;
using System.Linq;

namespace ETS2LA.UI;

/// <summary>
///  Gösterge'deki "Fren ve sinyal ışığı" anahtarı: oyundaki eklentinin (arclight.dll) ayar dosyasındaki
///  <c>tepki</c> satırı. Açıkken frende kabin kırmızı, sinyalde o tarafı turuncu yanıp söner.
///  Bu dosya saf metin işidir (testte derlenir); dosyaya yazma <c>ArcKabinTepki.Dosya.cs</c>'tedir.
/// </summary>
public static partial class ArcKabinTepki
{
	/// <summary>Genel bölümdeki (ilk <c>[isik]</c>'tan önce) satırlar, yorumsuz.</summary>
	private static string[] Genel(string metin) =>
		(metin ?? "").Split('\n').Select(s => s.Split('#')[0].Trim())
			.TakeWhile(s => !s.StartsWith("[", StringComparison.Ordinal)).ToArray();

	private static bool TepkiSatiri(string s) => s.Split((char[])null, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() == "tepki";

	public static bool Acik(string metin) =>
		Genel(metin).Where(TepkiSatiri).Select(s => s.Split((char[])null, StringSplitOptions.RemoveEmptyEntries)).LastOrDefault() is { Length: >= 2 } w
		&& w[1] != "0";

	/// <summary>Eski <c>tepki</c> satırlarını kaldırıp yenisini en başa koyar; diğer satırlara dokunmaz.</summary>
	public static string Yaz(string metin, bool acik)
	{
		var satirlar = (metin ?? "").Split('\n').ToList();
		var genelSonu = satirlar.FindIndex(s => s.Trim().StartsWith("[", StringComparison.Ordinal));
		if (genelSonu < 0) genelSonu = satirlar.Count;
		for (var i = genelSonu - 1; i >= 0; i--)
			if (TepkiSatiri(satirlar[i].Split('#')[0].Trim())) satirlar.RemoveAt(i);
		satirlar.Insert(0, "tepki " + (acik ? 1 : 0));
		return string.Join("\n", satirlar);
	}
}
