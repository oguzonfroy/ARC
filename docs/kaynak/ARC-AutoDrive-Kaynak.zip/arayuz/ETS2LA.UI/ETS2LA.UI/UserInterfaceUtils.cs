using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using ETS2LA.Logging;
using ETS2LA.Translations;
using Photino.NET;

namespace ETS2LA.UI;

public static class UserInterfaceUtils
{
	public static string ClassnameWithSpaces(string option)
	{
		return Regex.Replace(option, "(?<=[a-z])(?=[A-Z])|(?<=[A-Za-z])(?=[0-9])|(?<=[A-Z])(?=[A-Z][a-z])", " ");
	}

	public static void OpenUrl(string url)
	{
		try
		{
			Process.Start(url);
		}
		catch
		{
			if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
			{
				url = url.Replace("&", "^&");
				Process.Start(new ProcessStartInfo(url)
				{
					UseShellExecute = true
				});
				return;
			}
			if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
			{
				Process.Start("xdg-open", url);
				return;
			}
			if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
			{
				Process.Start("open", url);
				return;
			}
			throw;
		}
	}

	public static PhotinoDialogResult ShowMessageOnTop(this PhotinoWindow window, string title, string text, PhotinoDialogButtons buttons = PhotinoDialogButtons.Ok, PhotinoDialogIcon icon = PhotinoDialogIcon.Info)
	{
		return window.ShowMessage(title, text, buttons, icon);
	}

	public static void AskForRestart(string title, string message)
	{
		if (UserInterface.Current.Window.ShowMessageOnTop(T._("Restart Required"), T._("Changing this option requires a restart of ETS2LA to take effect. Restart now?"), PhotinoDialogButtons.YesNo) == PhotinoDialogResult.Yes)
		{
			Restart();
		}
	}

	public static void Restart()
	{
		Logger.Info(T._("Restarting ETS2LA..."), "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Utils.cs", 84);
		UserInterface.Current.Window.Close();
		using Process process = Process.GetCurrentProcess();
		Process.Start(new ProcessStartInfo
		{
			FileName = process.MainModule?.FileName,
			UseShellExecute = true,
			ArgumentList = { $"--restart-parent-process-id={process.Id}" }
		});
	}
}
