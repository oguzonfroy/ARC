using System;
using System.IO;
using System.Text;
using ETS2LA.Logging;

namespace ETS2LA.UI;

public static partial class ArcKabinTepki
{
	private static string Dosya => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "ARC Studio", "kabin_isigi.cfg");

	private static readonly object Kilit = new object();

	public static bool Durum
	{
		get
		{
			try { return File.Exists(Dosya) && Acik(File.ReadAllText(Dosya)); }
			catch { return false; }
		}
	}

	/// <summary>Anahtarı çevirir; oyundaki eklenti dosyayı saniyede beş kez okur, değişiklik hemen görünür.</summary>
	public static void Degistir()
	{
		lock (Kilit)
		{
			try
			{
				var yol = Dosya;
				Directory.CreateDirectory(Path.GetDirectoryName(yol));
				var eski = File.Exists(yol) ? File.ReadAllText(yol) : "";
				var gecici = yol + ".yeni";
				// Önce yanına, sonra üzerine: oyundaki eklenti yarım dosya görmez.
				File.WriteAllText(gecici, Yaz(eski, !Acik(eski)), new UTF8Encoding(false));
				File.Move(gecici, yol, true);
			}
			catch (Exception e)
			{
				Logger.Warn("ARC fren ve sinyal ışığı ayarı yazılamadı: " + e.Message);
			}
		}
	}
}
