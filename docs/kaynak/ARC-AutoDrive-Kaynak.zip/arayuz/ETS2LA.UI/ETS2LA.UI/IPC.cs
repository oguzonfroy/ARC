using System.Drawing;
using ETS2LA.Translations;
using Photino.Blazor;
using Photino.NET;

namespace ETS2LA.UI;

internal static class IPC
{
	public static void HandleMessage(string message, object sender, PhotinoBlazorApp app)
	{
		if (message.StartsWith("window:moveBy:"))
		{
			string[] array = message.Replace("window:moveBy:", "").Split(',');
			if (array.Length == 2 && int.TryParse(array[0], out var result) && int.TryParse(array[1], out var result2))
			{
				Point location = app.MainWindow.Location;
				app.MainWindow.SetLocation(new Point(location.X + result, location.Y + result2));
			}
			return;
		}
		if (message.StartsWith("window:setSize:"))
		{
			string[] array2 = message.Replace("window:setSize:", "").Split(',');
			if (array2.Length == 2 && int.TryParse(array2[0], out var result3) && int.TryParse(array2[1], out var result4))
			{
				app.MainWindow.SetSize(result3, result4);
			}
			return;
		}
		if (message.StartsWith("window:zoom"))
		{
			string[] array3 = message.Replace("window:zoom:", "").Split(',');
			if (array3.Length == 1 && int.TryParse(array3[0], out var result5))
			{
				WindowSettings.Current.Zoom = result5;
				WindowSettings.Current.Save();
				app.MainWindow.SetZoom(result5);
			}
			return;
		}
		switch (message)
		{
		default:
			_ = message == "window:notopmost";
			break;
		case "window:minimize":
			app.MainWindow.SetMinimized(minimized: true);
			break;
		case "window:maximize":
			app.MainWindow.SetMaximized(!app.MainWindow.Maximized);
			break;
		case "window:close":
			if (app.MainWindow.ShowMessageOnTop(T._("Are you sure?"), T._("This will disconnect ETS2LA from the game and close the window. You can minimize the window to keep ETS2LA running."), PhotinoDialogButtons.YesNo, PhotinoDialogIcon.Question) == PhotinoDialogResult.Yes)
			{
				app.MainWindow.Close();
			}
			break;
		case "window:topmost":
			break;
		}
	}
}
