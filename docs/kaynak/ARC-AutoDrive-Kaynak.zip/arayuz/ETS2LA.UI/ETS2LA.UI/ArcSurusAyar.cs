using System;
using System.IO;
using System.Text;
using System.Text.Json.Nodes;
using ETS2LA.Backend.Events;

namespace ETS2LA.UI;

public static class ArcSurusAyar
{
	public const string Uyari = "Bu özellik yardımcı bir araçtır ve tırın işaretli konumda her zaman tam olarak durmasını GARANTİ ETMEZ. Trafik, rota değişikliği, oyun verisindeki gecikme veya yol yapısı nedeniyle tır erken durabilir, geç durabilir ya da hedefi geçebilir. Bu özelliği kullanırken oluşabilecek kaza, hasar, ceza, teslimat kaybı ve TruckersMP dahil her türlü hesap yaptırımı tamamen kullanıcının sorumluluğundadır; ARC Studio sorumlu tutulamaz. Sürüş boyunca kontrol sende kalır, gerektiğinde hemen müdahale etmelisin.";

	private static readonly object Kilit = new object();

	private static bool dinleniyor;

	private static string Yol => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ETS2LA", "arc.driveassist.json");

	public static float Hassasiyet
	{
		get
		{
			try
			{
				return Math.Clamp(Oku()["SteeringGain"]?.GetValue<float>() ?? 1f, 0.4f, 2.5f);
			}
			catch
			{
				return 1f;
			}
		}
		set
		{
			Yaz((JsonObject o) =>
			{
				o["SteeringGain"] = Math.Clamp(value, 0.4f, 2.5f);
			});
		}
	}

	public static int DireksiyonModu
	{
		get
		{
			try
			{
				return Math.Clamp(Oku()["Wheel"]?.GetValue<int>() ?? 0, 0, 2);
			}
			catch
			{
				return 0;
			}
		}
		set
		{
			Yaz((JsonObject o) =>
			{
				o["Wheel"] = Math.Clamp(value, 0, 2);
			});
		}
	}

	public static bool HedefteDur
	{
		get
		{
			try
			{
				return Oku()["StopAtMarker"]?.GetValue<bool>() ?? false;
			}
			catch
			{
				return false;
			}
		}
		set
		{
			Yaz((JsonObject o) =>
			{
				o["StopAtMarker"] = value;
			});
		}
	}

	public static float Pay
	{
		get
		{
			try
			{
				return Math.Clamp(Oku()["StopMargin"]?.GetValue<float>() ?? 6f, 2f, 40f);
			}
			catch
			{
				return 6f;
			}
		}
		set
		{
			Yaz((JsonObject o) =>
			{
				o["StopMargin"] = Math.Clamp(value, 2f, 40f);
			});
		}
	}

	public static string Durum { get; private set; } = "Sürüş başlayınca devreye girer";

	public static bool MudahaleDireksiyon
	{
		get
		{
			try
			{
				return Oku()["TakeoverWheel"]?.GetValue<bool>() ?? true;
			}
			catch
			{
				return true;
			}
		}
		set
		{
			Yaz((JsonObject o) =>
			{
				o["TakeoverWheel"] = value;
			});
		}
	}

	public static bool MudahalePedal
	{
		get
		{
			try
			{
				return Oku()["TakeoverPedal"]?.GetValue<bool>() ?? true;
			}
			catch
			{
				return true;
			}
		}
		set
		{
			Yaz((JsonObject o) =>
			{
				o["TakeoverPedal"] = value;
			});
		}
	}

	public static float MudahaleEsik
	{
		get
		{
			try
			{
				return Math.Clamp(Oku()["TakeoverPercent"]?.GetValue<float>() ?? 8f, 2f, 40f);
			}
			catch
			{
				return 8f;
			}
		}
		set
		{
			Yaz((JsonObject o) =>
			{
				o["TakeoverPercent"] = Math.Clamp(value, 2f, 40f);
			});
		}
	}

	public static bool TelefonAcilsin
	{
		get
		{
			try
			{
				return Oku()["PhoneOn"]?.GetValue<bool>() ?? true;
			}
			catch
			{
				return true;
			}
		}
		set
		{
			Yaz((JsonObject o) =>
			{
				o["PhoneOn"] = value;
			});
		}
	}

	private static T Al<T>(string ad, T varsayilan)
	{
		try
		{
			JsonNode node = Oku()[ad];
			return node == null ? varsayilan : node.GetValue<T>();
		}
		catch
		{
			return varsayilan;
		}
	}

	public static string DireksiyonAdi { get; private set; } = "";

	private static JsonObject Oku()
	{
		try
		{
			return (JsonNode.Parse(File.ReadAllText(Yol)) as JsonObject) ?? new JsonObject();
		}
		catch
		{
			return new JsonObject();
		}
	}

	private static void Yaz(Action<JsonObject> degistir)
	{
		lock (Kilit)
		{
			try
			{
				JsonObject jsonObject = Oku();
				degistir(jsonObject);
				string text = Yol + ".ui";
				File.WriteAllText(text, jsonObject.ToJsonString(), new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
				File.Move(text, Yol, overwrite: true);
			}
			catch
			{
			}
		}
	}

	public static void DurumDinle()
	{
		if (!dinleniyor)
		{
			dinleniyor = true;
			Events.Current.Subscribe("ARC.DriveAssist.Status", (string d) =>
			{
				Durum = d;
			});
			Events.Current.Subscribe("ARC.DriveAssist.Wheel", (string d) =>
			{
				DireksiyonAdi = d;
			});
		}
	}

	public static void HedefteDurKabul()
	{
		Yaz((JsonObject o) =>
		{
			o["StopAccepted"] = true;
			o["StopAtMarker"] = true;
		});
	}
}
