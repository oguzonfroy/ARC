using System;
using System.Linq;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages;

[Route("/nasil-kurulur")]
public class NasilKurulur : ComponentBase
{
	[Inject]
	private NavigationManager Navigation { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full gap-6 p-6 max-w-3xl");
		__builder.AddMarkupContent(2, "<section class=\"arc-hero\"><p class=\"arc-etiket\">REHBER</p>\n        <h1 class=\"arc-baslik\">Nasıl Kurulur</h1>\n        <p class=\"description text-[13px]! mt-2\">Sırayla yap, her adım bir kez yapılır. Takıldığın yerde adımın düğmesi seni doğru sayfaya götürür.</p></section>");
		foreach (ArcRehber.Adim item in ArcRehber.Adimlar.Skip(1))
		{
			__builder.OpenElement(3, "section");
			__builder.AddAttribute(4, "class", "arc-hero");
			__builder.OpenElement(5, "h2");
			__builder.AddAttribute(6, "class", "font-bold text-[16px]");
			__builder.AddContent(7, item.Baslik);
			__builder.CloseElement();
			__builder.AddMarkupContent(8, "\n            ");
			__builder.OpenElement(9, "p");
			__builder.AddAttribute(10, "class", "description text-[12px]! mt-1");
			__builder.AddContent(11, item.Aciklama);
			__builder.CloseElement();
			__builder.AddMarkupContent(12, "\n            ");
			__builder.OpenElement(13, "ul");
			__builder.AddAttribute(14, "class", "flex flex-col gap-1.5 mt-3 text-[13px]");
			string[] maddeler = item.Maddeler;
			string[] array = maddeler;
			foreach (string textContent in array)
			{
				__builder.OpenElement(15, "li");
				__builder.AddAttribute(16, "class", "flex gap-2");
				__builder.AddMarkupContent(17, "<span class=\"text-accent\">•</span>");
				__builder.OpenElement(18, "span");
				__builder.AddContent(19, textContent);
				__builder.CloseElement();
				__builder.CloseElement();
			}
			__builder.CloseElement();
			if (item.Yol != null)
			{
				__builder.OpenElement(20, "a");
				__builder.AddAttribute(21, "class", "button button-accent mt-4 inline-block");
				__builder.AddAttribute(22, "href", item.Yol);
				__builder.AddContent(23, item.Dugme);
				__builder.CloseElement();
			}
			__builder.CloseElement();
		}
		__builder.OpenElement(24, "button");
		__builder.AddAttribute(25, "class", "button self-start");
		__builder.AddAttribute(26, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)TanitimiTekrarGoster));
		__builder.AddMarkupContent(27, "Tanıtımı tekrar göster");
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private void TanitimiTekrarGoster()
	{
		WindowSettings.Current.ArcIntroSeen = false;
		WindowSettings.Current.Save();
		Navigation.NavigateTo("/");
	}
}
