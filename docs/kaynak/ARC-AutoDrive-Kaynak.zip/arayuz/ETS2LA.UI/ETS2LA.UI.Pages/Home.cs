using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using ETS2LA.Backend;
using ETS2LA.Game.Telemetry;
using ETS2LA.Networking;
using ETS2LA.Networking.News;
using ETS2LA.Overlay;
using ETS2LA.Settings.Global;
using ETS2LA.Shared;
using ETS2LA.State;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using Markdig;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages;

[Route("/")]
public class Home : ComponentBase, IDisposable
{
	private class ArticleWrapper
	{
		public string RenderedTitle;

		public string RenderedContentSummary;

		public string RenderedContent;

		public Article Article { get; set; }

		public bool IsExpanded { get; set; }

		public string TranslatedTitle { get; set; } = string.Empty;

		public string TranslatedContentSummary { get; set; } = string.Empty;

		public string TranslatedContent { get; set; } = string.Empty;
	}

	private List<string> Sponsors = new List<string> { "AkhtiveLzz", "Lun011666", "luuukske", "McAs13", "Private Sponsor", "Private Sponsor" };

	private bool alreadyChecked;

	private bool sponsorBadgeLoaded;

	private bool sponsorBadgeFailed;

	private bool NewsSettingsDialogOpen;

	private static readonly MarkdownPipeline Pipeline = new MarkdownPipelineBuilder().UseAdvancedExtensions().Build();

	private List<ArticleWrapper> ArticleWrappers = new List<ArticleWrapper>();

	private List<(string Title, bool Open)> OverlayWindows = new List<(string, bool)>();

	private Timer? overlayTimer;

	private static readonly (string Renk, string Ad)[] OkRenkleri = new (string, string)[8]
	{
		("#FFFFFF", "Beyaz"),
		("#2DD4BF", "Turkuaz"),
		("#8B5CF6", "Mor"),
		("#22C55E", "Yeşil"),
		("#FACC15", "Sarı"),
		("#FB923C", "Turuncu"),
		("#EF4444", "Kırmızı"),
		("#3B82F6", "Mavi")
	};

	private static readonly (string Id, string Ad, string Aciklama)[] EklentiOzellikleri = new (string, string, string)[3]
	{
		("tumppi066.internalvisualization", "ARC Vision", "Yolu, şeritleri ve tırın konumunu canlı gösterir. Otonom sürüşten bağımsızdır"),
		("arc.discord", "Discord durumu", "Discord profilinde ARC ile sürdüğünü ve hızını gösterir"),
		("zkhan4509.realforcefeedback", "Direksiyon dönüşü", "Otopilot dönerken direksiyon setin de döner, güç geri bildirimi verir")
	};

	private bool hedefUyariAcik;

	private Timer? telemetriTimer;

	private string telemetriImza = "";

	private bool tanitimAcik = !WindowSettings.Current.ArcIntroSeen;

	private int tanitimAdim;

	private static readonly (DrivingMode Mode, string Name, string Info)[] DrivingModes = new (DrivingMode, string, string)[3]
	{
		(DrivingMode.FullSelfDriving, "Tam otomatik sürüş", "Direksiyon ve hız birlikte"),
		(DrivingMode.LaneAssistOnly, "Yalnız şerit takibi", "Direksiyon ARC'de, gaz ve fren sende"),
		(DrivingMode.AdaptiveCruiseControlOnly, "Yalnız adaptif hız", "Gaz ve fren ARC'de, direksiyon sende")
	};

	private bool UserExpiredDialogueOpen => NetworkingClient.Current.TokenExpired;

	private bool UnlimitedSpeed
	{
		get
		{
			if (AssistanceSettings.Current.MaximumSpeed <= 0f)
			{
				return !AssistanceSettings.Current.EnabledTrafficRules.Contains(TrafficRule.Speedlimits);
			}
			return false;
		}
	}

	private static GameTelemetryData Tele => GameTelemetry.Current.GetCurrentData();

	private static bool OyunBagli
	{
		get
		{
			if (ApplicationState.Current.IsGameRunning)
			{
				return Tele.sdkActive;
			}
			return false;
		}
	}

	private static bool Metrik => ApplicationState.Current.DisplayUnits != Units.Imperial;

	private static string HizBirim
	{
		get
		{
			if (!Metrik)
			{
				return "MPH";
			}
			return "KM/H";
		}
	}

	[Inject]
	private NavigationManager Navigation { get; set; }

	[Inject]
	private Microsoft.JSInterop.IJSRuntime JS { get; set; }

	private string logKopyaDurum = "";

	private bool logKopyalaniyor;

	// Üyeler sorun bildirirken logu tek tıkla Discord'a yapıştırabilsin (kullanıcı adı gizlenir).
	private async Task LogKopyala()
	{
		if (logKopyalaniyor || logKopyaDurum != "")
		{
			return;  // kopyalanırken ya da sonuç yazısı dururken ikinci tık yazıyı karıştırmasın
		}
		logKopyalaniyor = true;
		try
		{
			string metin = await Task.Run(() => ArcLogKopya.Hazirla(ETS2LA.Logging.LogFileWriter.Current.ReadRecent(),
				Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), Environment.UserName, DateTime.Now));
			logKopyaDurum = await Microsoft.JSInterop.JSRuntimeExtensions.InvokeAsync<bool>(JS, "copyToClipboard", new object[1] { metin })
				? "Kopyalandı, Discord'a yapıştır" : "Kopyalanamadı";
		}
		catch (Exception)
		{
			logKopyaDurum = "Kopyalanamadı";
		}
		logKopyalaniyor = false;
		StateHasChanged();
		await Task.Delay(2500);
		logKopyaDurum = "";
		StateHasChanged();
	}

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.OpenElement(9000, "div");
		__builder.AddAttribute(9001, "style", "display:flex;justify-content:flex-end;margin:0 0 8px 0");
		__builder.OpenElement(9002, "button");
		__builder.AddAttribute(9003, "type", "button");
		__builder.AddAttribute(9004, "title", "Auto Drive logunu panoya kopyalar; destek için Discord'a yapıştır");
		__builder.AddAttribute(9005, "style", "display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:8px;border:1px solid rgba(167,139,250,.35);background:rgba(109,40,217,.18);color:#e9e3ff;font-size:12px;font-weight:600;cursor:pointer");
		__builder.AddAttribute(9006, "disabled", logKopyalaniyor);
		__builder.AddAttribute(9007, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Func<Task>)LogKopyala));
		__builder.AddMarkupContent(9008, "<svg width=\"14\" height=\"14\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\"><rect x=\"9\" y=\"9\" width=\"13\" height=\"13\" rx=\"2\"></rect><path d=\"M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1\"></path></svg>");
		__builder.AddContent(9009, logKopyalaniyor ? "Kopyalanıyor..." : (logKopyaDurum != "" ? logKopyaDurum : "Log kopyala"));
		__builder.CloseElement();
		__builder.CloseElement();
		GameTelemetryData tele = Tele;
		bool oyunBagli = OyunBagli;
		bool enableAssists = ApplicationState.Current.EnableAssists;
		float num = (oyunBagli ? HizCevir(Math.Abs(tele.truckFloat.speed)) : 0f);
		float num2 = (oyunBagli ? HizCevir(tele.truckFloat.speedLimit) : 0f);
		float num3 = HizCevir(ApplicationState.Current.DesiredSpeed);
		float num4 = (Metrik ? 140 : 90);
		float num5 = 471.24f * Math.Clamp(num / num4, 0f, 1f);
		float num6 = 135f + 270f * Math.Clamp(num3 / num4, 0f, 1f);
		bool flag = num2 > 0f && num > num2 + 2f;
		(DrivingMode, string, string) tuple = DrivingModes.First(((DrivingMode Mode, string Name, string Info) tuple5) => tuple5.Mode == ApplicationState.Current.DrivingMode);
		__builder.OpenElement(1, "div");
		__builder.AddAttribute(2, "class", "kp-pano");
		// ARC Kokpit: solda sistemlerin durumu, ortada yarım daire hız göstergesi + aç/kapat, sağda rota.
		// Sıra numaraları bölge (region) içinde baştan sayılır; dışarıdakilerle çakışmaz.
		bool rotaVar = oyunBagli && tele.truckFloat.routeDistance > 1f;
		float rotaMesafe = tele.truckFloat.routeDistance / (Metrik ? 1000f : 1609.34f);
		StateSettings kkAyar = StateSettingsHandler.Current.GetSettings();
		DrivingMode kkMod = ApplicationState.Current.DrivingMode;
		bool seritAktif = enableAssists && kkMod != DrivingMode.AdaptiveCruiseControlOnly;
		bool hizAktif = enableAssists && kkMod != DrivingMode.LaneAssistOnly;
		(string Durum, string Sinif) bekle = oyunBagli ? ("HAZIR", "") : ("BEKLİYOR", "uyari");
		(string Ad, string Alt, string Durum, string Sinif, string Yol)[] sistemler = new (string, string, string, string, string)[6]
		{
			("Oyun bağlantısı", oyunBagli ? "Telemetri geliyor" : "Oyunu aç, SDK'yı etkinleştir",
				oyunBagli ? "BAĞLI" : "BEKLİYOR", oyunBagli ? "iyi" : "uyari",
				"<rect x='2' y='6' width='20' height='12' rx='4'/><path d='M7 10v4M5 12h4'/><circle cx='15.5' cy='11' r='1'/><circle cx='18' cy='13.5' r='1'/>"),
			("Şerit takibi", seritAktif ? "Direksiyon ARC'de" : (kkMod == DrivingMode.AdaptiveCruiseControlOnly ? "Bu modda kapalı" : "Sürüş başlayınca devreye girer"),
				seritAktif ? "AKTİF" : (kkMod == DrivingMode.AdaptiveCruiseControlOnly ? "KAPALI" : bekle.Durum),
				seritAktif ? "iyi" : (kkMod == DrivingMode.AdaptiveCruiseControlOnly ? "kapali" : bekle.Sinif),
				"<path d='M6 20L10 4M18 20L14 4M12 5v2M12 10v3M12 16v3'/>"),
			("Adaptif hız", hizAktif ? ((num3 > 0f) ? ("Hedef " + Math.Round(num3) + " " + HizBirim.ToLowerInvariant()) : "Gaz ve fren ARC'de") : (kkMod == DrivingMode.LaneAssistOnly ? "Bu modda kapalı" : "Sürüş başlayınca devreye girer"),
				hizAktif ? "AKTİF" : (kkMod == DrivingMode.LaneAssistOnly ? "KAPALI" : bekle.Durum),
				hizAktif ? "iyi" : (kkMod == DrivingMode.LaneAssistOnly ? "kapali" : bekle.Sinif),
				"<path d='M4 16a8 8 0 1 1 16 0'/><path d='M12 16l5-5'/>"),
			("Rota", rotaVar ? (string.IsNullOrEmpty(tele.configString.cityDst) ? "GPS rotası açık" : ("→ " + tele.configString.cityDst)) : "GPS'te rota yok",
				rotaVar ? "VAR" : "YOK", rotaVar ? "iyi" : "kapali",
				"<path d='M6 20c0-6 12-4 12-10a4 4 0 0 0-8 0'/><circle cx='6' cy='20' r='1.5'/><circle cx='14' cy='10' r='1.5'/>"),
			("Otomatik sollama", kkAyar.OvertakeEnabled ? "Boş şeritten geçer, sonra döner" : "Ayarlardan açılabilir",
				kkAyar.OvertakeEnabled ? "AÇIK" : "KAPALI", kkAyar.OvertakeEnabled ? "iyi" : "kapali",
				"<path d='M7 17l5-5-5-5M13 17l5-5-5-5'/>"),
			("Hedefte dur", ArcSurusAyar.HedefteDur ? ArcSurusAyar.Durum : "Rota sonunda durmaz",
				ArcSurusAyar.HedefteDur ? "AÇIK" : "KAPALI", ArcSurusAyar.HedefteDur ? "iyi" : "kapali",
				"<path d='M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z'/><circle cx='12' cy='10' r='2.5'/>")
		};
		double hizOran = Math.Clamp(num / num4, 0f, 1f);
		double hedefAci = (180.0 + 180.0 * Math.Clamp(num3 / num4, 0f, 1f)) * Math.PI / 180.0;
		__builder.OpenRegion(9100);
		__builder.OpenElement(1, "div");
		__builder.AddAttribute(2, "class", "kk-kokpit");
		// --- sol: sistemler
		__builder.OpenElement(3, "aside");
		__builder.AddAttribute(4, "class", "kk-sol");
		__builder.AddMarkupContent(5, "<span class=\"arc-etiket\">Sistemler</span>");
		foreach (var s in sistemler)
		{
			__builder.OpenElement(6, "div");
			__builder.AddAttribute(7, "class", "kk-sis " + s.Sinif);
			__builder.OpenElement(8, "span");
			__builder.AddAttribute(9, "class", "kk-ikon");
			__builder.AddContent(10, Ikon(s.Yol));
			__builder.CloseElement();
			__builder.OpenElement(11, "span");
			__builder.AddAttribute(12, "class", "kk-sis-yazi");
			__builder.OpenElement(13, "b");
			__builder.AddContent(14, s.Ad);
			__builder.CloseElement();
			__builder.OpenElement(15, "small");
			__builder.AddContent(16, s.Alt);
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.OpenElement(17, "em");
			__builder.AddContent(18, s.Durum);
			__builder.CloseElement();
			__builder.CloseElement();
		}
		__builder.CloseElement();
		// --- orta: hız göstergesi, durum, mod, aç/kapat
		__builder.OpenElement(20, "section");
		__builder.AddAttribute(21, "class", "kk-orta");
		__builder.OpenElement(22, "div");
		__builder.AddAttribute(23, "class", "kk-kadran");
		__builder.AddAttribute(24, "role", "img");
		__builder.AddAttribute(25, "aria-label", "Hız " + Math.Round(num) + " " + HizBirim);
		__builder.OpenElement(26, "svg");
		__builder.AddAttribute(27, "viewBox", "0 0 520 290");
		__builder.AddMarkupContent(28, "<defs><linearGradient id=\"kkHiz\" x1=\"0\" x2=\"1\"><stop offset=\"0\" stop-color=\"#6d28d9\"></stop><stop offset=\"1\" stop-color=\"#c4b5fd\"></stop></linearGradient></defs><path d=\"M60 270 A200 200 0 0 1 460 270\" fill=\"none\" stroke=\"rgba(255,255,255,.07)\" stroke-width=\"18\" stroke-linecap=\"round\"></path>");
		for (int i = 0; i <= 4; i++)
		{
			double a = (180.0 + 45.0 * i) * Math.PI / 180.0;
			__builder.OpenElement(29, "line");
			__builder.AddAttribute(30, "x1", F(260.0 + Math.Cos(a) * 222.0));
			__builder.AddAttribute(31, "y1", F(270.0 + Math.Sin(a) * 222.0));
			__builder.AddAttribute(32, "x2", F(260.0 + Math.Cos(a) * 234.0));
			__builder.AddAttribute(33, "y2", F(270.0 + Math.Sin(a) * 234.0));
			__builder.AddAttribute(34, "class", "kk-cizik");
			__builder.CloseElement();
		}
		if (hizOran > 0.002)
		{
			__builder.OpenElement(35, "path");
			__builder.AddAttribute(36, "class", "kk-yay");
			__builder.AddAttribute(37, "d", "M60 270 A200 200 0 0 1 460 270");
			__builder.AddAttribute(38, "pathLength", "100");
			__builder.AddAttribute(39, "fill", "none");
			__builder.AddAttribute(40, "stroke", flag ? "#ef4444" : "url(#kkHiz)");
			__builder.AddAttribute(41, "stroke-width", "18");
			__builder.AddAttribute(42, "stroke-linecap", "round");
			__builder.AddAttribute(43, "stroke-dasharray", F(hizOran * 100.0) + " 100");
			__builder.CloseElement();
		}
		if (num3 > 0f)
		{
			__builder.OpenElement(44, "circle");
			__builder.AddAttribute(45, "cx", F(260.0 + Math.Cos(hedefAci) * 200.0));
			__builder.AddAttribute(46, "cy", F(270.0 + Math.Sin(hedefAci) * 200.0));
			__builder.AddAttribute(47, "r", "8");
			__builder.AddAttribute(48, "class", "kk-hedef-isaret");
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.OpenElement(49, "div");
		__builder.AddAttribute(50, "class", "kk-hedef");
		__builder.AddMarkupContent(51, "<span>HEDEF</span>");
		__builder.OpenElement(52, "b");
		__builder.AddContent(53, (num3 > 0f) ? Math.Round(num3).ToString() : "–");
		__builder.CloseElement();
		__builder.CloseElement();
		if (num2 > 0f)
		{
			__builder.OpenElement(54, "div");
			__builder.AddAttribute(55, "class", "kk-sinir");
			__builder.AddAttribute(56, "title", "Hız sınırı");
			__builder.AddContent(57, Math.Round(num2));
			__builder.CloseElement();
		}
		__builder.OpenElement(58, "div");
		__builder.AddAttribute(59, "class", "kk-sayi" + (flag ? " asim" : ""));
		__builder.OpenElement(60, "b");
		__builder.AddContent(61, Math.Round(num));
		__builder.CloseElement();
		__builder.OpenElement(62, "small");
		__builder.AddContent(63, HizBirim);
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.OpenElement(64, "div");
		__builder.AddAttribute(65, "class", "kk-durum" + (enableAssists ? " aktif" : ""));
		__builder.AddContent(66, enableAssists ? "OTOPİLOT AKTİF" : (oyunBagli ? "OTOPİLOT HAZIR" : "OYUN BEKLENİYOR"));
		__builder.CloseElement();
		__builder.OpenElement(67, "div");
		__builder.AddAttribute(68, "class", "kk-durum-alt");
		__builder.AddContent(69, tuple.Item2 + " · " + tuple.Item3);
		__builder.CloseElement();
		__builder.OpenElement(70, "div");
		__builder.AddAttribute(71, "class", "kk-kontrol");
		__builder.OpenElement(72, "div");
		__builder.AddAttribute(73, "class", "kp-mod");
		__builder.AddAttribute(74, "role", "radiogroup");
		__builder.AddAttribute(75, "aria-label", "Sürüş modu");
		foreach (var md in DrivingModes)
		{
			DrivingMode secilecek = md.Mode;
			bool secili = kkMod == secilecek;
			__builder.OpenElement(76, "button");
			__builder.AddAttribute(77, "class", secili ? "secili" : "");
			__builder.AddAttribute(78, "role", "radio");
			__builder.AddAttribute(79, "aria-checked", secili);
			__builder.AddAttribute(80, "title", md.Name + ": " + md.Info);
			__builder.AddAttribute(81, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () => SelectDrivingMode(secilecek)));
			__builder.AddContent(82, secilecek switch
			{
				DrivingMode.FullSelfDriving => "Tam otomatik",
				DrivingMode.LaneAssistOnly => "Yalnız şerit",
				_ => "Yalnız hız"
			});
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.OpenElement(83, "button");
		__builder.AddAttribute(84, "class", "kk-guc kp-ana-dugme" + (enableAssists ? " durdur" : ""));
		__builder.AddAttribute(85, "title", enableAssists ? "Sürüşü durdur" : "Sürüşü başlat");
		__builder.AddAttribute(86, "aria-label", enableAssists ? "Sürüşü durdur" : "Sürüşü başlat");
		__builder.AddAttribute(87, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)ToggleAssists));
		__builder.AddMarkupContent(88, "<svg viewBox=\"0 0 24 24\" width=\"34\" height=\"34\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\" aria-hidden=\"true\"><path d=\"M12 3v8\"></path><path d=\"M6.3 6.8a8 8 0 1 0 11.4 0\"></path></svg>");
		__builder.CloseElement();
		__builder.OpenElement(89, "p");
		__builder.AddAttribute(90, "class", "kk-guc-yazi");
		__builder.AddContent(91, enableAssists ? "Durdurmak için bas ya da direksiyona dokun" : "Başlatmak için bas. Kısayol tuşları da çalışır");
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.OpenElement(92, "p");
		__builder.AddAttribute(93, "class", "kk-ipucu");
		__builder.AddContent(94, oyunBagli ? ("Vites " + Vites(tele.truckInt.gear) + " · " + Math.Round(tele.truckFloat.engineRpm) + " dev/dk") : "Oyun açılınca vites ve devir burada görünür");
		__builder.CloseElement();
		__builder.CloseElement();
		// --- sağ: rota
		__builder.OpenElement(95, "aside");
		__builder.AddAttribute(96, "class", "kk-sag");
		__builder.AddMarkupContent(97, "<span class=\"arc-etiket\">Rota</span>");
		__builder.OpenElement(98, "div");
		__builder.AddAttribute(99, "class", "kk-mesafe");
		__builder.AddContent(100, rotaVar ? rotaMesafe.ToString((rotaMesafe < 10f) ? "0.0" : "0") : "–");
		__builder.OpenElement(101, "small");
		__builder.AddContent(102, Metrik ? "km" : "mi");
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.OpenElement(103, "div");
		__builder.AddAttribute(104, "class", "kk-yer");
		__builder.AddContent(105, rotaVar ? (string.IsNullOrEmpty(tele.configString.cityDst) ? "GPS rotası açık" : ("→ " + tele.configString.cityDst)) : "GPS'te rota yok");
		__builder.CloseElement();
		__builder.OpenElement(106, "div");
		__builder.AddAttribute(107, "class", "kk-olculer");
		foreach (var (deger, ad) in new (string, string)[4]
		{
			(rotaVar ? Sure(tele.truckFloat.routeTime) : "–", "Kalan süre"),
			((oyunBagli && tele.configFloat.fuelCapacity > 0f) ? $"%{Math.Round(100f * tele.truckFloat.fuel / tele.configFloat.fuelCapacity)}" : "–", "Yakıt"),
			((oyunBagli && tele.truckBool.cruiseControl) ? Math.Round(HizCevir(tele.truckFloat.cruiseControlSpeed)).ToString() : "Kapalı", "Sabitleyici"),
			((num2 > 0f) ? $"%{Math.Round(num / num2 * 100f)}" : "–", "Hız / sınır")
		})
		{
			__builder.OpenElement(108, "div");
			__builder.AddAttribute(109, "class", "kp-olcu");
			__builder.OpenElement(110, "b");
			__builder.AddContent(111, deger);
			__builder.CloseElement();
			__builder.OpenElement(112, "span");
			__builder.AddContent(113, ad);
			__builder.CloseElement();
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.OpenElement(114, "div");
		__builder.AddAttribute(115, "class", "kp-ilerleme");
		__builder.AddAttribute(116, "title", "Hız / sınır");
		__builder.OpenElement(117, "div");
		__builder.AddAttribute(118, "style", "width:" + F((num2 > 0f) ? Math.Clamp(num / num2 * 100f, 0f, 100f) : 0f) + "%");
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.OpenElement(119, "button");
		__builder.AddAttribute(120, "type", "button");
		__builder.AddAttribute(121, "class", "kk-instagram");
		__builder.AddAttribute(122, "title", "ARC'ın Instagram hesabı");
		__builder.AddAttribute(123, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () => OpenInBrowser("https://www.instagram.com/arcapp.tr/")));
		__builder.AddMarkupContent(124, "<svg viewBox=\"0 0 24 24\" width=\"16\" height=\"16\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" aria-hidden=\"true\"><rect x=\"3\" y=\"3\" width=\"18\" height=\"18\" rx=\"5\"></rect><circle cx=\"12\" cy=\"12\" r=\"4\"></circle><circle cx=\"17.5\" cy=\"6.5\" r=\"1\" fill=\"currentColor\"></circle></svg><span>@arcapp.tr</span><small>Instagram</small>");
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseRegion();
		__builder.AddMarkupContent(207, "\r\n\r\n    ");
		__builder.OpenElement(208, "section");
		__builder.AddAttribute(209, "class", "kp-kart");
		__builder.AddMarkupContent(210, "<div class=\"kp-kart-baslik\"><h3>Hızlı kontroller</h3><span class=\"description\">Sürüşü başlatmadan da değiştirilebilir</span></div>\r\n        ");
		__builder.OpenElement(211, "div");
		__builder.AddAttribute(212, "class", "kp-anahtarlar");
		__builder.OpenElement(213, "button");
		__builder.AddAttribute(214, "class", "kp-anahtar" + (UnlimitedSpeed ? " acik" : ""));
		__builder.AddAttribute(215, "aria-pressed", UnlimitedSpeed);
		__builder.AddAttribute(216, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)ToggleUnlimitedSpeed));
		__builder.OpenElement(217, "span");
		__builder.AddAttribute(218, "class", "kp-anahtar-ikon");
		__builder.AddContent(219, Ikon("<path d='M4 16a8 8 0 1 1 16 0'/><path d='M12 16l5-5'/>"));
		__builder.CloseElement();
		__builder.AddMarkupContent(220, "\r\n                ");
		__builder.AddMarkupContent(221, "<span class=\"min-w-0\"><span class=\"kp-anahtar-ad block\">Sınırsız hız</span><span class=\"kp-anahtar-acik block\">Sınır uygulanmaz; hızı aşağıdaki çubuktan seçersin</span></span>\r\n                <span class=\"kp-dugmecik\"></span>");
		__builder.CloseElement();
		bool showRoadArrows = OverlaySettingsHandler.Current.GetSettings().ShowRoadArrows;
		__builder.OpenElement(222, "button");
		__builder.AddAttribute(223, "class", "kp-anahtar" + (showRoadArrows ? " acik" : ""));
		__builder.AddAttribute(224, "aria-pressed", showRoadArrows);
		__builder.AddAttribute(225, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)ToggleRoadArrows));
		__builder.OpenElement(226, "span");
		__builder.AddAttribute(227, "class", "kp-anahtar-ikon");
		__builder.AddContent(228, Ikon("<path d='M12 20V6M7 11l5-5 5 5'/>"));
		__builder.CloseElement();
		__builder.AddMarkupContent(229, "\r\n                ");
		__builder.AddMarkupContent(230, "<span class=\"min-w-0\"><span class=\"kp-anahtar-ad block\">Yol okları</span><span class=\"kp-anahtar-acik block\">GPS rotası yolda oklarla görünür</span></span>\r\n                <span class=\"kp-dugmecik\"></span>");
		__builder.CloseElement();
		bool showDriveHud = OverlaySettingsHandler.Current.GetSettings().ShowDriveHud;
		__builder.OpenElement(231, "button");
		__builder.AddAttribute(232, "class", "kp-anahtar" + (showDriveHud ? " acik" : ""));
		__builder.AddAttribute(233, "aria-pressed", showDriveHud);
		__builder.AddAttribute(234, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)ToggleDriveHud));
		__builder.OpenElement(235, "span");
		__builder.AddAttribute(236, "class", "kp-anahtar-ikon");
		__builder.AddContent(237, Ikon("<rect x='5' y='8' width='14' height='9' rx='2'/><path d='M8 17v2M16 17v2M7 8l1.5-3h7L17 8'/>"));
		__builder.CloseElement();
		__builder.AddMarkupContent(238, "\r\n                ");
		__builder.AddMarkupContent(239, "<span class=\"min-w-0\"><span class=\"kp-anahtar-ad block\">Öndeki araç</span><span class=\"kp-anahtar-acik block\">Oyunda öndeki aracı işaretler</span></span>\r\n                <span class=\"kp-dugmecik\"></span>");
		__builder.CloseElement();
		bool hedefteDur = ArcSurusAyar.HedefteDur;
		__builder.OpenRegion(9000);
		__builder.OpenElement(1, "button");
		__builder.AddAttribute(2, "class", "kp-anahtar" + (hedefteDur ? " acik" : ""));
		__builder.AddAttribute(3, "aria-pressed", hedefteDur);
		__builder.AddAttribute(4, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
		{
			if (ArcSurusAyar.HedefteDur)
			{
				ArcSurusAyar.HedefteDur = false;
			}
			else
			{
				hedefUyariAcik = true;
			}
		}));
		__builder.OpenElement(5, "span");
		__builder.AddAttribute(6, "class", "kp-anahtar-ikon");
		__builder.AddContent(7, Ikon("<path d='M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11z'/><circle cx='12' cy='10' r='2.5'/>"));
		__builder.CloseElement();
		__builder.AddMarkupContent(8, "<span class=\"min-w-0\"><span class=\"kp-anahtar-ad block\">Hedefte dur</span><span class=\"kp-anahtar-acik block\">GPS rotasının sonunda tırı durdurur</span></span>\r\n                <span class=\"kp-dugmecik\"></span>");
		__builder.CloseElement();
		__builder.CloseRegion();
		// ARC: fren ve sinyal kabin ışığı (arclight.dll, kabin_isigi.cfg "tepki")
		bool kabinTepki = ArcKabinTepki.Durum;
		__builder.OpenRegion(9800);
		__builder.OpenElement(1, "button");
		__builder.AddAttribute(2, "class", "kp-anahtar" + (kabinTepki ? " acik" : ""));
		__builder.AddAttribute(3, "aria-pressed", kabinTepki);
		__builder.AddAttribute(4, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)ArcKabinTepki.Degistir));
		__builder.OpenElement(5, "span");
		__builder.AddAttribute(6, "class", "kp-anahtar-ikon");
		__builder.AddContent(7, Ikon("<path d='M9 18h6M10 21h4'/><path d='M12 3a6 6 0 0 0-4 10.5c.8.8 1 1.5 1 2.5h6c0-1 .2-1.7 1-2.5A6 6 0 0 0 12 3z'/>"));
		__builder.CloseElement();
		__builder.AddMarkupContent(8, "<span class=\"min-w-0\"><span class=\"kp-anahtar-ad block\">Fren ve sinyal ışığı</span><span class=\"kp-anahtar-acik block\">Frende kabin kırmızı yanar, sinyalde o taraf turuncu yanıp söner</span></span>\r\n                <span class=\"kp-dugmecik\"></span>");
		__builder.CloseElement();
		__builder.CloseRegion();
		if (ArcTelefon.Kurulu)
		{
			bool istek = ArcTelefon.Istek;
			__builder.OpenRegion(9700);
			__builder.OpenElement(1, "button");
			__builder.AddAttribute(2, "class", "kp-anahtar" + (istek ? " acik" : ""));
			__builder.AddAttribute(3, "aria-pressed", istek);
			__builder.AddAttribute(4, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)ArcTelefon.Degistir));
			__builder.OpenElement(5, "span");
			__builder.AddAttribute(6, "class", "kp-anahtar-ikon");
			__builder.AddContent(7, Ikon("<rect x='7' y='2.5' width='10' height='19' rx='2.5'/><path d='M11 18.5h2'/>"));
			__builder.CloseElement();
			__builder.AddMarkupContent(8, "<span class=\"min-w-0\"><span class=\"kp-anahtar-ad block\">ARC Telefon</span><span class=\"kp-anahtar-acik block\">Sol Alt: fare telefona geçer, tır sürülmeye devam eder. Ctrl+Shift+P: göster, gizle</span></span>\r\n                <span class=\"kp-dugmecik\"></span>");
			__builder.CloseElement();
			__builder.CloseRegion();
		}
		(string, string, string)[] eklentiOzellikleri = EklentiOzellikleri;
		for (int num12 = 0; num12 < eklentiOzellikleri.Length; num12++)
		{
			(string, string, string) tuple3 = eklentiOzellikleri[num12];
			string item4 = tuple3.Item1;
			string item5 = tuple3.Item2;
			string item6 = tuple3.Item3;
			IPlugin plugin = Eklenti(item4);
			if (plugin != null)
			{
				bool isRunning = plugin._IsRunning;
				string eklentiId = item4;
				__builder.OpenElement(240, "button");
				__builder.AddAttribute(241, "class", "kp-anahtar" + (isRunning ? " acik" : ""));
				__builder.AddAttribute(242, "aria-pressed", isRunning);
				__builder.AddAttribute(243, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
				{
					ToggleEklenti(eklentiId);
				}));
				__builder.OpenElement(244, "span");
				__builder.AddAttribute(245, "class", "kp-anahtar-ikon");
				RenderTreeBuilder renderTreeBuilder = __builder;
				string yol;
				if (item4 == "zkhan4509.realforcefeedback")
				{
					yol = "<circle cx='12' cy='12' r='9'/><circle cx='12' cy='12' r='2.5'/><path d='M3.5 11h6M14.5 11h6M12 14.5V21'/>";
				}
				else
				{
					yol = ((item4 == "arc.discord") ? "<path d='M5 6h14v9H9l-4 3z'/>" : "<circle cx='12' cy='12' r='3'/><path d='M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z'/>");
				}
				renderTreeBuilder.AddContent(246, Ikon(yol));
				__builder.CloseElement();
				__builder.AddMarkupContent(247, "\r\n                    ");
				__builder.OpenElement(248, "span");
				__builder.AddAttribute(249, "class", "min-w-0");
				__builder.OpenElement(250, "span");
				__builder.AddAttribute(251, "class", "kp-anahtar-ad block");
				__builder.AddContent(252, item5);
				__builder.CloseElement();
				__builder.OpenElement(253, "span");
				__builder.AddAttribute(254, "class", "kp-anahtar-acik block");
				__builder.AddContent(255, item6);
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.AddMarkupContent(256, "\r\n                    <span class=\"kp-dugmecik\"></span>");
				__builder.CloseElement();
			}
		}
		__builder.CloseElement();
		// ARC: sinyal, sınırsız yol ve arka araç ayarları. Pathfinding ve hız kontrolü bunları ortak ayarlardan canlı okur.
		StateSettings surus = StateSettingsHandler.Current.GetSettings();
		__builder.OpenRegion(9400);
		__builder.OpenElement(1, "div");
		__builder.AddAttribute(2, "class", "arc-palet");
		__builder.AddAttribute(3, "style", "--ok-renk:#A78BFA;grid-template-columns:minmax(0,1fr);width:100%");
		__builder.OpenElement(4, "div");
		__builder.AddAttribute(5, "class", "arc-palet-govde");
		__builder.AddAttribute(6, "style", "flex:1 1 auto;width:100%");
		__builder.AddMarkupContent(7, "<div class=\"arc-palet-baslik\"><span>Sürüş davranışı</span></div>");
		__builder.OpenComponent<Slider>(8);
		__builder.AddComponentParameter(9, "Title", "Sinyal süresi");
		__builder.AddComponentParameter(10, "Description", "Dönüşten ve şerit değişiminden kaç saniye önce sinyal verilsin. 0 seçilirse kavşağa girerken verilir.");
		__builder.AddComponentParameter(11, "Suffix", " sn");
		__builder.AddComponentParameter(12, "Value", surus.IndicatorLeadSeconds);
		__builder.AddComponentParameter(13, "Min", 0f);
		__builder.AddComponentParameter(14, "Max", 10f);
		__builder.AddComponentParameter(15, "Step", 1f);
		__builder.AddComponentParameter(16, "ValueChanged", EventCallback.Factory.Create(this, (float value) =>
		{
			surus.IndicatorLeadSeconds = value;
			StateSettingsHandler.Current.Save();
		}));
		__builder.CloseComponent();
		__builder.OpenComponent<Slider>(17);
		__builder.AddComponentParameter(18, "Title", "Sınırsız yol hızı");
		__builder.AddComponentParameter(19, "Description", "Sınırsız hız açıkken ve sınırı olmayan yollarda gidilecek hız. 0 seçilirse Maksimum Hız'a, o da kapalıysa tırın çıkabildiği en yüksek hıza çıkılır.");
		__builder.AddComponentParameter(20, "Suffix", " km/s");
		__builder.AddComponentParameter(21, "Value", surus.NoLimitSpeed * 3.6f);
		__builder.AddComponentParameter(22, "Min", 0f);
		__builder.AddComponentParameter(23, "Max", 250f);
		__builder.AddComponentParameter(24, "Step", 5f);
		__builder.AddComponentParameter(25, "ValueChanged", EventCallback.Factory.Create(this, (float value) =>
		{
			surus.NoLimitSpeed = value / 3.6f;
			StateSettingsHandler.Current.Save();
		}));
		__builder.CloseComponent();
		__builder.OpenComponent<Switch>(26);
		__builder.AddComponentParameter(27, "Title", "Arkadan gelen aracı gözet");
		__builder.AddComponentParameter(28, "Description", "Yan şerit doluysa şerit değiştirmeyi bekletir, biri sollarken hızı kısa süre düşürür.");
		__builder.AddComponentParameter(29, "Value", surus.WatchRearTraffic);
		__builder.AddComponentParameter(30, "ValueChanged", EventCallback.Factory.Create(this, (bool value) =>
		{
			surus.WatchRearTraffic = value;
			StateSettingsHandler.Current.Save();
		}));
		__builder.CloseComponent();
		__builder.OpenComponent<Switch>(31);
		__builder.AddComponentParameter(32, "Title", "Otomatik sollama");
		__builder.AddComponentParameter(33, "Description", "Öndeki araç yavaşsa aynı yöndeki boş şeritten geçer, sonra şeridine döner. Sağını solunu kontrol eder, geçmeden önce ekranda haber verir. Karşı şeride çıkmaz.");
		__builder.AddComponentParameter(34, "Value", surus.OvertakeEnabled);
		__builder.AddComponentParameter(35, "ValueChanged", EventCallback.Factory.Create(this, (bool value) =>
		{
			surus.OvertakeEnabled = value;
			StateSettingsHandler.Current.Save();
		}));
		__builder.CloseComponent();
		if (surus.OvertakeEnabled)
		{
			__builder.OpenComponent<Switch>(36);
			__builder.AddComponentParameter(37, "Title", "Sollamadan önce aracı izle");
			__builder.AddComponentParameter(38, "Description", "Açıkken öndeki araç 5 saniye izlenir; hızlanmıyorsa sollanır. Kapalıyken yan şerit boşsa beklemeden sollanır.");
			__builder.AddComponentParameter(39, "Value", surus.OvertakeWatchFirst);
			__builder.AddComponentParameter(40, "ValueChanged", EventCallback.Factory.Create(this, (bool value) =>
			{
				surus.OvertakeWatchFirst = value;
				StateSettingsHandler.Current.Save();
			}));
			__builder.CloseComponent();
		}
		__builder.OpenComponent<Slider>(41);
		__builder.AddComponentParameter(42, "Title", "Işıksız kavşak hızı");
		__builder.AddComponentParameter(43, "Description", "Işığı olmayan kavşaklara (levha olsun olmasın) bu hızın üstünde girilmez. Kavşak yol parçasından tanınır, karşı trafiğe yol verilmez; yalnız yavaşlanır. 0 seçilirse kapalı.");
		__builder.AddComponentParameter(44, "Suffix", " km/s");
		__builder.AddComponentParameter(45, "Value", surus.JunctionSpeed * 3.6f);
		__builder.AddComponentParameter(46, "Min", 0f);
		__builder.AddComponentParameter(47, "Max", 60f);
		__builder.AddComponentParameter(48, "Step", 5f);
		__builder.AddComponentParameter(49, "ValueChanged", EventCallback.Factory.Create(this, (float value) =>
		{
			surus.JunctionSpeed = value / 3.6f;
			StateSettingsHandler.Current.Save();
		}));
		__builder.CloseComponent();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseRegion();
		if (hedefteDur)
		{
			ArcSurusAyar.DurumDinle();
			__builder.OpenRegion(9300);
			__builder.OpenElement(1, "div");
			__builder.AddAttribute(2, "class", "arc-palet");
			__builder.AddAttribute(3, "style", "--ok-renk:#A78BFA;grid-template-columns:auto minmax(0,1fr);width:100%");
			__builder.AddMarkupContent(4, "<div class=\"arc-palet-onizleme\" aria-hidden=\"true\"><svg viewBox=\"0 0 120 60\" fill=\"none\" stroke=\"#A78BFA\" stroke-width=\"3\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M60 52s17-14 17-27a17 17 0 1 0-34 0c0 13 17 27 17 27z\"/><circle cx=\"60\" cy=\"25\" r=\"6\"/></svg></div>");
			__builder.OpenElement(5, "div");
			__builder.AddAttribute(6, "class", "arc-palet-govde");
			__builder.AddAttribute(60, "style", "flex:1 1 auto;width:100%");
			__builder.OpenElement(7, "div");
			__builder.AddAttribute(8, "class", "arc-palet-baslik");
			__builder.AddMarkupContent(9, "<span>Hedefte dur</span>");
			__builder.OpenElement(10, "code");
			__builder.AddContent(11, ArcSurusAyar.Durum);
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.OpenComponent<Slider>(12);
			__builder.AddComponentParameter(13, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck("Hedefe kalan pay"));
			__builder.AddComponentParameter(14, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck("Tır, GPS rotasının sonuna bu kadar kala durur. Direksiyonu durana kadar otopilot tutar, duruşa yakın otopilot kapanır."));
			__builder.AddComponentParameter(15, "Suffix", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(" m"));
			__builder.AddComponentParameter(16, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(ArcSurusAyar.Pay));
			__builder.AddComponentParameter(17, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
			{
				ArcSurusAyar.Pay = value;
			})));
			__builder.AddComponentParameter(18, "Min", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(2f));
			__builder.AddComponentParameter(19, "Max", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(40f));
			__builder.AddComponentParameter(20, "Step", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(1f));
			__builder.AddComponentParameter(21, "Class", "w-full");
			__builder.CloseComponent();
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.CloseRegion();
		}
		if (showRoadArrows)
		{
			string roadArrowColor = OverlaySettingsHandler.Current.GetSettings().RoadArrowColor ?? "#FFFFFF";
			bool flag5 = OkRenkleri.Any(((string Renk, string Ad) r) => string.Equals(r.Renk, roadArrowColor, StringComparison.OrdinalIgnoreCase));
			__builder.OpenRegion(257);
			__builder.OpenElement(1, "div");
			__builder.AddAttribute(2, "class", "arc-palet");
			__builder.AddAttribute(3, "style", "--ok-renk:" + roadArrowColor);
			__builder.AddMarkupContent(4, "<div class=\"arc-palet-onizleme\" aria-hidden=\"true\"><svg viewBox=\"0 0 120 60\"><g class=\"arc-ok-akis\"><path d=\"M20 46 L60 14 L100 46\" /><path d=\"M20 46 L60 14 L100 46\" /><path d=\"M20 46 L60 14 L100 46\" /></g></svg></div>");
			__builder.OpenElement(5, "div");
			__builder.AddAttribute(6, "class", "arc-palet-govde");
			__builder.OpenElement(7, "div");
			__builder.AddAttribute(8, "class", "arc-palet-baslik");
			__builder.AddMarkupContent(9, "<span>Ok rengi</span>");
			__builder.OpenElement(10, "code");
			__builder.AddContent(11, roadArrowColor.ToUpperInvariant());
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.OpenElement(12, "div");
			__builder.AddAttribute(13, "class", "arc-palet-renkler");
			(string, string)[] okRenkleri = OkRenkleri;
			for (int num13 = 0; num13 < okRenkleri.Length; num13++)
			{
				(string, string) tuple4 = okRenkleri[num13];
				string renk = tuple4.Item1;
				string item7 = tuple4.Item2;
				bool flag6 = string.Equals(roadArrowColor, renk, StringComparison.OrdinalIgnoreCase);
				__builder.OpenElement(14, "button");
				__builder.AddAttribute(15, "title", item7);
				__builder.AddAttribute(16, "aria-label", item7);
				__builder.AddAttribute(17, "aria-pressed", flag6);
				__builder.AddAttribute(18, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
				{
					OkRengi(renk);
				}));
				__builder.AddAttribute(19, "class", "arc-renk" + (flag6 ? " secili" : ""));
				__builder.AddAttribute(20, "style", "--renk:" + renk);
				__builder.CloseElement();
			}
			__builder.OpenElement(21, "label");
			__builder.AddAttribute(22, "class", "arc-renk arc-renk-ozel" + ((!flag5) ? " secili" : ""));
			__builder.AddAttribute(23, "title", "Özel renk");
			__builder.AddAttribute(24, "style", "--renk:" + roadArrowColor);
			__builder.OpenElement(25, "input");
			__builder.AddAttribute(26, "type", "color");
			__builder.AddAttribute(27, "title", "Özel renk");
			__builder.AddAttribute(28, "aria-label", "Özel renk");
			__builder.AddAttribute(29, "value", roadArrowColor.ToLowerInvariant());
			__builder.AddAttribute(30, "onchange", EventCallback.Factory.Create(this, (ChangeEventArgs e) =>
			{
				OkRengi(e.Value?.ToString());
			}));
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.CloseRegion();
		}
		__builder.CloseElement();
		__builder.AddMarkupContent(273, "\r\n\r\n    ");
		__builder.OpenElement(274, "div");
		__builder.AddAttribute(275, "class", "grid gap-[14px]");
		__builder.OpenElement(276, "section");
		__builder.AddAttribute(277, "class", "kp-kart");
		__builder.AddMarkupContent(278, "<div class=\"kp-kart-baslik\"><h3>Oyun içi pencereler</h3></div>\r\n            ");
		__builder.AddMarkupContent(279, "<p class=\"description text-[12px]! mb-2\">Oyunda kendiliğinden açılmazlar; göz düğmesiyle aç. Oyun duraklatılmışken ya da Alt+Tab ile çıkınca başlığından sürükleyip köşesinden boyutlandırabilirsin; sürerken sağ Alt'a basılı tut.</p>");
		foreach (var overlayWindow in OverlayWindows)
		{
			string item8 = overlayWindow.Title;
			bool item9 = overlayWindow.Open;
			string tt = item8;
			bool o = item9;
			__builder.OpenElement(280, "button");
			__builder.AddAttribute(281, "class", "kp-liste-satir" + (o ? " acik" : ""));
			__builder.AddAttribute(282, "title", o ? "Gizle" : "Göster");
			__builder.AddAttribute(283, "aria-pressed", o);
			__builder.AddAttribute(284, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
			{
				if (tt == "Performans (FPS)")
				{
					TogglePerformance();
				}
				else
				{
					ToggleOverlayWindow(tt, o);
				}
			}));
			__builder.OpenElement(285, "span");
			__builder.AddAttribute(286, "class", "text-[13px] truncate");
			__builder.AddContent(287, T.L(tt));
			__builder.CloseElement();
			__builder.AddMarkupContent(288, "\r\n                    ");
			__builder.OpenElement(289, "svg");
			__builder.AddAttribute(290, "width", "18");
			__builder.AddAttribute(291, "height", "18");
			__builder.AddAttribute(292, "viewBox", "0 0 24 24");
			__builder.AddAttribute(293, "fill", "none");
			__builder.AddAttribute(294, "stroke", "currentColor");
			__builder.AddAttribute(295, "stroke-width", "2");
			__builder.AddAttribute(296, "opacity", o ? "1" : ".45");
			__builder.AddAttribute(297, "aria-hidden", "true");
			__builder.AddMarkupContent(298, "<path d=\"M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z\"></path><circle cx=\"12\" cy=\"12\" r=\"3\"></circle>");
			if (!o)
			{
				__builder.AddMarkupContent(299, "<path d=\"M3 3l18 18\"></path>");
			}
			__builder.CloseElement();
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.OpenRegion(9100);
		__builder.OpenComponent<Dialog>(1);
		__builder.AddComponentParameter(2, "Open", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(hedefUyariAcik));
		__builder.AddComponentParameter(3, "OpenChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool acik) =>
		{
			hedefUyariAcik = acik;
		})));
		__builder.AddComponentParameter(4, "Class", "max-w-xl!");
		__builder.AddAttribute(5, "ChildContent", (RenderFragment)((RenderTreeBuilder b) =>
		{
			b.OpenElement(6, "div");
			b.AddAttribute(7, "class", "flex flex-col gap-3");
			b.AddMarkupContent(8, "<h2 class=\"font-bold text-[20px]\">Sorumluluk uyarısı</h2>");
			b.OpenElement(9, "p");
			b.AddAttribute(10, "class", "description text-[13px]!");
			b.AddContent(11, "Bu özellik yardımcı bir araçtır ve tırın işaretli konumda her zaman tam olarak durmasını GARANTİ ETMEZ. Trafik, rota değişikliği, oyun verisindeki gecikme veya yol yapısı nedeniyle tır erken durabilir, geç durabilir ya da hedefi geçebilir. Bu özelliği kullanırken oluşabilecek kaza, hasar, ceza, teslimat kaybı ve TruckersMP dahil her türlü hesap yaptırımı tamamen kullanıcının sorumluluğundadır; ARC Studio sorumlu tutulamaz. Sürüş boyunca kontrol sende kalır, gerektiğinde hemen müdahale etmelisin.");
			b.CloseElement();
			b.OpenElement(12, "div");
			b.AddAttribute(13, "class", "flex gap-2 justify-end");
			b.OpenElement(14, "button");
			b.AddAttribute(15, "class", "button");
			b.AddAttribute(16, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
			{
				hedefUyariAcik = false;
			}));
			b.AddContent(17, "Vazgeç");
			b.CloseElement();
			b.OpenElement(18, "button");
			b.AddAttribute(19, "class", "button");
			b.AddAttribute(20, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
			{
				ArcSurusAyar.HedefteDurKabul();
				hedefUyariAcik = false;
			}));
			b.AddContent(21, "Okudum, sorumluluğu kabul ediyorum");
			b.CloseElement();
			b.CloseElement();
			b.CloseElement();
		}));
		__builder.CloseComponent();
		__builder.CloseRegion();
		__builder.AddMarkupContent(436, "\r\n\r\n    ");
		__builder.OpenComponent<Dialog>(437);
		__builder.AddComponentParameter(438, "Open", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(tanitimAcik));
		__builder.AddComponentParameter(439, "OpenChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool flag7) =>
		{
			if (!flag7)
			{
				TanitimiKapat();
			}
		})));
		__builder.AddComponentParameter(440, "Class", "max-w-xl!");
		__builder.AddAttribute(441, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder2) =>
		{
			ArcRehber.Adim adim2 = ArcRehber.Adimlar[tanitimAdim];
			renderTreeBuilder2.OpenElement(442, "div");
			renderTreeBuilder2.AddAttribute(443, "class", "flex flex-col gap-3");
			renderTreeBuilder2.OpenElement(444, "div");
			renderTreeBuilder2.AddAttribute(445, "class", "flex items-center justify-between");
			renderTreeBuilder2.OpenElement(446, "p");
			renderTreeBuilder2.AddAttribute(447, "class", "arc-etiket");
			renderTreeBuilder2.AddMarkupContent(448, "ETS2 AUTO DRIVE · ");
			renderTreeBuilder2.AddContent(449, tanitimAdim + 1);
			renderTreeBuilder2.AddContent(450, "/");
			renderTreeBuilder2.AddContent(451, ArcRehber.Adimlar.Length);
			renderTreeBuilder2.CloseElement();
			renderTreeBuilder2.AddMarkupContent(452, "\r\n                ");
			renderTreeBuilder2.OpenElement(453, "button");
			renderTreeBuilder2.AddAttribute(454, "class", "description text-[12px] hover:underline cursor-pointer");
			renderTreeBuilder2.AddAttribute(455, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)TanitimiKapat));
			renderTreeBuilder2.AddContent(456, "Atla");
			renderTreeBuilder2.CloseElement();
			renderTreeBuilder2.CloseElement();
			renderTreeBuilder2.AddMarkupContent(457, "\r\n            ");
			renderTreeBuilder2.OpenElement(458, "h2");
			renderTreeBuilder2.AddAttribute(459, "class", "font-bold text-[20px]");
			renderTreeBuilder2.AddContent(460, adim2.Baslik);
			renderTreeBuilder2.CloseElement();
			renderTreeBuilder2.AddMarkupContent(461, "\r\n            ");
			renderTreeBuilder2.OpenElement(462, "p");
			renderTreeBuilder2.AddAttribute(463, "class", "description text-[13px]!");
			renderTreeBuilder2.AddContent(464, adim2.Aciklama);
			renderTreeBuilder2.CloseElement();
			renderTreeBuilder2.AddMarkupContent(465, "\r\n            ");
			renderTreeBuilder2.OpenElement(466, "ul");
			renderTreeBuilder2.AddAttribute(467, "class", "flex flex-col gap-1.5 text-[13px]");
			string[] maddeler = adim2.Maddeler;
			string[] array = maddeler;
			foreach (string textContent3 in array)
			{
				renderTreeBuilder2.OpenElement(468, "li");
				renderTreeBuilder2.AddAttribute(469, "class", "flex gap-2");
				renderTreeBuilder2.AddMarkupContent(470, "<span class=\"text-accent\">•</span>");
				renderTreeBuilder2.OpenElement(471, "span");
				renderTreeBuilder2.AddContent(472, textContent3);
				renderTreeBuilder2.CloseElement();
				renderTreeBuilder2.CloseElement();
			}
			renderTreeBuilder2.CloseElement();
			renderTreeBuilder2.AddMarkupContent(473, "\r\n            ");
			renderTreeBuilder2.OpenElement(474, "div");
			renderTreeBuilder2.AddAttribute(475, "class", "flex gap-1.5 justify-center mt-1");
			for (int j = 0; j < ArcRehber.Adimlar.Length; j++)
			{
				renderTreeBuilder2.OpenElement(476, "span");
				renderTreeBuilder2.AddAttribute(477, "class", "h-1.5 rounded-full transition-all " + ((j == tanitimAdim) ? "w-6 bg-accent" : "w-1.5 bg-border"));
				renderTreeBuilder2.CloseElement();
			}
			renderTreeBuilder2.CloseElement();
			renderTreeBuilder2.AddMarkupContent(478, "\r\n            ");
			renderTreeBuilder2.OpenElement(479, "div");
			renderTreeBuilder2.AddAttribute(480, "class", "flex gap-2 mt-2");
			if (tanitimAdim > 0)
			{
				renderTreeBuilder2.OpenElement(481, "button");
				renderTreeBuilder2.AddAttribute(482, "class", "button");
				renderTreeBuilder2.AddAttribute(483, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
				{
					tanitimAdim--;
				}));
				renderTreeBuilder2.AddContent(484, "Geri");
				renderTreeBuilder2.CloseElement();
			}
			if (adim2.Yol != null)
			{
				renderTreeBuilder2.OpenElement(485, "button");
				renderTreeBuilder2.AddAttribute(486, "class", "button");
				renderTreeBuilder2.AddAttribute(487, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
				{
					TanitimdanGit(adim2.Yol);
				}));
				renderTreeBuilder2.AddContent(488, adim2.Dugme);
				renderTreeBuilder2.CloseElement();
			}
			if (tanitimAdim < ArcRehber.Adimlar.Length - 1)
			{
				renderTreeBuilder2.OpenElement(489, "button");
				renderTreeBuilder2.AddAttribute(490, "class", "button button-accent ml-auto");
				renderTreeBuilder2.AddAttribute(491, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
				{
					tanitimAdim++;
				}));
				renderTreeBuilder2.AddMarkupContent(492, "İleri");
				renderTreeBuilder2.CloseElement();
			}
			else
			{
				renderTreeBuilder2.OpenElement(493, "button");
				renderTreeBuilder2.AddAttribute(494, "class", "button button-accent ml-auto");
				renderTreeBuilder2.AddAttribute(495, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)TanitimiKapat));
				renderTreeBuilder2.AddContent(496, "Bitir");
				renderTreeBuilder2.CloseElement();
			}
			renderTreeBuilder2.CloseElement();
			renderTreeBuilder2.CloseElement();
		}));
		__builder.CloseComponent();
		__builder.AddMarkupContent(497, "\r\n\r\n    ");
		__builder.OpenComponent<Dialog>(498);
		__builder.AddComponentParameter(499, "Open", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(NewsSettingsDialogOpen));
		__builder.AddComponentParameter(500, "OpenChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool newsSettingsDialogOpen) =>
		{
			NewsSettingsDialogOpen = newsSettingsDialogOpen;
		})));
		__builder.AddAttribute(501, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder2) =>
		{
			renderTreeBuilder2.OpenElement(502, "div");
			renderTreeBuilder2.AddAttribute(503, "class", "flex flex-col gap-4");
			renderTreeBuilder2.OpenComponent<Switch>(504);
			renderTreeBuilder2.AddComponentParameter(505, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Show Plugin Updates")));
			renderTreeBuilder2.AddComponentParameter(506, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Show news articles about plugin updates, be that official or 3rd party plugins.")));
			renderTreeBuilder2.AddComponentParameter(507, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(WindowSettings.Current.ShowPluginUpdates));
			renderTreeBuilder2.AddComponentParameter(508, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool showPluginUpdates) =>
			{
				WindowSettings.Current.ShowPluginUpdates = showPluginUpdates;
			})));
			renderTreeBuilder2.CloseComponent();
			renderTreeBuilder2.AddMarkupContent(509, "\r\n            ");
			renderTreeBuilder2.OpenComponent<Switch>(510);
			renderTreeBuilder2.AddComponentParameter(511, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Only Show Official News")));
			renderTreeBuilder2.AddComponentParameter(512, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Only show news articles from official sources, such as the ETS2LA team or it's developers.")));
			renderTreeBuilder2.AddComponentParameter(513, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(WindowSettings.Current.OnlyFromOfficialUsers));
			renderTreeBuilder2.AddComponentParameter(514, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool onlyFromOfficialUsers) =>
			{
				WindowSettings.Current.OnlyFromOfficialUsers = onlyFromOfficialUsers;
			})));
			renderTreeBuilder2.CloseComponent();
			renderTreeBuilder2.AddMarkupContent(515, "\r\n            ");
			renderTreeBuilder2.OpenComponent<Switch>(516);
			renderTreeBuilder2.AddComponentParameter(517, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Translate News Articles")));
			renderTreeBuilder2.AddComponentParameter(518, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Translate news articles to your selected display language. This may take a while depending on the number of articles and your internet connection.")));
			renderTreeBuilder2.AddComponentParameter(519, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(WindowSettings.Current.TranslateNews));
			renderTreeBuilder2.AddComponentParameter(520, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool translateNews) =>
			{
				WindowSettings.Current.TranslateNews = translateNews;
			})));
			renderTreeBuilder2.CloseComponent();
			renderTreeBuilder2.AddMarkupContent(521, "\r\n            ");
			renderTreeBuilder2.OpenElement(522, "p");
			renderTreeBuilder2.AddAttribute(523, "class", "description mt-2");
			renderTreeBuilder2.AddContent(524, T._("Press anywhere outside the dialog to close it."));
			renderTreeBuilder2.CloseElement();
			renderTreeBuilder2.CloseElement();
		}));
		__builder.CloseComponent();
		__builder.AddMarkupContent(525, "\r\n\r\n    ");
		__builder.OpenComponent<Dialog>(526);
		__builder.AddComponentParameter(527, "Open", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(UserExpiredDialogueOpen));
		__builder.AddComponentParameter(528, "OpenChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool flag7) =>
		{
			if (!flag7)
			{
				NetworkingClient.Current.TokenExpired = false;
			}
		})));
		__builder.AddAttribute(529, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder2) =>
		{
			renderTreeBuilder2.OpenElement(530, "div");
			renderTreeBuilder2.AddAttribute(531, "class", "flex flex-col gap-4");
			renderTreeBuilder2.OpenElement(532, "p");
			renderTreeBuilder2.AddContent(533, T._("Your session has expired or you don't have a connection to our servers. Please log in again if you wish to use server-side features."));
			renderTreeBuilder2.CloseElement();
			renderTreeBuilder2.AddMarkupContent(534, "\r\n            ");
			renderTreeBuilder2.OpenElement(535, "button");
			renderTreeBuilder2.AddAttribute(536, "class", "button button-accent w-full! mt-3");
			renderTreeBuilder2.AddAttribute(537, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
			{
				NetworkingClient.Current.TokenExpired = false;
				Navigation.NavigateTo("/settings/account", forceLoad: true);
			}));
			renderTreeBuilder2.AddContent(538, T._("Go to Account Settings"));
			renderTreeBuilder2.CloseElement();
			renderTreeBuilder2.AddMarkupContent(539, "\r\n            ");
			renderTreeBuilder2.OpenElement(540, "p");
			renderTreeBuilder2.AddAttribute(541, "class", "description mt-2");
			renderTreeBuilder2.AddContent(542, T._("Press anywhere outside the dialog to close it."));
			renderTreeBuilder2.CloseElement();
			renderTreeBuilder2.CloseElement();
		}));
		__builder.CloseComponent();
		__builder.CloseElement();
	}

	private void RefreshOverlayWindows()
	{
		try
		{
			OverlayWindows = OverlayHandler.Current.GetWindows();
		}
		catch
		{
		}
		InvokeAsync((Action)StateHasChanged);
	}

	private void ToggleOverlayWindow(string title, bool open)
	{
		OverlayHandler.Current.SetWindowOpen(title, !open);
		RefreshOverlayWindows();
	}

	private void ToggleUnlimitedSpeed()
	{
		AssistanceSettings current = AssistanceSettings.Current;
		bool flag = !UnlimitedSpeed;
		current.MaximumSpeed = 0f;
		current.EnabledTrafficRules = (flag ? current.EnabledTrafficRules.Where((TrafficRule r) => r != TrafficRule.Speedlimits).ToList() : current.EnabledTrafficRules.Append(TrafficRule.Speedlimits).Distinct().ToList());
		current.Save();
	}

	private void ToggleRoadArrows()
	{
		OverlaySettings settings = OverlaySettingsHandler.Current.GetSettings();
		settings.ShowRoadArrows = !settings.ShowRoadArrows;
		OverlaySettingsHandler.Current.Save();
	}

	private void OkRengi(string? renk)
	{
		if (!string.IsNullOrWhiteSpace(renk))
		{
			OverlaySettingsHandler.Current.GetSettings().RoadArrowColor = renk.ToUpperInvariant();
			OverlaySettingsHandler.Current.Save();
		}
	}

	private static IPlugin? Eklenti(string id)
	{
		return PluginBackend.Current.PluginHandler?.LoadedPlugins.FirstOrDefault((IPlugin p) => p.Info.Id == id);
	}

	private void ToggleEklenti(string id)
	{
		PluginHandler pluginHandler = PluginBackend.Current.PluginHandler;
		IPlugin plugin = Eklenti(id);
		if (pluginHandler != null && plugin != null)
		{
			if (plugin._IsRunning)
			{
				pluginHandler.DisablePlugin(plugin);
			}
			else
			{
				pluginHandler.EnablePlugin(plugin);
			}
		}
	}

	private void ToggleDriveHud()
	{
		OverlaySettings settings = OverlaySettingsHandler.Current.GetSettings();
		settings.ShowDriveHud = !settings.ShowDriveHud;
		OverlaySettingsHandler.Current.Save();
	}

	private void TogglePerformance()
	{
		OverlayHandler.Current.PerformanceVisible = !OverlayHandler.Current.PerformanceVisible;
		RefreshOverlayWindows();
	}

	private static float HizCevir(float ms)
	{
		return ms * (Metrik ? 3.6f : 2.23694f);
	}

	private static string F(double v)
	{
		return v.ToString("0.##", CultureInfo.InvariantCulture);
	}

	private static string Vites(int g)
	{
		if (g <= 0)
		{
			if (g >= 0)
			{
				return "N";
			}
			return $"R{-g}";
		}
		return $"D{g}";
	}

	private static string Sure(float sn)
	{
		TimeSpan timeSpan = TimeSpan.FromSeconds(Math.Max(0f, sn));
		if (!(timeSpan.TotalHours >= 1.0))
		{
			return $"{timeSpan.Minutes} dk";
		}
		return $"{(int)timeSpan.TotalHours} sa {timeSpan.Minutes} dk";
	}

	private static MarkupString Ikon(string yol)
	{
		return new MarkupString("<svg viewBox='0 0 24 24' width='18' height='18' fill='none' stroke='currentColor' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round' aria-hidden='true'>" + yol + "</svg>");
	}

	private void TelemetriTik()
	{
		GameTelemetryData tele = Tele;
		string text = $"{OyunBagli}|{ApplicationState.Current.EnableAssists}|{ApplicationState.Current.DrivingMode}|{(int)HizCevir(Math.Abs(tele.truckFloat.speed))}|{(int)tele.truckFloat.speedLimit}|{(int)ApplicationState.Current.DesiredSpeed}|{tele.truckInt.gear}|{(int)(tele.truckFloat.routeDistance / 100f)}|{(int)(tele.truckFloat.routeTime / 60f)}|{(int)(tele.truckFloat.engineRpm / 50f)}|{tele.truckBool.cruiseControl}|{(int)tele.truckFloat.fuel}";
		if (!(text == telemetriImza))
		{
			telemetriImza = text;
			InvokeAsync((Action)StateHasChanged);
		}
	}

	public void Dispose()
	{
		telemetriTimer?.Dispose();
		overlayTimer?.Dispose();
	}

	private void TanitimiKapat()
	{
		tanitimAcik = false;
		WindowSettings.Current.ArcIntroSeen = true;
		WindowSettings.Current.Save();
	}

	private void TanitimdanGit(string yol)
	{
		TanitimiKapat();
		Navigation.NavigateTo(yol);
	}

	private void SelectDrivingMode(DrivingMode mode)
	{
		ApplicationState.Current.DrivingMode = mode;
		StateHasChanged();
	}

	private void ToggleAssists()
	{
		ApplicationState.Current.SetAssistsEnabled(!ApplicationState.Current.EnableAssists);
		StateHasChanged();
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		if (!WindowSettings.Current.HasCompletedOnboarding)
		{
			Navigation.NavigateTo("/onboarding", forceLoad: true);
		}
		if (!alreadyChecked)
		{
			Task.Run(() =>
			{
				CheckForUpdates();
			});
			Task.Run(() =>
			{
				LoadNewsArticles();
			});
			alreadyChecked = true;
		}
		overlayTimer = new Timer((object? _) =>
		{
			RefreshOverlayWindows();
		}, null, 0, 2000);
		telemetriTimer = new Timer((object? _) =>
		{
			TelemetriTik();
		}, null, 0, 250);
	}

	private async void LoadNewsArticles()
	{
		Language language = StateSettingsHandler.Current.GetSettings().DisplayLanguage;
		foreach (Article article in NetworkingClient.Current.News.Articles)
		{
			bool flag = article.Content.Contains("plugin update", StringComparison.OrdinalIgnoreCase) || article.Content.Contains("library update", StringComparison.OrdinalIgnoreCase);
			bool flag2 = article.Author.Equals("ETS2LA Team", StringComparison.OrdinalIgnoreCase) || article.Author.Equals("Tumppi066", StringComparison.OrdinalIgnoreCase);
			if (!(!WindowSettings.Current.ShowPluginUpdates & flag) && (!WindowSettings.Current.OnlyFromOfficialUsers | flag2))
			{
				ArticleWrappers.Add(new ArticleWrapper
				{
					Article = article,
					RenderedTitle = Markdown.ToHtml(article.Title ?? string.Empty, Pipeline),
					RenderedContentSummary = Markdown.ToHtml(article.ContentSummary ?? string.Empty, Pipeline),
					RenderedContent = Markdown.ToHtml(article.Content ?? string.Empty, Pipeline)
				});
			}
		}
		InvokeAsync((Action)StateHasChanged);
		if (!WindowSettings.Current.TranslateNews || language.Code == "en")
		{
			return;
		}
		foreach (ArticleWrapper wrapper in ArticleWrappers)
		{
			DynamicTranslationTask titleTranslationTask = new DynamicTranslationTask(wrapper.Article.Title ?? string.Empty, language.Code.Replace("_", "-"));
			DynamicTranslationTask contentSummaryTranslationTask = new DynamicTranslationTask(wrapper.Article.ContentSummary ?? string.Empty, language.Code.Replace("_", "-"));
			DynamicTranslationTask contentTranslationTask = new DynamicTranslationTask(wrapper.Article.Content ?? string.Empty, language.Code.Replace("_", "-"));
			titleTranslationTask.OnTranslationCompleted += (string translatedText) =>
			{
				wrapper.TranslatedTitle = translatedText;
				wrapper.RenderedTitle = Markdown.ToHtml(translatedText, Pipeline);
			};
			contentSummaryTranslationTask.OnTranslationCompleted += (string translatedText) =>
			{
				wrapper.TranslatedContentSummary = translatedText;
				wrapper.RenderedContentSummary = Markdown.ToHtml(translatedText, Pipeline);
			};
			contentTranslationTask.OnTranslationCompleted += (string translatedText) =>
			{
				wrapper.TranslatedContent = translatedText;
				wrapper.RenderedContent = Markdown.ToHtml(translatedText, Pipeline);
			};
			InlineArray3<Task> buffer = default;
			buffer[0] = Task.Run(() => titleTranslationTask.StartTranslationAsync());
			buffer[1] = Task.Run(() => contentSummaryTranslationTask.StartTranslationAsync());
			buffer[2] = Task.Run(() => contentTranslationTask.StartTranslationAsync());
			await Task.WhenAll(buffer);
			InvokeAsync((Action)StateHasChanged);
		}
	}

	private void CheckForUpdates()
	{
	}

	private void OpenInBrowser(string url)
	{
		UserInterfaceUtils.OpenUrl(url);
	}

	private void OnSponsorBadgeLoaded()
	{
		sponsorBadgeLoaded = true;
		sponsorBadgeFailed = false;
	}

	private void OnSponsorBadgeFailed()
	{
		sponsorBadgeLoaded = false;
		sponsorBadgeFailed = true;
	}

	private void OpenSponsorPage()
	{
		UserInterfaceUtils.OpenUrl("https://github.com/sponsors/Tumppi066");
	}
}
