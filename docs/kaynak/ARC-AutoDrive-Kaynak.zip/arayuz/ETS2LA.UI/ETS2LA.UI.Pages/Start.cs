using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using ETS2LA.Game;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages;

[Route("/start")]
public class Start : ComponentBase
{
	private string? truckersMP = ArcHub.TruckersMpBul();

	private List<Installation> Games => GameHandler.Current.Installations;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-108 m-5 ml-8 gap-6");
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex flex-col gap-2");
		__builder.AddMarkupContent(4, "<h2 class=\"font-bold text-[18px]\">TruckersMP</h2>");
		if (truckersMP != null)
		{
			__builder.OpenElement(5, "button");
			__builder.AddAttribute(6, "class", "button button-accent w-full!");
			__builder.AddAttribute(7, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)StartTruckersMP));
			__builder.AddMarkupContent(8, "TruckersMP'de Başlat");
			__builder.CloseElement();
			__builder.AddMarkupContent(9, "\r\n            ");
			__builder.OpenElement(10, "p");
			__builder.AddAttribute(11, "class", "description text-[11px]! break-all");
			__builder.AddContent(12, truckersMP);
			__builder.CloseElement();
			__builder.AddMarkupContent(13, "\r\n            ");
			__builder.OpenElement(14, "button");
			__builder.AddAttribute(15, "class", "button button-small self-start");
			__builder.AddAttribute(16, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)SelectTruckersMP));
			__builder.AddMarkupContent(17, "Başka konum seç");
			__builder.CloseElement();
		}
		else
		{
			__builder.AddMarkupContent(18, "<p class=\"description\">TruckersMP launcher'ı bulunamadı. Kuruluysa konumunu seç, değilse indir.</p>\r\n            ");
			__builder.OpenElement(19, "div");
			__builder.AddAttribute(20, "class", "flex gap-2");
			__builder.OpenElement(21, "button");
			__builder.AddAttribute(22, "class", "button button-accent");
			__builder.AddAttribute(23, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)SelectTruckersMP));
			__builder.AddMarkupContent(24, "Konumu seç");
			__builder.CloseElement();
			__builder.AddMarkupContent(25, "\r\n                ");
			__builder.OpenElement(26, "button");
			__builder.AddAttribute(27, "class", "button");
			__builder.AddAttribute(28, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)DownloadTruckersMP));
			__builder.AddMarkupContent(29, "İndir");
			__builder.CloseElement();
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.AddMarkupContent(30, "\r\n\r\n    ");
		__builder.OpenElement(31, "div");
		__builder.AddAttribute(32, "class", "flex flex-col gap-2");
		__builder.AddMarkupContent(33, "<h2 class=\"font-bold text-[18px]\">Tek oyunculu</h2>");
		foreach (Installation game in Games)
		{
			__builder.OpenElement(34, "button");
			__builder.AddAttribute(35, "class", "button w-full!");
			__builder.AddAttribute(36, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
			{
				StartGame(game);
			}));
			__builder.AddMarkupContent(37, "Oyunu Başlat");
			__builder.CloseElement();
			__builder.AddMarkupContent(38, "\r\n            ");
			__builder.OpenElement(39, "p");
			__builder.AddAttribute(40, "class", "description text-[11px]! break-all");
			__builder.AddContent(41, game.ExecutablePath);
			__builder.CloseElement();
		}
		if (Games.Count == 0)
		{
			__builder.AddMarkupContent(42, "<p class=\"description\">Oyun bulunamadı. Ayarlar → Oyun SDK'sı sayfasından ekleyebilirsin.</p>");
		}
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private void StartGame(Installation game)
	{
		string executablePath = game.ExecutablePath;
		if (!File.Exists(executablePath))
		{
			UserInterface.Current.Window.ShowMessageOnTop(T._("Game not found"), T._("The selected game executable was not found."));
		}
		else
		{
			Process.Start(executablePath);
		}
	}

	private void StartTruckersMP()
	{
		truckersMP = ArcHub.TruckersMpBul();
		if (truckersMP != null)
		{
			Process.Start(new ProcessStartInfo(truckersMP)
			{
				UseShellExecute = true,
				WorkingDirectory = Path.GetDirectoryName(truckersMP)
			});
		}
	}

	private void SelectTruckersMP()
	{
		string text = UserInterface.Current.Window.ShowOpenFile("TruckersMP Launcher", null, multiSelect: false, new (string, string[])[1] { ("TruckersMP Launcher", new string[1] { ".exe" }) }).FirstOrDefault();
		if (text != null && File.Exists(text))
		{
			WindowSettings.Current.TruckersMPPath = text;
			WindowSettings.Current.Save();
			truckersMP = text;
		}
	}

	private void DownloadTruckersMP()
	{
		Process.Start(new ProcessStartInfo("https://truckersmp.com/download")
		{
			UseShellExecute = true
		});
	}
}
