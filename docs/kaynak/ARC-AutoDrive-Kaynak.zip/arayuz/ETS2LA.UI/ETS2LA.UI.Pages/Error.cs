using System.Collections.Generic;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Pages;

[Route("/Error/{StatusCode:int}/{Message}")]
public class Error : ComponentBase
{
	private static readonly Dictionary<int, string> HttpDescriptions = new Dictionary<int, string>
	{
		[400] = T._("The server could not understand the request due to invalid syntax or corrupted request data."),
		[401] = T._("Authentication is required. The client must authenticate itself to get the requested response."),
		[403] = T._("You do not have permission to access this resource. The server understood the request but refuses to authorize it."),
		[404] = T._("The server cannot find the requested resource. The URL may be misspelled, or the resource has been removed."),
		[405] = T._("The request method is recognized by the server but is not supported by the target resource."),
		[408] = T._("The server timed out waiting for the request from the client."),
		[429] = T._("Too many requests. You have sent too many requests in a given amount of time."),
		[500] = T._("Internal server error. The server encountered an unexpected condition that prevented it from fulfilling the request."),
		[502] = T._("Bad gateway. The server, while acting as a gateway or proxy, received an invalid response from an inbound server."),
		[503] = T._("Service unavailable. The server is currently unable to handle the request due to temporary overloading or maintenance."),
		[504] = T._("Gateway timeout. The server was acting as a gateway or proxy and did not receive a timely response from the upstream server.")
	};

	[Parameter]
	public int StatusCode { get; set; } = 404;

	[Parameter]
	public string Message { get; set; } = "Not Found";

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col p-6 w-lg");
		if (Message == "Not Found")
		{
			__builder.AddMarkupContent(2, "<img class=\"rounded-md\" src=\"https://static2.klipy.com/ii/c3a19a0b747a76e98651f2b9a3cca5ff/4d/87/oyStUROc.gif\" alt=\"Kermit is lost, he's looking at a map and around him.\">\r\n        <br>\r\n        ");
			__builder.OpenElement(3, "p");
			__builder.AddContent(4, T._("You took a wrong turn!"));
			__builder.CloseElement();
			__builder.AddMarkupContent(5, "\r\n        ");
			__builder.AddMarkupContent(6, "<p class=\"description\">\r\n            Buraya nasıl geldin? Bize <a href=\"https://discord.gg/n9tyDcqwbA\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"text-text-l hover:underline\">Discord sunucumuzdan</a> haber ver.\r\n        </p>");
		}
		else
		{
			__builder.OpenElement(7, "img");
			__builder.AddAttribute(8, "class", "rounded-md");
			__builder.AddAttribute(9, "src", "https://http.cat/" + StatusCode);
			__builder.AddAttribute(10, "alt", "Cat status code " + StatusCode);
			__builder.CloseElement();
			__builder.AddMarkupContent(11, "\r\n        <br>\r\n        ");
			__builder.OpenElement(12, "p");
			__builder.AddContent(13, StatusCode);
			__builder.AddContent(14, " - ");
			__builder.AddContent(15, Message);
			__builder.CloseElement();
			__builder.AddMarkupContent(16, "\r\n        ");
			__builder.OpenElement(17, "p");
			__builder.AddAttribute(18, "class", "description");
			__builder.AddContent(19, GetHttpDescription(StatusCode));
			__builder.AddMarkupContent(20, "<br><br>\r\n            Bunun bir hata olduğunu düşünüyorsan ");
			__builder.AddMarkupContent(21, "<a href=\"https://discord.gg/n9tyDcqwbA\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"text-text-l hover:underline\">Discord sunucumuzdan</a> bildir.\r\n        ");
			__builder.CloseElement();
		}
		__builder.CloseElement();
	}

	private string GetHttpDescription(int code)
	{
		if (!HttpDescriptions.TryGetValue(code, out var value))
		{
			return string.Empty;
		}
		return value;
	}
}
