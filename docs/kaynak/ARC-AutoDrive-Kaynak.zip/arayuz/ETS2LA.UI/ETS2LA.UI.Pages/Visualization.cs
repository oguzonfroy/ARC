using System;
using System.Linq;
using ETS2LA.Backend;
using ETS2LA.Backend.Events;
using ETS2LA.Game.Telemetry;
using ETS2LA.Shared;
using ETS2LA.State;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Pages;

[Route("/visualization")]
public class Visualization : ComponentBase
{
	private IPlugin? VisualizationSockets;

	private float RealPedalValue
	{
		get
		{
			TruckFloat truckFloat = GameTelemetry.Current.GetCurrentData().truckFloat;
			return Math.Clamp(Math.Max(truckFloat.gameThrottle, truckFloat.gameBrake), 0f, 1f);
		}
	}

	private float GivenPedalValue
	{
		get
		{
			TruckFloat truckFloat = GameTelemetry.Current.GetCurrentData().truckFloat;
			return Math.Clamp(Math.Max(truckFloat.userThrottle, truckFloat.userBrake), 0f, 1f);
		}
	}

	private bool IsBraking => GameTelemetry.Current.GetCurrentData().truckFloat.gameBrake > 0.01f;

	private bool IsControllingAcceleration
	{
		get
		{
			if (ApplicationState.Current.DrivingMode <= DrivingMode.FullSelfDriving)
			{
				return ApplicationState.Current.EnableAssists;
			}
			return false;
		}
	}

	private bool RightIndicator => GameTelemetry.Current.GetCurrentData().truckBool.blinkerRightOn;

	private bool LeftIndicator => GameTelemetry.Current.GetCurrentData().truckBool.blinkerLeftOn;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "w-full h-full overflow-hidden");
		if (VisualizationSockets == null || !VisualizationSockets._IsRunning)
		{
			__builder.OpenElement(2, "div");
			__builder.AddAttribute(3, "class", "w-full h-full flex flex-col justify-center items-center gap-2");
			__builder.OpenElement(4, "p");
			__builder.AddAttribute(5, "class", "font-bold");
			__builder.AddContent(6, T._("Please enable the Visualization Sockets plugin."));
			__builder.CloseElement();
			__builder.AddMarkupContent(7, "\n            ");
			__builder.OpenElement(8, "p");
			__builder.AddAttribute(9, "class", "description");
			__builder.AddContent(10, T._("If you've not yet installed it, you can find it in the catalogue."));
			__builder.CloseElement();
			__builder.CloseElement();
		}
		else
		{
			__builder.OpenElement(11, "div");
			__builder.AddAttribute(12, "class", "w-full h-full relative");
			__builder.AddMarkupContent(13, "<iframe src=\"Visualization/index.html\" class=\"w-full h-full bg-bg\"></iframe>\n            \n            \n            ");
			__builder.OpenElement(14, "div");
			__builder.AddAttribute(15, "class", "absolute top-0 left-0 right-0 bottom-0 flex");
			__builder.OpenElement(16, "div");
			__builder.AddAttribute(17, "class", "w-full h-full flex flex-col justify-between");
			__builder.OpenElement(18, "div");
			__builder.AddAttribute(19, "class", "flex flex-row w-full gap-5");
			__builder.OpenElement(20, "div");
			__builder.AddAttribute(21, "class", "ml-4 mt-4 h-28 w-2 overflow-hidden rounded-md bg-white/15");
			__builder.OpenElement(22, "div");
			__builder.AddAttribute(23, "class", "relative h-full w-full");
			__builder.OpenElement(24, "div");
			string text;
			if (IsBraking)
			{
				text = "bg-red-400 top-0";
			}
			else
			{
				text = (IsControllingAcceleration ? "bg-sky-400 bottom-0" : "bg-gray-400 bottom-0");
			}
			__builder.AddAttribute(25, "class", "z-5 absolute inset-x-0 rounded-md " + text);
			__builder.AddAttribute(26, "style", "height: " + GivenPedalValue * 100f + "%;");
			__builder.CloseElement();
			__builder.AddMarkupContent(27, "\n                                ");
			__builder.OpenElement(28, "div");
			string text2;
			if (IsBraking)
			{
				text2 = "bg-red-500 top-0";
			}
			else
			{
				text2 = (IsControllingAcceleration ? "bg-sky-500 bottom-0" : "bg-gray-500 bottom-0");
			}
			__builder.AddAttribute(29, "class", "z-10 absolute inset-x-0 rounded-md " + text2);
			__builder.AddAttribute(30, "style", "height: " + RealPedalValue * 100f + "%;");
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.AddMarkupContent(31, "\n                        ");
			__builder.OpenElement(32, "div");
			__builder.AddAttribute(33, "class", "flex flex-col mt-4");
			__builder.OpenElement(34, "p");
			__builder.AddAttribute(35, "class", "text-[72px] font-normal leading-none");
			__builder.AddContent(36, Math.Abs(Math.Round(UnitConversions.FromScientificUnits(UnitType.Speed, GameTelemetry.Current.GetCurrentData().truckFloat.speed, ApplicationState.Current.DisplayUnits), 0)));
			__builder.CloseElement();
			__builder.AddMarkupContent(37, "\n                            ");
			__builder.OpenElement(38, "p");
			__builder.AddAttribute(39, "class", "description text-[12px]");
			__builder.AddContent(40, UnitConversions.GetUnitAbbreviation(UnitType.Speed, ApplicationState.Current.DisplayUnits));
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.AddMarkupContent(41, "\n                    <div class=\"flex w-full h-full justify-end items-end\"></div>");
			__builder.CloseElement();
			__builder.AddMarkupContent(42, "\n                ");
			__builder.OpenElement(43, "div");
			__builder.AddAttribute(44, "class", "w-full h-full flex flex-col");
			__builder.OpenElement(45, "div");
			__builder.AddAttribute(46, "class", "flex w-full h-full justify-end");
			__builder.OpenElement(47, "div");
			__builder.AddAttribute(48, "class", "flex flex-col w-12.5 items-center mt-4 mr-6 gap-2");
			__builder.OpenElement(49, "div");
			__builder.AddAttribute(50, "class", "flex gap-1 px-2.5 items-center");
			__builder.OpenElement(51, "p");
			__builder.AddAttribute(52, "class", IsControllingAcceleration ? "text-sky-500 text-[18px]" : "text-description text-[18px]");
			__builder.AddContent(53, Math.Round(UnitConversions.FromScientificUnits(UnitType.Speed, ApplicationState.Current.DesiredSpeed, ApplicationState.Current.DisplayUnits), 0));
			__builder.CloseElement();
			if (IsControllingAcceleration)
			{
				__builder.AddMarkupContent(54, "<svg class=\"text-sky-500 text-[18px]\" xmlns=\"http://www.w3.org/2000/svg\" width=\"1em\" height=\"1em\" viewBox=\"0 0 24 24\"><path d=\"M0 0h24v24H0z\" fill=\"none\"></path>\n                                        <g fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\"><path d=\"M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0\"></path>\n                                            <path d=\"M11 12a1 1 0 1 0 2 0a1 1 0 1 0-2 0m2.41-1.41L16 8m-9 4a5 5 0 0 1 5-5\"></path></g></svg>");
			}
			else
			{
				__builder.AddMarkupContent(55, "<svg class=\"text-description text-[18px]\" xmlns=\"http://www.w3.org/2000/svg\" width=\"1em\" height=\"1em\" viewBox=\"0 0 24 24\"><path d=\"M0 0h24v24H0z\" fill=\"none\"></path>\n                                        <g fill=\"none\" stroke=\"currentColor\" stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\"><path d=\"M20.038 16.052A9 9 0 0 0 7.971 3.95M5.638 5.636a9 9 0 1 0 12.73 12.726\"></path>\n                                            <path d=\"M11.283 11.303a1 1 0 0 0 1.419 1.41M14 10l2-2m-9 4c0-1.386.564-2.64 1.475-3.546m2.619-1.372Q11.536 7.001 12 7M3 3l18 18\"></path></g></svg>");
			}
			__builder.CloseElement();
			__builder.AddMarkupContent(56, "\n\n                            ");
			__builder.OpenElement(57, "div");
			__builder.AddAttribute(58, "class", "relative w-12.5 h-12.5");
			__builder.AddMarkupContent(59, "<svg class=\"absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2\" height=\"50\" width=\"50\" xmlns=\"http://www.w3.org/2000/svg\"><circle r=\"23\" cx=\"25\" cy=\"25\" fill=\"none\" stroke=\"#D94646\" stroke-width=\"4\"></circle></svg>\n                                ");
			__builder.OpenElement(60, "p");
			__builder.AddAttribute(61, "class", "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[22px] font-normal");
			__builder.AddContent(62, Math.Abs(Math.Round(UnitConversions.FromScientificUnits(UnitType.Speed, GameTelemetry.Current.GetCurrentData().truckFloat.speedLimit, ApplicationState.Current.DisplayUnits), 0)));
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.AddMarkupContent(63, "\n                    <div class=\"flex w-full h-full justify-end items-end mb-4 mr-4\"></div>");
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.CloseElement();
		}
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		VisualizationSockets = PluginBackend.Current.PluginHandler?.LoadedPlugins.FirstOrDefault((IPlugin p) => p.Info.Id == "tumppi066.visualizationsockets");
		if (VisualizationSockets != null && VisualizationSockets._IsRunning)
		{
			WindowState.Current.IsSidebarOpen = false;
			WindowState.Current.RequestFullReload();
			Events.Current.Subscribe(GameTelemetry.Current.EventString, (GameTelemetryData data) =>
			{
				InvokeAsync((Action)StateHasChanged);
			});
		}
	}
}
