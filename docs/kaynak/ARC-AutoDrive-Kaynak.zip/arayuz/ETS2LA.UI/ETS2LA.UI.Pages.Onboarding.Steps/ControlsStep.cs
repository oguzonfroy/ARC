using System;
using System.Collections.Generic;
using ETS2LA.Controls;
using ETS2LA.State;
using ETS2LA.Translations;
using ETS2LA.UI.Pages.Settings;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Onboarding.Steps;

public class ControlsStep : ComponentBase
{
	[Parameter]
	public Action OnNext { get; set; }

	[Parameter]
	public Action OnPrevious { get; set; }

	private List<string> DisplayOnly { get; set; } = new List<string> { "ETS2LA.Controls.Cancel", "ETS2LA.Controls.Increase", "ETS2LA.Controls.Decrease" };

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex gap-12 text-start items-center justify-center");
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex flex-col gap-2 max-w-108");
		__builder.OpenElement(4, "div");
		__builder.AddAttribute(5, "class", "flex flex-col gap-1");
		__builder.OpenElement(6, "h3");
		__builder.AddContent(7, (MarkupString)T._("Controls"));
		__builder.CloseElement();
		__builder.AddMarkupContent(8, "\n            ");
		__builder.OpenElement(9, "p");
		__builder.AddContent(10, (MarkupString)T._("ETS2LA uses a control setup that should be similar to real life systems. You can rebind the default controls on the right side."));
		__builder.CloseElement();
		__builder.AddMarkupContent(11, "\n            ");
		__builder.OpenElement(12, "p");
		__builder.AddAttribute(13, "class", "pt-1");
		__builder.AddContent(14, (MarkupString)T._("Assists Enabled: <span class=\"text-text-accent font-bold\">{0}</span>", ApplicationState.Current.EnableAssists));
		__builder.CloseElement();
		__builder.AddMarkupContent(15, "\n            ");
		__builder.OpenElement(16, "p");
		__builder.AddContent(17, (MarkupString)T._("Assist Mode: <span class=\"text-text-accent font-bold\">{0}</span>", ApplicationState.Current.DrivingModeTranslation[ApplicationState.Current.DrivingMode]));
		__builder.CloseElement();
		__builder.AddMarkupContent(18, "\n            ");
		__builder.OpenElement(19, "p");
		__builder.AddContent(20, (MarkupString)T._("Target Speed: <span class=\"text-text-accent font-bold\">{0} {1}</span>", (int)Math.Round(UnitConversions.FromScientificUnits(UnitType.Speed, ApplicationState.Current.DesiredSpeed, ApplicationState.Current.DisplayUnits), 0), UnitConversions.GetUnitAbbreviation(UnitType.Speed, ApplicationState.Current.DisplayUnits)));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(21, "\n\n        ");
		__builder.OpenElement(22, "div");
		__builder.AddAttribute(23, "class", "flex gap-2 mt-2");
		__builder.OpenElement(24, "button");
		__builder.AddAttribute(25, "class", "button w-full!");
		__builder.AddAttribute(26, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, OnNext));
		__builder.AddContent(27, T._("Continue"));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(28, "\n        \n        <img src=\"assets/defaultcontrols.png\" alt=\"Control Image\" class=\"max-w-full rounded-md mt-3\">");
		__builder.CloseElement();
		__builder.AddMarkupContent(29, "\n\n    ");
		__builder.OpenElement(30, "div");
		__builder.AddAttribute(31, "class", "max-w-120 max-h-full overflow-y-auto overflow-x-hidden flex flex-col gap-2");
		__builder.OpenComponent<ETS2LA.UI.Pages.Settings.Controls>(32);
		__builder.AddComponentParameter(33, "DisplayOnly", RuntimeHelpers.TypeCheck(DisplayOnly));
		__builder.CloseComponent();
		__builder.CloseElement();
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		ControlsBackend.Current.On("ETS2LA.Controls.Cancel", (object value, ControlChangeEventArgs args) =>
		{
			InvokeAsync((Action)StateHasChanged);
		});
		ControlsBackend.Current.On("ETS2LA.Controls.Increase", (object value, ControlChangeEventArgs args) =>
		{
			InvokeAsync((Action)StateHasChanged);
		});
		ControlsBackend.Current.On("ETS2LA.Controls.Decrease", (object value, ControlChangeEventArgs args) =>
		{
			InvokeAsync((Action)StateHasChanged);
		});
	}
}
