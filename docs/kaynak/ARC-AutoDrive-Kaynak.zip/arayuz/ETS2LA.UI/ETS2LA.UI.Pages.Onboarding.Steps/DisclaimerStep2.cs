using System;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Onboarding.Steps;

public class DisclaimerStep2 : ComponentBase
{
	[Parameter]
	public Action OnNext { get; set; }

	[Parameter]
	public Action OnPrevious { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col gap-2");
		__builder.OpenElement(2, "h3");
		__builder.AddContent(3, (MarkupString)T._("Final Disclaimer <span class=\"description\">2/2</span>"));
		__builder.CloseElement();
		__builder.AddMarkupContent(4, "\n    ");
		__builder.OpenElement(5, "div");
		__builder.AddAttribute(6, "class", "max-w-108");
		__builder.OpenElement(7, "p");
		__builder.AddContent(8, (MarkupString)T._("Additionally, some communities like VTCs, Job Trackers and Leaderboards will ban either specific features, or the entirety of ETS2LA. <span class=\"text-text-accent font-bold\">Please check with your community <i>before</i> using ETS2LA.</span>"));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(9, "\n\n    ");
		__builder.OpenElement(10, "div");
		__builder.AddAttribute(11, "class", "flex gap-2 mt-4");
		__builder.OpenElement(12, "button");
		__builder.AddAttribute(13, "class", "button w-full!");
		__builder.AddAttribute(14, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, OnNext));
		__builder.AddContent(15, T._("I understand, now let me in!"));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}
}
