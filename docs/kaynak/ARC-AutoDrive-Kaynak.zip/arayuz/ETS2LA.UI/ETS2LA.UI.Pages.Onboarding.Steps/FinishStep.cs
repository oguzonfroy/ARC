using System;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Pages.Onboarding.Steps;

public class FinishStep : ComponentBase
{
	private bool isSidebarOpen => WindowState.Current.IsSidebarOpen;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "left-2 flex absolute gap-2 transition-all duration-300 ease-in-out" + (isSidebarOpen ? " top-56.5" : " top-2"));
		__builder.AddMarkupContent(2, "<p class=\"animate-pulse text-lg\">\ud83e\udc50</p>\n    ");
		__builder.OpenElement(3, "div");
		__builder.AddAttribute(4, "class", "mt-0.5");
		if (isSidebarOpen)
		{
			__builder.OpenElement(5, "p");
			__builder.AddContent(6, T._("You can enable the plugins we installed in a previous step here."));
			__builder.CloseElement();
		}
		else
		{
			__builder.OpenElement(7, "p");
			__builder.AddContent(8, T._("Use this button to extend the sidebar."));
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(9, "\n\n");
		__builder.OpenElement(10, "p");
		__builder.AddAttribute(11, "class", "description");
		__builder.AddContent(12, T._("Look in the top left corner."));
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		WindowState.Current.NeedsFullReload += (object? sender, EventArgs e) =>
		{
			InvokeAsync((Action)StateHasChanged);
		};
		WindowSettings.Current.HasCompletedOnboarding = true;
		WindowSettings.Current.Save();
	}
}
