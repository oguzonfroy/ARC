using System;
using System.Threading.Tasks;
using ETS2LA.Logging;
using ETS2LA.Networking;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Onboarding.Steps;

public class PluginStep : ComponentBase
{
	private bool installing;

	private bool installed;

	[Parameter]
	public Action OnNext { get; set; }

	[Parameter]
	public Action OnPrevious { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col gap-2 max-w-108");
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex flex-col gap-1");
		__builder.OpenElement(4, "h3");
		__builder.AddContent(5, T._("Recommended Plugins"));
		__builder.CloseElement();
		__builder.AddMarkupContent(6, "\n        ");
		__builder.OpenElement(7, "p");
		__builder.AddContent(8, (MarkupString)T._("To get started fast, you can install our <span class=\"text-text-accent font-bold\">recommended</span> plugins. These contain everything you need to get driving."));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(9, "\n\n    ");
		__builder.OpenElement(10, "div");
		__builder.AddAttribute(11, "class", "mt-2 flex flex-col gap-2");
		if (!installing)
		{
			if (installed)
			{
				__builder.OpenElement(12, "p");
				__builder.AddAttribute(13, "class", "mb-2");
				__builder.AddContent(14, (MarkupString)T._("<span class=\"text-text-accent\"))>Success!</span> You can find more plugins in the catalogue later."));
				__builder.CloseElement();
				__builder.AddMarkupContent(15, "\n                ");
				__builder.OpenElement(16, "button");
				__builder.AddAttribute(17, "class", "button button-accent w-full!");
				__builder.AddAttribute(18, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)RestartAndContinue));
				__builder.AddContent(19, T._("Restart and Continue"));
				__builder.CloseElement();
			}
			else
			{
				__builder.OpenElement(20, "button");
				__builder.AddAttribute(21, "class", "button button-accent w-full!");
				__builder.AddAttribute(22, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)InstallRecommendedPlugins));
				__builder.AddContent(23, T._("Install Plugins"));
				__builder.CloseElement();
				__builder.AddMarkupContent(24, "\n                ");
				__builder.OpenElement(25, "button");
				__builder.AddAttribute(26, "class", "button w-full!");
				__builder.AddAttribute(27, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, OnNext));
				__builder.AddContent(28, T._("Continue"));
				__builder.CloseElement();
			}
		}
		else
		{
			__builder.OpenElement(29, "p");
			__builder.AddAttribute(30, "class", "description");
			__builder.AddContent(31, T._("Installing..."));
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private void InstallRecommendedPlugins()
	{
		Logger.Info("Installing recommended plugins...", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Onboarding\\Steps\\PluginStep.razor", 19);
		Task.Run(() =>
		{
			installing = true;
			InvokeAsync(() =>
			{
				StateHasChanged();
			});
			NetworkingClient.Current.Plugins.InstallPlugin("tumppi066.laneassist");
			NetworkingClient.Current.Plugins.InstallPlugin("tumppi066.adaptivecruisecontrol");
			NetworkingClient.Current.Plugins.InstallPlugin("tumppi066.visualizationsockets");
			installing = false;
			installed = true;
			InvokeAsync(() =>
			{
				StateHasChanged();
			});
		});
	}

	private void RestartAndContinue()
	{
		WindowSettings.Current.OnboardingStep++;
		WindowSettings.Current.Save();
		UserInterfaceUtils.Restart();
	}
}
