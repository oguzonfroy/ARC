using System;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Onboarding.Steps;

public class SDKReminderStep : ComponentBase
{
	[Parameter]
	public Action OnNext { get; set; }

	[Parameter]
	public Action OnPrevious { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col gap-2 max-w-108");
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex flex-col gap-1");
		__builder.OpenElement(4, "h3");
		__builder.AddContent(5, T._("Remember!"));
		__builder.CloseElement();
		__builder.AddMarkupContent(6, "\n        ");
		__builder.OpenElement(7, "p");
		__builder.AddContent(8, (MarkupString)T._("You'll have to reinstall the SDK for <span class=\"text-text-accent font-bold\">every game update</span>. You'll find the installation page in the settings."));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(9, "\n\n    ");
		__builder.OpenElement(10, "div");
		__builder.AddAttribute(11, "class", "flex gap-2 mt-2");
		__builder.OpenElement(12, "button");
		__builder.AddAttribute(13, "class", "button w-full!");
		__builder.AddAttribute(14, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, OnNext));
		__builder.AddContent(15, T._("I understand"));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}
}
