using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using ETS2LA.Logging;
using ETS2LA.Notifications;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Onboarding.Steps;

public class EnsureGameClosed : ComponentBase
{
	[Parameter]
	public Action OnNext { get; set; }

	[Parameter]
	public Action OnPrevious { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col gap-2 max-w-108");
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex flex-col gap-1");
		__builder.OpenElement(4, "h3");
		__builder.AddContent(5, T._("Before we begin."));
		__builder.CloseElement();
		__builder.AddMarkupContent(6, "\n        ");
		__builder.OpenElement(7, "p");
		__builder.AddContent(8, (MarkupString)T._("Please ensure <span class=\"text-text-accent font-bold\">ETS2 and ATS are closed</span>. You can start the game after completing the onboarding process."));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(9, "\n\n    ");
		__builder.OpenElement(10, "div");
		__builder.AddAttribute(11, "class", "flex gap-2 mt-2");
		__builder.OpenElement(12, "button");
		__builder.AddAttribute(13, "class", "button w-full!");
		__builder.AddAttribute(14, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)ContinueIfGameClosed));
		__builder.AddContent(15, T._("Continue"));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
	}

	private void ContinueIfGameClosed()
	{
		List<string> searchFor = new List<string> { "eurotrucks2", "amtrucks" };
		if ((from p in Process.GetProcesses()
			where searchFor.Any((string s) => p.ProcessName.ToLower().Contains(s))
			select p).ToList().Count > 0)
		{
			Logger.Info("Game is still running, cannot continue onboarding.", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Onboarding\\Steps\\EnsureGameClosed.razor", 28);
			NotificationHandler.Current.SendNotification(new Notification
			{
				Id = "ETS2LA.UI.Onboarding.EnsureGameClosed.GameRunning",
				Title = T._("Game is still running"),
				Content = T._("Please close the game before continuing with the onboarding process."),
				IsProgressIndeterminate = false,
				Level = NotificationLevel.Warning,
				CloseAfter = 2f
			});
		}
		else
		{
			Logger.Info("Game is closed, continuing onboarding.", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Onboarding\\Steps\\EnsureGameClosed.razor", 40);
			OnNext?.Invoke();
		}
	}
}
