using System;
using System.Collections.Generic;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Onboarding.Steps;

public class PrivacyPolicyStep : ComponentBase
{
	public bool IsChina => false;

	[Parameter]
	public Action OnNext { get; set; }

	[Parameter]
	public Action OnPrevious { get; set; }

	private List<string> DisplayOnly { get; set; } = new List<string> { "ETS2LA.Overlay.Interact" };

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex gap-12 text-start items-center justify-center");
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex flex-col gap-2 min-w-96 max-w-108");
		__builder.OpenElement(4, "div");
		__builder.AddAttribute(5, "class", "flex flex-col gap-1");
		__builder.OpenElement(6, "h3");
		__builder.AddContent(7, (MarkupString)T._("Privacy Policy"));
		__builder.CloseElement();
		if (IsChina)
		{
			__builder.OpenElement(8, "p");
			__builder.AddAttribute(9, "class", "text-[14px]");
			__builder.AddContent(10, (MarkupString)T._("• If you create an account, we transfer your account information to an international recipient."));
			__builder.CloseElement();
			__builder.AddMarkupContent(11, "\n                ");
			__builder.OpenElement(12, "p");
			__builder.AddAttribute(13, "class", "text-[14px] ml-2");
			__builder.AddContent(14, (MarkupString)T._("• ETS2LA Developers, contact@ets2la.com, Poland."));
			__builder.CloseElement();
		}
		else
		{
			__builder.OpenElement(15, "p");
			__builder.AddAttribute(16, "class", "description");
			__builder.AddContent(17, (MarkupString)T._("We don't sell or transfer your personal data to any third parties, in fact, we don't even collect it. However, we are still obligated to display and acquire your consent before proceeding."));
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.AddMarkupContent(18, "\n\n        ");
		__builder.OpenElement(19, "div");
		__builder.AddAttribute(20, "class", "flex gap-2 mt-2");
		__builder.OpenElement(21, "button");
		__builder.AddAttribute(22, "class", "button w-full!");
		__builder.AddAttribute(23, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, IsChina ? new Action(OpenCNPrivacyPolicy) : new Action(OpenGlobalPrivacyPolicy)));
		__builder.AddContent(24, T._("Open Externally"));
		__builder.CloseElement();
		__builder.AddMarkupContent(25, "\n            ");
		__builder.OpenElement(26, "button");
		__builder.AddAttribute(27, "class", "button w-full!");
		__builder.AddAttribute(28, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, OnNext));
		__builder.AddContent(29, T._("Continue"));
		__builder.CloseElement();
		__builder.CloseElement();
		if (IsChina)
		{
			__builder.OpenElement(30, "p");
			__builder.AddAttribute(31, "class", "description mt-1");
			__builder.AddContent(32, (MarkupString)T._("By clicking <span class=\"font-bold\">Continue</span>, you agree to our Privacy Policy."));
			__builder.CloseElement();
			__builder.AddMarkupContent(33, "\n            ");
			__builder.OpenElement(34, "p");
			__builder.AddAttribute(35, "class", "description");
			__builder.AddContent(36, (MarkupString)T._("By clicking <span class=\"font-bold\">Continue</span>, you agree to the transfer of your possible account information to an international recipient."));
			__builder.CloseElement();
		}
		else
		{
			__builder.OpenElement(37, "p");
			__builder.AddAttribute(38, "class", "description");
			__builder.AddContent(39, (MarkupString)T._("By clicking <span class=\"font-bold\">Continue</span>, you agree to our Privacy Policy."));
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.AddMarkupContent(40, "\n\n    ");
		__builder.OpenElement(41, "div");
		__builder.AddAttribute(42, "class", "flex flex-col gap-2 w-[450px]");
		if (IsChina)
		{
			__builder.AddMarkupContent(43, "<iframe src=\"https://docs.ets2la.cn/service-privacy\" class=\"w-[450px] h-[500px] rounded-md border border-border\"></iframe>");
		}
		else
		{
			__builder.AddMarkupContent(44, "<iframe src=\"https://ets2la.com/?clean#/legal/privacy\" class=\"w-[450px] h-[500px] rounded-md border border-border\"></iframe>");
		}
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private void OpenGlobalPrivacyPolicy()
	{
		UserInterfaceUtils.OpenUrl("https://ets2la.com/#/legal/privacy");
	}

	private void OpenCNPrivacyPolicy()
	{
		UserInterfaceUtils.OpenUrl("https://docs.ets2la.cn/service-privacy");
	}
}
