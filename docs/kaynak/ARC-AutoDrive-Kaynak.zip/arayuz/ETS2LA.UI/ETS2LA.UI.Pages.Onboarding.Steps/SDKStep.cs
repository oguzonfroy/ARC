using ETS2LA.Translations;
using ETS2LA.UI.Pages.Settings;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Onboarding.Steps;

public class SDKStep : ComponentBase
{
	private bool hasInstalledSDK;

	[Parameter]
	public EventCallback OnNext { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex gap-12 text-start items-center justify-center");
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex flex-col gap-2 max-w-108");
		__builder.OpenElement(4, "h3");
		__builder.AddContent(5, T._("SDK Installation"));
		__builder.CloseElement();
		__builder.AddMarkupContent(6, "\n        ");
		__builder.OpenElement(7, "p");
		__builder.AddContent(8, (MarkupString)T._("ETS2LA requires you to install our <span class=\"text-text-accent font-bold\">SDK</span> to get started. Please install the SDK for <span class=\"text-text-accent font-bold\">at least one game</span> to continue."));
		__builder.CloseElement();
		if (hasInstalledSDK)
		{
			__builder.OpenElement(9, "button");
			__builder.AddAttribute(10, "class", "button mt-2 w-full!");
			__builder.AddAttribute(11, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, OnNext));
			__builder.AddContent(12, T._("Continue"));
			__builder.CloseElement();
		}
		else
		{
			__builder.OpenElement(13, "p");
			__builder.AddAttribute(14, "class", "description mt-2");
			__builder.AddContent(15, T._("Waiting..."));
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.AddMarkupContent(16, "\n\n    ");
		__builder.OpenElement(17, "div");
		__builder.AddAttribute(18, "class");
		__builder.OpenComponent<SDK>(19);
		__builder.AddComponentParameter(20, "IsOnboarding", RuntimeHelpers.TypeCheck(value: true));
		__builder.AddComponentParameter(21, "OnOneSDKInstalled", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, () =>
		{
			hasInstalledSDK = true;
		})));
		__builder.CloseComponent();
		__builder.CloseElement();
		__builder.CloseElement();
	}
}
