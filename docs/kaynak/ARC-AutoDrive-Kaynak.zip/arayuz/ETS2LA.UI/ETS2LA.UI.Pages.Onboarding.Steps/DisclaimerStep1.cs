using System;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Onboarding.Steps;

public class DisclaimerStep1 : ComponentBase
{
	[Parameter]
	public Action OnNext { get; set; }

	[Parameter]
	public Action OnPrevious { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col gap-2");
		__builder.OpenElement(2, "h3");
		__builder.AddContent(3, (MarkupString)T._("Final Disclaimer <span class=\"description\">1/2</span>"));
		__builder.CloseElement();
		__builder.AddMarkupContent(4, "\n    ");
		__builder.OpenElement(5, "div");
		__builder.AddAttribute(6, "class", "max-w-108");
		__builder.OpenElement(7, "p");
		__builder.AddContent(8, (MarkupString)T._("This is a highly experimental program. ETS2LA is not perfect, and you will find issues with it's driving and safety. <span class=\"text-text-accent font-bold\">Do not leave ETS2LA unattended, especially in multiplayer.</span>"));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(9, "\n\n    ");
		__builder.OpenElement(10, "div");
		__builder.AddAttribute(11, "class", "flex gap-2 mt-4");
		__builder.OpenElement(12, "button");
		__builder.AddAttribute(13, "class", "button w-full!");
		__builder.AddAttribute(14, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, OnNext));
		__builder.AddContent(15, T._("I won't leave ETS2LA unattended"));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}
}
