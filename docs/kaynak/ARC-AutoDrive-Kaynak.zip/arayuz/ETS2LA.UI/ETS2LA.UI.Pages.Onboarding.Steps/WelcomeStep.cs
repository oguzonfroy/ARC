using System;
using System.Collections.Generic;
using System.Linq;
using ETS2LA.Logging;
using ETS2LA.State;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Onboarding.Steps;

public class WelcomeStep : ComponentBase
{
	private Language initialLanguage = StateSettingsHandler.Current.GetSettings().DisplayLanguage;

	private List<string> displayLanguageOptions = Languages.SupportedLanguages.Select((Language l) => l.NativeName + " - " + l.EnglishName).ToList();

	private bool hasChangedLanguage;

	[Parameter]
	public Action OnNext { get; set; }

	private int CurrentLanguage => Languages.SupportedLanguages.FindIndex((Language l) => l.Code == StateSettingsHandler.Current.GetSettings().DisplayLanguage?.Code);

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col gap-2");
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex flex-col gap-1");
		__builder.OpenElement(4, "h3");
		__builder.AddContent(5, T._("Welcome to ETS2LA!"));
		__builder.CloseElement();
		__builder.AddMarkupContent(6, "\r\n        ");
		__builder.OpenElement(7, "p");
		__builder.AddContent(8, (MarkupString)T._("Please complete this <span class=\"text-text-accent font-bold\">short</span> onboarding process to get started."));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(9, "\r\n\r\n    ");
		__builder.OpenElement(10, "div");
		__builder.AddAttribute(11, "class", "flex gap-2");
		__builder.OpenComponent<Dropdown>(12);
		__builder.AddComponentParameter(13, "Title", "");
		__builder.AddComponentParameter(14, "Description", "");
		__builder.AddComponentParameter(15, "Class", "min-w-64 h-[39px]! mt-2");
		__builder.AddComponentParameter(16, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)displayLanguageOptions));
		__builder.AddComponentParameter(17, "SelectedIndex", RuntimeHelpers.TypeCheck(CurrentLanguage));
		__builder.AddComponentParameter(18, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create((object)this, (Action<int>)OnDisplayLanguageChanged)));
		__builder.CloseComponent();
		if (hasChangedLanguage)
		{
			__builder.OpenElement(19, "button");
			__builder.AddAttribute(20, "class", "button button-accent mt-2 h-[39px] w-full!");
			__builder.AddAttribute(21, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)Restart));
			__builder.AddContent(22, T._("Restart"));
			__builder.CloseElement();
		}
		else
		{
			__builder.OpenElement(23, "button");
			__builder.AddAttribute(24, "class", "button mt-2 h-[39px] w-full!");
			__builder.AddAttribute(25, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, OnNext));
			__builder.AddContent(26, T._("Next"));
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.AddMarkupContent(27, "\r\n\r\n    ");
		__builder.OpenElement(28, "div");
		__builder.AddAttribute(29, "class", "flex flex-col gap-1 mt-1");
		__builder.OpenElement(30, "p");
		__builder.AddAttribute(31, "class", "description");
		__builder.AddContent(32, T._("If you can't interact with the Window, press CTRL+R."));
		__builder.CloseElement();
		__builder.AddMarkupContent(33, "\r\n        ");
		__builder.OpenElement(34, "p");
		__builder.AddAttribute(35, "class", "description");
		__builder.AddAttribute(36, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)OpenFAQ));
		__builder.AddContent(37, (MarkupString)"Ekran tamamen siyahsa yardım için <span class=\"description hover:underline\">ARC sitesine</span> bak.");
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private void OnDisplayLanguageChanged(int index)
	{
		string selectedLanguageName = displayLanguageOptions[index].Split("-")[1].Trim();
		Logger.Info($"Selecting language {selectedLanguageName} ({index})", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Onboarding\\Steps\\WelcomeStep.razor", 25);
		Language language = Languages.SupportedLanguages.FirstOrDefault((Language l) => l.EnglishName == selectedLanguageName);
		if (language == null)
		{
			Logger.Error(T._("{0} not found in supported languages.", selectedLanguageName), "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Onboarding\\Steps\\WelcomeStep.razor", 29);
			return;
		}
		StateSettingsHandler.Current.GetSettings().DisplayLanguage = language;
		StateSettingsHandler.Current.Save();
		if (language.Code == initialLanguage.Code)
		{
			hasChangedLanguage = false;
		}
		else
		{
			hasChangedLanguage = true;
		}
	}

	private void Restart()
	{
		UserInterfaceUtils.Restart();
	}

	private void OpenFAQ()
	{
		UserInterfaceUtils.OpenUrl("https://arcappss.com.tr/");
	}
}
