using System;
using System.Collections.Generic;
using ETS2LA.Translations;
using ETS2LA.UI.Pages.Settings;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Onboarding.Steps;

public class OverlayStep : ComponentBase
{
	[Parameter]
	public Action OnNext { get; set; }

	[Parameter]
	public Action OnPrevious { get; set; }

	private List<string> DisplayOnly { get; set; } = new List<string> { "ETS2LA.Overlay.Interact" };

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex gap-12 text-start items-center justify-center");
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex flex-col gap-2 max-w-108");
		__builder.OpenElement(4, "div");
		__builder.AddAttribute(5, "class", "flex flex-col gap-1");
		__builder.OpenElement(6, "h3");
		__builder.AddContent(7, (MarkupString)T._("Overlay"));
		__builder.CloseElement();
		__builder.AddMarkupContent(8, "\n            ");
		__builder.OpenElement(9, "p");
		__builder.AddContent(10, (MarkupString)T._("ETS2LA will display information on top of the game. You can interact with these overlay elements using <span class=\"text-text-accent font-bold\">Overlay Interaction</span>. Try it!"));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(11, "\n\n        ");
		__builder.OpenElement(12, "div");
		__builder.AddAttribute(13, "class", "flex gap-2 mt-2");
		__builder.OpenElement(14, "button");
		__builder.AddAttribute(15, "class", "button w-full!");
		__builder.AddAttribute(16, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, OnNext));
		__builder.AddContent(17, T._("Continue"));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(18, "\n\n    ");
		__builder.OpenElement(19, "div");
		__builder.AddAttribute(20, "class", "max-w-108");
		__builder.OpenComponent<ETS2LA.UI.Pages.Settings.Controls>(21);
		__builder.AddComponentParameter(22, "DisplayOnly", RuntimeHelpers.TypeCheck(DisplayOnly));
		__builder.CloseComponent();
		__builder.CloseElement();
		__builder.CloseElement();
	}
}
