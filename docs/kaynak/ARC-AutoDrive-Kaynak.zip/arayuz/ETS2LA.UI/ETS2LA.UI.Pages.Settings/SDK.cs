using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ETS2LA.Game;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Layouts;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Settings;

[Layout(typeof(SettingsLayout))]
[Route("/settings/sdk")]
public class SDK : ComponentBase
{
	private GameHandler gameHandler = GameHandler.Current;

	[Parameter]
	public bool IsOnboarding { get; set; }

	[Parameter]
	public EventCallback OnOneSDKInstalled { get; set; }

	private List<Installation> controlInstances => gameHandler.Installations;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col ml-8 m-5 gap-24");
		if (controlInstances.Count > 0)
		{
			__builder.OpenElement(2, "div");
			__builder.AddAttribute(3, "class", "grid grid-cols-[repeat(auto-fill,minmax(27rem,1fr))] gap-4 py-2 px-3");
			for (int i = 0; i < controlInstances.Count; i++)
			{
				Installation instance = controlInstances[i];
				bool flag = instance.IsSDKInstalled(instance.Version);
				__builder.OpenElement(4, "div");
				__builder.AddAttribute(5, "class", "flex flex-col justify-between rounded-sm bg-control-bg-dark border p-4 gap-3 border-bg-darker");
				__builder.OpenElement(6, "div");
				__builder.AddAttribute(7, "class", "flex flex-col gap-1");
				__builder.OpenElement(8, "p");
				__builder.AddContent(9, UserInterfaceUtils.ClassnameWithSpaces(instance.Type.ToString()) + "  -  " + instance.Version.ToString());
				__builder.CloseElement();
				if (!IsOnboarding)
				{
					__builder.OpenElement(10, "p");
					__builder.AddAttribute(11, "class", "description");
					__builder.AddContent(12, flag ? T._("SDKs are currently installed.") : T._("SDKs need to be installed."));
					__builder.AddContent(13, " ");
					__builder.AddContent(14, T._("This game was found at"));
					__builder.AddContent(15, " ");
					__builder.AddContent(16, instance.Path);
					__builder.CloseElement();
				}
				else
				{
					__builder.OpenElement(17, "p");
					__builder.AddAttribute(18, "class", "description");
					__builder.AddContent(19, instance.Path);
					__builder.CloseElement();
				}
				__builder.CloseElement();
				__builder.AddMarkupContent(20, "\n\n                    ");
				__builder.OpenElement(21, "button");
				__builder.AddAttribute(22, "class", flag ? "hidden" : "button button-accent w-full!");
				__builder.AddAttribute(23, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
				{
					OnOneSDKInstalled.InvokeAsync();
					instance.InstallSDK(instance.Version);
				}));
				__builder.AddContent(24, T._("Install SDKs"));
				__builder.CloseElement();
				__builder.AddMarkupContent(25, "\n                    ");
				__builder.OpenElement(26, "button");
				__builder.AddAttribute(27, "class", flag ? "button w-full!" : "hidden");
				__builder.AddAttribute(28, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
				{
					instance.UninstallSDK(instance.Version);
				}));
				__builder.AddContent(29, T._("Uninstall SDKs"));
				__builder.CloseElement();
				__builder.CloseElement();
			}
			__builder.CloseElement();
		}
		if ((IsOnboarding && controlInstances.Count == 0) || !IsOnboarding)
		{
			__builder.OpenElement(30, "div");
			__builder.AddAttribute(31, "class", IsOnboarding ? " justify-self-center" : " h-full");
			__builder.OpenElement(32, "div");
			__builder.AddAttribute(33, "class", "flex flex-col gap-4 w-108" + (IsOnboarding ? "" : " absolute bottom-6"));
			__builder.OpenElement(34, "p");
			__builder.AddAttribute(35, "class", "description text-warning");
			__builder.AddContent(36, T._("Cracked games or demos will block our SDK from loading. They do not work, and we don't intend to fix this."));
			__builder.CloseElement();
			__builder.AddMarkupContent(37, "\n                ");
			__builder.OpenElement(38, "button");
			__builder.AddAttribute(39, "class", "button w-full!");
			__builder.AddAttribute(40, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)AddGameManually));
			__builder.AddContent(41, T._("Add Game Manually"));
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.CloseElement();
		}
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		if (controlInstances.Any((Installation i) => i.IsSDKInstalled(i.Version)))
		{
			OnOneSDKInstalled.InvokeAsync();
		}
	}

	private void AddGameManually()
	{
		string text = UserInterface.Current.Window.ShowOpenFile(T._("Select core.scs"), null, multiSelect: false, new (string, string[])[1] { ("core.scs", new string[1] { ".scs" }) }).FirstOrDefault();
		if (text == null)
		{
			return;
		}
		if (!File.Exists(text))
		{
			UserInterface.Current.Window.ShowMessageOnTop(T._("Invalid file"), T._("The selected file does not exist."));
			return;
		}
		if (!text.EndsWith("core.scs", StringComparison.OrdinalIgnoreCase))
		{
			UserInterface.Current.Window.ShowMessageOnTop(T._("Invalid file"), T._("The selected file is not a core.scs file."));
			return;
		}
		string text2 = Path.GetDirectoryName(text) ?? "";
		if (!Directory.Exists(text2))
		{
			UserInterface.Current.Window.ShowMessageOnTop(T._("Invalid directory"), T._("The selected directory does not exist."));
		}
		else if (GameHandler.Current.AddManualInstallation(text2) != null)
		{
			UserInterface.Current.Window.ShowMessageOnTop(T._("Game added"), T._("The game has been added successfully."));
		}
		else
		{
			UserInterface.Current.Window.ShowMessageOnTop(T._("Failed to add game"), T._("Please see the logs for more information."));
		}
	}
}
