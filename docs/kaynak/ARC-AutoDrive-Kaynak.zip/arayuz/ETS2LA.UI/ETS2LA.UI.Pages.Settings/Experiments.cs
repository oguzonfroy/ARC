using ETS2LA.Game;
using ETS2LA.ML;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using ETS2LA.UI.Shared.Layouts;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Pages.Settings;

[Layout(typeof(SettingsLayout))]
[Route("/settings/experiments")]
public class Experiments : ComponentBase
{
	private bool MemoryOutputChanged;

	private bool RenderVisionCameras
	{
		get
		{
			return MLSettings.Current.RenderVisionCameras;
		}
		set
		{
			MLSettings.Current.RenderVisionCameras = value;
			MLSettings.Current.Save();
		}
	}

	private bool EnableModernOutputForPedals
	{
		get
		{
			return GameSettings.Current.EnableModernOutputForPedals;
		}
		set
		{
			GameSettings current = GameSettings.Current;
			if (value != current.EnableModernOutputForPedals)
			{
				MemoryOutputChanged = true;
				current.EnableModernOutputForPedals = value;
				GameSettings.Current.Save();
			}
		}
	}

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full p-5 px-8 gap-3");
		__builder.OpenComponent<Switch>(2);
		__builder.AddComponentParameter(3, "Title", RuntimeHelpers.TypeCheck(T._("Render Vision Cameras")));
		__builder.AddComponentParameter(4, "Description", RuntimeHelpers.TypeCheck(T._("Render the vision cameras in the game world. This is useful for debugging, but can cause performance issues.")));
		__builder.AddComponentParameter(5, "Value", RuntimeHelpers.TypeCheck(RenderVisionCameras));
		__builder.AddComponentParameter(6, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			RenderVisionCameras = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(7, "\n    ");
		__builder.OpenComponent<Switch>(8);
		__builder.AddComponentParameter(9, "Title", RuntimeHelpers.TypeCheck(T._("Enable Memory Output for Pedals")));
		__builder.AddComponentParameter(10, "Description", RuntimeHelpers.TypeCheck(T._("Allows ETS2LA to control throttle and brake using direct memory editing. This might not work on some systems, but allows for control even while tabbed out of the game. If you enable this and it doesn't work, please report the issue on our Discord server.")));
		__builder.AddComponentParameter(11, "Value", RuntimeHelpers.TypeCheck(EnableModernOutputForPedals));
		__builder.AddComponentParameter(12, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			EnableModernOutputForPedals = value;
		})));
		__builder.CloseComponent();
		if (MemoryOutputChanged)
		{
			__builder.OpenElement(13, "p");
			__builder.AddAttribute(14, "class", "text-sm text-text-accent");
			__builder.AddContent(15, (MarkupString)T._("You may need to restart the game to apply this change."));
			__builder.CloseElement();
		}
		__builder.CloseElement();
	}
}
