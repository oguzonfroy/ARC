using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ETS2LA.Networking.Updates;
using ETS2LA.Notifications;
using ETS2LA.State;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using ETS2LA.UI.Shared.Layouts;
using Markdig;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;
using Velopack;
using Velopack.Sources;

namespace ETS2LA.UI.Pages.Settings;

[Layout(typeof(SettingsLayout))]
[Route("/settings/updates")]
public class Updates : ComponentBase
{
	private IUpdateSource source = Updater.Current.GetSelectedSource().source;

	private UpdateManager updateManager = Updater.Current.UpdateManager;

	private UpdateInfo? latestUpdateInfo;

	private string[] availableChannels = Updater.AvailableChannels;

	private MarkupString? RenderedContent;

	private static readonly MarkdownPipeline Pipeline = new MarkdownPipelineBuilder().UseAdvancedExtensions().Build();

	private string selectedChannel
	{
		get
		{
			return UpdaterSettings.Current.SelectedChannel;
		}
		set
		{
			UpdaterSettings.Current.SelectedChannel = value;
			UpdaterSettings.Current.Save();
			StateHasChanged();
		}
	}

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col max-w-full m-5 ml-8 mr-8 gap-4");
		__builder.OpenComponent<Dropdown>(2);
		__builder.AddComponentParameter(3, "Title", "Update Channel");
		__builder.AddComponentParameter(4, "Description", "Select the update channel you want to listen to. Nightly contains experimental features and will crash more often.");
		__builder.AddComponentParameter(5, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)availableChannels));
		__builder.AddComponentParameter(6, "SelectedIndex", RuntimeHelpers.TypeCheck(Array.IndexOf(availableChannels, selectedChannel)));
		__builder.AddComponentParameter(7, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (int index) =>
		{
			selectedChannel = availableChannels[index];
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(8, "\n\n    ");
		__builder.OpenElement(9, "div");
		__builder.AddAttribute(10, "class", "flex flex-col gap-2");
		__builder.OpenElement(11, "div");
		__builder.AddAttribute(12, "class", "text-description");
		__builder.AddContent(13, T._("Current Version: {0}", updateManager.CurrentVersion?.ToString() ?? T._("Unknown Version")));
		__builder.CloseElement();
		__builder.AddMarkupContent(14, "\n        ");
		__builder.OpenElement(15, "div");
		__builder.AddAttribute(16, "class", "text-description");
		__builder.AddContent(17, T._("Latest Version: {0}", latestUpdateInfo?.TargetFullRelease?.Version.ToString() ?? T._("Unchanged / Unavailable")));
		__builder.CloseElement();
		__builder.CloseElement();
		if (latestUpdateInfo != null)
		{
			__builder.OpenElement(18, "button");
			__builder.AddAttribute(19, "class", "button button-accent");
			__builder.AddAttribute(20, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)OnInstallAndRestartClick));
			__builder.AddAttribute(21, "disabled", latestUpdateInfo == null);
			__builder.AddContent(22, T._("Install Update and Restart"));
			__builder.CloseElement();
		}
		__builder.OpenElement(23, "div");
		__builder.AddAttribute(24, "class", "flex flex-col gap-1");
		if (RenderedContent.HasValue)
		{
			__builder.OpenElement(25, "div");
			__builder.AddAttribute(26, "class", "[&_img]:max-w-[410px] [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:list-decimal [&_ol]:pl-5 [&_p]:mb-2 [&_h1]:mb-3 [&_h2]:mb-3 [&_h3]:mb-3 [&_h4]:mb-1 [&_h4]:mt-4 [&_li]:mb-1 [&_strong]:text-text-accent [&_code]:text-description [&_code]:bg-control-bg [&_code]:rounded-sm [&_code]:px-1  whitespace-normal");
			__builder.AddContent(27, RenderedContent);
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.CloseElement();
	}

	protected override async Task OnInitializedAsync()
	{
		Task.Run(() =>
		{
			CheckForUpdates();
		});
	}

	private void CheckForUpdates()
	{
		NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
		{
			Id = "ETS2LA.UI.Settings.Updates.CheckingForUpdates",
			Title = T._("Checking for updates..."),
			Content = T._("This might take a while depending on your internet connection and the source."),
			IsProgressIndeterminate = true
		});
		latestUpdateInfo = null;
		try
		{
			latestUpdateInfo = updateManager.CheckForUpdates();
		}
		catch
		{
			NotificationHandler.Current.CloseNotification("ETS2LA.UI.Settings.Updates.CheckingForUpdates");
			NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
			{
				Id = "ETS2LA.UI.Settings.Updates.ErrorCheckingForUpdates",
				Title = T._("Error Checking for Updates"),
				Content = T._("An error occurred while checking for updates."),
				IsProgressIndeterminate = false,
				Level = NotificationLevel.Warning
			});
			return;
		}
		if (latestUpdateInfo != null)
		{
			NotificationHandler.Current.CloseNotification("ETS2LA.UI.Settings.Updates.CheckingForUpdates");
			NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
			{
				Id = "ETS2LA.UI.Settings.Updates.UpdateAvailable",
				Title = T._("Update Available"),
				Content = T._("A new update is available: {0}", latestUpdateInfo.TargetFullRelease?.Version.ToString() ?? T._("Unknown Version")),
				IsProgressIndeterminate = false,
				Level = NotificationLevel.Warning
			});
			string text = latestUpdateInfo.TargetFullRelease?.NotesMarkdown ?? T._("No release notes available.");
			try
			{
				text = text.Split("---")[0];
			}
			catch
			{
			}
			Language displayLanguage = StateSettingsHandler.Current.GetSettings().DisplayLanguage;
			if (displayLanguage.Code != "en")
			{
				RenderedContent = new MarkupString(Markdown.ToHtml(T._("Translating release notes..."), Pipeline));
				DynamicTranslationTask dynamicTranslationTask = new DynamicTranslationTask(text, displayLanguage.Code.Replace("_", "-"));
				dynamicTranslationTask.OnTranslationCompleted += (string translated) =>
				{
					RenderedContent = new MarkupString(Markdown.ToHtml(translated, Pipeline));
					InvokeAsync((Action)StateHasChanged);
				};
				dynamicTranslationTask.StartTranslationAsync();
			}
			else
			{
				RenderedContent = new MarkupString(Markdown.ToHtml(text, Pipeline));
			}
			InvokeAsync((Action)StateHasChanged);
		}
		else
		{
			NotificationHandler.Current.CloseNotification("ETS2LA.UI.Settings.Updates.CheckingForUpdates");
			NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
			{
				Id = "ETS2LA.UI.Settings.Updates.NoUpdateAvailable",
				Title = T._("No Update Available"),
				Content = T._("You are running the latest version."),
				IsProgressIndeterminate = false,
				Level = NotificationLevel.Success
			});
			InvokeAsync((Action)StateHasChanged);
		}
	}

	private void DownloadCallback(int progress)
	{
		NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
		{
			Id = "ETS2LA.UI.Settings.Updates.DownloadingUpdate",
			Title = T._("Downloading Update"),
			Content = T._("Download progress: {0}%", progress),
			Progress = progress,
			CloseAfter = 0f
		});
	}

	public void OnInstallAndRestartClick()
	{
		if (latestUpdateInfo != null)
		{
			Task.Run(() =>
			{
				NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
				{
					Id = "ETS2LA.UI.Settings.Updates.DownloadingUpdate",
					Title = T._("Downloading Update"),
					Content = T._("Starting download..."),
					Level = NotificationLevel.Information,
					Progress = 0f,
					CloseAfter = 0f
				});
				updateManager.DownloadUpdates(latestUpdateInfo, DownloadCallback);
				updateManager.ApplyUpdatesAndRestart(latestUpdateInfo);
				NotificationHandler.Current.CloseNotification("ETS2LA.UI.Settings.Updates.DownloadingUpdate");
			});
		}
	}
}
