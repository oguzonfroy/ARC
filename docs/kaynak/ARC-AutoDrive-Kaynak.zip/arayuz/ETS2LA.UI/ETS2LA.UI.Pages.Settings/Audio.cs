using System;
using System.Threading.Tasks;
using ETS2LA.Audio;
using ETS2LA.Logging;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using ETS2LA.UI.Shared.Layouts;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;

namespace ETS2LA.UI.Pages.Settings;

[Layout(typeof(SettingsLayout))]
[Route("/settings/audio")]
public class Audio : ComponentBase
{
	public float Volume
	{
		get
		{
			return (float)Math.Round(AudioHandler.Current.GetVolume() * 100f, 0);
		}
		set
		{
			if (value != Volume)
			{
				AudioHandler.Current.SetVolume(value / 100f);
				if (AudioHandler.Current.GetQueueLength() == 0)
				{
					AudioHandler.Current.Play(DefaultAudio.PreAlert);
				}
			}
		}
	}

	[Inject]
	private IJSRuntime JS { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full p-5 px-8 gap-3");
		__builder.OpenComponent<SectionTitle>(2);
		__builder.AddComponentParameter(3, "Title", RuntimeHelpers.TypeCheck(T._("Audio Settings")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(4, "\n    ");
		__builder.OpenComponent<Slider>(5);
		__builder.AddComponentParameter(6, "Title", RuntimeHelpers.TypeCheck(T._("Volume")));
		__builder.AddComponentParameter(7, "Description", RuntimeHelpers.TypeCheck(T._("Adjust the volume of the audio output.")));
		__builder.AddComponentParameter(8, "Suffix", "%");
		__builder.AddComponentParameter(9, "Min", RuntimeHelpers.TypeCheck(0f));
		__builder.AddComponentParameter(10, "Max", RuntimeHelpers.TypeCheck(100f));
		__builder.AddComponentParameter(11, "Value", RuntimeHelpers.TypeCheck(Volume));
		__builder.AddComponentParameter(12, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			Volume = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(13, "\n    ");
		__builder.OpenComponent<Switch>(14);
		__builder.AddComponentParameter(15, "Title", "Menü tıklama sesi");
		__builder.AddComponentParameter(16, "Description", "Menüde bir düğmeye bastığında kısa ve hafif bir tık sesi çalar.");
		__builder.AddComponentParameter(17, "Value", RuntimeHelpers.TypeCheck(WindowSettings.Current.ClickSound));
		__builder.AddComponentParameter(18, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) => SetClickSound(value))));
		__builder.CloseComponent();
		__builder.AddMarkupContent(19, "\n    ");
		__builder.OpenComponent<SectionTitle>(20);
		__builder.AddComponentParameter(21, "Title", RuntimeHelpers.TypeCheck(T._("Test Audio")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(22, "\n    ");
		__builder.OpenElement(23, "div");
		__builder.AddAttribute(24, "class", "grid grid-cols-4 gap-3");
		DefaultAudio[] values = Enum.GetValues<DefaultAudio>();
		DefaultAudio[] array = values;
		foreach (DefaultAudio audio in array)
		{
			__builder.OpenElement(25, "button");
			__builder.AddAttribute(26, "Class", "button w-full!");
			__builder.AddAttribute(27, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
			{
				PlaySound(audio);
			}));
			__builder.AddContent(28, audio);
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private async Task SetClickSound(bool value)
	{
		WindowSettings.Current.ClickSound = value;
		WindowSettings.Current.Save();
		await JS.InvokeVoidAsync("arcTikSesiAyarla", value);
	}

	public void PlaySound(DefaultAudio audio)
	{
		Logger.Info($"Playing sound: {audio}", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Audio.razor", 33);
		AudioHandler.Current.Play(audio);
	}
}
