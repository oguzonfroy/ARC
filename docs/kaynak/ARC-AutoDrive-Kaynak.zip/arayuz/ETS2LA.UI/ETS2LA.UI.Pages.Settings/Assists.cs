using System;
using System.Collections.Generic;
using System.Linq;
using ETS2LA.Settings.Global;
using ETS2LA.State;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using ETS2LA.UI.Shared.Layouts;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Pages.Settings;

[Layout(typeof(SettingsLayout))]
[Route("/settings/assists")]
public class Assists : ComponentBase
{
	private static Dictionary<AccelerationResponseOption, string> TranslateAccelerationOptions = new Dictionary<AccelerationResponseOption, string>
	{
		{
			AccelerationResponseOption.Slow,
			T._("Slow")
		},
		{
			AccelerationResponseOption.Normal,
			T._("Normal")
		},
		{
			AccelerationResponseOption.Fast,
			T._("Fast")
		}
	};

	private static List<string> AccelerationOptions = (from option in Enum.GetNames<AccelerationResponseOption>().ToList()
		select TranslateAccelerationOptions[Enum.Parse<AccelerationResponseOption>(option)]).ToList();

	private static Dictionary<SteeringSensitivityOption, string> TranslateSteeringResponseOptions = new Dictionary<SteeringSensitivityOption, string>
	{
		{
			SteeringSensitivityOption.Slow,
			T._("Slow")
		},
		{
			SteeringSensitivityOption.Normal,
			T._("Normal")
		},
		{
			SteeringSensitivityOption.Fast,
			T._("Fast")
		}
	};

	private static List<string> SteeringResponseOptions = (from option in Enum.GetNames<SteeringSensitivityOption>().ToList()
		select TranslateSteeringResponseOptions[Enum.Parse<SteeringSensitivityOption>(option)]).ToList();

	private static Dictionary<FollowingDistanceOption, string> TranslateFollowingDistanceOptions = new Dictionary<FollowingDistanceOption, string>
	{
		{
			FollowingDistanceOption.Near,
			T._("Near")
		},
		{
			FollowingDistanceOption.Normal,
			T._("Normal")
		},
		{
			FollowingDistanceOption.Far,
			T._("Far")
		}
	};

	private static List<string> FollowingDistanceOptions = (from option in Enum.GetNames<FollowingDistanceOption>().ToList()
		select TranslateFollowingDistanceOptions[Enum.Parse<FollowingDistanceOption>(option)]).ToList();

	private static Dictionary<SetSpeedBehaviour, string> TranslateSetSpeedBehaviourOptions = new Dictionary<SetSpeedBehaviour, string>
	{
		{
			SetSpeedBehaviour.CurrentSpeed,
			T._("Current Speed")
		},
		{
			SetSpeedBehaviour.SpeedLimit,
			T._("Speed Limit")
		}
	};

	private static List<string> SetSpeedBehaviourOptions = (from option in Enum.GetNames<SetSpeedBehaviour>().ToList()
		select TranslateSetSpeedBehaviourOptions[Enum.Parse<SetSpeedBehaviour>(option)]).ToList();

	private static Dictionary<SpeedLimitWarning, string> TranslateSpeedLimitWarningOptions = new Dictionary<SpeedLimitWarning, string>
	{
		{
			SpeedLimitWarning.Chime,
			T._("Chime")
		},
		{
			SpeedLimitWarning.Off,
			T._("Off")
		},
		{
			SpeedLimitWarning.Visual,
			T._("Visual")
		}
	};

	private static List<string> SpeedLimitWarningOptions = (from option in Enum.GetNames<SpeedLimitWarning>().ToList()
		select TranslateSpeedLimitWarningOptions[Enum.Parse<SpeedLimitWarning>(option)]).ToList();

	private static Dictionary<CollisionAvoidance, string> TranslateCollisionAvoidanceOptions = new Dictionary<CollisionAvoidance, string>
	{
		{
			CollisionAvoidance.Early,
			T._("Early")
		},
		{
			CollisionAvoidance.Medium,
			T._("Medium")
		},
		{
			CollisionAvoidance.Late,
			T._("Late")
		},
		{
			CollisionAvoidance.Off,
			T._("Off")
		}
	};

	private static List<string> CollisionAvoidanceOptions = (from option in Enum.GetNames<CollisionAvoidance>().ToList()
		select TranslateCollisionAvoidanceOptions[Enum.Parse<CollisionAvoidance>(option)]).ToList();

	private static Dictionary<TrafficRule, string> TranslateTrafficRuleOptions = new Dictionary<TrafficRule, string>
	{
		{
			TrafficRule.TrafficLights,
			T._("Traffic Lights")
		},
		{
			TrafficRule.Gates,
			T._("Gates")
		},
		{
			TrafficRule.Speedlimits,
			T._("Speed Limits")
		}
	};

	private static List<string> TrafficRuleOptions = (from option in Enum.GetNames<TrafficRule>().ToList()
		select TranslateTrafficRuleOptions[Enum.Parse<TrafficRule>(option)]).ToList();

	private bool SnapTo10s
	{
		get
		{
			return StateSettingsHandler.Current.GetSettings().SnapTo10s;
		}
		set
		{
			StateSettingsHandler.Current.GetSettings().SnapTo10s = value;
			StateSettingsHandler.Current.Save();
		}
	}

	private bool PauseWhenUnstable
	{
		get
		{
			return AssistanceSettings.Current.PauseWhenUnstable;
		}
		set
		{
			AssistanceSettings.Current.PauseWhenUnstable = value;
			AssistanceSettings.Current.Save();
		}
	}

	private float SpeedControlStepSize
	{
		get
		{
			return StateSettingsHandler.Current.GetSettings().SpeedControlStepSize;
		}
		set
		{
			StateSettingsHandler.Current.GetSettings().SpeedControlStepSize = (int)Math.Round(value);
			StateSettingsHandler.Current.Save();
		}
	}

	private float MaximumSpeedLimit
	{
		get
		{
			return AssistanceSettings.Current.MaximumSpeed;
		}
		set
		{
			AssistanceSettings.Current.MaximumSpeed = value;
			AssistanceSettings.Current.Save();
		}
	}

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full p-5 px-8 gap-3");
		__builder.OpenComponent<SectionTitle>(2);
		__builder.AddComponentParameter(3, "Title", RuntimeHelpers.TypeCheck(T._("Keybind Behaviour")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(4, "\r\n    \r\n    ");
		__builder.OpenComponent<Slider>(5);
		__builder.AddComponentParameter(6, "Title", RuntimeHelpers.TypeCheck(T._("Speed Control Step Size")));
		__builder.AddComponentParameter(7, "Description", RuntimeHelpers.TypeCheck(T._("The step size for changing the cruise control speed.")));
		__builder.AddComponentParameter(8, "Suffix", RuntimeHelpers.TypeCheck(DisplayUnits()));
		__builder.AddComponentParameter(9, "Value", RuntimeHelpers.TypeCheck(SpeedControlStepSize));
		__builder.AddComponentParameter(10, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			SpeedControlStepSize = value;
		})));
		__builder.AddComponentParameter(11, "Min", RuntimeHelpers.TypeCheck(1f));
		__builder.AddComponentParameter(12, "Max", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(13, "Step", RuntimeHelpers.TypeCheck(1f));
		__builder.CloseComponent();
		__builder.AddMarkupContent(14, "\r\n    ");
		__builder.OpenComponent<Switch>(15);
		__builder.AddComponentParameter(16, "Title", RuntimeHelpers.TypeCheck(T._("Snap to each 10 {0}", DisplayUnits())));
		__builder.AddComponentParameter(17, "Description", RuntimeHelpers.TypeCheck(T._("When changing the speed, snap to the nearest 10. i.e. 37 -> 39 -> 40 -> 42...")));
		__builder.AddComponentParameter(18, "Value", RuntimeHelpers.TypeCheck(SnapTo10s));
		__builder.AddComponentParameter(19, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			SnapTo10s = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(20, "\r\n\r\n    ");
		__builder.OpenComponent<SectionTitle>(21);
		__builder.AddComponentParameter(22, "Class", "mt-8");
		__builder.AddComponentParameter(23, "Title", RuntimeHelpers.TypeCheck(T._("Responsiveness")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(24, "\r\n    ");
		__builder.OpenComponent<Listbox>(25);
		__builder.AddComponentParameter(26, "Title", RuntimeHelpers.TypeCheck(T._("Steering Sensitivity")));
		__builder.AddComponentParameter(27, "Description", RuntimeHelpers.TypeCheck(T._("Adjust how ETS2LA will respond to necessary steering changes. This for example controls how quickly ETS2LA will lane-change.")));
		__builder.AddComponentParameter(28, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)SteeringResponseOptions));
		__builder.AddComponentParameter(29, "SelectedIndex", RuntimeHelpers.TypeCheck(Array.IndexOf(SteeringResponseOptions.ToArray(), TranslateSteeringResponseOptions[AssistanceSettings.Current.SteeringSensitivity] ?? string.Empty)));
		__builder.AddComponentParameter(30, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (int index) =>
		{
			AssistanceSettings.Current.SteeringSensitivity = (SteeringSensitivityOption)index;
			AssistanceSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.OpenRegion(9200);
		__builder.OpenComponent<Slider>(1);
		__builder.AddComponentParameter(2, "Title", RuntimeHelpers.TypeCheck("Direksiyon hassasiyeti"));
		__builder.AddComponentParameter(3, "Description", RuntimeHelpers.TypeCheck("Otomatik sürüşte direksiyonun ne kadar güçlü tepki vereceği, her hızda geçerlidir. Tır virajda geniş kalıyorsa artır, yalpalıyorsa azalt. Normal: %100."));
		__builder.AddComponentParameter(4, "Suffix", RuntimeHelpers.TypeCheck("%"));
		__builder.AddComponentParameter(5, "Value", RuntimeHelpers.TypeCheck(MathF.Round(ArcSurusAyar.Hassasiyet * 100f)));
		__builder.AddComponentParameter(6, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			ArcSurusAyar.Hassasiyet = value / 100f;
		})));
		__builder.AddComponentParameter(7, "Min", RuntimeHelpers.TypeCheck(40f));
		__builder.AddComponentParameter(8, "Max", RuntimeHelpers.TypeCheck(250f));
		__builder.AddComponentParameter(9, "Step", RuntimeHelpers.TypeCheck(5f));
		__builder.CloseComponent();
		__builder.OpenComponent<Listbox>(10);
		__builder.AddComponentParameter(11, "Title", RuntimeHelpers.TypeCheck("Direksiyon modu"));
		__builder.AddComponentParameter(12, "Description", RuntimeHelpers.TypeCheck("Açıkken direksiyon, gaz ve fren doğrudan oyuna yazılır; oyundaki direksiyon ayarlarını klavyeye almak gerekmez. Otomatik: bağlı direksiyon algılanınca açılır."));
		__builder.AddComponentParameter(13, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)new List<string> { "Otomatik", "Açık", "Kapalı" }));
		__builder.AddComponentParameter(14, "SelectedIndex", RuntimeHelpers.TypeCheck(ArcSurusAyar.DireksiyonModu));
		__builder.AddComponentParameter(15, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (int index) =>
		{
			ArcSurusAyar.DireksiyonModu = index;
		})));
		__builder.CloseComponent();
		__builder.CloseRegion();
		ArcSurusAyar.DurumDinle();
		__builder.OpenRegion(9600);
		__builder.OpenComponent<SectionTitle>(1);
		__builder.AddComponentParameter(2, "Class", "mt-8");
		__builder.AddComponentParameter(3, "Title", RuntimeHelpers.TypeCheck("Direksiyon seti"));
		__builder.CloseComponent();
		__builder.OpenElement(4, "p");
		__builder.AddAttribute(5, "class", "description text-[13px]!");
		__builder.AddContent(6, string.IsNullOrEmpty(ArcSurusAyar.DireksiyonAdi) ? "Bağlı direksiyon seti algılanmadı." : ("Algılanan set: " + ArcSurusAyar.DireksiyonAdi));
		__builder.CloseElement();
		__builder.OpenComponent<Switch>(7);
		__builder.AddComponentParameter(8, "Title", RuntimeHelpers.TypeCheck("Direksiyonu çevirince otopilot kapansın"));
		__builder.AddComponentParameter(9, "Description", RuntimeHelpers.TypeCheck("Otopilot açıkken direksiyonu elle çevirdiğinde sürüş sende kalır."));
		__builder.AddComponentParameter(10, "Value", RuntimeHelpers.TypeCheck(ArcSurusAyar.MudahaleDireksiyon));
		__builder.AddComponentParameter(11, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool v) =>
		{
			ArcSurusAyar.MudahaleDireksiyon = v;
		})));
		__builder.CloseComponent();
		__builder.OpenComponent<Slider>(12);
		__builder.AddComponentParameter(13, "Title", RuntimeHelpers.TypeCheck("Müdahale eşiği"));
		__builder.AddComponentParameter(14, "Description", RuntimeHelpers.TypeCheck("Direksiyonun ne kadar çevrilince müdahale sayılacağı. Kendiliğinden kapanıyorsa artır, geç algılıyorsa azalt."));
		__builder.AddComponentParameter(15, "Suffix", RuntimeHelpers.TypeCheck("%"));
		__builder.AddComponentParameter(16, "Value", RuntimeHelpers.TypeCheck(MathF.Round(ArcSurusAyar.MudahaleEsik)));
		__builder.AddComponentParameter(17, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			ArcSurusAyar.MudahaleEsik = value;
		})));
		__builder.AddComponentParameter(18, "Min", RuntimeHelpers.TypeCheck(2f));
		__builder.AddComponentParameter(19, "Max", RuntimeHelpers.TypeCheck(40f));
		__builder.AddComponentParameter(20, "Step", RuntimeHelpers.TypeCheck(1f));
		__builder.CloseComponent();
		__builder.OpenComponent<Switch>(21);
		__builder.AddComponentParameter(22, "Title", RuntimeHelpers.TypeCheck("Pedala basınca otopilot kapansın"));
		__builder.AddComponentParameter(23, "Description", RuntimeHelpers.TypeCheck("Fren ya da debriyaj pedalına bastığında otopilot kapanır.     "));
		__builder.AddComponentParameter(24, "Value", RuntimeHelpers.TypeCheck(ArcSurusAyar.MudahalePedal));
		__builder.AddComponentParameter(25, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool v) =>
		{
			ArcSurusAyar.MudahalePedal = v;
		})));
		__builder.CloseComponent();
		__builder.CloseRegion();
		__builder.AddMarkupContent(31, "\r\n    ");
		__builder.OpenComponent<Listbox>(32);
		__builder.AddComponentParameter(33, "Title", RuntimeHelpers.TypeCheck(T._("Acceleration Response")));
		__builder.AddComponentParameter(34, "Description", RuntimeHelpers.TypeCheck(T._("Adjust how quickly ETS2LA will respond to desired changes in acceleration. Emergency braking is not affected.")));
		__builder.AddComponentParameter(35, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)AccelerationOptions));
		__builder.AddComponentParameter(36, "SelectedIndex", RuntimeHelpers.TypeCheck(Array.IndexOf(AccelerationOptions.ToArray(), TranslateAccelerationOptions[AssistanceSettings.Current.AccelerationResponse] ?? string.Empty)));
		__builder.AddComponentParameter(37, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (int index) =>
		{
			AssistanceSettings.Current.AccelerationResponse = (AccelerationResponseOption)index;
			AssistanceSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(38, "\r\n    ");
		__builder.OpenComponent<Listbox>(39);
		__builder.AddComponentParameter(40, "Title", RuntimeHelpers.TypeCheck(T._("Following Distance")));
		__builder.AddComponentParameter(41, "Description", RuntimeHelpers.TypeCheck(T._("Adjust the distance ETS2LA will try to maintain from the vehicle in front of you when using Adaptive Cruise Control.")));
		__builder.AddComponentParameter(42, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)FollowingDistanceOptions));
		__builder.AddComponentParameter(43, "SelectedIndex", RuntimeHelpers.TypeCheck(Array.IndexOf(FollowingDistanceOptions.ToArray(), TranslateFollowingDistanceOptions[AssistanceSettings.Current.FollowingDistance] ?? string.Empty)));
		__builder.AddComponentParameter(44, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (int index) =>
		{
			AssistanceSettings.Current.FollowingDistance = (FollowingDistanceOption)index;
			AssistanceSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(45, "\r\n    ");
		__builder.OpenComponent<Listbox>(46);
		__builder.AddComponentParameter(47, "Title", RuntimeHelpers.TypeCheck(T._("Collision Avoidance")));
		__builder.AddComponentParameter(48, "Description", RuntimeHelpers.TypeCheck(T._("How early ETS2LA will attempt to respond to possible collisions. Turning this to off will disable collision avoidance regardless of your enabled plugins.")));
		__builder.AddComponentParameter(49, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)CollisionAvoidanceOptions));
		__builder.AddComponentParameter(50, "SelectedIndex", RuntimeHelpers.TypeCheck(Array.IndexOf(CollisionAvoidanceOptions.ToArray(), TranslateCollisionAvoidanceOptions[AssistanceSettings.Current.CollisionAvoidanceOption] ?? string.Empty)));
		__builder.AddComponentParameter(51, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (int index) =>
		{
			AssistanceSettings.Current.CollisionAvoidanceOption = (CollisionAvoidance)index;
			AssistanceSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(52, "\r\n\r\n    ");
		__builder.OpenComponent<SectionTitle>(53);
		__builder.AddComponentParameter(54, "Class", "mt-8");
		__builder.AddComponentParameter(55, "Title", RuntimeHelpers.TypeCheck(T._("Warnings")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(56, "\r\n    ");
		__builder.OpenComponent<Listbox>(57);
		__builder.AddComponentParameter(58, "Title", RuntimeHelpers.TypeCheck(T._("Speed Limit Warning")));
		__builder.AddComponentParameter(59, "Description", RuntimeHelpers.TypeCheck(T._("How ETS2LA will warn you about exceeding the speed limit by a major amount.")));
		__builder.AddComponentParameter(60, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)SpeedLimitWarningOptions));
		__builder.AddComponentParameter(61, "SelectedIndex", RuntimeHelpers.TypeCheck(Array.IndexOf(SpeedLimitWarningOptions.ToArray(), TranslateSpeedLimitWarningOptions[AssistanceSettings.Current.SpeedLimitWarningOption] ?? string.Empty)));
		__builder.AddComponentParameter(62, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (int index) =>
		{
			AssistanceSettings.Current.SpeedLimitWarningOption = (SpeedLimitWarning)index;
			AssistanceSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(63, "\r\n    ");
		__builder.OpenComponent<Switch>(64);
		__builder.AddComponentParameter(65, "Title", RuntimeHelpers.TypeCheck(T._("Pause When Unstable")));
		__builder.AddComponentParameter(66, "Description", RuntimeHelpers.TypeCheck(T._("We will pause the game when we detect instability or the steering is unresponsive / disables itself for other reasons.")));
		__builder.AddComponentParameter(67, "Value", RuntimeHelpers.TypeCheck(PauseWhenUnstable));
		__builder.AddComponentParameter(68, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			PauseWhenUnstable = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(69, "\r\n\r\n    ");
		__builder.OpenComponent<SectionTitle>(70);
		__builder.AddComponentParameter(71, "Class", "mt-8");
		__builder.AddComponentParameter(72, "Title", RuntimeHelpers.TypeCheck(T._("Overrides")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(73, "\r\n    ");
		__builder.OpenComponent<Slider>(74);
		__builder.AddComponentParameter(75, "Title", RuntimeHelpers.TypeCheck(T._("Maximum Speed")));
		__builder.AddComponentParameter(76, "Description", RuntimeHelpers.TypeCheck(T._("The maximum speed ETS2LA will accelerate to. It might still drift over this limit due to momentum.")));
		__builder.AddComponentParameter(77, "Suffix", RuntimeHelpers.TypeCheck((MaximumSpeedLimit == 0f) ? (DisplayUnits() + " " + T._("Disabled")) : DisplayUnits()));
		__builder.AddComponentParameter(78, "Value", RuntimeHelpers.TypeCheck(ToDisplayUnits(MaximumSpeedLimit)));
		__builder.AddComponentParameter(79, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			MaximumSpeedLimit = ToScientificUnits(value);
		})));
		__builder.AddComponentParameter(80, "Min", RuntimeHelpers.TypeCheck(0f));
		__builder.AddComponentParameter(81, "Max", RuntimeHelpers.TypeCheck(250f));
		__builder.AddComponentParameter(82, "Step", RuntimeHelpers.TypeCheck(1f));
		__builder.CloseComponent();
		__builder.AddMarkupContent(83, "\r\n    ");
		__builder.OpenComponent<Dropdown>(84);
		__builder.AddComponentParameter(85, "Title", RuntimeHelpers.TypeCheck(T._("Enabled Traffic Rules")));
		__builder.AddComponentParameter(86, "Description", RuntimeHelpers.TypeCheck(T._("Select which traffic rules ETS2LA should obey. More might be added later, and all plugins won't necessarily support all rules.")));
		__builder.AddComponentParameter(87, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)TrafficRuleOptions));
		__builder.AddComponentParameter(88, "SelectedIndices", RuntimeHelpers.TypeCheck((IReadOnlyList<int>)AssistanceSettings.Current.EnabledTrafficRules.Select((TrafficRule rule) => (int)rule).ToList()));
		__builder.AddComponentParameter(89, "SelectedIndicesChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (IReadOnlyList<int> indices) =>
		{
			AssistanceSettings.Current.EnabledTrafficRules = indices.Select((int index) => (TrafficRule)index).ToList();
			AssistanceSettings.Current.Save();
		})));
		__builder.AddComponentParameter(90, "Multiple", RuntimeHelpers.TypeCheck(value: true));
		__builder.CloseComponent();
		__builder.AddMarkupContent(91, "\r\n    ");
		__builder.OpenComponent<Slider>(92);
		__builder.AddComponentParameter(93, "Title", RuntimeHelpers.TypeCheck(T._("Speedlimit Offset")));
		__builder.AddComponentParameter(94, "Description", RuntimeHelpers.TypeCheck(T._("ETS2LA will offset the speedlimit by this amount.")));
		__builder.AddComponentParameter(95, "Suffix", RuntimeHelpers.TypeCheck(DisplayUnits()));
		__builder.AddComponentParameter(96, "Value", RuntimeHelpers.TypeCheck(ToDisplayUnits(StateSettingsHandler.Current.GetSettings().DesiredSpeedStaticOffset)));
		__builder.AddComponentParameter(97, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			StateSettingsHandler.Current.GetSettings().DesiredSpeedStaticOffset = ToScientificUnits(value);
			StateSettingsHandler.Current.Save();
			InvokeAsync((Action)StateHasChanged);
		})));
		__builder.AddComponentParameter(98, "Min", RuntimeHelpers.TypeCheck(-20f));
		__builder.AddComponentParameter(99, "Max", RuntimeHelpers.TypeCheck(20f));
		__builder.AddComponentParameter(100, "Step", RuntimeHelpers.TypeCheck(1f));
		__builder.CloseComponent();
		__builder.AddMarkupContent(101, "\r\n    ");
		__builder.OpenComponent<Slider>(102);
		__builder.AddComponentParameter(103, "Title", RuntimeHelpers.TypeCheck(T._("Speedlimit Offset")));
		__builder.AddComponentParameter(104, "Description", RuntimeHelpers.TypeCheck(T._("ETS2LA will offset the speedlimit by this percentage.")));
		__builder.AddComponentParameter(105, "Suffix", "%");
		__builder.AddComponentParameter(106, "Value", RuntimeHelpers.TypeCheck(StateSettingsHandler.Current.GetSettings().DesiredSpeedPercentageOffset));
		__builder.AddComponentParameter(107, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			StateSettingsHandler.Current.GetSettings().DesiredSpeedPercentageOffset = value;
			StateSettingsHandler.Current.Save();
			InvokeAsync((Action)StateHasChanged);
		})));
		__builder.AddComponentParameter(108, "Min", RuntimeHelpers.TypeCheck(-20f));
		__builder.AddComponentParameter(109, "Max", RuntimeHelpers.TypeCheck(20f));
		__builder.AddComponentParameter(110, "Step", RuntimeHelpers.TypeCheck(1f));
		__builder.CloseComponent();
		__builder.AddMarkupContent(111, "\r\n    ");
		__builder.OpenElement(112, "p");
		__builder.AddAttribute(113, "class", "description");
		__builder.AddContent(114, T._("When receiving a speedlimit of {0} {1}, we will set the speed to {2} {3}.", 50, DisplayUnits(), Math.Round(50f + ToDisplayUnits(StateSettingsHandler.Current.GetSettings().DesiredSpeedStaticOffset) + 50f * StateSettingsHandler.Current.GetSettings().DesiredSpeedPercentageOffset / 100f, 0), DisplayUnits()));
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private float ToDisplayUnits(float value)
	{
		Units displayUnits = ApplicationState.Current.DisplayUnits;
		return (int)Math.Round(UnitConversions.FromScientificUnits(UnitType.Speed, value, displayUnits), 0);
	}

	private float ToScientificUnits(float value)
	{
		Units displayUnits = ApplicationState.Current.DisplayUnits;
		return UnitConversions.ToScientificUnits(UnitType.Speed, value, displayUnits);
	}

	private string DisplayUnits()
	{
		Units displayUnits = ApplicationState.Current.DisplayUnits;
		return UnitConversions.GetUnitAbbreviation(UnitType.Speed, displayUnits);
	}
}
