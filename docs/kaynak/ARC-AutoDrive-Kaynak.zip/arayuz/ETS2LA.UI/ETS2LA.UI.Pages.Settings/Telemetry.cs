using ETS2LA.Settings.Global;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using ETS2LA.UI.Shared.Layouts;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Pages.Settings;

[Layout(typeof(SettingsLayout))]
[Route("/settings/telemetry")]
public class Telemetry : ComponentBase
{
	private bool AnonymousTelemetry
	{
		get
		{
			return UserSettings.Current.IsTelemetryEnabled;
		}
		set
		{
			UserSettings.Current.IsTelemetryEnabled = value;
			UserSettings.Current.Save();
			UserInterfaceUtils.AskForRestart(T._("Restart Required"), T._("Changing this option requires a restart of ETS2LA to take effect. Restart now?"));
		}
	}

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full p-5 px-8 gap-3");
		__builder.OpenComponent<Switch>(2);
		__builder.AddComponentParameter(3, "Title", RuntimeHelpers.TypeCheck(T._("Anonymous Telemetry")));
		__builder.AddComponentParameter(4, "Description", RuntimeHelpers.TypeCheck(T._("Anonymous telemetry helps us improve ETS2LA by giving us insights into users' system specs, crashes, and other usage data. Your data cannot be identified with any personal information.")));
		__builder.AddComponentParameter(5, "Value", RuntimeHelpers.TypeCheck(AnonymousTelemetry));
		__builder.AddComponentParameter(6, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			AnonymousTelemetry = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(7, "\n    ");
		__builder.OpenElement(8, "a");
		__builder.AddAttribute(9, "href", "https://telemetry.ets2la.com/public-dashboards/17f53fce4749475c8efcab181b1306f3");
		__builder.AddAttribute(10, "target", "_blank");
		__builder.AddAttribute(11, "class", "text-text-l hover:text-text-h hover:underline transition-colors");
		__builder.AddContent(12, T._("View Public Telemetry"));
		__builder.CloseElement();
		__builder.CloseElement();
	}
}
