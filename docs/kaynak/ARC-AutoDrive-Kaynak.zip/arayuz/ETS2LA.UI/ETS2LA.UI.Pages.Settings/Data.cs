using System;
using System.Collections.Generic;
using System.Linq;
using ETS2LA.Game.Data;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using ETS2LA.UI.Shared.Layouts;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Pages.Settings;

[Layout(typeof(SettingsLayout))]
[Route("/settings/data")]
public class Data : ComponentBase
{
	private static Dictionary<DataFidelity, string> TranslateDataFidelity = new Dictionary<DataFidelity, string>
	{
		{
			DataFidelity.Low,
			"Düşük (önerilen)"
		},
		{
			DataFidelity.Medium,
			T._("Medium")
		},
		{
			DataFidelity.High,
			T._("High")
		},
		{
			DataFidelity.Extreme,
			T._("Extreme")
		}
	};

	private static List<string> DataFidelityOptions = (from fidelity in Enum.GetNames<DataFidelity>().ToList()
		select TranslateDataFidelity[Enum.Parse<DataFidelity>(fidelity)]).ToList();

	private static Dictionary<CurveQuality, string> TranslateCurveQuality = new Dictionary<CurveQuality, string>
	{
		{
			CurveQuality.Low,
			T._("Low")
		},
		{
			CurveQuality.MatchGame,
			T._("Game")
		},
		{
			CurveQuality.High,
			T._("High")
		}
	};

	private static List<string> CurveQualityOptions = (from quality in Enum.GetNames<CurveQuality>().ToList()
		select TranslateCurveQuality[Enum.Parse<CurveQuality>(quality)]).ToList();

	private bool ForceBaseMapName
	{
		get
		{
			return DataSettings.Current.ForceBaseMapName;
		}
		set
		{
			DataSettings.Current.ForceBaseMapName = value;
			DataSettings.Current.Save();
			UserInterfaceUtils.AskForRestart(T._("Restart Required"), T._("Changing this option requires a restart of ETS2LA to take effect. Restart now?"));
		}
	}

	private bool ForceMapLoad
	{
		get
		{
			return DataSettings.Current.ForceMapLoad;
		}
		set
		{
			DataSettings.Current.ForceMapLoad = value;
			DataSettings.Current.Save();
		}
	}

	private bool ShowRamWarningHigh => (float)GC.GetGCMemoryInfo().TotalAvailableMemoryBytes / 1.0737418E+09f < 15f;

	private bool ShowRamWarningExtreme => (float)GC.GetGCMemoryInfo().TotalAvailableMemoryBytes / 1.0737418E+09f < 19f;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full p-5 px-8 gap-3");
		// ARC: önce kullanıcının işine yarayan veri kalitesi, en altta "Sorun giderme" (eskiden en üstteydi).
		__builder.OpenComponent<SectionTitle>(17);
		__builder.AddComponentParameter(19, "Title", "Harita verisi");
		__builder.CloseComponent();
		__builder.AddMarkupContent(20, "\n    ");
		__builder.OpenComponent<Listbox>(21);
		__builder.AddComponentParameter(22, "Title", "Veri seviyesi");
		__builder.AddComponentParameter(23, "Description", "Oyun haritasından ne kadar bilgi yükleneceği. Bütün seviyelerde sürüş aynıdır; yüksek seviyeler yalnız daha çok RAM kullanır. Düşük seviyede ARC kullanılmayan harita noktalarını da bellekten atar (yaklaşık 700 MB daha az RAM).");
		__builder.AddComponentParameter(24, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)DataFidelityOptions));
		__builder.AddComponentParameter(25, "SelectedIndex", RuntimeHelpers.TypeCheck(Array.IndexOf(DataFidelityOptions.ToArray(), TranslateDataFidelity[DataSettings.Current.DataFidelity] ?? string.Empty)));
		__builder.AddComponentParameter(26, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (int index) =>
		{
			if (index == 3 && ShowRamWarningExtreme)
			{
				UserInterface.Current.Window.ShowMessageOnTop(T._("Warning: Insufficient RAM"), T._("Your system has less than 20GB of RAM. Extreme data fidelity uses significant amounts of RAM, and may cause your system to become unstable. Please select a lower fidelity."));
			}
			else if (index == 2 && ShowRamWarningHigh)
			{
				UserInterface.Current.Window.ShowMessageOnTop(T._("Warning: Insufficient RAM"), T._("Your system has less than 16GB of RAM. High data fidelity uses significant amounts of RAM, and may cause your system to become unstable. Please select a lower fidelity."));
			}
			else
			{
				DataSettings.Current.DataFidelity = (DataFidelity)index;
				DataSettings.Current.Save();
				InvokeAsync((Action)StateHasChanged);
				UserInterfaceUtils.AskForRestart(T._("Restart Required"), T._("Changing this option requires a restart of ETS2LA to take effect. Restart now?"));
			}
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(27, "\n    ");
		__builder.OpenElement(28, "div");
		__builder.AddAttribute(29, "class", "flex flex-col gap-2");
		if (DataSettings.Current.DataFidelity == DataFidelity.Low)
		{
			__builder.OpenElement(30, "p");
			__builder.AddAttribute(31, "class", "description");
			__builder.AddContent(32, T._("This setting only loads roads and intersections visible on the in game map. It discards all other information."));
			__builder.CloseElement();
		}
		if (DataSettings.Current.DataFidelity == DataFidelity.Medium)
		{
			__builder.OpenElement(33, "p");
			__builder.AddAttribute(34, "class", "description");
			__builder.AddContent(35, T._("This setting drops redundant information while maintaining most detail objects (such as signs). Doesn't include any roads / intersections not shown in the in game map."));
			__builder.CloseElement();
		}
		if (DataSettings.Current.DataFidelity == DataFidelity.High)
		{
			__builder.OpenElement(36, "p");
			__builder.AddAttribute(37, "class", "description");
			__builder.AddContent(38, T._("This setting drops redundant information while maintaining most detail objects (such as signs). Includes all hidden and AI only roads."));
			__builder.CloseElement();
		}
		if (DataSettings.Current.DataFidelity == DataFidelity.Extreme)
		{
			__builder.OpenElement(39, "p");
			__builder.AddAttribute(40, "class", "description");
			__builder.AddContent(41, (MarkupString)T._("This setting includes all available data, most of which is redundant. <span class=\"text-warning\">Warning: Extreme uses significant amounts of RAM, expect over 10GB of usage.</span>"));
			__builder.CloseElement();
		}
		if (ShowRamWarningHigh)
		{
			__builder.OpenElement(42, "p");
			__builder.AddAttribute(43, "class", "description text-warning");
			__builder.AddContent(44, T._("Warning: Your system has less than 16GB of RAM. You can only select up to Medium."));
			__builder.CloseElement();
		}
		if (ShowRamWarningExtreme && !ShowRamWarningHigh)
		{
			__builder.OpenElement(45, "p");
			__builder.AddAttribute(46, "class", "description text-warning");
			__builder.AddContent(47, T._("Warning: Your system has less than 20GB of RAM. You can only select up to High."));
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.AddMarkupContent(48, "\n\n    ");
		__builder.OpenComponent<Listbox>(49);
		__builder.AddComponentParameter(50, "Title", RuntimeHelpers.TypeCheck(T._("Curve Quality")));
		__builder.AddComponentParameter(51, "Description", RuntimeHelpers.TypeCheck(T._("Adjust the quality of the curves used for path planning and visualization. By default this matches the game.")));
		__builder.AddComponentParameter(52, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)CurveQualityOptions));
		__builder.AddComponentParameter(53, "SelectedIndex", RuntimeHelpers.TypeCheck(Array.IndexOf(CurveQualityOptions.ToArray(), TranslateCurveQuality[DataSettings.Current.CurveQuality] ?? string.Empty)));
		__builder.AddComponentParameter(54, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (int index) =>
		{
			DataSettings.Current.CurveQuality = (CurveQuality)index;
			DataSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.OpenComponent<SectionTitle>(55);
		__builder.AddComponentParameter(56, "Class", "mt-8");
		__builder.AddComponentParameter(57, "Title", "Sorun giderme (yalnız gerekirse)");
		__builder.CloseComponent();
		__builder.OpenComponent<Switch>(58);
		__builder.AddComponentParameter(6, "Title", RuntimeHelpers.TypeCheck(T._("Force Base Map Name")));
		__builder.AddComponentParameter(7, "Description", RuntimeHelpers.TypeCheck(T._("Some mods implement additional maps like japan.mbd or russia.mbd. If you find your mods are not loading properly, try enabling this option. This is known to be required for RusMap.")));
		__builder.AddComponentParameter(8, "Value", RuntimeHelpers.TypeCheck(ForceBaseMapName));
		__builder.AddComponentParameter(9, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			ForceBaseMapName = value;
		})));
		__builder.CloseComponent();
		__builder.OpenComponent<Switch>(59);
		__builder.AddComponentParameter(12, "Title", RuntimeHelpers.TypeCheck(T._("Force Map Load")));
		__builder.AddComponentParameter(13, "Description", RuntimeHelpers.TypeCheck(T._("Force ETS2LA to load the map on game startup. This can resolve issues where your game.log.txt is not where ETS2LA expects it.")));
		__builder.AddComponentParameter(14, "Value", RuntimeHelpers.TypeCheck(ForceMapLoad));
		__builder.AddComponentParameter(15, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			ForceMapLoad = value;
		})));
		__builder.CloseComponent();
		__builder.CloseElement();
	}
}
