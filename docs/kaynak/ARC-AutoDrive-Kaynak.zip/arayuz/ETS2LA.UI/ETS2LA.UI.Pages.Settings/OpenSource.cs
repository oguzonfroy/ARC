using System.Collections.Generic;
using ETS2LA.UI.Shared.Components;
using ETS2LA.UI.Shared.Layouts;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Settings;

[Layout(typeof(SettingsLayout))]
[Route("/settings/opensource")]
public class OpenSource : ComponentBase
{
	private struct Project
	{
		public string Name { get; set; }

		public string License { get; set; }

		public string Description { get; set; }

		public string Url { get; set; }
	}

	private List<Project> Projects = new List<Project>
	{
		new Project
		{
			Name = "ARC ETS2 Auto Drive",
			License = "GPL-3.0",
			Description = "ARC ETS2 Auto Drive, ETS2LA (GPL-3.0) tabanlıdır ve ARC Studio tarafından değiştirilmiştir. GPL-3.0 lisansıyla dağıtılır ve HİÇBİR GARANTİ VERİLMEZ. Değiştirilmiş kaynak kodu programla birlikte gelir (program klasöründeki kaynak.tar).",
			Url = "https://www.gnu.org/licenses/gpl-3.0.html"
		},
		new Project
		{
			Name = "ETS2LA",
			License = "GPL-3.0",
			Description = "ETS2LA is licensed under GPLv3. Any modifications to the software must also be released under the same license and the source code must be made available to the public.",
			Url = "https://github.com/ETS2LA/ETS2LA"
		},
		new Project
		{
			Name = "ets2la-plugin",
			License = "MIT",
			Description = "While ETS2LA is licensed under GPLv3, it's game side plugin is licensed under MIT. This plugin is largely based on the work of dariowouters, and he remains the primary maintainer of the plugin. The plugin is used to read and write game memory for data not available via the SCS SDK.",
			Url = "https://github.com/ETS2LA/plugin"
		},
		new Project
		{
			Name = "TruckLib",
			License = "GPL-2.0",
			Description = "We heavily rely on TruckLib for it's data loading and parsing. ETS2LA would not be where it is today without TruckLib and the work of its developer.",
			Url = "https://github.com/sk-zk/TruckLib"
		},
		new Project
		{
			Name = "scs-sdk-plugin",
			License = "MIT",
			Description = "Originally created by nlhans, then later maintained by RenCloud and truckermudgeon, this plugin is used to read telemetry data from the SCS SDK.",
			Url = "https://github.com/truckermudgeon/scs-sdk-plugin"
		},
		new Project
		{
			Name = "TruckSim Maps",
			License = "GPL-3.0",
			Description = "All our mapping data is based on TruckSim Maps. This project has done the tedious work of converting the SCS map data into a real world coordinate system for use in mapping libraries such as MapLibre.",
			Url = "https://github.com/truckermudgeon/maps"
		},
		new Project
		{
			Name = "OpenPilot",
			License = "MIT",
			Description = "We use OpenPilot's audio files for our alerts. OpenPilot is an open source driving agent that can be used to control certain vehicles.",
			Url = "https://github.com/commaai/openpilot"
		},
		new Project
		{
			Name = "NuGet Packages",
			License = "Various",
			Description = "We use various NuGet packages in ETS2LA. Please refer to the source code and the NuGet package manager for a full list of packages and their respective licenses.",
			Url = "https://www.nuget.org/"
		},
		new Project
		{
			Name = "NPM Packages",
			License = "Various",
			Description = "We use various NPM packages in our Visualization. Please refer to the source code and an NPM compatible package manager for a full list of packages and their respective licenses.",
			Url = "https://github.com/ETS2LA/visualization/blob/main/bun.lock"
		}
	};

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-108 m-5 ml-8 gap-4");
		foreach (Project project in Projects)
		{
			__builder.OpenElement(2, "div");
			__builder.AddAttribute(3, "class", "flex flex-col gap-1");
			__builder.OpenComponent<Tooltip>(4);
			__builder.AddComponentParameter(5, "Content", RuntimeHelpers.TypeCheck(project.Url));
			__builder.AddComponentParameter(6, "Class", "w-fit");
			__builder.AddAttribute(7, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder) =>
			{
				renderTreeBuilder.OpenElement(8, "p");
				renderTreeBuilder.AddAttribute(9, "class", "font-semibold hover:underline hover:cursor-pointer");
				renderTreeBuilder.AddAttribute(10, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
				{
					OpenUrl(project.Url);
				}));
				renderTreeBuilder.AddContent(11, project.Name);
				renderTreeBuilder.CloseElement();
			}));
			__builder.CloseComponent();
			__builder.AddMarkupContent(12, "\n            ");
			__builder.OpenElement(13, "p");
			__builder.AddAttribute(14, "class", "description");
			__builder.AddContent(15, project.Description);
			__builder.CloseElement();
			__builder.AddMarkupContent(16, "\n            ");
			__builder.OpenElement(17, "p");
			__builder.AddAttribute(18, "class", "description");
			__builder.AddContent(19, "License: ");
			__builder.AddContent(20, project.License);
			__builder.CloseElement();
			__builder.CloseElement();
		}
		__builder.CloseElement();
	}

	private void OpenUrl(string url)
	{
		UserInterfaceUtils.OpenUrl(url);
	}
}
