using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ETS2LA.Controls;
using ETS2LA.Logging;
using ETS2LA.Notifications;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using ETS2LA.UI.Shared.Layouts;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Settings;

[Layout(typeof(SettingsLayout))]
[Route("/settings/controls")]
public class Controls : ComponentBase
{
	private ControlsBackend controlsBackend = ControlsBackend.Current;

	private List<string> axisTypeOptions = Enum.GetNames<AxisType>().ToList();

	private Thread? bindingThread;

	private ControlInstance? bindingControl;

	private float bindingTimeout = 5f;

	private Dictionary<ControlDefinition, object> controlValues = new Dictionary<ControlDefinition, object>();

	[Parameter]
	public List<string> DisplayOnly { get; set; } = new List<string>();

	private List<ControlInstance> controlInstances => controlsBackend.GetRegisteredControls();

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "grid grid-cols-[repeat(auto-fill,minmax(27rem,1fr))] gap-4 py-2 px-3");
		foreach (ControlInstance control in controlInstances)
		{
			if (DisplayOnly.Count <= 0 || DisplayOnly.Contains(control.Definition.Id))
			{
				__builder.OpenElement(2, "div");
				__builder.AddAttribute(3, "class", "flex flex-col gap-2 rounded-sm bg-control-bg-dark border border-bg-darker justify-between");
				__builder.OpenElement(4, "div");
				__builder.AddAttribute(5, "class", "flex flex-col gap-1 p-4");
				__builder.OpenElement(6, "p");
				__builder.AddAttribute(7, "class", "font-semibold");
				__builder.AddContent(8, control.Definition.Name);
				__builder.CloseElement();
				__builder.AddMarkupContent(9, "\n                ");
				__builder.OpenElement(10, "p");
				__builder.AddAttribute(11, "class", "description");
				__builder.AddContent(12, control.Definition.Description);
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.AddMarkupContent(13, "\n            ");
				__builder.OpenElement(14, "div");
				__builder.AddAttribute(15, "class", "w-full flex flex-col justify-self-end");
				__builder.OpenElement(16, "div");
				__builder.AddAttribute(17, "class", IsAxis(control) ? "w-full mt-1 flex items-center gap-2 px-2" : "hidden");
				__builder.AddMarkupContent(18, "<p class=\"description\">-1</p>\n                    ");
				__builder.OpenElement(19, "div");
				__builder.AddAttribute(20, "class", "w-full h-2 bg-bg-dark rounded-sm flex justify-between");
				__builder.OpenElement(21, "div");
				__builder.AddAttribute(22, "class", "h-2 bg-accent-dark rounded-sm");
				__builder.AddAttribute(23, "style", "width:" + (GetAxisValue(control) + 1f) / 2f * 100f + "%");
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.AddMarkupContent(24, "\n                    ");
				__builder.AddMarkupContent(25, "<p class=\"description\">1</p>");
				__builder.CloseElement();
				__builder.AddMarkupContent(26, "\n                ");
				__builder.OpenElement(27, "div");
				__builder.AddAttribute(28, "class", "flex gap-0");
				__builder.OpenElement(29, "button");
				__builder.AddAttribute(30, "class", GetClass(control));
				__builder.AddAttribute(31, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
				{
					StartBinding(control);
				}));
				__builder.OpenElement(32, "p");
				__builder.AddContent(33, GetDeviceName(control));
				__builder.CloseElement();
				__builder.AddMarkupContent(34, "\n                        ");
				__builder.OpenElement(35, "p");
				__builder.AddContent(36, GetControlType(control));
				__builder.AddContent(37, " ");
				__builder.AddContent(38, GetControlIdName(control));
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.AddMarkupContent(39, "\n                    ");
				__builder.OpenComponent<Dropdown>(40);
				__builder.AddComponentParameter(41, "Title", "");
				__builder.AddComponentParameter(42, "Description", "");
				__builder.AddComponentParameter(43, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)axisTypeOptions));
				__builder.AddComponentParameter(44, "SelectedIndex", RuntimeHelpers.TypeCheck((int)control.AxisBehavior));
				__builder.AddComponentParameter(45, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, async (int index) =>
				{
					control.AxisBehavior = (AxisType)index;
					controlsBackend.UpdateAxisBehavior(control.Definition.Id, control.AxisBehavior);
				})));
				__builder.AddComponentParameter(46, "Class", RuntimeHelpers.TypeCheck(IsAxis(control) ? "gap-0! text-[0px] w-10! min-w-10! h-[40px] p-0! bg-bg-dark!" : "hidden"));
				__builder.CloseComponent();
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.CloseElement();
			}
		}
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		Task.Factory.StartNew((Func<Task>)(async () =>
		{
			using PeriodicTimer timer = new PeriodicTimer(TimeSpan.FromMilliseconds(100L));
			while (await timer.WaitForNextTickAsync())
			{
				await InvokeAsync((Action)StateHasChanged);
			}
		}), TaskCreationOptions.LongRunning);
		controlsBackend.ControlValueChanged += async (object? s, ControlChangeEventArgs e) =>
		{
			await HandleControlValueChanged(s, e);
		};
	}

	private async Task HandleControlValueChanged(object? sender, ControlChangeEventArgs e)
	{
		controlValues[e.controlDefinition] = e.NewValue;
	}

	private string GetControlType(ControlInstance control)
	{
		if (!control.IsBound())
		{
			return T._("Unbound");
		}
		bool flag = control.DeviceId.ToString().ToLower().StartsWith("keyboard");
		bool flag2 = control.ControlId.ToString()?.StartsWith("Button ") ?? false;
		bool flag3 = control.ControlId.ToString()?.StartsWith("Hat ") ?? false;
		if (flag)
		{
			return T._("Key");
		}
		if (flag2)
		{
			return T._("Button");
		}
		if (flag3)
		{
			return "Hat " + control.ControlId.ToString()?.Split(" ")?.ElementAtOrDefault(1);
		}
		return control.AxisBehavior.ToString();
	}

	private string GetDeviceName(ControlInstance control)
	{
		if (string.IsNullOrEmpty(control.DeviceId))
		{
			return T._("Unbound");
		}
		if (control.DeviceId.ToLower().StartsWith("keyboard"))
		{
			return T._("Keyboard");
		}
		InputDeviceInfo inputDeviceInfoById = controlsBackend.GetInputDeviceInfoById(control.DeviceId);
		string text = ((inputDeviceInfoById != null) ? inputDeviceInfoById.Name : T._("Not Connected"));
		if (text.StartsWith("Controller ("))
		{
			text = text.Replace("Controller (", "");
			string text2;
			if (!text.EndsWith(")"))
			{
				text2 = text;
			}
			else
			{
				string text3 = text;
				text2 = text3.Substring(0, text3.Length - 1);
			}
			text = text2;
		}
		if (text.Length > 43)
		{
			text = text.Substring(0, 40) + "...";
		}
		return text;
	}

	private string GetControlIdName(ControlInstance control)
	{
		string controlType = GetControlType(control);
		string text = control.ControlId.ToString() ?? "Unbound";
		text = text.Replace(controlType, "").Trim();
		if (controlType.StartsWith("Hat"))
		{
			text = text switch
			{
				"Up" => "↑", 
				"Right" => "→", 
				"Down" => "↓", 
				"Left" => "←", 
				_ => text, 
			};
		}
		if (controlType.StartsWith(T._("Key")))
		{
			text = text switch
			{
				"Up" => "↑", 
				"Right" => "→", 
				"Down" => "↓", 
				"Left" => "←", 
				_ => text, 
			};
		}
		return text;
	}

	private void BindingThreadFunction()
	{
		if (bindingControl == null)
		{
			Logger.Error(T._("Binding thread started with no control to bind."), "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Controls.razor", 150);
			return;
		}
		NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
		{
			Id = "ETS2LA.UI.Settings.Controls.Binding",
			Title = T._("Binding {0}", bindingControl?.Definition.Name ?? T._("Unknown Control")),
			Content = T._("Press a button or move an axis on your input device to bind it to this control. This will time out in {0} seconds.", bindingTimeout),
			IsProgressIndeterminate = true
		});
		(string, string) input = controlsBackend.WaitForInput(bindingTimeout);
		if (string.IsNullOrEmpty(input.Item1) || string.IsNullOrEmpty(input.Item2))
		{
			Logger.Info(T._("Binding for control {0} ({1}) timed out.", bindingControl.Definition.Name, bindingControl.ControlId), "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Controls.razor", 164);
			NotificationHandler.Current.CloseNotification("ETS2LA.UI.Settings.Controls.Binding");
			NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
			{
				Id = "ETS2LA.UI.Settings.Controls.Binding.Timeout",
				Title = T._("Binding Timed Out"),
				Content = T._("Binding for control {0} ({1}) timed out.", bindingControl.Definition.Name, bindingControl.ControlId),
				Level = NotificationLevel.Warning
			});
			bindingControl = null;
			bindingThread = null;
			InvokeAsync((Action)StateHasChanged);
			return;
		}
		controlsBackend.UpdateControlBindings(bindingControl.Definition.Id, input.Item1, input.Item2);
		List<string> list = (from c in controlInstances
			where c.Definition.Id != bindingControl.Definition.Id && c.DeviceId == input.Item1 && c.ControlId?.ToString() == input.Item2
			select c.Definition.Name).ToList();
		if (list.Count > 0)
		{
			NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
			{
				Id = "ARC.Settings.Controls.Conflict",
				Title = "Tuş çakışması",
				Content = input.Item2 + " tuşu ayrıca şunlara atanmış: " + string.Join(", ", list) + ". Birlikte tetiklenmemeleri için birini değiştir.",
				Level = NotificationLevel.Warning,
				CloseAfter = 10f
			});
		}
		Logger.Info(T._("Bound control {0} ({1}) to device {2} and control {3}", bindingControl.Definition.Name, bindingControl.Definition.Id, input.Item1, input.Item2), "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Controls.razor", 197);
		NotificationHandler.Current.CloseNotification("ETS2LA.UI.Settings.Controls.Binding");
		NotificationHandler.Current.SendNotification(new ETS2LA.Notifications.Notification
		{
			Id = "ETS2LA.UI.Settings.Controls.Binding.Success",
			Title = T._("Binding Successful"),
			Content = T._("Bound control {0} ({1}) to device {2} and control {3}", bindingControl?.Definition.Name ?? T._("Unknown Control"), bindingControl?.Definition.Id ?? T._("Unknown Control ID"), input.Item1, input.Item2),
			Level = NotificationLevel.Success
		});
		bindingControl = null;
		bindingThread = null;
		InvokeAsync((Action)StateHasChanged);
	}

	private void StartBinding(ControlInstance control)
	{
		if (bindingThread != null && bindingThread.IsAlive)
		{
			bindingThread.Interrupt();
			bindingThread.Join();
			bindingThread = null;
		}
		Logger.Info(T._("Starting binding for control {0} ({1})", control.Definition.Name, control.ControlId), "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Controls.razor", 221);
		bindingControl = control;
		bindingThread = new Thread(() =>
		{
			BindingThreadFunction();
		});
		StateHasChanged();
		bindingThread.Start();
	}

	private string GetClass(ControlInstance control)
	{
		GetControlType(control);
		string text = "flex w-full bg-bg-dark/70 hover:bg-bg/60 rounded-sm rounded-t-none p-3 px-4 justify-between transition-colors";
		if (bindingControl == control && bindingThread != null && bindingThread.IsAlive)
		{
			text += " border-accent!";
		}
		if (!IsAxis(control))
		{
			bool flag = false;
			int num;
			if (controlValues.TryGetValue(control.Definition, out var value))
			{
				if (value is bool)
				{
					flag = (bool)value;
					num = 1;
				}
				else
				{
					num = 0;
				}
			}
			else
			{
				num = 0;
			}
			if (((uint)num & (flag ? 1u : 0u)) != 0)
			{
				text += " bg-accent-dark! border-accent!";
			}
		}
		else if (GetAxisValue(control) > 0.6f)
		{
			text += " bg-accent-dark! border-accent!";
		}
		return text;
	}

	private float GetAxisValue(ControlInstance control)
	{
		if (controlValues.TryGetValue(control.Definition, out var value) && value is float)
		{
			return (float)value;
		}
		return 0f;
	}

	private bool IsAxis(ControlInstance control)
	{
		if (!GetControlIdName(control).Contains("Axis"))
		{
			return GetControlType(control).Contains("Axis");
		}
		return true;
	}
}
