using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ETS2LA.Logging;
using ETS2LA.Overlay;
using ETS2LA.State;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using ETS2LA.UI.Shared.Layouts;
using Hexa.NET.GLFW;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.JSInterop;

namespace ETS2LA.UI.Pages.Settings;

[Layout(typeof(SettingsLayout))]
[Route("/settings/display")]
public class Display : ComponentBase
{
	private Dictionary<Units, string> displayUnitTranslations = new Dictionary<Units, string>
	{
		{
			Units.Metric,
			T._("Metric")
		},
		{
			Units.Imperial,
			T._("Imperial")
		},
		{
			Units.Scientific,
			T._("Scientific")
		}
	};

	private List<string> displayLanguageOptions = Languages.SupportedLanguages.Select((Language l) => l.NativeName + " - " + l.EnglishName).ToList();

	private bool FontSizeHasChanged;

	private int CurrentARFramerate => (int)Math.Round((OverlayHandler.Current.AverageFrameTime > 0f) ? ((float)(int)(1f / (OverlayHandler.Current.AverageFrameTime / 1000f))) : 0f, 0);

	private int CurrentUnits => (int)ApplicationState.Current.DisplayUnits;

	private int CurrentLanguage => Languages.SupportedLanguages.FindIndex((Language l) => l.Code == StateSettingsHandler.Current.GetSettings().DisplayLanguage?.Code);

	private int MonitorIndex
	{
		get
		{
			return OverlaySettingsHandler.Current.GetSettings().MonitorIndex;
		}
		set
		{
			OverlaySettingsHandler.Current.GetSettings().MonitorIndex = value;
			OverlaySettingsHandler.Current.Save();
			UserInterfaceUtils.AskForRestart("Restart Required", "Changing this option requires a restart of ETS2LA to take effect. Restart now?");
		}
	}

	private bool DisableOverlay
	{
		get
		{
			return OverlaySettingsHandler.Current.GetSettings().DisableOverlay;
		}
		set
		{
			OverlaySettingsHandler.Current.GetSettings().DisableOverlay = value;
			OverlaySettingsHandler.Current.Save();
			UserInterfaceUtils.AskForRestart("Restart Required", "Changing this option requires a restart of ETS2LA to take effect. Restart now?");
		}
	}

	private bool OverlayInteractionIsToggle
	{
		get
		{
			return OverlaySettingsHandler.Current.GetSettings().OverlayInteractionIsToggle;
		}
		set
		{
			OverlaySettingsHandler.Current.GetSettings().OverlayInteractionIsToggle = value;
			OverlaySettingsHandler.Current.Save();
		}
	}

	private bool SupportMultipleViewports
	{
		get
		{
			return OverlaySettingsHandler.Current.GetSettings().SupportMultipleViewports;
		}
		set
		{
			OverlaySettingsHandler.Current.GetSettings().SupportMultipleViewports = value;
			OverlaySettingsHandler.Current.Save();
			UserInterfaceUtils.AskForRestart("Restart Required", "Changing this option requires a restart of ETS2LA to take effect. Restart now?");
		}
	}

	private bool LimitOverlayFramerate
	{
		get
		{
			return OverlaySettingsHandler.Current.GetSettings().LimitFramerate;
		}
		set
		{
			OverlaySettingsHandler.Current.GetSettings().LimitFramerate = value;
			OverlaySettingsHandler.Current.Save();
		}
	}

	private int MaxOverlayFramerate
	{
		get
		{
			return OverlaySettingsHandler.Current.GetSettings().MaxFramerate;
		}
		set
		{
			OverlaySettingsHandler.Current.GetSettings().MaxFramerate = value;
			OverlaySettingsHandler.Current.Save();
		}
	}

	private bool RenderARElements
	{
		get
		{
			return OverlaySettingsHandler.Current.GetSettings().RenderAR;
		}
		set
		{
			OverlaySettingsHandler.Current.GetSettings().RenderAR = value;
			OverlaySettingsHandler.Current.Save();
		}
	}

	private bool SimplifiedGraphics
	{
		get
		{
			return OverlaySettingsHandler.Current.GetSettings().SimplifiedGraphics;
		}
		set
		{
			OverlaySettingsHandler.Current.GetSettings().SimplifiedGraphics = value;
			OverlaySettingsHandler.Current.Save();
		}
	}

	private bool StopRenderingWhenGamePaused
	{
		get
		{
			return OverlaySettingsHandler.Current.GetSettings().DontRenderWhenPaused;
		}
		set
		{
			OverlaySettingsHandler.Current.GetSettings().DontRenderWhenPaused = value;
			OverlaySettingsHandler.Current.Save();
		}
	}

	private float MaxRenderDistance
	{
		get
		{
			return OverlaySettingsHandler.Current.GetSettings().MaxARDistance;
		}
		set
		{
			OverlaySettingsHandler.Current.GetSettings().MaxARDistance = value;
			OverlaySettingsHandler.Current.Save();
		}
	}

	private bool StayOnTop
	{
		get
		{
			return WindowSettings.Current.StayOnTop;
		}
		set
		{
			if (value != StayOnTop)
			{
				WindowSettings.Current.StayOnTop = value;
				WindowSettings.Current.Save();
				UserInterfaceUtils.AskForRestart(T._("Restart Required"), T._("Changing this option requires a restart of ETS2LA to take effect. Restart now?"));
			}
		}
	}

	[Inject]
	private IJSRuntime JS { get; set; }

	private List<string> GetMonitorNames()
	{
		try
		{
			List<string> list = new List<string>();
			int num = 0;
			foreach (GLFWvidmodePtr monitorMode in OverlayHandler.Current.MonitorModes)
			{
				list.Add($"Monitor {num}: {monitorMode.Width}x{monitorMode.Height} @ {monitorMode.RefreshRate}Hz");
				num++;
			}
			return list;
		}
		catch
		{
			return new List<string> { T._("Error retrieving monitor names") };
		}
	}

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full p-5 px-8 gap-2");
		__builder.OpenComponent<SectionTitle>(2);
		__builder.AddComponentParameter(3, "Title", RuntimeHelpers.TypeCheck(T._("Units and Language")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(4, "\n    ");
		__builder.OpenComponent<Listbox>(5);
		__builder.AddComponentParameter(6, "Title", RuntimeHelpers.TypeCheck(T._("Display Units")));
		__builder.AddComponentParameter(7, "Description", RuntimeHelpers.TypeCheck(T._("The units ETS2LA will use when displaying information to a user. Scientific has only slight differences to metric.")));
		__builder.AddComponentParameter(8, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)displayUnitTranslations.Values.ToList()));
		__builder.AddComponentParameter(9, "SelectedIndex", RuntimeHelpers.TypeCheck(CurrentUnits));
		__builder.AddComponentParameter(10, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create((object)this, (Action<int>)OnDisplayUnitChanged)));
		__builder.CloseComponent();
		__builder.AddMarkupContent(11, "\n    ");
		__builder.OpenComponent<Dropdown>(12);
		__builder.AddComponentParameter(13, "Title", RuntimeHelpers.TypeCheck(T._("Display Language")));
		__builder.AddComponentParameter(14, "Description", RuntimeHelpers.TypeCheck(T._("The language ETS2LA will be displayed at. Translations are provided by the community, we cannot guarantee their accuracy.") + "<br/><br/>" + T._("Translated by:") + "<br/>" + string.Join("<br/>", T.LanguageCredits(Languages.SupportedLanguages[CurrentLanguage].Code))));
		__builder.AddComponentParameter(15, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)displayLanguageOptions));
		__builder.AddComponentParameter(16, "SelectedIndex", RuntimeHelpers.TypeCheck(CurrentLanguage));
		__builder.AddComponentParameter(17, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create((object)this, (Action<int>)OnDisplayLanguageChanged)));
		__builder.CloseComponent();
		__builder.AddMarkupContent(18, "\n    \n    ");
		__builder.OpenComponent<SectionTitle>(19);
		__builder.AddComponentParameter(20, "Class", "mt-8");
		__builder.AddComponentParameter(21, "Title", RuntimeHelpers.TypeCheck(T._("Window")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(22, "\n    ");
		__builder.OpenComponent<Slider>(23);
		__builder.AddComponentParameter(24, "Title", RuntimeHelpers.TypeCheck(T._("Window Zoom")));
		__builder.AddComponentParameter(25, "Suffix", "%");
		__builder.AddComponentParameter(26, "Description", RuntimeHelpers.TypeCheck(T._("The zoom level of the ETS2LA window. This can be used to scale the window to your monitor's DPI settings.")));
		__builder.AddComponentParameter(27, "Min", RuntimeHelpers.TypeCheck(50f));
		__builder.AddComponentParameter(28, "Max", RuntimeHelpers.TypeCheck(200f));
		__builder.AddComponentParameter(29, "Value", RuntimeHelpers.TypeCheck((float)WindowSettings.Current.Zoom));
		__builder.AddComponentParameter(30, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			HandleZoomChanged(value);
		})));
		__builder.AddComponentParameter(31, "ValueSubmitted", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create<float>(this, () => HandleZoomSubmitted())));
		__builder.CloseComponent();
		__builder.AddMarkupContent(32, "\n    ");
		__builder.OpenComponent<Switch>(33);
		__builder.AddComponentParameter(34, "Title", RuntimeHelpers.TypeCheck(T._("Stay on Top")));
		__builder.AddComponentParameter(35, "Description", RuntimeHelpers.TypeCheck(T._("Keep the ETS2LA window on top of other windows. If you want to use the visualization on a single monitor setup, this is recommended.")));
		__builder.AddComponentParameter(36, "Value", RuntimeHelpers.TypeCheck(StayOnTop));
		__builder.AddComponentParameter(37, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			StayOnTop = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(38, "\n\n    ");
		__builder.OpenComponent<SectionTitle>(39);
		__builder.AddComponentParameter(40, "Class", "mt-8");
		__builder.AddComponentParameter(41, "Title", RuntimeHelpers.TypeCheck(T._("Overlay")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(42, "\n    ");
		__builder.OpenComponent<Switch>(43);
		__builder.AddComponentParameter(44, "Title", RuntimeHelpers.TypeCheck(T._("Disable Overlay")));
		__builder.AddComponentParameter(45, "Description", RuntimeHelpers.TypeCheck(T._("Disables the overlay entirely. This will fix the black screen issue at the cost of breaking all features that rely on the overlay, including AR and the HUD.")));
		__builder.AddComponentParameter(46, "Value", RuntimeHelpers.TypeCheck(DisableOverlay));
		__builder.AddComponentParameter(47, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			DisableOverlay = value;
		})));
		__builder.CloseComponent();
		__builder.OpenRegion(900);
		__builder.AddMarkupContent(0, "\n    ");
		__builder.OpenComponent<Dropdown>(1);
		__builder.AddComponentParameter(2, "Title", RuntimeHelpers.TypeCheck(T._("Monitor")));
		__builder.AddComponentParameter(3, "Description", RuntimeHelpers.TypeCheck(T._("The monitor ETS2LA's overlay will be displayed on. If you have multiple monitors, you can select which one to use here. Please select the monitor the game is running on, and ensure the game is in fullscreen.")));
		__builder.AddComponentParameter(4, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)GetMonitorNames()));
		__builder.AddComponentParameter(5, "SelectedIndex", RuntimeHelpers.TypeCheck(MonitorIndex));
		__builder.AddComponentParameter(6, "SelectedIndexChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (int index) =>
		{
			MonitorIndex = index;
		})));
		__builder.CloseComponent();
		__builder.CloseRegion();
		__builder.AddMarkupContent(48, "\n    ");
		__builder.OpenComponent<Slider>(49);
		__builder.AddComponentParameter(50, "Title", RuntimeHelpers.TypeCheck(T._("Overlay Font Size")));
		__builder.AddComponentParameter(51, "Suffix", "px");
		__builder.AddComponentParameter(52, "Description", RuntimeHelpers.TypeCheck(T._("The font size of the overlay. This can be used to scale the overlay to your monitor's DPI settings.")));
		__builder.AddComponentParameter(53, "Min", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(54, "Max", RuntimeHelpers.TypeCheck(30f));
		__builder.AddComponentParameter(55, "Value", RuntimeHelpers.TypeCheck((float)OverlaySettingsHandler.Current.GetSettings().BaseFontSize));
		__builder.AddComponentParameter(56, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			HandleFontSizeChanged(value);
		})));
		__builder.CloseComponent();
		if (FontSizeHasChanged)
		{
			__builder.OpenElement(57, "p");
			__builder.AddAttribute(58, "class", "text-sm text-description! font-normal!");
			__builder.AddContent(59, T._("You must restart ETS2LA for the font size change to take effect."));
			__builder.CloseElement();
		}
		__builder.OpenComponent<Switch>(60);
		__builder.AddComponentParameter(61, "Title", RuntimeHelpers.TypeCheck(T._("Keybind is Toggle")));
		__builder.AddComponentParameter(62, "Description", RuntimeHelpers.TypeCheck(T._("When enabled, the overlay will toggle between interaction and non-interaction mode when you press it's keybind. When disabled, the overlay will only be interactive while you hold down the keybind.")));
		__builder.AddComponentParameter(63, "Value", RuntimeHelpers.TypeCheck(OverlaySettingsHandler.Current.GetSettings().OverlayInteractionIsToggle));
		__builder.AddComponentParameter(64, "Class", RuntimeHelpers.TypeCheck((!DisableOverlay) ? "" : "opacity-30 pointer-events-none"));
		__builder.AddComponentParameter(65, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			OverlayInteractionIsToggle = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(66, "\n    ");
		__builder.OpenComponent<Switch>(67);
		__builder.AddComponentParameter(68, "Title", RuntimeHelpers.TypeCheck(T._("Support Multiple Viewports")));
		__builder.AddComponentParameter(69, "Description", RuntimeHelpers.TypeCheck(T._("This allows ETS2LA to render in multiple viewports, meaning you can move overlay windows to any monitor.")));
		__builder.AddComponentParameter(70, "Value", RuntimeHelpers.TypeCheck(SupportMultipleViewports));
		__builder.AddComponentParameter(71, "Class", RuntimeHelpers.TypeCheck((!DisableOverlay) ? "" : "opacity-30 pointer-events-none"));
		__builder.AddComponentParameter(72, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			SupportMultipleViewports = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(73, "\n    ");
		__builder.OpenComponent<Switch>(74);
		__builder.AddComponentParameter(75, "Title", RuntimeHelpers.TypeCheck(T._("Limit Overlay Framerate")));
		__builder.AddComponentParameter(76, "Description", RuntimeHelpers.TypeCheck(T._("In most situations, over half of ETS2LA's CPU use is consumed by the overlay. Limiting the framerate will reduce CPU usage.")));
		__builder.AddComponentParameter(77, "Value", RuntimeHelpers.TypeCheck(LimitOverlayFramerate));
		__builder.AddComponentParameter(78, "Class", RuntimeHelpers.TypeCheck((!DisableOverlay) ? "" : "opacity-30 pointer-events-none"));
		__builder.AddComponentParameter(79, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			LimitOverlayFramerate = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(80, "\n    ");
		__builder.OpenComponent<Slider>(81);
		__builder.AddComponentParameter(82, "Title", RuntimeHelpers.TypeCheck(T._("Max Overlay Framerate")));
		__builder.AddComponentParameter(83, "Description", RuntimeHelpers.TypeCheck(T._("Currently running at {0} FPS.", CurrentARFramerate)));
		__builder.AddComponentParameter(84, "Suffix", "FPS");
		__builder.AddComponentParameter(85, "Class", RuntimeHelpers.TypeCheck((LimitOverlayFramerate && !DisableOverlay) ? "" : "opacity-30 pointer-events-none"));
		__builder.AddComponentParameter(86, "Min", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(87, "Max", RuntimeHelpers.TypeCheck(120f));
		__builder.AddComponentParameter(88, "Value", RuntimeHelpers.TypeCheck((float)MaxOverlayFramerate));
		__builder.AddComponentParameter(89, "HighlightValue", RuntimeHelpers.TypeCheck((float?)CurrentARFramerate));
		__builder.AddComponentParameter(90, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			MaxOverlayFramerate = (int)value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(91, "\n\n    ");
		__builder.OpenComponent<SectionTitle>(92);
		__builder.AddComponentParameter(93, "Class", "mt-8");
		__builder.AddComponentParameter(94, "Title", RuntimeHelpers.TypeCheck(T._("3D Renderer")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(95, "\n    ");
		__builder.OpenComponent<Switch>(96);
		__builder.AddComponentParameter(97, "Title", RuntimeHelpers.TypeCheck(T._("Render AR Elements")));
		__builder.AddComponentParameter(98, "Description", RuntimeHelpers.TypeCheck(T._("We can render elements in the game world using the overlay. This will use additional CPU and GPU resources.")));
		__builder.AddComponentParameter(99, "Value", RuntimeHelpers.TypeCheck(RenderARElements));
		__builder.AddComponentParameter(100, "Class", RuntimeHelpers.TypeCheck((!DisableOverlay) ? "" : "opacity-30 pointer-events-none"));
		__builder.AddComponentParameter(101, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			RenderARElements = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(102, "\n    ");
		__builder.OpenComponent<Switch>(103);
		__builder.AddComponentParameter(104, "Title", RuntimeHelpers.TypeCheck(T._("Simplified Graphics")));
		__builder.AddComponentParameter(105, "Description", RuntimeHelpers.TypeCheck(T._("Using simplified graphics can improve performance on lower-end hardware, or fix situations in which advanced features like shaders are not supported.")));
		__builder.AddComponentParameter(106, "Class", RuntimeHelpers.TypeCheck((!DisableOverlay && RenderARElements) ? "" : "opacity-30 pointer-events-none"));
		__builder.AddComponentParameter(107, "Value", RuntimeHelpers.TypeCheck(SimplifiedGraphics));
		__builder.AddComponentParameter(108, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			SimplifiedGraphics = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(109, "\n    ");
		__builder.OpenComponent<Switch>(110);
		__builder.AddComponentParameter(111, "Title", RuntimeHelpers.TypeCheck(T._("Stop Rendering When Game is Paused")));
		__builder.AddComponentParameter(112, "Description", RuntimeHelpers.TypeCheck(T._("When the game reports itself being paused, ETS2LA won't render AR elements.")));
		__builder.AddComponentParameter(113, "Class", RuntimeHelpers.TypeCheck((!DisableOverlay && RenderARElements) ? "" : "opacity-30 pointer-events-none"));
		__builder.AddComponentParameter(114, "Value", RuntimeHelpers.TypeCheck(StopRenderingWhenGamePaused));
		__builder.AddComponentParameter(115, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			StopRenderingWhenGamePaused = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(116, "\n    ");
		__builder.OpenComponent<Slider>(117);
		__builder.AddComponentParameter(118, "Title", RuntimeHelpers.TypeCheck(T._("Max Render Distance")));
		__builder.AddComponentParameter(119, "Suffix", "m");
		__builder.AddComponentParameter(120, "Description", RuntimeHelpers.TypeCheck(T._("The maximum distance at which 3D elements will be rendered. Lowering this can be used to improve performance on lower-end hardware.")));
		__builder.AddComponentParameter(121, "Class", RuntimeHelpers.TypeCheck((!DisableOverlay && RenderARElements) ? "" : "opacity-30 pointer-events-none"));
		__builder.AddComponentParameter(122, "Min", RuntimeHelpers.TypeCheck(50f));
		__builder.AddComponentParameter(123, "Max", RuntimeHelpers.TypeCheck(512f));
		__builder.AddComponentParameter(124, "Value", RuntimeHelpers.TypeCheck(MaxRenderDistance));
		__builder.AddComponentParameter(125, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			MaxRenderDistance = value;
		})));
		__builder.CloseComponent();
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		Task.Factory.StartNew((Func<Task>)(async () =>
		{
			using PeriodicTimer timer = new PeriodicTimer(TimeSpan.FromMilliseconds(500L));
			while (await timer.WaitForNextTickAsync())
			{
				await InvokeAsync((Action)StateHasChanged);
			}
		}), TaskCreationOptions.LongRunning);
	}

	private void OnDisplayUnitChanged(int index)
	{
		StateSettingsHandler.Current.GetSettings().DisplayUnits = (Units)index;
		StateSettingsHandler.Current.Save();
	}

	private void OnDisplayLanguageChanged(int index)
	{
		string selectedLanguageName = displayLanguageOptions[index].Split("-")[1].Trim();
		Logger.Info($"Selecting language {selectedLanguageName} ({index})", "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Display.razor", 186);
		Language language = Languages.SupportedLanguages.FirstOrDefault((Language l) => l.EnglishName == selectedLanguageName);
		if (language == null)
		{
			Logger.Error(T._("{0} not found in supported languages.", selectedLanguageName), "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\ETS2LA.UI\\Pages\\Settings\\Display.razor", 190);
		}
		else
		{
			StateSettingsHandler.Current.GetSettings().DisplayLanguage = language;
			StateSettingsHandler.Current.Save();
			UserInterfaceUtils.AskForRestart(T._("Restart Required"), T._("Changing the display language requires a restart of ETS2LA to take effect. Restart now?"));
		}
	}

	private void HandleZoomChanged(float newZoom)
	{
		newZoom = (int)Math.Round(newZoom);
		WindowSettings.Current.Zoom = (int)newZoom;
	}

	private void HandleFontSizeChanged(float newFontSize)
	{
		newFontSize = (int)Math.Round(newFontSize);
		OverlaySettingsHandler.Current.GetSettings().BaseFontSize = (int)newFontSize;
		OverlaySettingsHandler.Current.Save();
		FontSizeHasChanged = true;
		InvokeAsync((Action)StateHasChanged);
	}

	private async Task HandleZoomSubmitted()
	{
		await JS.InvokeVoidAsync("sendIPCMessage", $"window:zoom:{WindowSettings.Current.Zoom}");
		WindowSettings.Current.Save();
	}
}
