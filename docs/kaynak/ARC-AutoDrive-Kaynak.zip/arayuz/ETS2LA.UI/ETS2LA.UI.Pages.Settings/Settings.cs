using ETS2LA.UI.Shared.Layouts;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Pages.Settings;

[Layout(typeof(SettingsLayout))]
[Route("/settings")]
public class Settings : ComponentBase
{
	[Inject]
	private NavigationManager Navigation { get; set; }

	// ARC: "Ayarlar"a basınca sağ taraf boş kalıyordu; en çok kullanılan sayfa açılır.
	protected override void OnInitialized()
	{
		Navigation.NavigateTo("/settings/assists", replace: true);
	}

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
	}
}
