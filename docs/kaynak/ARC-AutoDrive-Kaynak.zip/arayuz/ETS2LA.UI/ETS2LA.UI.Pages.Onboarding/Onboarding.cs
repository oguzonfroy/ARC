using System;
using System.Threading.Tasks;
using ETS2LA.UI.Pages.Onboarding.Steps;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Pages.Onboarding;

[Route("/onboarding")]
public class Onboarding : ComponentBase
{
	private bool transitionOut;

	private int currentStep;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", (transitionOut ? "opacity-0" : "opacity-100") + " flex flex-col items-center justify-center w-full h-full relative transition-all duration-200 ease-in-out");
		switch (currentStep)
		{
		case 0:
			__builder.OpenComponent<WelcomeStep>(2);
			__builder.AddComponentParameter(3, "OnNext", new Action(NextStep));
			__builder.CloseComponent();
			break;
		case 1:
			__builder.OpenComponent<PrivacyPolicyStep>(4);
			__builder.AddComponentParameter(5, "OnNext", new Action(NextStep));
			__builder.CloseComponent();
			break;
		case 2:
			__builder.OpenComponent<EnsureGameClosed>(6);
			__builder.AddComponentParameter(7, "OnNext", new Action(NextStep));
			__builder.CloseComponent();
			break;
		case 3:
			__builder.OpenComponent<SDKStep>(8);
			__builder.AddComponentParameter(9, "OnNext", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create((object)this, (Action)NextStep)));
			__builder.CloseComponent();
			break;
		case 4:
			__builder.OpenComponent<SDKReminderStep>(10);
			__builder.AddComponentParameter(11, "OnNext", new Action(NextStep));
			__builder.CloseComponent();
			break;
		case 5:
			__builder.OpenComponent<OverlayStep>(12);
			__builder.AddComponentParameter(13, "OnNext", new Action(NextStep));
			__builder.CloseComponent();
			break;
		case 6:
			__builder.OpenComponent<ControlsStep>(14);
			__builder.AddComponentParameter(15, "OnNext", new Action(NextStep));
			__builder.CloseComponent();
			break;
		case 7:
			__builder.OpenComponent<PluginStep>(16);
			__builder.AddComponentParameter(17, "OnNext", new Action(NextStep));
			__builder.CloseComponent();
			break;
		case 8:
			__builder.OpenComponent<DisclaimerStep1>(18);
			__builder.AddComponentParameter(19, "OnNext", new Action(NextStep));
			__builder.CloseComponent();
			break;
		case 9:
			__builder.OpenComponent<DisclaimerStep2>(20);
			__builder.AddComponentParameter(21, "OnNext", new Action(NextStep));
			__builder.CloseComponent();
			break;
		case 10:
			__builder.OpenComponent<FinishStep>(22);
			__builder.CloseComponent();
			break;
		}
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		currentStep = WindowSettings.Current.OnboardingStep;
		if (currentStep == 1)
		{
			currentStep = 2;
		}
		WindowState.Current.IsSidebarOpen = false;
		WindowState.Current.RequestFullReload();
	}

	private void NextStep()
	{
		transitionOut = true;
		InvokeAsync((Action)StateHasChanged);
		Task.Delay(300).ContinueWith((Task _) =>
		{
			InvokeAsync(() =>
			{
				transitionOut = false;
				currentStep++;
				if (currentStep == 1)
				{
					currentStep = 2;
				}
				WindowSettings.Current.OnboardingStep = currentStep;
				WindowSettings.Current.Save();
				StateHasChanged();
			});
		});
	}

	private void PreviousStep()
	{
		currentStep--;
	}
}
