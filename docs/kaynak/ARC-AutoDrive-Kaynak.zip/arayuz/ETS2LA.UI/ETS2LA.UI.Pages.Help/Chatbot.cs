using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using ETS2LA.Backend;
using ETS2LA.Game;
using ETS2LA.Logging;
using ETS2LA.Networking.Settings;
using ETS2LA.Networking.Users;
using ETS2LA.Shared;
using ETS2LA.State;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using Markdig;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;

namespace ETS2LA.UI.Pages.Help;

[Route("/help/chatbot")]
public class Chatbot : ComponentBase
{
	private sealed class ChatMessage(string role, string text)
	{
		public string Role { get; } = role;

		public string Text { get; set; } = text;

		public bool RequestLog { get; set; }

		public string Log { get; init; } = string.Empty;
	}

	private string currentVersion = Assembly.GetEntryAssembly()?.GetName().Version?.ToString(3) ?? "unknown";

	private const string Endpoint = "https://mandarinbot-api.lun011666.com/ask";

	private static readonly MarkdownPipeline MarkdownPipeline = new MarkdownPipelineBuilder().UseAdvancedExtensions().Build();

	private static readonly List<ChatMessage> Messages = new List<ChatMessage>();

	private CancellationTokenSource? requestCancellation;

	private Stopwatch? thinkingTimer;

	private bool ShowLogDialog;

	private bool IsReadingLog;

	private string LogPreview = string.Empty;

	private string? ViewedLog;

	private string Draft = string.Empty;

	private string Status = string.Empty;

	private string Error = string.Empty;

	private static bool IsSending;

	private ElementReference inputElement;

	private DotNetObjectReference<Chatbot>? selfReference;

	private User? CurrentUser => NetworkingSettings.Current.CurrentUser;

	private bool ShowStateDialog { get; set; }

	[Inject]
	private IJSRuntime JS { get; set; }

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex h-full w-full flex-col gap-4 p-5 px-8");
		if (CurrentUser == null || string.IsNullOrEmpty(CurrentUser.JwtToken) || DateTime.UtcNow >= CurrentUser.Expiry)
		{
			__builder.OpenElement(2, "p");
			__builder.AddAttribute(3, "class", "description text-center");
			__builder.AddContent(4, T._("Please log in to use the chatbot."));
			__builder.CloseElement();
		}
		else
		{
			__builder.OpenElement(5, "div");
			__builder.AddAttribute(6, "class", "flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto");
			if (Messages.Count == 0)
			{
				__builder.OpenElement(7, "p");
				__builder.AddAttribute(8, "class", "description m-auto text-center");
				__builder.AddContent(9, (MarkupString)T._("This chatbot is provided for free by <span class=\"text-text-l\">Lun011666</span>.<br/>For the sake of the community, we ask you not to abuse access."));
				__builder.CloseElement();
			}
			foreach (ChatMessage message in Messages)
			{
				__builder.OpenElement(10, "div");
				__builder.AddAttribute(11, "class", "max-w-[85%] rounded-md p-3 " + ((message.Role == "user") ? "ml-auto bg-accent text-white" : "mr-auto bg-control-bg"));
				if (message.Role == "assistant" && !string.IsNullOrWhiteSpace(message.Text))
				{
					__builder.OpenElement(12, "div");
					__builder.AddAttribute(13, "class", "[&_p]:mb-2 [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:list-decimal [&_ol]:pl-5 [&_code]:rounded-sm [&_code]:bg-bg-dark [&_code]:px-1 whitespace-normal [&_a]:text-text-accent");
					__builder.AddContent(14, (MarkupString)Markdown.ToHtml(message.Text, MarkdownPipeline));
					__builder.CloseElement();
					if (message.RequestLog && message == Messages.LastOrDefault())
					{
						__builder.OpenElement(15, "button");
						__builder.AddAttribute(16, "type", "button");
						__builder.AddAttribute(17, "class", "button mt-3");
						__builder.AddAttribute(18, "disabled", IsSending || IsReadingLog);
						__builder.AddAttribute(19, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Func<Task>)OpenLogDialog));
						__builder.AddContent(20, T._("Share log"));
						__builder.CloseElement();
					}
				}
				else if (message.Role == "assistant" && string.IsNullOrWhiteSpace(message.Text))
				{
					__builder.AddMarkupContent(21, "<svg class=\"animate-spin h-5 w-5 text-text-l m-auto\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" viewBox=\"0 0 24 24\"><circle class=\"opacity-25\" cx=\"12\" cy=\"12\" r=\"10\" stroke=\"currentColor\" stroke-width=\"4\"></circle>\n                            <path class=\"opacity-75\" fill=\"currentColor\" d=\"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z\"></path></svg>");
				}
				else if (message.Log.Length > 0)
				{
					__builder.OpenElement(22, "button");
					__builder.AddAttribute(23, "type", "button");
					__builder.AddAttribute(24, "class", "whitespace-pre-wrap text-left hover:underline");
					__builder.AddAttribute(25, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
					{
						ViewedLog = message.Log;
					}));
					__builder.AddContent(26, message.Text);
					__builder.CloseElement();
				}
				else
				{
					__builder.OpenElement(27, "p");
					__builder.AddAttribute(28, "class", "whitespace-pre-wrap");
					__builder.AddContent(29, message.Text);
					__builder.CloseElement();
				}
				__builder.CloseElement();
			}
			if (IsSending)
			{
				__builder.OpenElement(30, "p");
				__builder.AddAttribute(31, "class", "description");
				__builder.AddContent(32, Status);
				__builder.AddContent(33, " - ");
				__builder.AddContent(34, FormatElapsed());
				__builder.CloseElement();
			}
			if (!string.IsNullOrEmpty(Error))
			{
				__builder.OpenElement(35, "p");
				__builder.AddAttribute(36, "class", "text-warning");
				__builder.AddContent(37, (MarkupString)Error);
				__builder.CloseElement();
			}
			__builder.CloseElement();
			__builder.OpenElement(38, "form");
			__builder.AddAttribute(39, "class", "flex flex-col gap-2");
			__builder.AddAttribute(40, "onsubmit", EventCallback.Factory.Create<EventArgs>((object)this, (Func<Task>)SendMessage));
			__builder.AddEventPreventDefaultAttribute(41, "onsubmit", value: true);
			__builder.OpenElement(42, "textarea");
			__builder.AddAttribute(43, "class", "min-h-12 flex-1 resize-y rounded-md border border-border bg-control-bg p-3 text-text placeholder:text-text-muted focus:outline-none focus:ring-2 focus:ring-accent");
			__builder.AddAttribute(44, "placeholder", T._("Ask a question..."));
			__builder.AddAttribute(45, "rows", "2");
			__builder.AddAttribute(46, "disabled", IsSending);
			__builder.AddAttribute(47, "value", BindConverter.FormatValue(Draft));
			__builder.AddAttribute(48, "oninput", EventCallback.Factory.CreateBinder(this, (string? __value) =>
			{
				Draft = __value;
			}, Draft));
			__builder.SetUpdatesAttributeName("value");
			__builder.AddElementReferenceCapture(49, (ElementReference __value) =>
			{
				inputElement = __value;
			});
			__builder.CloseElement();
			__builder.AddMarkupContent(50, "\n            ");
			__builder.OpenElement(51, "p");
			__builder.AddAttribute(52, "class", "description hover:cursor-pointer hover:underline");
			__builder.AddAttribute(53, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
			{
				ShowStateDialog = true;
			}));
			__builder.AddContent(54, (MarkupString)T._("Send using <span class=\"text-text-l\">Enter</span>, new line with <span class=\"text-text-l\">Shift+Enter</span>. Some basic information is sent along with each message, <span class=\"text-text-l\">click to display</span>."));
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.OpenComponent<Dialog>(55);
			__builder.AddComponentParameter(56, "Open", RuntimeHelpers.TypeCheck(ShowStateDialog));
			__builder.AddComponentParameter(57, "OpenChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
			{
				ShowStateDialog = value;
			})));
			__builder.AddComponentParameter(58, "Class", "w-full max-w-2xl");
			__builder.AddAttribute(59, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder) =>
			{
				renderTreeBuilder.OpenElement(60, "div");
				renderTreeBuilder.AddAttribute(61, "class", "flex flex-col gap-3");
				renderTreeBuilder.OpenElement(62, "p");
				renderTreeBuilder.AddAttribute(63, "class", "description");
				renderTreeBuilder.AddContent(64, T._("The following information is sent along with each message to help the chatbot provide better answers. It does not contain any personal information."));
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.AddMarkupContent(65, "\n                ");
				renderTreeBuilder.OpenElement(66, "pre");
				renderTreeBuilder.AddAttribute(67, "class", "max-h-[50vh] overflow-y-auto rounded-md border border-border bg-bg-dark p-3 text-sm");
				renderTreeBuilder.OpenElement(68, "code");
				renderTreeBuilder.AddContent(69, JsonSerializer.Serialize(GetStateInfo(), new JsonSerializerOptions
				{
					WriteIndented = true
				}));
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.AddMarkupContent(70, "\n                ");
				renderTreeBuilder.OpenElement(71, "p");
				renderTreeBuilder.AddAttribute(72, "class", "description mt-2");
				renderTreeBuilder.AddContent(73, T._("Press anywhere outside the dialog to close it."));
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.CloseElement();
			}));
			__builder.CloseComponent();
			__builder.OpenComponent<Dialog>(74);
			__builder.AddComponentParameter(75, "Open", RuntimeHelpers.TypeCheck(ShowLogDialog));
			__builder.AddComponentParameter(76, "OpenChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
			{
				ShowLogDialog = value;
			})));
			__builder.AddComponentParameter(77, "Class", "w-full max-w-2xl");
			__builder.AddAttribute(78, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder) =>
			{
				renderTreeBuilder.OpenElement(79, "div");
				renderTreeBuilder.AddAttribute(80, "class", "flex flex-col gap-3");
				renderTreeBuilder.OpenElement(81, "p");
				renderTreeBuilder.AddAttribute(82, "class", "description");
				renderTreeBuilder.AddContent(83, T._("User folder paths are hidden automatically. Review the log for other personal information before sending."));
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.AddMarkupContent(84, "\n                ");
				renderTreeBuilder.OpenElement(85, "textarea");
				renderTreeBuilder.AddAttribute(86, "class", "max-h-[50vh] w-full resize-y rounded-md border border-border bg-bg-dark p-3 font-mono text-sm text-text focus:outline-none focus:ring-2 focus:ring-accent");
				renderTreeBuilder.AddAttribute(87, "rows", "14");
				renderTreeBuilder.AddAttribute(88, "aria-label", T._("Log preview"));
				renderTreeBuilder.AddAttribute(89, "value", BindConverter.FormatValue(LogPreview));
				renderTreeBuilder.AddAttribute(90, "oninput", EventCallback.Factory.CreateBinder(this, (string? __value) =>
				{
					LogPreview = __value;
				}, LogPreview));
				renderTreeBuilder.SetUpdatesAttributeName("value");
				renderTreeBuilder.CloseElement();
				if (!string.IsNullOrEmpty(Error))
				{
					renderTreeBuilder.OpenElement(91, "p");
					renderTreeBuilder.AddAttribute(92, "class", "text-warning");
					renderTreeBuilder.AddContent(93, Error);
					renderTreeBuilder.CloseElement();
				}
				renderTreeBuilder.OpenElement(94, "div");
				renderTreeBuilder.AddAttribute(95, "class", "mt-2 flex flex-wrap items-center justify-between gap-3");
				renderTreeBuilder.OpenElement(96, "p");
				renderTreeBuilder.AddAttribute(97, "class", "description");
				renderTreeBuilder.AddContent(98, T._("Press anywhere outside the dialog to close it."));
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.AddMarkupContent(99, "\n                    ");
				renderTreeBuilder.OpenElement(100, "button");
				renderTreeBuilder.AddAttribute(101, "type", "button");
				renderTreeBuilder.AddAttribute(102, "class", "button button-accent ml-auto");
				renderTreeBuilder.AddAttribute(103, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Func<Task>)SendLog));
				renderTreeBuilder.AddAttribute(104, "disabled", IsSending || string.IsNullOrWhiteSpace(LogPreview));
				renderTreeBuilder.AddContent(105, T._("Send log"));
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.CloseElement();
			}));
			__builder.CloseComponent();
			__builder.AddMarkupContent(106, "\n        ");
			__builder.OpenComponent<Dialog>(107);
			__builder.AddComponentParameter(108, "Open", RuntimeHelpers.TypeCheck(ViewedLog != null));
			__builder.AddComponentParameter(109, "OpenChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool _) =>
			{
				ViewedLog = null;
			})));
			__builder.AddComponentParameter(110, "Class", "w-full max-w-2xl");
			__builder.AddAttribute(111, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder) =>
			{
				renderTreeBuilder.OpenElement(112, "div");
				renderTreeBuilder.AddAttribute(113, "class", "flex flex-col gap-3");
				renderTreeBuilder.OpenElement(114, "pre");
				renderTreeBuilder.AddAttribute(115, "class", "max-h-[50vh] overflow-auto whitespace-pre-wrap rounded-md border border-border bg-bg-dark p-3 text-sm");
				renderTreeBuilder.OpenElement(116, "code");
				renderTreeBuilder.AddContent(117, ViewedLog);
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.AddMarkupContent(118, "\n                ");
				renderTreeBuilder.OpenElement(119, "p");
				renderTreeBuilder.AddAttribute(120, "class", "description mt-2");
				renderTreeBuilder.AddContent(121, T._("Press anywhere outside the dialog to close it."));
				renderTreeBuilder.CloseElement();
				renderTreeBuilder.CloseElement();
			}));
			__builder.CloseComponent();
		}
		__builder.CloseElement();
	}

	protected override async Task OnAfterRenderAsync(bool firstRender)
	{
		if (firstRender && CurrentUser != null && !string.IsNullOrEmpty(CurrentUser.JwtToken) && !(DateTime.UtcNow >= CurrentUser.Expiry))
		{
			selfReference = DotNetObjectReference.Create(this);
			await JS.InvokeVoidAsync("chatInput.attach", inputElement, selfReference);
		}
	}

	public void Dispose()
	{
		selfReference?.Dispose();
	}

	[JSInvokable]
	public async Task OnEnterPressed()
	{
		await SendMessage();
		await InvokeAsync((Action)StateHasChanged);
	}

	private object GetStateInfo()
	{
		return new
		{
			version = currentVersion,
			language = StateSettingsHandler.Current.GetSettings().DisplayLanguage.EnglishName,
			enabled_plugins = (from p in PluginBackend.Current.PluginHandler.LoadedPlugins
				where p._IsRunning
				select new
				{
					id = p.Info.Id,
					name = p.Info.Name,
					version = p.Info.Version
				}).ToArray(),
			installed_plugins = PluginBackend.Current.PluginHandler.LoadedPlugins.Select((IPlugin p) => new
			{
				id = p.Info.Id,
				name = p.Info.Name,
				version = p.Info.Version
			}).ToArray(),
			installed_libraries = PluginBackend.Current.PluginHandler.LoadedLibraryPlugins.Select((ILibraryPlugin l) => new
			{
				id = l.Info.Id,
				name = l.Info.Name,
				version = l.Info.Version
			}).ToArray(),
			sdk_info = GameHandler.Current.Installations.Select((Installation g) => new
			{
				game = g.Type.ToString(),
				installed = g.IsSDKInstalled(g.Version),
				version = g.Version
			}).ToArray(),
			comment_from_client = "This ETS2LA client cannot send images, videos or other media. The user can only answer in text."
		};
	}

	private Task SendMessage()
	{
		return SendRequest(Draft.Trim());
	}

	private async Task SendRequest(string message, string diagnostics = "")
	{
		if (string.IsNullOrEmpty(message) || IsSending)
		{
			return;
		}
		if (CurrentUser == null || string.IsNullOrEmpty(CurrentUser.JwtToken) || DateTime.UtcNow >= CurrentUser.Expiry)
		{
			Error = T._("Please log in before using the chatbot.");
			return;
		}
		if (diagnostics.Length == 0)
		{
			Draft = string.Empty;
		}
		Error = string.Empty;
		Status = T._("Thinking...");
		IsSending = true;
		Messages.Add(new ChatMessage("user", message)
		{
			Log = diagnostics
		});
		ChatMessage assistant = new ChatMessage("assistant", string.Empty);
		Messages.Add(assistant);
		requestCancellation = new CancellationTokenSource(TimeSpan.FromSeconds(630L));
		thinkingTimer = Stopwatch.StartNew();
		try
		{
			using HttpClient client = new HttpClient
			{
				Timeout = Timeout.InfiniteTimeSpan
			};
			using HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "https://mandarinbot-api.lun011666.com/ask");
			request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", CurrentUser.JwtToken);
			request.Content = JsonContent.Create(new
			{
				message = message,
				diagnostics = diagnostics,
				history = (from item in Messages.Take(Messages.Count - 2)
					select new
					{
						role = item.Role,
						text = item.Text
					}).ToArray(),
				state = GetStateInfo(),
				stream = true
			});
			using HttpResponseMessage response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, requestCancellation.Token);
			if (response.StatusCode == HttpStatusCode.Unauthorized)
			{
				throw new InvalidOperationException(T._("Your login token is invalid or expired."));
			}
			if (response.StatusCode == HttpStatusCode.Forbidden)
			{
				throw new InvalidOperationException(await DescribeForbidden(response, requestCancellation.Token));
			}
			response.EnsureSuccessStatusCode();
			await ReadEvents(response, assistant, requestCancellation.Token);
			Status = string.Empty;
		}
		catch (OperationCanceledException) when (requestCancellation?.IsCancellationRequested ?? false)
		{
			Status = T._("Request cancelled.");
		}
		catch (Exception ex2)
		{
			Error = ex2.Message;
			Messages.Remove(assistant);
		}
		finally
		{
			requestCancellation?.Dispose();
			requestCancellation = null;
			IsSending = false;
		}
	}

	private async Task ReadEvents(HttpResponseMessage response, ChatMessage assistant, CancellationToken cancellationToken)
	{
		await using Stream stream = await response.Content.ReadAsStreamAsync(cancellationToken);
		using StreamReader reader = new StreamReader(stream);
		string eventName = string.Empty;
		StringBuilder data = new StringBuilder();
		while (true)
		{
			string text = await reader.ReadLineAsync(cancellationToken);
			if (text == null)
			{
				break;
			}
			if (text.StartsWith("event:", StringComparison.OrdinalIgnoreCase))
			{
				eventName = text.Substring(6).Trim();
			}
			else if (text.StartsWith("data:", StringComparison.OrdinalIgnoreCase))
			{
				if (data.Length > 0)
				{
					data.Append('\n');
				}
				data.Append(text.Substring(5).TrimStart());
			}
			else if (text.Length == 0)
			{
				ProcessEvent(eventName, data.ToString(), assistant);
				eventName = string.Empty;
				data.Clear();
				await InvokeAsync((Action)StateHasChanged);
			}
		}
		ProcessEvent(eventName, data.ToString(), assistant);
	}

	private void ProcessEvent(string eventName, string data, ChatMessage assistant)
	{
		if (string.IsNullOrWhiteSpace(data))
		{
			return;
		}
		try
		{
			using JsonDocument jsonDocument = JsonDocument.Parse(data);
			JsonElement rootElement = jsonDocument.RootElement;
			string a = (rootElement.TryGetProperty("type", out var value) ? value.GetString() : eventName);
			string text = GetString(rootElement, "text") ?? GetString(rootElement, "message") ?? GetString(rootElement, "content") ?? GetString(rootElement, "answer") ?? string.Empty;
			if (string.Equals(a, "status", StringComparison.OrdinalIgnoreCase))
			{
				Status = DescribeStatus(rootElement);
			}
			else if (string.Equals(a, "done", StringComparison.OrdinalIgnoreCase))
			{
				assistant.Text = text;
				assistant.RequestLog = rootElement.TryGetProperty("request_log", out var value2) && value2.ValueKind == JsonValueKind.True;
				Status = string.Empty;
			}
			else if (string.Equals(a, "out_of_scope", StringComparison.OrdinalIgnoreCase))
			{
				assistant.Text += T._("I'm sorry, but I cannot answer that question. Please ask something else ETS2LA related.");
			}
			else if (!string.IsNullOrEmpty(text))
			{
				assistant.Text += text;
			}
		}
		catch (JsonException)
		{
			assistant.Text += data;
		}
	}

	private static async Task<string> DescribeForbidden(HttpResponseMessage response, CancellationToken cancellationToken)
	{
		string fallback = T._("Your account is not allowed to use the chatbot.");
		try
		{
			string text = await response.Content.ReadAsStringAsync(cancellationToken);
			if (string.IsNullOrWhiteSpace(text))
			{
				return fallback;
			}
			using JsonDocument jsonDocument = JsonDocument.Parse(text);
			JsonElement root = jsonDocument.RootElement;
			if (root.TryGetProperty("error", out var value) && value.ValueKind == JsonValueKind.Object)
			{
				root = value;
			}
			string text2 = GetString(root, "reason");
			string text3 = (string.IsNullOrWhiteSpace(text2) ? fallback : text2);
			if (root.TryGetProperty("blocked_until", out var value2))
			{
				if (value2.ValueKind == JsonValueKind.Null)
				{
					return T._("You are permanently banned.<br/>Reason: {0}", text3);
				}
				if (value2.ValueKind == JsonValueKind.Number && value2.TryGetDouble(out var value3))
				{
					DateTimeOffset dateTimeOffset = DateTimeOffset.FromUnixTimeSeconds((int)value3).ToLocalTime();
					return T._("You are blocked until {1}.<br/>Reason: {0}", text3, dateTimeOffset.ToString("f"));
				}
			}
			return text3;
		}
		catch (Exception)
		{
			return fallback;
		}
	}

	private static string DescribeStatus(JsonElement root)
	{
		string text = GetString(root, "phase") ?? "progress";
		string text2 = GetString(root, "tool");
		string text3 = GetString(root, "model");
		string text4 = GetString(root, "language");
		string text5 = ((text2 != null) ? ("Using tool: " + text2) : text);
		if (text3 != null)
		{
			text5 = text5 + " (" + text3 + ")";
		}
		if (text4 != null)
		{
			text5 = text5 + " [" + text4 + "]";
		}
		if (text5.Count() <= 0)
		{
			return T._("Thinking...");
		}
		return char.ToUpper(text5[0]) + text5.Substring(1);
	}

	private string FormatElapsed()
	{
		if (thinkingTimer != null)
		{
			return $"{thinkingTimer.Elapsed.TotalSeconds:0}s";
		}
		return "0s";
	}

	private static string? GetString(JsonElement root, string propertyName)
	{
		if (!root.TryGetProperty(propertyName, out var value) || value.ValueKind != JsonValueKind.String)
		{
			return null;
		}
		return value.GetString();
	}

	private void CancelRequest()
	{
		requestCancellation?.Cancel();
	}

	private async Task OpenLogDialog()
	{
		if (IsSending || IsReadingLog)
		{
			return;
		}
		Error = string.Empty;
		IsReadingLog = true;
		try
		{
			LogPreview = await Task.Run(() => RedactLog(LogFileWriter.Current.ReadRecent()));
			ShowLogDialog = true;
		}
		catch (IOException)
		{
			Error = T._("Unable to read the current log.");
		}
		catch (UnauthorizedAccessException)
		{
			Error = T._("Unable to read the current log.");
		}
		finally
		{
			IsReadingLog = false;
		}
	}

	private async Task SendLog()
	{
		if (!IsSending && !string.IsNullOrWhiteSpace(LogPreview))
		{
			ShowLogDialog = false;
			await SendRequest(T._("Log sent. Click here to view it."), LogPreview);
		}
	}

	private static string RedactLog(string text)
	{
		string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
		if (!string.IsNullOrEmpty(folderPath))
		{
			text = text.Replace(folderPath, "~", OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal);
		}
		text = Regex.Replace(text, "(?i)([A-Z]:[\\\\/]+Users[\\\\/]+)[^\\\\/\\r\\n\"']+", "$1<user>", RegexOptions.CultureInvariant | RegexOptions.NonBacktracking);
		text = Regex.Replace(text, "(/home/)[^/\\s\"']+", "$1<user>", RegexOptions.CultureInvariant | RegexOptions.NonBacktracking);
		return text;
	}
}
