using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;

namespace ETS2LA.UI.Pages.Help;

[Route("/help/wiki")]
public class Wiki : ComponentBase
{
	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.AddMarkupContent(0, "<div class=\"w-full h-full overflow-hidden\"><iframe src=\"https://arcappss.com.tr/\" class=\"w-full h-full\" style=\"border: none;\"></iframe></div>");
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		WindowState.Current.IsSidebarOpen = false;
		WindowState.Current.RequestFullReload();
	}
}
