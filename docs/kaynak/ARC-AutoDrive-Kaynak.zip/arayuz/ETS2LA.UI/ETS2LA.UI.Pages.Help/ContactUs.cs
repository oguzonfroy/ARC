using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Help;

[Route("/help/contact")]
public class ContactUs : ComponentBase
{
	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col p-6 gap-3");
		__builder.AddMarkupContent(2, "<p class=\"arc-etiket\">Destek</p>\n    ");
		__builder.AddMarkupContent(3, "<h2>Bize ulaşın</h2>\n    ");
		__builder.AddMarkupContent(4, "<p class=\"description text-[13px]! max-w-lg\">Sorun, öneri ya da lisans için Discord sunucumuzdan yaz; en hızlı cevabı orada veriyoruz.</p>\n    ");
		__builder.OpenElement(5, "div");
		__builder.AddAttribute(6, "class", "flex flex-col gap-2 mt-2");
		__builder.OpenElement(7, "button");
		__builder.AddAttribute(8, "class", "button button-accent w-64!");
		__builder.AddAttribute(9, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
		{
			OpenInBrowser("https://discord.gg/n9tyDcqwbA");
		}));
		__builder.AddContent(10, "Discord'dan yaz");
		__builder.CloseElement();
		__builder.AddMarkupContent(11, "\n        ");
		__builder.OpenElement(12, "button");
		__builder.AddAttribute(13, "class", "button w-64!");
		__builder.AddAttribute(14, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
		{
			OpenInBrowser("https://arcappss.com.tr/");
		}));
		__builder.AddContent(15, "arcappss.com.tr");
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private void OpenInBrowser(string url)
	{
		UserInterfaceUtils.OpenUrl(url);
	}
}
