using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using ETS2LA.Backend;
using ETS2LA.Shared;
using ETS2LA.Translations;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Plugins;

[Route("/plugins/manager")]
public class Manager : ComponentBase
{
	private PluginHandler handler;

	private List<IPlugin> Plugins = new List<IPlugin>();

	private List<IPlugin> FilteredPlugins = new List<IPlugin>();

	private string searchQuery = "";

	private bool AllEnabled => FilteredPlugins.All((IPlugin p) => p._IsRunning);

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex h-full w-full flex-col bg-bg-dark");
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex p-1.5 h-full w-full");
		__builder.OpenElement(4, "div");
		__builder.AddAttribute(5, "class", "w-[230px] pl-2 pr-3 pt-2 flex gap-3 flex-col h-full");
		__builder.OpenElement(6, "input");
		__builder.AddAttribute(7, "type", "text");
		__builder.AddAttribute(8, "placeholder", T._("Search for plugins..."));
		__builder.AddAttribute(9, "class", "w-full p-2 rounded-md bg-control-bg text-text-muted placeholder:text-text-muted focus:outline-none focus:ring-2 focus:ring-accent");
		__builder.AddAttribute(10, "oninput", EventCallback.Factory.Create((object)this, (Action<ChangeEventArgs>)OnSearchQueryChanged));
		__builder.CloseElement();
		__builder.AddMarkupContent(11, "\n\n        ");
		__builder.OpenElement(12, "div");
		__builder.AddAttribute(13, "class", "flex flex-col gap-1");
		__builder.OpenElement(14, "div");
		__builder.AddAttribute(15, "class", "flex gap-1");
		__builder.OpenElement(16, "button");
		__builder.AddAttribute(17, "class", "button w-full!");
		__builder.AddAttribute(18, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)OpenPluginFolder));
		__builder.AddMarkupContent(19, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1em\" height=\"1em\" viewBox=\"0 0 16 16\"><path d=\"M0 0h16v16H0z\" fill=\"none\"></path>\n                        <g fill=\"currentColor\"><path d=\"M14.081 7a1 1 0 0 1 .942 1.336l-1.55 4.337A2 2 0 0 1 11.592 14H3a2 2 0 0 1-.923-.227l1.51-5.66A1.5 1.5 0 0 1 5.037 7z\"></path>\n                            <path d=\"M4.586 2a1 1 0 0 1 .707.293L7 4h4a2 2 0 0 1 2 2H5.036a2.5 2.5 0 0 0-2.415 1.855l-1.366 5.12A2 2 0 0 1 1 12V4a2 2 0 0 1 2-2z\"></path></g></svg>");
		__builder.CloseElement();
		__builder.AddMarkupContent(20, "\n                ");
		__builder.OpenElement(21, "button");
		__builder.AddAttribute(22, "class", "button w-full!");
		__builder.AddAttribute(23, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
		{
			RefreshPlugins(fullReload: true);
		}));
		__builder.AddMarkupContent(24, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1em\" height=\"1em\" viewBox=\"0 0 24 24\"><path d=\"M0 0h24v24H0z\" fill=\"none\"></path>\n                        <path fill=\"currentColor\" d=\"M18.13 17.13c-.15.18-.31.36-.48.52c-.73.74-1.59 1.31-2.54 1.71c-1.97.83-4.26.83-6.23 0c-.95-.4-1.81-.98-2.54-1.72a7.8 7.8 0 0 1-1.71-2.54c-.42-.99-.63-2.03-.63-3.11H2c0 1.35.26 2.66.79 3.89c.5 1.19 1.23 2.26 2.14 3.18s1.99 1.64 3.18 2.14c1.23.52 2.54.79 3.89.79s2.66-.26 3.89-.79c1.19-.5 2.26-1.23 3.18-2.14c.17-.17.32-.35.48-.52L22 20.99v-6h-6l2.13 2.13Zm.94-12.2a9.9 9.9 0 0 0-3.18-2.14a10.12 10.12 0 0 0-7.79 0c-1.19.5-2.26 1.23-3.18 2.14c-.17.17-.32.35-.48.52L1.99 3v6h6L5.86 6.87c.15-.18.31-.36.48-.52c.73-.74 1.59-1.31 2.54-1.71c1.97-.83 4.26-.83 6.23 0c.95.4 1.81.98 2.54 1.72c.74.73 1.31 1.59 1.71 2.54c.42.99.63 2.03.63 3.11h2c0-1.35-.26-2.66-.79-3.89c-.5-1.19-1.23-2.26-2.14-3.18Z\"></path></svg>");
		__builder.CloseElement();
		__builder.CloseElement();
		if (AllEnabled)
		{
			__builder.OpenElement(25, "button");
			__builder.AddAttribute(26, "class", "button w-full! button-accent");
			__builder.AddAttribute(27, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)DisableAllPlugins));
			__builder.AddContent(28, T._("Disable All"));
			__builder.CloseElement();
		}
		else
		{
			__builder.OpenElement(29, "button");
			__builder.AddAttribute(30, "class", "button w-full!");
			__builder.AddAttribute(31, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)EnableAllPlugins));
			__builder.AddContent(32, T._("Enable All"));
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.AddMarkupContent(33, "\n\n    <div class=\"mt-2 mb-2 bg-control-bg w-0.5 rounded-md\"></div>\n\n    \n    ");
		__builder.OpenElement(34, "div");
		__builder.AddAttribute(35, "class", "w-full h-full bg-bg-dark overflow-y-auto");
		__builder.OpenElement(36, "div");
		__builder.AddAttribute(37, "class", "grid grid-cols-[repeat(auto-fill,minmax(27rem,1fr))] gap-4 py-2 px-3");
		if (FilteredPlugins.Count == 0)
		{
			__builder.OpenElement(38, "div");
			__builder.AddAttribute(39, "class", "flex flex-col h-full");
			__builder.OpenElement(40, "p");
			__builder.AddContent(41, T._("No plugins found."));
			__builder.CloseElement();
			__builder.AddMarkupContent(42, "\n                    ");
			__builder.OpenElement(43, "p");
			__builder.AddAttribute(44, "class", "text-text-accent");
			__builder.AddContent(45, T._("Did you remember to restart after installing them?"));
			__builder.CloseElement();
			__builder.CloseElement();
		}
		else
		{
			for (int num = 0; num < FilteredPlugins.Count; num++)
			{
				IPlugin plugin = FilteredPlugins[num];
				bool flag = plugin._IsRunning || plugin.Info.HideEnableDisableButton;
				string text = "/plugins/adjustments/" + plugin.Info.Id;
				bool flag2 = HasRoute(plugin, text);
				__builder.OpenElement(46, "div");
				__builder.AddAttribute(47, "class", "flex flex-col justify-between rounded-sm bg-control-bg-dark border p-4" + (flag ? " border-accent-dark" : " border-bg-darker"));
				__builder.OpenElement(48, "div");
				__builder.AddAttribute(49, "class", "flex w-full");
				__builder.OpenElement(50, "div");
				__builder.AddAttribute(51, "class", "flex flex-col gap-1 w-full");
				__builder.OpenElement(52, "div");
				__builder.AddAttribute(53, "class", "flex w-full justify-between");
				__builder.OpenElement(54, "div");
				__builder.AddAttribute(55, "class", "flex flex-col gap-0 w-full");
				__builder.OpenElement(56, "p");
				__builder.AddAttribute(57, "class", "font-semibold");
				__builder.AddContent(58, T.L(plugin.Info.Name));
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.AddMarkupContent(59, "\n                                    ");
				__builder.OpenElement(60, "div");
				__builder.AddAttribute(61, "class", "flex flex-col gap-0 items-end min-w-fit");
				if (flag)
				{
					__builder.OpenElement(62, "span");
					__builder.AddAttribute(63, "class", "text-text-accent text-[12px]");
					__builder.AddContent(64, T._("Enabled"));
					__builder.CloseElement();
				}
				else
				{
					__builder.OpenElement(65, "span");
					__builder.AddAttribute(66, "class", "text-description text-[12px]");
					__builder.AddContent(67, T._("Disabled"));
					__builder.CloseElement();
				}
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.AddMarkupContent(68, "\n                                ");
				__builder.OpenElement(69, "p");
				__builder.AddAttribute(70, "class", "description");
				__builder.AddContent(71, T.L(plugin.Info.Description));
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.AddMarkupContent(72, "\n                        ");
				__builder.OpenElement(73, "div");
				__builder.AddAttribute(74, "class", "flex justify-between items-center mt-2");
				__builder.OpenElement(75, "div");
				__builder.AddAttribute(76, "class", "flex items-center gap-2");
				string[] tags = plugin.Info.Tags;
				string[] array = tags;
				foreach (string text2 in array)
				{
					__builder.OpenElement(77, "span");
					__builder.AddAttribute(78, "class", "bg-control-bg rounded-sm text-[12px] p-1");
					__builder.AddContent(79, UserInterfaceUtils.ClassnameWithSpaces(text2.ToString()));
					__builder.CloseElement();
				}
				__builder.CloseElement();
				__builder.AddMarkupContent(80, "\n                            ");
				__builder.OpenElement(81, "div");
				__builder.AddAttribute(82, "class", "flex items-center gap-2");
				if (flag && !plugin.Info.HideEnableDisableButton)
				{
					__builder.OpenElement(83, "button");
					__builder.AddAttribute(84, "class", "button button-small button-accent w-full!");
					__builder.AddAttribute(85, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
					{
						handler.DisablePlugin(plugin);
					}));
					__builder.AddContent(86, T._("Disable"));
					__builder.CloseElement();
				}
				else if (!flag && !plugin.Info.HideEnableDisableButton)
				{
					__builder.OpenElement(87, "button");
					__builder.AddAttribute(88, "class", "button button-small w-full!");
					__builder.AddAttribute(89, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
					{
						handler.EnablePlugin(plugin);
					}));
					__builder.AddContent(90, T._("Enable"));
					__builder.CloseElement();
				}
				if (flag2)
				{
					if (plugin.Info.PluginPageButtonName != "Adjustments")
					{
						__builder.OpenElement(91, "a");
						__builder.AddAttribute(92, "class", "button button-small w-full! min-w-fit");
						__builder.AddAttribute(93, "href", text);
						__builder.AddContent(94, plugin.Info.PluginPageButtonName);
						__builder.CloseElement();
					}
					else
					{
						__builder.OpenElement(95, "a");
						__builder.AddAttribute(96, "class", "button button-small w-full! min-w-fit");
						__builder.AddAttribute(97, "href", text);
						__builder.AddContent(98, T._("Adjustments"));
						__builder.CloseElement();
					}
				}
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.CloseElement();
			}
		}
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		handler = PluginBackend.Current.PluginHandler;
		RefreshPlugins();
	}

	private void OnSearchQueryChanged(ChangeEventArgs e)
	{
		searchQuery = e.Value?.ToString() ?? string.Empty;
		FilterPlugins();
	}

	private void RefreshPlugins(bool fullReload = false)
	{
		if (handler == null)
		{
			handler = PluginBackend.Current.PluginHandler;
		}
		if (handler == null)
		{
			return;
		}
		Task.Run(() =>
		{
			if (fullReload)
			{
				Plugins = new List<IPlugin>();
				FilteredPlugins = new List<IPlugin>();
				InvokeAsync((Action)StateHasChanged);
				handler.UnloadPlugins();
				handler.LoadPlugins();
			}
			Plugins = handler.LoadedPlugins;
			FilterPlugins();
			InvokeAsync((Action)StateHasChanged);
		});
	}

	private void OpenPluginFolder()
	{
		if (handler == null)
		{
			handler = PluginBackend.Current.PluginHandler;
		}
		if (handler != null)
		{
			string text = handler.PluginRootPath;
			if (text == "")
			{
				text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ETS2LA", "current", "Plugins");
			}
			if (Directory.Exists(text))
			{
				Process.Start("explorer.exe", text);
			}
		}
	}

	private void FilterPlugins()
	{
		if (string.IsNullOrWhiteSpace(searchQuery))
		{
			FilteredPlugins = Plugins;
			return;
		}
		FilteredPlugins = Plugins.Where((IPlugin p) => p.Info.Name.Contains(searchQuery, StringComparison.OrdinalIgnoreCase) || p.Info.Description.Contains(searchQuery, StringComparison.OrdinalIgnoreCase) || p.Info.AuthorName.Contains(searchQuery, StringComparison.OrdinalIgnoreCase) || p.Info.Tags.Any((string tag) => tag.ToString().Contains(searchQuery, StringComparison.OrdinalIgnoreCase))).ToList();
	}

	private void EnableAllPlugins()
	{
		Task.Run(() =>
		{
			foreach (IPlugin filteredPlugin in FilteredPlugins)
			{
				if (!filteredPlugin._IsRunning)
				{
					handler.EnablePlugin(filteredPlugin);
				}
			}
			InvokeAsync((Action)StateHasChanged);
		});
	}

	private void DisableAllPlugins()
	{
		Task.Run(() =>
		{
			foreach (IPlugin filteredPlugin in FilteredPlugins)
			{
				if (filteredPlugin._IsRunning)
				{
					handler.DisablePlugin(filteredPlugin);
				}
			}
			InvokeAsync((Action)StateHasChanged);
		});
	}

	public bool HasRoute(IPlugin plugin, string route)
	{
		string expectedRoute = (route.StartsWith("/") ? route : ("/" + route));
		foreach (Assembly pluginAssembly in handler.PluginAssemblies)
		{
			try
			{
				if ((from t in pluginAssembly.GetTypes()
					where typeof(IComponent).IsAssignableFrom(t)
					select t).SelectMany((Type t) => t.GetCustomAttributes<RouteAttribute>()).Any((RouteAttribute attr) => string.Equals(attr.Template, expectedRoute, StringComparison.OrdinalIgnoreCase)))
				{
					return true;
				}
			}
			catch (ReflectionTypeLoadException)
			{
			}
		}
		return false;
	}
}
