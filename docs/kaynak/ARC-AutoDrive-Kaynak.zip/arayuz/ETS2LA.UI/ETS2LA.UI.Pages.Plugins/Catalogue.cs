using System;
using System.Collections.Generic;
using System.Linq;
using ETS2LA.Backend.Plugins;
using ETS2LA.Networking;
using ETS2LA.Networking.Plugins;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.AspNetCore.Components.Web;

namespace ETS2LA.UI.Pages.Plugins;

[Route("/plugins/catalogue")]
public class Catalogue : ComponentBase
{
	private List<NetworkPlugin> plugins = new List<NetworkPlugin>();

	private List<NetworkPlugin> filteredPlugins = new List<NetworkPlugin>();

	private string searchQuery = string.Empty;

	private bool hideInstalled;

	private Dictionary<NetworkPlugin, string> selectedVersions = new Dictionary<NetworkPlugin, string>();

	private bool needsRestart;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex h-full w-full flex-col bg-bg-dark");
		__builder.OpenElement(2, "div");
		__builder.AddAttribute(3, "class", "flex p-1.5 h-full w-full");
		__builder.OpenElement(4, "div");
		__builder.AddAttribute(5, "class", "w-[230px] pl-2 pr-3 pt-2 flex gap-6.5 flex-col h-full");
		__builder.OpenElement(6, "div");
		__builder.AddAttribute(7, "class", "flex flex-col gap-3");
		__builder.OpenElement(8, "input");
		__builder.AddAttribute(9, "type", "text");
		__builder.AddAttribute(10, "placeholder", T._("Search for plugins..."));
		__builder.AddAttribute(11, "class", "w-full p-2 rounded-md bg-control-bg text-text-muted placeholder:text-text-muted focus:outline-none focus:ring-2 focus:ring-accent");
		__builder.AddAttribute(12, "oninput", EventCallback.Factory.Create((object)this, (Action<ChangeEventArgs>)OnSearchQueryChanged));
		__builder.CloseElement();
		__builder.AddMarkupContent(13, "\n\n            ");
		__builder.OpenElement(14, "div");
		__builder.AddAttribute(15, "class", "flex flex-col gap-3");
		__builder.OpenElement(16, "button");
		__builder.AddAttribute(17, "class", "button w-full!");
		__builder.AddAttribute(18, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
		{
			RefreshPlugins();
		}));
		__builder.AddMarkupContent(19, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1em\" height=\"1em\" viewBox=\"0 0 24 24\"><path d=\"M0 0h24v24H0z\" fill=\"none\"></path>\n                        <path fill=\"currentColor\" d=\"M18.13 17.13c-.15.18-.31.36-.48.52c-.73.74-1.59 1.31-2.54 1.71c-1.97.83-4.26.83-6.23 0c-.95-.4-1.81-.98-2.54-1.72a7.8 7.8 0 0 1-1.71-2.54c-.42-.99-.63-2.03-.63-3.11H2c0 1.35.26 2.66.79 3.89c.5 1.19 1.23 2.26 2.14 3.18s1.99 1.64 3.18 2.14c1.23.52 2.54.79 3.89.79s2.66-.26 3.89-.79c1.19-.5 2.26-1.23 3.18-2.14c.17-.17.32-.35.48-.52L22 20.99v-6h-6l2.13 2.13Zm.94-12.2a9.9 9.9 0 0 0-3.18-2.14a10.12 10.12 0 0 0-7.79 0c-1.19.5-2.26 1.23-3.18 2.14c-.17.17-.32.35-.48.52L1.99 3v6h6L5.86 6.87c.15-.18.31-.36.48-.52c.73-.74 1.59-1.31 2.54-1.71c1.97-.83 4.26-.83 6.23 0c.95.4 1.81.98 2.54 1.72c.74.73 1.31 1.59 1.71 2.54c.42.99.63 2.03.63 3.11h2c0-1.35-.26-2.66-.79-3.89c-.5-1.19-1.23-2.26-2.14-3.18Z\"></path></svg>");
		__builder.CloseElement();
		__builder.AddMarkupContent(20, "\n\n                ");
		__builder.OpenElement(21, "div");
		__builder.AddAttribute(22, "class", "flex items-center gap-2");
		__builder.OpenElement(23, "input");
		__builder.AddAttribute(24, "type", "checkbox");
		__builder.AddAttribute(25, "class", "checkbox");
		__builder.AddAttribute(26, "id", "hide-installed");
		__builder.AddAttribute(27, "value", hideInstalled.ToString());
		__builder.AddAttribute(28, "oninput", EventCallback.Factory.Create((object)this, (Action<ChangeEventArgs>)OnHideInstalledChanged));
		__builder.CloseElement();
		__builder.AddMarkupContent(29, "\n                    ");
		__builder.OpenElement(30, "label");
		__builder.AddAttribute(31, "for", "hide-installed");
		__builder.AddAttribute(32, "class", hideInstalled ? "text-[12px] transition-all duration-150" : "description transition-all duration-150");
		__builder.AddContent(33, T._("Hide Installed"));
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
		if (needsRestart)
		{
			__builder.OpenElement(34, "div");
			__builder.AddAttribute(35, "class", "flex flex-col gap-2");
			__builder.OpenElement(36, "p");
			__builder.AddAttribute(37, "class", "text-text-accent text-[12px]");
			__builder.AddContent(38, T._("Changes will take effect after restarting the application."));
			__builder.CloseElement();
			__builder.AddMarkupContent(39, "\n                ");
			__builder.OpenElement(40, "button");
			__builder.AddAttribute(41, "class", "button button-small button-accent w-full!");
			__builder.AddAttribute(42, "onclick", EventCallback.Factory.Create<MouseEventArgs>((object)this, (Action)Restart));
			__builder.AddContent(43, T._("Restart Now"));
			__builder.CloseElement();
			__builder.CloseElement();
		}
		__builder.CloseElement();
		__builder.AddMarkupContent(44, "\n\n    <div class=\"mt-2 mb-2 bg-control-bg w-0.5 rounded-md\"></div>\n\n    \n    ");
		__builder.OpenElement(45, "div");
		__builder.AddAttribute(46, "class", "w-full h-full bg-bg-dark overflow-y-auto");
		__builder.OpenElement(47, "div");
		__builder.AddAttribute(48, "class", "grid grid-cols-[repeat(auto-fill,minmax(27rem,1fr))] gap-4 py-2 px-3");
		if (filteredPlugins.Count == 0)
		{
			__builder.OpenElement(49, "div");
			__builder.AddAttribute(50, "class", "flex flex-col h-full");
			__builder.OpenElement(51, "p");
			__builder.AddAttribute(52, "class", "text-text-muted");
			__builder.AddContent(53, T._("No plugins found."));
			__builder.CloseElement();
			__builder.CloseElement();
		}
		else
		{
			for (int num = 0; num < filteredPlugins.Count; num++)
			{
				NetworkPlugin plugin = filteredPlugins[num];
				string installedVersion = GetInstalledVersion(plugin);
				NetworkPluginVersion pluginUpdate = NetworkingClient.Current.Plugins.GetPluginUpdate(plugin.Id);
				__builder.OpenElement(54, "div");
				__builder.AddAttribute(55, "class", "flex flex-col justify-between rounded-sm bg-control-bg-dark border p-4" + (string.IsNullOrEmpty(installedVersion) ? " border-bg-darker" : " border-accent-dark"));
				__builder.OpenElement(56, "div");
				__builder.AddAttribute(57, "class", "flex w-full");
				__builder.OpenElement(58, "div");
				__builder.AddAttribute(59, "class", "flex flex-col gap-1 w-full");
				__builder.OpenElement(60, "div");
				__builder.AddAttribute(61, "class", "flex w-full justify-between");
				__builder.OpenElement(62, "div");
				__builder.AddAttribute(63, "class", "flex flex-col gap-0");
				__builder.OpenElement(64, "p");
				__builder.AddAttribute(65, "class", "font-semibold");
				__builder.AddContent(66, T.L(plugin.Name));
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.AddMarkupContent(67, "\n                                    ");
				__builder.OpenElement(68, "div");
				__builder.AddAttribute(69, "class", "flex flex-col gap-0 items-end min-w-fit");
				if (pluginUpdate != null)
				{
					__builder.OpenElement(70, "span");
					__builder.AddAttribute(71, "class", "text-text-accent text-[12px]");
					__builder.AddContent(72, T._("Update to {0} from {1}", pluginUpdate.Version, installedVersion));
					__builder.CloseElement();
					__builder.AddMarkupContent(73, "\n                                            ");
					__builder.OpenComponent<Tooltip>(74);
					__builder.AddComponentParameter(75, "Content", RuntimeHelpers.TypeCheck(pluginUpdate.Changelog));
					__builder.AddComponentParameter(76, "Origin", "auto");
					__builder.AddAttribute(77, "ChildContent", (RenderFragment)((RenderTreeBuilder renderTreeBuilder) =>
					{
						renderTreeBuilder.OpenElement(78, "span");
						renderTreeBuilder.AddAttribute(79, "class", "text-[12px]");
						renderTreeBuilder.AddContent(80, T._("Changelog"));
						renderTreeBuilder.CloseElement();
					}));
					__builder.CloseComponent();
				}
				else if (!string.IsNullOrEmpty(installedVersion))
				{
					__builder.OpenElement(81, "span");
					__builder.AddAttribute(82, "class", "text-[12px]");
					__builder.AddContent(83, T._("Installed {0}", installedVersion));
					__builder.CloseElement();
				}
				else
				{
					__builder.OpenElement(84, "span");
					__builder.AddAttribute(85, "class", "text-description text-[12px]");
					__builder.AddContent(86, T._("Not Installed"));
					__builder.CloseElement();
				}
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.AddMarkupContent(87, "\n                                ");
				__builder.OpenElement(88, "p");
				__builder.AddAttribute(89, "class", "description");
				__builder.AddContent(90, T.L(plugin.Description));
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.AddMarkupContent(91, "\n                        ");
				__builder.OpenElement(92, "div");
				__builder.AddAttribute(93, "class", "flex justify-between items-center mt-2");
				__builder.OpenElement(94, "div");
				__builder.AddAttribute(95, "class", "flex items-center gap-2");
				foreach (NetworkPluginTags tag in plugin.Tags)
				{
					__builder.OpenElement(96, "span");
					__builder.AddAttribute(97, "class", "bg-control-bg hover:bg-control transition-all duration-300 rounded-sm text-[12px] p-1");
					__builder.AddContent(98, UserInterfaceUtils.ClassnameWithSpaces(tag.ToString()));
					__builder.CloseElement();
				}
				__builder.CloseElement();
				__builder.AddMarkupContent(99, "\n                            ");
				__builder.OpenElement(100, "div");
				__builder.AddAttribute(101, "class", "flex items-center gap-2");
				__builder.OpenComponent<Dropdown>(102);
				__builder.AddComponentParameter(103, "Title", "");
				__builder.AddComponentParameter(104, "Description", "");
				__builder.AddComponentParameter(105, "Options", RuntimeHelpers.TypeCheck((IReadOnlyList<string>)VersionsForPlugin(plugin)));
				__builder.AddComponentParameter(106, "SelectedIndex", RuntimeHelpers.TypeCheck(VersionsForPlugin(plugin).IndexOf(selectedVersions[plugin])));
				__builder.AddComponentParameter(107, "OnSelect", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (int index) =>
				{
					selectedVersions[plugin] = VersionsForPlugin(plugin)[index];
				})));
				__builder.AddComponentParameter(108, "Class", "text-[12px]!");
				__builder.CloseComponent();
				if (pluginUpdate != null)
				{
					__builder.OpenElement(109, "button");
					__builder.AddAttribute(110, "class", "button button-small button-accent w-full!");
					__builder.AddAttribute(111, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
					{
						needsRestart = true;
						NetworkingClient.Current.Plugins.UpdatePlugin(plugin.Id);
					}));
					__builder.AddContent(112, T._("Update to {0}", pluginUpdate.Version));
					__builder.CloseElement();
				}
				else if (!string.IsNullOrEmpty(installedVersion))
				{
					__builder.OpenElement(113, "button");
					__builder.AddAttribute(114, "class", "button button-small w-full!");
					__builder.AddAttribute(115, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
					{
						needsRestart = true;
						NetworkingClient.Current.Plugins.UninstallPlugin(plugin.Id);
					}));
					__builder.AddContent(116, T._("Uninstall"));
					__builder.CloseElement();
				}
				else
				{
					__builder.OpenElement(117, "button");
					__builder.AddAttribute(118, "class", "button button-small w-full!");
					__builder.AddAttribute(119, "onclick", EventCallback.Factory.Create<MouseEventArgs>(this, () =>
					{
						needsRestart = true;
						NetworkingClient.Current.Plugins.InstallPlugin(plugin.Id, selectedVersions[plugin].Split(" ")[0]);
					}));
					__builder.AddContent(120, T._("Install"));
					__builder.CloseElement();
				}
				__builder.CloseElement();
				__builder.CloseElement();
				__builder.CloseElement();
			}
		}
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
		__builder.CloseElement();
	}

	private void OnSearchQueryChanged(ChangeEventArgs e)
	{
		searchQuery = e.Value?.ToString() ?? string.Empty;
		FilterPlugins();
	}

	private void OnHideInstalledChanged(ChangeEventArgs e)
	{
		hideInstalled = (bool)e.Value;
		FilterPlugins();
	}

	private void FilterPlugins()
	{
		if (!string.IsNullOrWhiteSpace(searchQuery))
		{
			filteredPlugins = plugins.Where((NetworkPlugin p) => p.Name.Contains(searchQuery, StringComparison.OrdinalIgnoreCase) || p.Description.Contains(searchQuery, StringComparison.OrdinalIgnoreCase) || p.Author.Contains(searchQuery, StringComparison.OrdinalIgnoreCase) || p.Tags.Any((NetworkPluginTags tag) => tag.ToString().Contains(searchQuery, StringComparison.OrdinalIgnoreCase))).ToList();
		}
		else
		{
			filteredPlugins = plugins;
		}
		if (hideInstalled)
		{
			filteredPlugins = filteredPlugins.Where((NetworkPlugin p) => string.IsNullOrEmpty(GetInstalledVersion(p))).ToList();
		}
		InvokeAsync((Action)StateHasChanged);
	}

	protected override void OnInitialized()
	{
		base.OnInitialized();
		plugins = NetworkingClient.Current.Plugins.AvailablePlugins;
		foreach (NetworkPlugin plugin in plugins)
		{
			if (!selectedVersions.ContainsKey(plugin))
			{
				selectedVersions[plugin] = plugin.Versions.Last().Version;
			}
		}
		FilterPlugins();
	}

	private async void RefreshPlugins()
	{
		plugins = new List<NetworkPlugin>();
		filteredPlugins = new List<NetworkPlugin>();
		await InvokeAsync((Action)StateHasChanged);
		await NetworkingClient.Current.Plugins.FetchAvailablePluginsAsync();
		plugins = NetworkingClient.Current.Plugins.AvailablePlugins;
		foreach (NetworkPlugin plugin in plugins)
		{
			if (!selectedVersions.ContainsKey(plugin))
			{
				selectedVersions[plugin] = plugin.Versions.Last().Version;
			}
		}
		FilterPlugins();
	}

	private List<string> VersionsForPlugin(NetworkPlugin plugin)
	{
		return plugin.Versions.Select((NetworkPluginVersion v) => v.Version.ToString() + " " + $"({v.AppVersion})").Reverse().ToList();
	}

	private string GetInstalledVersion(NetworkPlugin plugin)
	{
		return InstalledPluginManifest.Current.InstalledPlugins.FirstOrDefault((InstalledPlugin p) => p.Id == plugin.Id).Version?.ToString() ?? string.Empty;
	}

	private void Restart()
	{
		UserInterfaceUtils.Restart();
	}
}
