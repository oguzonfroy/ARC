using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("LaneAssist")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+ddff0611e681248b3f9abdfecd4415475f9c0bbe")]
[assembly: AssemblyProduct("LaneAssist")]
[assembly: AssemblyTitle("LaneAssist")]
[assembly: AssemblyVersion("1.0.0.0")]
