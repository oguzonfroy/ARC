using System;
using System.Numerics;
using ETS2LA.Shared;
using TruckLib;

namespace LaneAssist.Utils;

public static class LaneAssistUtils
{
	public static double DistanceTo(Vector3Double a, Vector3Double b)
	{
		double num = a.X - b.X;
		double num2 = a.Z - b.Z;
		return Math.Sqrt(num * num + num2 * num2);
	}

	public static double DistanceTo(Vector3 a, Vector3Double b)
	{
		double num = (double)a.X - b.X;
		double num2 = (double)a.Z - b.Z;
		return Math.Sqrt(num * num + num2 * num2);
	}

	public static double DistanceTo(Vector3Double a, Vector3 b)
	{
		double num = a.X - (double)b.X;
		double num2 = a.Z - (double)b.Z;
		return Math.Sqrt(num * num + num2 * num2);
	}

	public static double DistanceTo(Vector3 a, Vector3 b)
	{
		double num = a.X - b.X;
		double num2 = a.Z - b.Z;
		return Math.Sqrt(num * num + num2 * num2);
	}

	public static float GetAngleFromStraight(Vector3 truckRotation, OrientedPoint lanePoint)
	{
		Vector3 vector = lanePoint.Rotation.ToEulerDeg();
		float num = truckRotation.X * 360f;
		if (num < 0f)
		{
			num += 360f;
		}
		float num2;
		for (num2 = vector.Y - num; num2 > 100f; num2 -= 180f)
		{
		}
		for (; num2 < -100f; num2 += 180f)
		{
		}
		return num2;
	}
}
