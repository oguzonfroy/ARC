using System;

namespace LaneAssist;

/// <summary>
///  Yüksek hızda direksiyon düzeltmesini kısar. Aynı direksiyon hareketi tırın yönünü hızla orantılı, şeritteki yerini
///  hızın karesiyle orantılı değiştirir; sabit kazanç 90 km/s üstünde sağa sola salınıma yol açar.
/// </summary>
public static class SpeedSteering
{
    public const float StartSpeed = 25f;
    public const float TrailerStartSpeed = 22.2f;
    const float MinFactor = 0.3f;

    /// <summary>Yön hatası düzeltmesinin çarpanı. Dorseliyken kısma 80 km/s'den başlar.</summary>
    public static float AngleFactor(float speed, bool trailer = false)
    {
        var start = trailer ? TrailerStartSpeed : StartSpeed;
        return speed <= start ? 1f : MathF.Max(start / speed, MinFactor);
    }

    /// <summary>Şerit ortasına uzaklık düzeltmesinin çarpanı. Dorseliyken kısma 80 km/s'den başlar.</summary>
    public static float DistanceFactor(float speed, bool trailer = false)
    {
        var start = trailer ? TrailerStartSpeed : StartSpeed;
        if (speed <= start) return 1f;
        var ratio = start / speed;
        return MathF.Max(ratio * ratio, MinFactor);
    }
}
