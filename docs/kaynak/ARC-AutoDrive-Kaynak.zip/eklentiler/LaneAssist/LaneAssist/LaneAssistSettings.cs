using System;
using ETS2LA.Settings;

namespace LaneAssist;

[Serializable]
public class LaneAssistSettings
{
	[NonSerialized]
	private static readonly Lazy<LaneAssistSettings> _instance = new Lazy<LaneAssistSettings>(() => new LaneAssistSettings(loadSettings: true));

	public int SteeringPointCount = 5;

	public float RawControlSpeedThreshold = 27.222223f;

	public bool RenderPlannedPath = true;

	public bool PlayEnableDisableAudio = true;

	public bool WidenTurnsWithTrailer = true;

	public float WidenStartSpeed = 9.722222f;

	public float MaxWidenAmount = 1.5f;

	public float MaxWidenAtAngle = 30f;

	[NonSerialized]
	private SettingsHandler? _settingsHandler;

	public static LaneAssistSettings Current => _instance.Value;

	public LaneAssistSettings(bool loadSettings = false)
	{
		if (loadSettings)
		{
			_settingsHandler = new SettingsHandler();
			LaneAssistSettings laneAssistSettings = _settingsHandler.Load<LaneAssistSettings>("tumppi066.laneassist.json");
			if (laneAssistSettings != null)
			{
				SteeringPointCount = laneAssistSettings.SteeringPointCount;
				RawControlSpeedThreshold = laneAssistSettings.RawControlSpeedThreshold;
				RenderPlannedPath = laneAssistSettings.RenderPlannedPath;
				PlayEnableDisableAudio = laneAssistSettings.PlayEnableDisableAudio;
				WidenTurnsWithTrailer = laneAssistSettings.WidenTurnsWithTrailer;
				WidenStartSpeed = laneAssistSettings.WidenStartSpeed;
				MaxWidenAmount = laneAssistSettings.MaxWidenAmount;
				MaxWidenAtAngle = laneAssistSettings.MaxWidenAtAngle;
			}
		}
	}

	public LaneAssistSettings()
	{
	}

	public void Save()
	{
		_settingsHandler?.Save("tumppi066.laneassist.json", this);
	}
}
