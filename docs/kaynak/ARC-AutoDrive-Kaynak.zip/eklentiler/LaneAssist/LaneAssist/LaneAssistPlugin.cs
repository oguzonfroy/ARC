using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using ETS2LA.Audio;
using ETS2LA.Backend.Events;
using ETS2LA.Game;
using ETS2LA.Game.Data;
using ETS2LA.Game.Output;
using ETS2LA.Game.PpdFiles;
using ETS2LA.Game.SDK;
using ETS2LA.Game.SiiFiles;
using ETS2LA.Game.Telemetry;
using ETS2LA.Logging;
using ETS2LA.Overlay;
using ETS2LA.Overlay.AR;
using ETS2LA.Settings.Global;
using ETS2LA.Shared;
using ETS2LA.State;
using ETS2LA.Translations;
using Hexa.NET.ImGui;
using LaneAssist.Utils;
using PIDLib;
using PathLib;
using TruckLib;

namespace LaneAssist;

public class LaneAssistPlugin : Plugin
{
	private WindowDefinition windowDefinition = new WindowDefinition
	{
		Title = "LKAS",
		Flags = (ImGuiWindowFlags.NoDecoration | ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoBackground)
	};

	private Dictionary<SteeringSensitivityOption, float> sensitivityMultipliers = new Dictionary<SteeringSensitivityOption, float>
	{
		{
			SteeringSensitivityOption.Slow,
			1.5f
		},
		{
			SteeringSensitivityOption.Normal,
			2f
		},
		{
			SteeringSensitivityOption.Fast,
			3f
		}
	};

	private const float AT_SPEED = 4.16f;

	private const float START_AT_SPEED = 19.44f;

	private string lastFrameError = "";

	private float lastFrameSteeringOutput;

	private float lastFrameAngleOutput;

	private float lastFrameDistanceOutput;

	private float lastFrameTurnOffset;

	private bool wasActive;

	private int tickCounter;

	private int loadedInstallation = -1;

	private GameTelemetryData? telemetryData;

	private MapData? mapData;

	private PlannedPathData? lastPlannedPathData;

	private PIDController anglePid = new PIDController(1.1f, 0f, 0f);

	private PIDController distancePid = new PIDController(8f, 1f, 0f, derivateFromActual: false, 2f);

	private KalmanFilter filteredCross = new KalmanFilter(0.014f, 0.22f);

	private KalmanFilter filteredAngle = new KalmanFilter(0.015f, 0.2f);

	private float roadPrefabTaperFactor;

	private float secondaryColorTaperFactor = 1f;

	private uint primaryColor = 8960904u;

	private uint secondaryColor = 2290649156u;

	private BaseVehicle? lastLeadingVehicle;

	private ParsedSemaphore? lastTargetParsedSemaphore;

	public override PluginInformation Info
	{
		get
		{
			PluginInformation pluginInformation = new PluginInformation { Name = "", Description = "", Version = "", Id = "" };
			pluginInformation.Name = T._("Lane Assist");
			pluginInformation.Description = T._("This plugin provides simple lane assist features. You'll need it enabled to use that feature of ETS2LA.");
			pluginInformation.AuthorName = "Tumppi066";
			pluginInformation.Version = "1.6.2";
			pluginInformation.AppVersionSupport.LowerBound = "2026.11.5250";
			pluginInformation.Icon = "https://avatars.githubusercontent.com/u/162675991?s=128";
			pluginInformation.Id = "tumppi066.laneassist";
			pluginInformation.Tags = new string[2] { "Steering", "Assists" };
			pluginInformation.DependsOn.Add(new PluginDependency
			{
				Id = "tumppi066.pathfinding"
			});
			pluginInformation.DependsOn.Add(new PluginDependency
			{
				Id = "tumppi066.pathlib"
			});
			pluginInformation.DependsOn.Add(new PluginDependency
			{
				Id = "tumppi066.pidlib"
			});
			return pluginInformation;
		}
	}

	public override float TickRate => 30f;

	public override void Init()
	{
		base.Init();
	}

	public override void OnEnable()
	{
		base.OnEnable();
		OverlayHandler.Current.RegisterWindow(windowDefinition, RenderWindow);
		ArKaydiniDene();
		GameTelemetry.Current.ReadTrailerData = true;
		Events.Current.Subscribe(GameTelemetry.Current.EventString, (GameTelemetryData data) =>
		{
			telemetryData = data;
		});
		Events.Current.Subscribe<PlannedPathData>("Pathfinding.PlannedPathData", UpdatePlannedPath);
		Events.Current.Subscribe("AdaptiveCruiseControl.LeadingVehicle", (BaseVehicle? vehicle) =>
		{
			lastLeadingVehicle = vehicle;
		});
		Events.Current.Subscribe("AdaptiveCruiseControl.TargetParsedSemaphore", (ParsedSemaphore? semaphore) =>
		{
			lastTargetParsedSemaphore = semaphore;
		});
		Events.Current.Subscribe("ARC.Pathfinding.RecoveryTolerance", (float tolerance) =>
		{
			arcKurtarmaToleransi = tolerance;
			Volatile.Write(ref arcKurtarmaZamani, Environment.TickCount64);
		});
		Task.Run((Action)MapUpdateThread);
	}

	private double arcKurtarmaToleransi;

	private long arcKurtarmaZamani;

	// ARC: çizim katmanı ilk karede oluşur. Eklenti ondan önce açılırsa eskiden hata verip yol çizgileri
	// program yeniden açılana kadar gelmiyordu; kayıt hazır olunca yapılır, kaybolursa yenilenir.
	private ARRenderer? arcKayitliAr;

	private long arcSonCizim;

	private long arcSonKayit;

	private void ArKaydiniDene()
	{
		ARRenderer? ar = OverlayHandler.Current.AR;
		if (ar == null)
		{
			return;
		}
		long simdi = Environment.TickCount64;
		GameTelemetryData tele = telemetryData;
		bool kayip = arcKayitliAr == ar && simdi - Volatile.Read(ref arcSonCizim) > 5000 && simdi - arcSonKayit > 5000
			&& tele != null && !tele.paused && OverlaySettingsHandler.Current.GetSettings().RenderAR;
		if (arcKayitliAr == ar && !kayip)
		{
			return;
		}
		ar.UnregisterRenderCallback("LKASRenderer");
		ar.RegisterRenderCallback(new ARRenderCallback
		{
			Definition = new ARRendererDefinition
			{
				Name = "LKASRenderer"
			},
			Render3D = RenderAR
		});
		arcKayitliAr = ar;
		arcSonKayit = simdi;
	}

	private void UpdatePlannedPath(PlannedPathData data)
	{
		lastPlannedPathData = data;
		arcSonYolZamani = DateTime.UtcNow;
	}

	// ARC: mavi yol çizgisi yalnızca güncel ve tırın gerçekten üzerinde olduğu rotayı gösterir.
	private int arcAsimKare;

	private DateTime arcSonYolZamani = DateTime.MinValue;

	private Vector3 arcSonTirKonumu;

	private Vector3 arcTirYonu;

	private int arcGecerliKare;

	private bool ArcYolGosterilebilir()
	{
		PlannedPathData yol = lastPlannedPathData;
		GameTelemetryData tele = telemetryData;
		if (yol == null || yol.HasError || tele == null || yol.PlannedPath == null || yol.PlannedPath.Count == 0)
		{
			return false;
		}
		// Pathfinding saniyede 30 kez yeni rota yollar; 0,75 sn gelmediyse eski rota çizilmez.
		if ((DateTime.UtcNow - arcSonYolZamani).TotalSeconds > 0.75)
		{
			return false;
		}
		Vector3 tir = tele.truckPlacement.coordinate.ToVector3();
		Vector3 hareket = tir - arcSonTirKonumu;
		hareket.Y = 0f;
		if (hareket.Length() > 0.3f)
		{
			if (hareket.Length() < 25f)
			{
				arcTirYonu = Vector3.Normalize(hareket);
			}
			arcSonTirKonumu = tir;
		}
		float uzunluk = yol.TotalLength;
		if (!(uzunluk > 0f))
		{
			return false;
		}
		float mesafe = yol.GetFactorForPoint(tir) * uzunluk;
		OrientedPoint? yakin = yol.InterpolateDist(mesafe, 0f, true);
		if (!yakin.HasValue)
		{
			return false;
		}
		Vector3 fark = yakin.Value.Position - tir;
		fark.Y = 0f;
		// Tır rotadan 6 m'den fazla uzaktaysa rota artık tırın yolu değildir.
		if (fark.Length() > 6f)
		{
			return false;
		}
		if (tele.truckFloat.speed > 2f && arcTirYonu != Vector3.Zero)
		{
			OrientedPoint? ileri = yol.InterpolateDist(mesafe + 5f, 0f, false);
			if (ileri.HasValue)
			{
				Vector3 yolYonu = ileri.Value.Position - yakin.Value.Position;
				yolYonu.Y = 0f;
				// Rota tırın gittiği yönden 70 dereceden fazla sapıyorsa (yanlış yol / ters yön) çizme.
				if (yolYonu.Length() > 0.5f && Vector3.Dot(Vector3.Normalize(yolYonu), arcTirYonu) < 0.34f)
				{
					return false;
				}
			}
		}
		return true;
	}

	public void MapUpdateThread()
	{
		while (_IsRunning)
		{
			Thread.Sleep(5000);
			int num = 0;
			bool flag = false;
			foreach (Installation installation in GameHandler.Current.Installations)
			{
				if (installation.IsParsed)
				{
					flag = true;
					break;
				}
				num++;
			}
			if (flag && num != loadedInstallation)
			{
				mapData = GameHandler.Current.Installations[num].GetMapData();
				IFileSystem fileSystem = GameHandler.Current.Installations[num].GetFileSystem();
				if (fileSystem != null)
				{
					SiiFileHandler.Current.SetFileSystem(fileSystem);
				}
				if (fileSystem != null)
				{
					PpdFileHandler.Current.SetFileSystem(fileSystem);
				}
				if (mapData != null)
				{
					loadedInstallation = num;
				}
			}
		}
	}

	private void ResetPIDs()
	{
		filteredCross.Reset();
		filteredAngle.Reset();
		anglePid.Reset();
		distancePid.Reset();
	}

	private void CheckPlaySound(bool isActive, bool dontPause = false)
	{
		if ((!wasActive & isActive) && tickCounter > 5)
		{
			GameTelemetryData? gameTelemetryData = telemetryData;
			if (gameTelemetryData != null && !gameTelemetryData.paused && !dontPause)
			{
				AudioHandler.Current.Play(DefaultAudio.PreAlert);
			}
		}
		else if (wasActive && !isActive && tickCounter > 5)
		{
			ResetPIDs();
			GameTelemetryData? gameTelemetryData2 = telemetryData;
			if (gameTelemetryData2 != null && !gameTelemetryData2.paused && !dontPause)
			{
				AudioHandler.Current.Play(DefaultAudio.SoftWarning);
				if (AssistanceSettings.Current.PauseWhenUnstable && ApplicationState.Current.EnableAssists)
				{
					ControlEvent data = new ControlEvent
					{
						ChannelDefinition = new ControlChannelDefinition
						{
							Id = "LaneAssist.PauseWhenUnstable",
							Timeout = 0.1f
						},
						Properties = new ControlProperties
						{
							BooleanType = ControlBooleanType.TrueToToggle
						},
						Variables = new ControlVariables
						{
							pause = true
						}
					};
					Events.Current.Publish(GameOutput.Current.EventString, data);
				}
			}
		}
		if (tickCounter <= 5 && wasActive != isActive)
		{
			tickCounter++;
			return;
		}
		wasActive = isActive;
		tickCounter = 0;
	}

	public override void Tick()
	{
		ArKaydiniDene();
		if (ApplicationState.Current.DrivingMode < DrivingMode.FullSelfDriving)
		{
			ResetPIDs();
			lastFrameError = T._("Driving mode does not include lane keeping.");
			CheckPlaySound(isActive: false, dontPause: true);
			return;
		}
		if (!ApplicationState.Current.EnableAssists)
		{
			ResetPIDs();
			lastFrameError = T._("Assists are paused in the application state.");
			CheckPlaySound(isActive: false, dontPause: true);
			return;
		}
		if (telemetryData == null)
		{
			ResetPIDs();
			lastFrameError = T._("Waiting for telemetry data...");
			CheckPlaySound(isActive: false, dontPause: true);
			return;
		}
		if (mapData == null)
		{
			ResetPIDs();
			lastFrameError = T._("Waiting for map data...");
			CheckPlaySound(isActive: false, dontPause: true);
			return;
		}
		if (lastPlannedPathData == null || lastPlannedPathData.HasError)
		{
			ResetPIDs();
			lastFrameError = T._("Waiting for path data...");
			CheckPlaySound(isActive: false, dontPause: true);
			return;
		}
		if (telemetryData.paused)
		{
			ResetPIDs();
			lastFrameError = T._("Game is paused.");
			return;
		}
		if (telemetryData.truckFloat.speed < 0.1f)
		{
			ResetPIDs();
		}
		Vector3Double coordinate = telemetryData.truckPlacement.coordinate;
		float num = 1.2f * Math.Max(1f, telemetryData.truckFloat.speed / 25f * 3.6f);
		float num2 = lastPlannedPathData.GetFactorForPoint(coordinate.ToVector3()) * lastPlannedPathData.TotalLength;
		List<OrientedPoint> list = new List<OrientedPoint>();
		for (int i = 0; i < LaneAssistSettings.Current.SteeringPointCount; i++)
		{
			OrientedPoint? orientedPoint = lastPlannedPathData.InterpolateDist(num2 + (float)i * num, 0f, i == 0);
			if (orientedPoint.HasValue)
			{
				list.Add(orientedPoint.Value);
			}
		}
		if (list.Count == 0)
		{
			lastFrameError = T._("Could not find closest point on lane.");
			CheckPlaySound(isActive: false);
			return;
		}
		float num3 = telemetryData.truckFloat.speed;
		bool flag = telemetryData.trailers.Any((TrailerInfo trailer) => trailer.comBool.attached);
		float widenStartSpeed = LaneAssistSettings.Current.WidenStartSpeed;
		float num4 = widenStartSpeed * 1.25f;
		float num5 = (flag ? (1f - Math.Clamp((num3 - widenStartSpeed) / (num4 - widenStartSpeed), 0f, 1f)) : 0f);
		if (num5 > 0f && LaneAssistSettings.Current.WidenTurnsWithTrailer)
		{
			float y = list[0].Rotation.ToEulerDeg().Y;
			float num6;
			for (num6 = list[list.Count - 1].Rotation.ToEulerDeg().Y - y; num6 > 180f; num6 -= 360f)
			{
			}
			for (; num6 < -180f; num6 += 360f)
			{
			}
			lastFrameTurnOffset = Math.Clamp((0f - num6) / LaneAssistSettings.Current.MaxWidenAtAngle, -1f, 1f) * LaneAssistSettings.Current.MaxWidenAmount * num5;
			list.Clear();
			for (int num7 = 0; num7 < LaneAssistSettings.Current.SteeringPointCount; num7++)
			{
				OrientedPoint? orientedPoint2 = lastPlannedPathData.InterpolateDist(num2 + (float)num7 * num, lastFrameTurnOffset, num7 == 0);
				if (orientedPoint2.HasValue)
				{
					list.Add(orientedPoint2.Value);
				}
			}
		}
		else
		{
			lastFrameTurnOffset = 0f;
		}
		// ARC: dorseyle viraj açılırken hedef çizgi bilerek kaydırılır; o kayma sapma sayılmaz.
		double num8 = ((lastPlannedPathData.PlannedPath.Count > 0 && lastPlannedPathData.PlannedPath[0].targetLaneIndex != 0) ? 5.5f : (2.25f + Math.Abs(lastFrameTurnOffset)));
		// ARC: rota yeni kurulduysa tırın kendi şeridine dönebilmesi için geçici olarak daha uzaktan da direksiyon verilir.
		if (Environment.TickCount64 - Volatile.Read(ref arcKurtarmaZamani) < 500)
		{
			num8 = Math.Max(num8, arcKurtarmaToleransi);
		}
		if (LaneAssistUtils.DistanceTo(coordinate, list[0].Position) > num8)
		{
			lastFrameError = T._("Closest point on lane is too far from the truck, likely due to incorrect path. Clearing path.");
			CheckPlaySound(isActive: false);
			return;
		}
		float num9 = 1f;
		if (num3 < 4.16f)
		{
			num9 = sensitivityMultipliers[AssistanceSettings.Current.SteeringSensitivity];
		}
		else if (num3 < 19.44f)
		{
			num9 = 1f + (19.44f - num3) / 15.280001f * (sensitivityMultipliers[AssistanceSettings.Current.SteeringSensitivity] - 1f);
		}
		List<float> list2 = new List<float>();
		foreach (OrientedPoint item in list)
		{
			list2.Add(LaneAssistUtils.GetAngleFromStraight(telemetryData.truckPlacement.rotation.ToVector3(), item));
		}
		float num10 = list2.Average();
		if (num3 < LaneAssistSettings.Current.RawControlSpeedThreshold)
		{
			num10 = filteredAngle.Update(num10);
		}
		else
		{
			filteredAngle.Reset();
		}
		float num11 = (lastFrameAngleOutput = (0f - anglePid.Update(0f, num10)) * num9 / 100f * SpeedSteering.AngleFactor(num3, flag));
		List<float> list3 = new List<float>();
		foreach (OrientedPoint item2 in list)
		{
			if (list3.Count >= 1)
			{
				break;
			}
			Vector3Double vector3Double = new Vector3Double(item2.Position.X, item2.Position.Y, item2.Position.Z) - coordinate;
			float num12 = (float)telemetryData.truckPlacement.rotation.X * 360f;
			double num13 = vector3Double.X * Math.Cos((double)num12 * Math.PI / 180.0) - vector3Double.Z * Math.Sin((double)num12 * Math.PI / 180.0);
			list3.Add((float)num13);
		}
		float num14 = list3.Average();
		if (num3 < LaneAssistSettings.Current.RawControlSpeedThreshold)
		{
			num14 = filteredCross.Update(num14);
		}
		else
		{
			filteredCross.Reset();
		}
		float num15 = num11 + (lastFrameDistanceOutput = distancePid.Update(0f, num14) * num9 / 100f * SpeedSteering.DistanceFactor(num3, flag));
		// ARC: kullanıcının hassasiyeti her hızda çıkışa uygulanır.
		num15 *= ArcSurusAyar.DireksiyonKazanci;
		// ARC: dar virajda düzeltme bir an 1'i aşınca direksiyon bırakılıyordu. Tam kırılmaya kırpılır; yalnızca
		// aşım 0,7 sn sürerse (gerçekten yanlış rota) devre dışı kalınır.
		if (Math.Abs(num15) > 1f)
		{
			arcAsimKare++;
			if (arcAsimKare > 20)
			{
				lastFrameError = T._("Steering correction too high, likely due to incorrect path. Clearing path.");
				CheckPlaySound(isActive: false);
				return;
			}
			num15 = Math.Clamp(num15, -1f, 1f);
		}
		else
		{
			arcAsimKare = 0;
		}
		ControlEvent data = new ControlEvent
		{
			ChannelDefinition = new ControlChannelDefinition
			{
				Id = "LaneAssist.SteeringCorrection",
				Timeout = 0.1f
			},
			Properties = new ControlProperties(),
			Variables = new ControlVariables
			{
				steering = num15
			}
		};
		Events.Current.Publish(GameOutput.Current.EventString, data);
		lastFrameSteeringOutput = 0f - num15;
		lastFrameError = "";
		CheckPlaySound(isActive: true);
	}

	private void RenderWindow()
	{
		if (!(!string.IsNullOrEmpty(lastFrameError) | (lastPlannedPathData?.HasError ?? false)))
		{
			ImGui.TextColored(new Vector4(0.5f, 1f, 0.5f, 1f), T._("Active"));
			if (telemetryData?.truckFloat.speed > LaneAssistSettings.Current.RawControlSpeedThreshold)
			{
				ImGui.SameLine();
				ImGui.TextColored(new Vector4(1f, 0.5f, 0.5f, 1f), "-  " + T._("High Speed"));
			}
			ImGui.SliderFloat("##steeringslider", ref lastFrameSteeringOutput, -1f, 1f);
			ImGui.TextColored(new Vector4(0.8f, 0.8f, 0.8f, 0.8f), $"° {0f - lastFrameAngleOutput:0.###}");
			ImGui.TextColored(new Vector4(0.8f, 0.8f, 0.8f, 0.8f), $"∆ {0f - lastFrameDistanceOutput:0.###}");
			if (lastFrameTurnOffset != 0f)
			{
				ImGui.TextColored(new Vector4(0.8f, 0.8f, 0.8f, 0.8f), $"↷ {0f - lastFrameTurnOffset:0.###}");
			}
		}
		else
		{
			ImGui.TextColored(new Vector4(1f, 0.5f, 0.5f, 1f), T._("Paused"));
			ImGui.TextColored(new Vector4(1f, 0.9f, 0.9f, 0.6f), lastFrameError ?? "");
			ImGui.TextColored(new Vector4(1f, 0.9f, 0.9f, 0.6f), lastPlannedPathData?.ErrorMessage ?? "");
		}
	}

	private float SmoothInOut(float t)
	{
		return t * t * (3f - 2f * t);
	}

	private float GetDistanceToVehicle(BaseVehicle vehicle)
	{
		if (telemetryData == null)
		{
			return float.MaxValue;
		}
		if (vehicle is TrafficVehicle { trailer_count: >0 } trafficVehicle)
		{
			return Vector3.Distance(trafficVehicle.trailers[trafficVehicle.trailer_count - 1].Position, telemetryData.truckPlacement.coordinate.ToVector3()) - trafficVehicle.trailers[trafficVehicle.trailer_count - 1].Size.Z / 2f;
		}
		return Vector3.Distance(vehicle.Position, telemetryData.truckPlacement.coordinate.ToVector3()) - vehicle.Size.Z / 2f;
	}

	private uint InterpolateSecondaryColor()
	{
		float num = SmoothInOut(secondaryColorTaperFactor);
		uint num2 = (primaryColor & 0xFF000000u) >> 24;
		uint num3 = (primaryColor & 0xFF0000) >> 16;
		uint num4 = (primaryColor & 0xFF00) >> 8;
		uint num5 = primaryColor & 0xFF;
		uint num6 = (secondaryColor & 0xFF000000u) >> 24;
		uint num7 = (secondaryColor & 0xFF0000) >> 16;
		uint num8 = (secondaryColor & 0xFF00) >> 8;
		uint num9 = secondaryColor & 0xFF;
		uint num10 = (uint)((float)num2 * (1f - num) + (float)num6 * num);
		uint num11 = (uint)((float)num3 * (1f - num) + (float)num7 * num);
		uint num12 = (uint)((float)num4 * (1f - num) + (float)num8 * num);
		uint num13 = (uint)((float)num5 * (1f - num) + (float)num9 * num);
		return (num10 << 24) | (num11 << 16) | (num12 << 8) | num13;
	}

	private static ARCoordinate WithY(ARCoordinate c, float y)
	{
		return new ARCoordinate(c.OffsetX, y, c.OffsetZ, c.Center);
	}

	private static void AppendRibbon(List<ARCoordinate> allLeft, List<ARCoordinate> allCenter, List<ARCoordinate> allRight, List<ARCoordinate> left, List<ARCoordinate> center, List<ARCoordinate> right, List<string> allOwner, string owner)
	{
		int num = Math.Min(center.Count, Math.Min(left.Count, right.Count));
		for (int i = 0; i < num; i++)
		{
			allLeft.Add(left[i]);
			allCenter.Add(center[i]);
			allRight.Add(right[i]);
			allOwner.Add(owner);
		}
	}

	private static void AlignPrefabsToRoads(List<ARCoordinate> center, List<ARCoordinate> left, List<ARCoordinate> right, List<string> owners)
	{
		int num = Math.Min(center.Count, Math.Min(left.Count, Math.Min(right.Count, owners.Count)));
		if (num < 2)
		{
			return;
		}
		int i = 0;
		while (i < num)
		{
			bool flag = owners[i] == "prefab";
			int num2 = i;
			for (; i < num && owners[i] == "prefab" == flag; i++)
			{
			}
			int num3 = i - 1;
			if (!flag)
			{
				continue;
			}
			bool flag2 = num2 > 0;
			bool flag3 = num3 + 1 < num;
			if (flag2 || flag3)
			{
				float num4 = (flag2 ? (center[num2 - 1].OffsetY - center[num2].OffsetY) : (center[num3 + 1].OffsetY - center[num3].OffsetY));
				float num5 = (flag3 ? (center[num3 + 1].OffsetY - center[num3].OffsetY) : num4);
				int num6 = Math.Max(1, num3 - num2);
				for (int j = num2; j <= num3; j++)
				{
					float num7 = num4 + (num5 - num4) * ((float)(j - num2) / (float)num6);
					center[j] = WithY(center[j], center[j].OffsetY + num7);
					left[j] = WithY(left[j], left[j].OffsetY + num7);
					right[j] = WithY(right[j], right[j].OffsetY + num7);
				}
			}
		}
	}

	private void DrawRibbonSegment(ARRenderer AR, List<ARCoordinate> allLeft, List<ARCoordinate> allCenter, List<ARCoordinate> allRight, List<string> allOwner, int start, int end, float targetDistance)
	{
		int num = end - start + 1;
		if (num >= 2)
		{
			List<ARCoordinate> range = allLeft.GetRange(start, num);
			List<ARCoordinate> range2 = allCenter.GetRange(start, num);
			List<ARCoordinate> range3 = allRight.GetRange(start, num);
			List<string> range4 = allOwner.GetRange(start, num);
			AlignPrefabsToRoads(range2, range, range3, range4);
			SmoothHeights(range, 5);
			SmoothHeights(range2, 5);
			SmoothHeights(range3, 5);
			// ARC: şerit artık oyunun içinde çizilir; veri ARC.DriveAssist üzerinden gider.
			if (arcSerit.Count == 0)
			{
				arcSerit.Add((targetDistance < 100000f) ? targetDistance : 0f);
				arcSerit.Add(BitConverter.UInt32BitsToSingle(InterpolateSecondaryColor()));
			}
			for (int k = 0; k < num; k++)
			{
				arcSerit.AddRange(new float[10]
				{
					range[k].OffsetX, range[k].OffsetY, range[k].OffsetZ,
					range2[k].OffsetX, range2[k].OffsetY, range2[k].OffsetZ,
					range3[k].OffsetX, range3[k].OffsetY, range3[k].OffsetZ,
					(k == 0) ? 1f : 0f
				});
			}
		}
	}

	private static void SmoothHeights(List<ARCoordinate> points, int window)
	{
		if (points.Count < 3)
		{
			return;
		}
		int num = Math.Max(1, window / 2);
		float[] array = new float[points.Count];
		for (int i = 0; i < points.Count; i++)
		{
			float num2 = 0f;
			int num3 = 0;
			for (int j = -num; j <= num; j++)
			{
				int num4 = i + j;
				if (num4 >= 0 && num4 < points.Count)
				{
					num2 += points[num4].OffsetY;
					num3++;
				}
			}
			array[i] = num2 / (float)num3;
		}
		for (int k = 0; k < points.Count; k++)
		{
			points[k] = WithY(points[k], array[k]);
		}
	}

	private readonly List<float> arcSerit = new List<float>();

	private void RenderAR()
	{
		Volatile.Write(ref arcSonCizim, Environment.TickCount64);
		arcSerit.Clear();
		try
		{
			RenderARIc();
		}
		finally
		{
			Events.Current.Publish("ARC.Hud.Ribbon", arcSerit.ToArray());
		}
	}

	private void RenderARIc()
	{
		if (!LaneAssistSettings.Current.RenderPlannedPath)
		{
			return;
		}
		// ARC: geçersiz/eski rota anında gizlenir; tekrar görünmesi için birkaç kare art arda geçerli olmalı (titreme olmasın).
		if (!ArcYolGosterilebilir())
		{
			arcGecerliKare = 0;
			return;
		}
		if (arcGecerliKare < 6)
		{
			arcGecerliKare++;
			return;
		}
		ARRenderer aR = OverlayHandler.Current.AR;
		bool simplifiedGraphics = OverlaySettingsHandler.Current.GetSettings().SimplifiedGraphics;
		float val = ((lastLeadingVehicle != null) ? GetDistanceToVehicle(lastLeadingVehicle) : float.MaxValue);
		float val2 = ((lastTargetParsedSemaphore != null) ? Vector3.Distance(lastTargetParsedSemaphore.GetCurveStartWorldCoordinates().Position, telemetryData?.truckPlacement.coordinate.ToVector3() ?? Vector3.Zero) : float.MaxValue);
		float num = Math.Min(val, val2);
		if (num == float.MaxValue && secondaryColorTaperFactor > 0f)
		{
			secondaryColorTaperFactor -= 0.05f;
		}
		else if (secondaryColorTaperFactor < 1f)
		{
			secondaryColorTaperFactor += 0.05f;
		}
		ARCoordinate? aRCoordinate = null;
		ARCoordinate? aRCoordinate2 = null;
		ARCoordinate? aRCoordinate3 = null;
		List<ARCoordinate> allLeft = new List<ARCoordinate>();
		List<ARCoordinate> list = new List<ARCoordinate>();
		List<ARCoordinate> allRight = new List<ARCoordinate>();
		List<string> allOwner = new List<string>();
		for (int i = 0; i < lastPlannedPathData?.PlannedPath.Count; i++)
		{
			List<ARCoordinate> list2 = new List<ARCoordinate>();
			List<ARCoordinate> list3 = new List<ARCoordinate>();
			List<ARCoordinate> list4 = new List<ARCoordinate>();
			PlannedItem plannedItem = lastPlannedPathData?.PlannedPath[i];
			bool flag = plannedItem != null && plannedItem.direction == Direction.Backward;
			try
			{
				if (plannedItem?.item is ParsedRoadList parsedRoadList)
				{
					float num2 = 0f;
					while (true)
					{
						bool flag2 = num2 >= parsedRoadList.TotalLength;
						float distance = (flag2 ? parsedRoadList.TotalLength : num2);
						float num3 = 4.5f * SmoothInOut(roadPrefabTaperFactor) + 4.5f * (1f - SmoothInOut(roadPrefabTaperFactor));
						try
						{
							float num4 = parsedRoadList.DistanceToFactor(distance);
							if (flag)
							{
								num4 = 1f - num4;
							}
							OrientedPoint? orientedPoint = plannedItem.Interpolate(num4, (0f - num3) / 2f);
							OrientedPoint? orientedPoint2 = plannedItem.Interpolate(num4);
							OrientedPoint? orientedPoint3 = plannedItem.Interpolate(num4, num3 / 2f);
							if (simplifiedGraphics)
							{
								if (orientedPoint.HasValue && orientedPoint3.HasValue && list2.Count > 0)
								{
									aR.Draw3DLine(list2.Last(), flag ? new ARCoordinate(orientedPoint.Value.Position) : new ARCoordinate(orientedPoint3.Value.Position), 12290286u, 2f);
								}
								if (orientedPoint3.HasValue && orientedPoint.HasValue && list4.Count > 0)
								{
									aR.Draw3DLine(list4.Last(), flag ? new ARCoordinate(orientedPoint3.Value.Position) : new ARCoordinate(orientedPoint.Value.Position), 12290286u, 2f);
								}
							}
							if (orientedPoint.HasValue)
							{
								if (flag)
								{
									list2.Add(new ARCoordinate(orientedPoint.Value.Position));
								}
								else
								{
									list4.Add(new ARCoordinate(orientedPoint.Value.Position));
								}
							}
							if (orientedPoint2.HasValue)
							{
								list3.Add(new ARCoordinate(orientedPoint2.Value.Position));
							}
							if (orientedPoint3.HasValue)
							{
								if (flag)
								{
									list4.Add(new ARCoordinate(orientedPoint3.Value.Position));
								}
								else
								{
									list2.Add(new ARCoordinate(orientedPoint3.Value.Position));
								}
							}
						}
						catch
						{
						}
						roadPrefabTaperFactor += 0.1f;
						if (roadPrefabTaperFactor > 1f)
						{
							roadPrefabTaperFactor = 1f;
						}
						if (flag2)
						{
							break;
						}
						num2 += 2f;
					}
					AppendRibbon(allLeft, list, allRight, list2, list3, list4, allOwner, (plannedItem?.item is ParsedPrefab) ? "prefab" : "road");
				}
				if (plannedItem?.item is ParsedPrefab)
				{
					PrefabPath prefabPath = plannedItem.prefabPath;
					if (prefabPath == null)
					{
						continue;
					}
					float num5 = 0f;
					while (true)
					{
						bool flag3 = num5 >= prefabPath.Length;
						float distance2 = (flag3 ? prefabPath.Length : num5);
						try
						{
							float num6 = 4.5f * SmoothInOut(roadPrefabTaperFactor) + 4.5f * (1f - SmoothInOut(roadPrefabTaperFactor));
							OrientedPoint? orientedPoint4 = prefabPath.InterpolateDist(distance2, (0f - num6) / 2f);
							OrientedPoint? orientedPoint5 = prefabPath.InterpolateDist(distance2);
							OrientedPoint? orientedPoint6 = prefabPath.InterpolateDist(distance2, num6 / 2f);
							if (simplifiedGraphics && orientedPoint5.HasValue && list3.Count > 0)
							{
								aR.Draw3DLine(list3.Last(), new ARCoordinate(orientedPoint5.Value.Position), 12290286u, 2f);
							}
							if (orientedPoint5.HasValue)
							{
								list3.Add(new ARCoordinate(orientedPoint5.Value.Position));
							}
							if (orientedPoint4.HasValue)
							{
								list2.Add(new ARCoordinate(orientedPoint4.Value.Position));
							}
							if (orientedPoint6.HasValue)
							{
								list4.Add(new ARCoordinate(orientedPoint6.Value.Position));
							}
						}
						catch
						{
						}
						roadPrefabTaperFactor -= 0.05f;
						if (roadPrefabTaperFactor < 0f)
						{
							roadPrefabTaperFactor = 0f;
						}
						if (flag3)
						{
							break;
						}
						num5++;
					}
					AppendRibbon(allLeft, list, allRight, list2, list3, list4, allOwner, (plannedItem?.item is ParsedPrefab) ? "prefab" : "road");
					_ = plannedItem.endNode.Position;
				}
			}
			catch (Exception value)
			{
				Logger.Error($"Error while rendering AR for planned path item {i}: {value}", "C:\\Users\\Tumppi066\\Documents\\GitHub\\core-plugins\\Plugins\\LaneAssist\\Program.cs", 726);
			}
			aRCoordinate = ((list2.Count > 0) ? new ARCoordinate?(list2.Last()) : aRCoordinate);
			aRCoordinate2 = ((list3.Count > 0) ? new ARCoordinate?(list3.Last()) : aRCoordinate2);
			aRCoordinate3 = ((list4.Count > 0) ? new ARCoordinate?(list4.Last()) : aRCoordinate3);
		}
		if (simplifiedGraphics || list.Count <= 1)
		{
			return;
		}
		int start = 0;
		for (int j = 1; j <= list.Count; j++)
		{
			if (j == list.Count || MathF.Abs(list[j].OffsetY - list[j - 1].OffsetY) > 1f)
			{
				DrawRibbonSegment(aR, allLeft, list, allRight, allOwner, start, j - 1, num);
				start = j;
			}
		}
	}

	public override void OnDisable()
	{
		base.OnDisable();
		OverlayHandler.Current.UnregisterWindow(windowDefinition);
		OverlayHandler.Current.AR?.UnregisterRenderCallback("LKASRenderer");
		arcKayitliAr = null;
		Events.Current.Unsubscribe(GameTelemetry.Current.EventString, (GameTelemetryData data) =>
		{
			telemetryData = data;
		});
		Events.Current.Unsubscribe("Pathfinding.PlannedPathData", (PlannedPathData data) =>
		{
			lastPlannedPathData = data;
		});
	}

	public override void Shutdown()
	{
		LaneAssistSettings.Current.Save();
		base.Shutdown();
	}
}

/// <summary>ARC Sürüş Ayarları eklentisinin yazdığı ayar; saniyede bir okunur, dosya yoksa varsayılan.</summary>
internal static class ArcSurusAyar
{
	private static float kazanc = 1f;

	private static DateTime sonBakis = DateTime.MinValue;

	private static readonly string Yol = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ETS2LA", "arc.driveassist.json");

	public static float DireksiyonKazanci
	{
		get
		{
			if ((DateTime.UtcNow - sonBakis).TotalSeconds >= 1.0)
			{
				sonBakis = DateTime.UtcNow;
				try
				{
					using System.Text.Json.JsonDocument d = System.Text.Json.JsonDocument.Parse(System.IO.File.ReadAllText(Yol));
					kazanc = Math.Clamp(d.RootElement.GetProperty("SteeringGain").GetSingle(), 0.4f, 2.5f);
				}
				catch
				{
					kazanc = 1f;
				}
			}
			return kazanc;
		}
	}
}
