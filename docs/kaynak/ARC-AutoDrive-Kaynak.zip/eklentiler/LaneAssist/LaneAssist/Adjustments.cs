using ETS2LA.State;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;

namespace LaneAssist;

[Route("/plugins/adjustments/tumppi066.laneassist")]
public class Adjustments : ComponentBase
{
	private int SteeringPointCount
	{
		get
		{
			return LaneAssistSettings.Current.SteeringPointCount;
		}
		set
		{
			LaneAssistSettings.Current.SteeringPointCount = value;
			LaneAssistSettings.Current.Save();
		}
	}

	private float RawControlSpeedThreshold
	{
		get
		{
			return LaneAssistSettings.Current.RawControlSpeedThreshold;
		}
		set
		{
			LaneAssistSettings.Current.RawControlSpeedThreshold = value;
			LaneAssistSettings.Current.Save();
		}
	}

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full p-5 px-8 gap-3");
		__builder.OpenComponent<SectionTitle>(2);
		__builder.AddComponentParameter(3, "Title", RuntimeHelpers.TypeCheck(T._("General")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(4, "\r\n\r\n    ");
		__builder.OpenComponent<Slider>(5);
		__builder.AddComponentParameter(6, "Title", RuntimeHelpers.TypeCheck(T._("Steering Point Count")));
		__builder.AddComponentParameter(7, "Description", RuntimeHelpers.TypeCheck(T._("Targeted steering angle is based on this many points ahead of the vehicle. More points will result in smoother but less responsive steering.")));
		__builder.AddComponentParameter(8, "Value", RuntimeHelpers.TypeCheck((float)SteeringPointCount));
		__builder.AddComponentParameter(9, "Min", RuntimeHelpers.TypeCheck(1f));
		__builder.AddComponentParameter(10, "Max", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(11, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			SteeringPointCount = (int)value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(12, "\r\n\r\n    ");
		__builder.OpenComponent<Slider>(13);
		__builder.AddComponentParameter(14, "Title", RuntimeHelpers.TypeCheck(T._("Raw Control Speed Threshold")));
		__builder.AddComponentParameter(15, "Description", RuntimeHelpers.TypeCheck(T._("Speed at which ETS2LA will turn off filters to ensure it doesn't sway between lanes.")));
		__builder.AddComponentParameter(16, "Value", RuntimeHelpers.TypeCheck(UnitConversions.FromScientificUnits(UnitType.Speed, RawControlSpeedThreshold, ApplicationState.Current.DisplayUnits)));
		__builder.AddComponentParameter(17, "Suffix", RuntimeHelpers.TypeCheck(UnitConversions.GetUnitAbbreviation(UnitType.Speed, ApplicationState.Current.DisplayUnits)));
		__builder.AddComponentParameter(18, "Min", RuntimeHelpers.TypeCheck(0f));
		__builder.AddComponentParameter(19, "Max", RuntimeHelpers.TypeCheck(100f));
		__builder.AddComponentParameter(20, "Step", RuntimeHelpers.TypeCheck(1f));
		__builder.AddComponentParameter(21, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			RawControlSpeedThreshold = UnitConversions.ToScientificUnits(UnitType.Speed, value, ApplicationState.Current.DisplayUnits);
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(22, "\r\n\r\n    ");
		__builder.OpenComponent<Switch>(23);
		__builder.AddComponentParameter(24, "Title", RuntimeHelpers.TypeCheck(T._("Render Planned Path")));
		__builder.AddComponentParameter(25, "Description", RuntimeHelpers.TypeCheck(T._("Render the planned path in the AR overlay. If this doesn't work, try to enable 'Simplified Graphics' in the Display Settings.")));
		__builder.AddComponentParameter(26, "Value", RuntimeHelpers.TypeCheck(LaneAssistSettings.Current.RenderPlannedPath));
		__builder.AddComponentParameter(27, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			LaneAssistSettings.Current.RenderPlannedPath = value;
			LaneAssistSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(28, "\r\n\r\n    ");
		__builder.OpenComponent<Switch>(29);
		__builder.AddComponentParameter(30, "Title", RuntimeHelpers.TypeCheck(T._("Play Audio")));
		__builder.AddComponentParameter(31, "Description", RuntimeHelpers.TypeCheck(T._("Enable or disable audio cues in various situations.")));
		__builder.AddComponentParameter(32, "Value", RuntimeHelpers.TypeCheck(LaneAssistSettings.Current.PlayEnableDisableAudio));
		__builder.AddComponentParameter(33, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			LaneAssistSettings.Current.PlayEnableDisableAudio = value;
			LaneAssistSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(34, "\r\n\r\n    ");
		__builder.OpenComponent<SectionTitle>(35);
		__builder.AddComponentParameter(36, "Title", RuntimeHelpers.TypeCheck(T._("Path Widening")));
		__builder.CloseComponent();
		__builder.AddMarkupContent(37, "\r\n\r\n    ");
		__builder.OpenComponent<Switch>(38);
		__builder.AddComponentParameter(39, "Title", RuntimeHelpers.TypeCheck(T._("Widen Turns With Trailer")));
		__builder.AddComponentParameter(40, "Description", RuntimeHelpers.TypeCheck(T._("When enabled, ETS2LA will widen turns when a trailer is attached. This can help prevent the trailer from hitting curbs or other obstacles.")));
		__builder.AddComponentParameter(41, "Value", RuntimeHelpers.TypeCheck(LaneAssistSettings.Current.WidenTurnsWithTrailer));
		__builder.AddComponentParameter(42, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			LaneAssistSettings.Current.WidenTurnsWithTrailer = value;
			LaneAssistSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(43, "\r\n\r\n    ");
		__builder.OpenComponent<Slider>(44);
		__builder.AddComponentParameter(45, "Title", RuntimeHelpers.TypeCheck(T._("Max Widen Amount")));
		__builder.AddComponentParameter(46, "Description", RuntimeHelpers.TypeCheck(T._("Maximum amount to widen turns when a trailer is attached. This is a percentage of the lane width.")));
		__builder.AddComponentParameter(47, "Value", RuntimeHelpers.TypeCheck(LaneAssistSettings.Current.MaxWidenAmount));
		__builder.AddComponentParameter(48, "Suffix", "m");
		__builder.AddComponentParameter(49, "Min", RuntimeHelpers.TypeCheck(0f));
		__builder.AddComponentParameter(50, "Max", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(51, "Step", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(52, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			LaneAssistSettings.Current.MaxWidenAmount = value;
			LaneAssistSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(53, "\r\n\r\n    ");
		__builder.OpenComponent<Slider>(54);
		__builder.AddComponentParameter(55, "Title", RuntimeHelpers.TypeCheck(T._("Widen Start Speed")));
		__builder.AddComponentParameter(56, "Description", RuntimeHelpers.TypeCheck(T._("Speed at which ETS2LA will start widening turns when a trailer is attached. Below this speed, the widening will be disabled.")));
		__builder.AddComponentParameter(57, "Value", RuntimeHelpers.TypeCheck(LaneAssistSettings.Current.WidenStartSpeed));
		__builder.AddComponentParameter(58, "Suffix", "m/s");
		__builder.AddComponentParameter(59, "Min", RuntimeHelpers.TypeCheck(0f));
		__builder.AddComponentParameter(60, "Max", RuntimeHelpers.TypeCheck(20f));
		__builder.AddComponentParameter(61, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			LaneAssistSettings.Current.WidenStartSpeed = value;
			LaneAssistSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(62, "\r\n\r\n    ");
		__builder.OpenComponent<Slider>(63);
		__builder.AddComponentParameter(64, "Title", RuntimeHelpers.TypeCheck(T._("Max Widen At Angle")));
		__builder.AddComponentParameter(65, "Description", RuntimeHelpers.TypeCheck(T._("The angle at which ETS2LA will apply the maximum widening when a trailer is attached. Below this angle, the widening will be scaled down.")));
		__builder.AddComponentParameter(66, "Value", RuntimeHelpers.TypeCheck(LaneAssistSettings.Current.MaxWidenAtAngle));
		__builder.AddComponentParameter(67, "Suffix", "°");
		__builder.AddComponentParameter(68, "Min", RuntimeHelpers.TypeCheck(0f));
		__builder.AddComponentParameter(69, "Max", RuntimeHelpers.TypeCheck(90f));
		__builder.AddComponentParameter(70, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			LaneAssistSettings.Current.MaxWidenAtAngle = value;
			LaneAssistSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.CloseElement();
	}
}
