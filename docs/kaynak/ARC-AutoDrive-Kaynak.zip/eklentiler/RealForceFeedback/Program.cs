using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using ETS2LA.Backend.Events;
using ETS2LA.Controls.Windows;
using ETS2LA.Game.Telemetry;
using ETS2LA.Logging;
using ETS2LA.Notifications;
using ETS2LA.Settings;
using ETS2LA.Shared;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using ForceFeedback;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;
using Microsoft.CodeAnalysis;
using SharpDX;
using SharpDX.DirectInput;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.DisableOptimizations | DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | DebuggableAttribute.DebuggingModes.EnableEditAndContinue)]
namespace RealForceFeedback
{
	[Route("/plugins/adjustments/zkhan4509.realforcefeedback")]
	public class Settings : ComponentBase
	{
		private SettingsHandler _settingsHandler = new SettingsHandler();

		private FfbSettings _settings = new FfbSettings();

		private const string SettingsFilename = "realffb_settings.json";

		private float Kp
		{
			get
			{
				return _settings.Kp;
			}
			set
			{
				_settings.Kp = value;
				SaveSettings();
			}
		}

		private float Ki
		{
			get
			{
				return _settings.Ki;
			}
			set
			{
				_settings.Ki = value;
				SaveSettings();
			}
		}

		private float Kd
		{
			get
			{
				return _settings.Kd;
			}
			set
			{
				_settings.Kd = value;
				SaveSettings();
			}
		}

		private float MaxIntegral
		{
			get
			{
				return _settings.MaxIntegral;
			}
			set
			{
				_settings.MaxIntegral = value;
				SaveSettings();
			}
		}

		private float CenterBoost
		{
			get
			{
				return _settings.CenterBoost;
			}
			set
			{
				_settings.CenterBoost = value;
				SaveSettings();
			}
		}

		private bool InvertSteering
		{
			get
			{
				return _settings.InvertSteering;
			}
			set
			{
				_settings.InvertSteering = value;
				SaveSettings();
			}
		}

		private float MaxPidForce
		{
			get
			{
				return _settings.MaxPidForce;
			}
			set
			{
				_settings.MaxPidForce = value;
				SaveSettings();
			}
		}

		private float MaxTotalForce
		{
			get
			{
				return _settings.MaxTotalForce;
			}
			set
			{
				_settings.MaxTotalForce = value;
				SaveSettings();
			}
		}

		private float Smoothing
		{
			get
			{
				return _settings.Smoothing;
			}
			set
			{
				_settings.Smoothing = value;
				SaveSettings();
			}
		}

		private bool EnableEngineVibration
		{
			get
			{
				return _settings.EnableEngineVibration;
			}
			set
			{
				_settings.EnableEngineVibration = value;
				SaveSettings();
			}
		}

		private float EngineVibrationScale
		{
			get
			{
				return _settings.EngineVibrationScale;
			}
			set
			{
				_settings.EngineVibrationScale = value;
				SaveSettings();
			}
		}

		private bool EnableBumpEffects
		{
			get
			{
				return _settings.EnableBumpEffects;
			}
			set
			{
				_settings.EnableBumpEffects = value;
				SaveSettings();
			}
		}

		private float BumpSensitivity
		{
			get
			{
				return _settings.BumpSensitivity;
			}
			set
			{
				_settings.BumpSensitivity = value;
				SaveSettings();
			}
		}

		private float MaxBumpForce
		{
			get
			{
				return _settings.MaxBumpForce;
			}
			set
			{
				_settings.MaxBumpForce = value;
				SaveSettings();
			}
		}

		protected override void BuildRenderTree(RenderTreeBuilder __builder)
		{
			__builder.OpenElement(0, "div");
			__builder.AddAttribute(1, "class", "flex flex-col w-108 m-5 ml-8 gap-6 pb-12");
			__builder.OpenElement(2, "div");
			__builder.AddAttribute(3, "class", "flex flex-col gap-1");
			__builder.OpenElement(4, "h1");
			__builder.AddAttribute(5, "class", "text-xl font-bold");
			__builder.AddContent(6, T._("Real Force Feedback Settings", Array.Empty<object>()));
			__builder.CloseElement();
			__builder.AddMarkupContent(7, "\n        ");
			__builder.OpenElement(8, "p");
			__builder.AddAttribute(9, "class", "text-sm text-description");
			__builder.AddContent(10, T._("Configure PID steering gains, engine vibration, and bump force feedback response.", Array.Empty<object>()));
			__builder.CloseElement();
			__builder.CloseElement();
			__builder.AddMarkupContent(11, "\n\n    ");
			__builder.OpenComponent<Separator>(12);
			__builder.AddComponentParameter(13, "Label", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Steering PID Response", Array.Empty<object>())));
			__builder.CloseComponent();
			__builder.AddMarkupContent(14, "\n\n    ");
			__builder.OpenComponent<Slider>(15);
			__builder.AddComponentParameter(16, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Proportional Gain (Kp)", Array.Empty<object>())));
			__builder.AddComponentParameter(17, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Proportional response force multiplier for steering error.", Array.Empty<object>())));
			__builder.AddComponentParameter(18, "Min", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0f));
			__builder.AddComponentParameter(19, "Max", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(20f));
			__builder.AddComponentParameter(20, "Step", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.1f));
			__builder.AddComponentParameter(21, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(Kp));
			__builder.AddComponentParameter(22, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
			{
				Kp = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(23, "\n\n    ");
			__builder.OpenComponent<Slider>(24);
			__builder.AddComponentParameter(25, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Integral Gain (Ki)", Array.Empty<object>())));
			__builder.AddComponentParameter(26, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Integral correction gain for steady-state steering error.", Array.Empty<object>())));
			__builder.AddComponentParameter(27, "Min", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0f));
			__builder.AddComponentParameter(28, "Max", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(2f));
			__builder.AddComponentParameter(29, "Step", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.05f));
			__builder.AddComponentParameter(30, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(Ki));
			__builder.AddComponentParameter(31, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
			{
				Ki = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(32, "\n\n    ");
			__builder.OpenComponent<Slider>(33);
			__builder.AddComponentParameter(34, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Derivative Gain (Kd)", Array.Empty<object>())));
			__builder.AddComponentParameter(35, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Damping force multiplier against fast steering movement.", Array.Empty<object>())));
			__builder.AddComponentParameter(36, "Min", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0f));
			__builder.AddComponentParameter(37, "Max", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(10f));
			__builder.AddComponentParameter(38, "Step", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.1f));
			__builder.AddComponentParameter(39, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(Kd));
			__builder.AddComponentParameter(40, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
			{
				Kd = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(41, "\n\n    ");
			__builder.OpenComponent<Slider>(42);
			__builder.AddComponentParameter(43, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Max Integral Term", Array.Empty<object>())));
			__builder.AddComponentParameter(44, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Clamps the maximum accumulated integral error.", Array.Empty<object>())));
			__builder.AddComponentParameter(45, "Min", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0f));
			__builder.AddComponentParameter(46, "Max", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(1f));
			__builder.AddComponentParameter(47, "Step", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.05f));
			__builder.AddComponentParameter(48, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(MaxIntegral));
			__builder.AddComponentParameter(49, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
			{
				MaxIntegral = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(50, "\n\n    ");
			__builder.OpenComponent<Slider>(51);
			__builder.AddComponentParameter(52, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Center Boost / Stiffness", Array.Empty<object>())));
			__builder.AddComponentParameter(53, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Optional extra force boost near center. Set to 0.0 for a smooth natural feel without center snapping.", Array.Empty<object>())));
			__builder.AddComponentParameter(54, "Min", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0f));
			__builder.AddComponentParameter(55, "Max", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.5f));
			__builder.AddComponentParameter(56, "Step", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.01f));
			__builder.AddComponentParameter(57, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(CenterBoost));
			__builder.AddComponentParameter(58, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
			{
				CenterBoost = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(59, "\n\n    ");
			__builder.OpenComponent<ETS2LA.UI.Shared.Components.Switch>(60);
			__builder.AddComponentParameter(61, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Invert Steering Axis", Array.Empty<object>())));
			__builder.AddComponentParameter(62, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Flips the steering force feedback direction if your physical wheel turns opposite to in-game steering.", Array.Empty<object>())));
			__builder.AddComponentParameter(63, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(InvertSteering));
			__builder.AddComponentParameter(64, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool v) =>
			{
				InvertSteering = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(65, "\n\n    ");
			__builder.OpenComponent<Separator>(66);
			__builder.AddComponentParameter(67, "Label", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Force & Smoothing Constraints", Array.Empty<object>())));
			__builder.AddComponentParameter(68, "Class", "mt-4");
			__builder.CloseComponent();
			__builder.AddMarkupContent(69, "\n\n    ");
			__builder.OpenComponent<Slider>(70);
			__builder.AddComponentParameter(71, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Max PID Force", Array.Empty<object>())));
			__builder.AddComponentParameter(72, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Limits the maximum force output generated by the PID controller.", Array.Empty<object>())));
			__builder.AddComponentParameter(73, "Min", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.1f));
			__builder.AddComponentParameter(74, "Max", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(1f));
			__builder.AddComponentParameter(75, "Step", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.05f));
			__builder.AddComponentParameter(76, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(MaxPidForce));
			__builder.AddComponentParameter(77, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
			{
				MaxPidForce = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(78, "\n\n    ");
			__builder.OpenComponent<Slider>(79);
			__builder.AddComponentParameter(80, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Max Total Force", Array.Empty<object>())));
			__builder.AddComponentParameter(81, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Overall maximum force limit applied to force feedback motors.", Array.Empty<object>())));
			__builder.AddComponentParameter(82, "Min", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.1f));
			__builder.AddComponentParameter(83, "Max", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(1f));
			__builder.AddComponentParameter(84, "Step", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.05f));
			__builder.AddComponentParameter(85, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(MaxTotalForce));
			__builder.AddComponentParameter(86, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
			{
				MaxTotalForce = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(87, "\n\n    ");
			__builder.OpenComponent<Slider>(88);
			__builder.AddComponentParameter(89, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Force Smoothing", Array.Empty<object>())));
			__builder.AddComponentParameter(90, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Low-pass filtering factor to smooth out rapid force transitions.", Array.Empty<object>())));
			__builder.AddComponentParameter(91, "Min", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0f));
			__builder.AddComponentParameter(92, "Max", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.5f));
			__builder.AddComponentParameter(93, "Step", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.01f));
			__builder.AddComponentParameter(94, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(Smoothing));
			__builder.AddComponentParameter(95, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
			{
				Smoothing = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(96, "\n\n    ");
			__builder.OpenComponent<Separator>(97);
			__builder.AddComponentParameter(98, "Label", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Engine Vibration", Array.Empty<object>())));
			__builder.AddComponentParameter(99, "Class", "mt-4");
			__builder.CloseComponent();
			__builder.AddMarkupContent(100, "\n\n    ");
			__builder.OpenComponent<ETS2LA.UI.Shared.Components.Switch>(101);
			__builder.AddComponentParameter(102, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Enable Engine Vibration", Array.Empty<object>())));
			__builder.AddComponentParameter(103, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Simulates engine idle and RPM vibration on the wheel motor.", Array.Empty<object>())));
			__builder.AddComponentParameter(104, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EnableEngineVibration));
			__builder.AddComponentParameter(105, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool v) =>
			{
				EnableEngineVibration = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(106, "\n\n    ");
			__builder.OpenComponent<Slider>(107);
			__builder.AddComponentParameter(108, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Engine Vibration Scale", Array.Empty<object>())));
			__builder.AddComponentParameter(109, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Intensity multiplier for engine vibration force effects.", Array.Empty<object>())));
			__builder.AddComponentParameter(110, "Class", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EnableEngineVibration ? "" : "opacity-30 pointer-events-none"));
			__builder.AddComponentParameter(111, "Min", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0f));
			__builder.AddComponentParameter(112, "Max", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(3f));
			__builder.AddComponentParameter(113, "Step", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.1f));
			__builder.AddComponentParameter(114, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EngineVibrationScale));
			__builder.AddComponentParameter(115, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
			{
				EngineVibrationScale = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(116, "\n\n    ");
			__builder.OpenComponent<Separator>(117);
			__builder.AddComponentParameter(118, "Label", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Road Bump Effects", Array.Empty<object>())));
			__builder.AddComponentParameter(119, "Class", "mt-4");
			__builder.CloseComponent();
			__builder.AddMarkupContent(120, "\n\n    ");
			__builder.OpenComponent<ETS2LA.UI.Shared.Components.Switch>(121);
			__builder.AddComponentParameter(122, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Enable Bump Effects", Array.Empty<object>())));
			__builder.AddComponentParameter(123, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Translates vertical chassis acceleration into road bump forces.", Array.Empty<object>())));
			__builder.AddComponentParameter(124, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EnableBumpEffects));
			__builder.AddComponentParameter(125, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool v) =>
			{
				EnableBumpEffects = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(126, "\n\n    ");
			__builder.OpenComponent<Slider>(127);
			__builder.AddComponentParameter(128, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Bump Sensitivity", Array.Empty<object>())));
			__builder.AddComponentParameter(129, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Sensitivity threshold to road surface bumps.", Array.Empty<object>())));
			__builder.AddComponentParameter(130, "Class", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EnableBumpEffects ? "" : "opacity-30 pointer-events-none"));
			__builder.AddComponentParameter(131, "Min", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.01f));
			__builder.AddComponentParameter(132, "Max", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.5f));
			__builder.AddComponentParameter(133, "Step", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.01f));
			__builder.AddComponentParameter(134, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(BumpSensitivity));
			__builder.AddComponentParameter(135, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
			{
				BumpSensitivity = v;
			})));
			__builder.CloseComponent();
			__builder.AddMarkupContent(136, "\n\n    ");
			__builder.OpenComponent<Slider>(137);
			__builder.AddComponentParameter(138, "Title", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Max Bump Force", Array.Empty<object>())));
			__builder.AddComponentParameter(139, "Description", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(T._("Maximum allowable force impulse for road bumps.", Array.Empty<object>())));
			__builder.AddComponentParameter(140, "Class", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EnableBumpEffects ? "" : "opacity-30 pointer-events-none"));
			__builder.AddComponentParameter(141, "Min", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.05f));
			__builder.AddComponentParameter(142, "Max", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(1f));
			__builder.AddComponentParameter(143, "Step", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(0.05f));
			__builder.AddComponentParameter(144, "Value", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(MaxBumpForce));
			__builder.AddComponentParameter(145, "ValueChanged", Microsoft.AspNetCore.Components.CompilerServices.RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
			{
				MaxBumpForce = v;
			})));
			__builder.CloseComponent();
			__builder.CloseElement();
		}

		protected override void OnInitialized()
		{
			base.OnInitialized();
			_settings = _settingsHandler.Load<FfbSettings>("realffb_settings.json");
		}

		private void SaveSettings()
		{
			_settingsHandler.Save<FfbSettings>("realffb_settings.json", _settings);
		}

		public Settings()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected Obj, but got Unknown
		}
	}
}
namespace Microsoft.Extensions.Validation.Embedded
{
	[Embedded]
	[AttributeUsage(AttributeTargets.Class)]
	internal sealed class ValidatableTypeAttribute : Attribute
	{
	}
}
namespace Microsoft.CodeAnalysis
{
	[Embedded]
	internal sealed class EmbeddedAttribute : Attribute
	{
	}
}
namespace ForceFeedback
{
	[Serializable]
	public class FfbSettings
	{
		public float Kp { get; set; } = 5f;

		public float Ki { get; set; } = 0.2f;

		public float Kd { get; set; } = 2.5f;

		public float MaxIntegral { get; set; } = 0.35f;

		public bool InvertSteering { get; set; } = true;

		public float CenterBoost { get; set; } = 0f;

		public float MaxPidForce { get; set; } = 0.45f;

		public float MaxTotalForce { get; set; } = 1f;

		public float Smoothing { get; set; } = 0.05f;

		public bool EnableEngineVibration { get; set; } = true;

		public float EngineVibrationScale { get; set; } = 1f;

		public bool EnableBumpEffects { get; set; } = true;

		public float BumpSensitivity { get; set; } = 0.1f;

		public float MaxBumpForce { get; set; } = 0.3f;
	}
	public class WheelDevice
	{
		public required Joystick Joystick;

		public required string DeviceName;

		public required Guid InstanceGuid;

		public EffectInfo? ConstantForceInfo;

		public Effect? ConstantForceEffect;

		public Effect? EngineEffect;

		public bool IsInitialized = false;

		public bool IsLowPower = true;

		private readonly object _lock = new object();

		private float _last = 0f;

		private float _lastError = 0f;

		private float _integralError = 0f;

		private FfbSettings _settings;

		private DateTime _lastForceErrorLog = DateTime.MinValue;

		private bool _effectUpdateDisabled = false;

		private EffectParameters? _cachedEffectParams;

		private ConstantForce _cachedConstantForce = new ConstantForce();

		private EffectParameters? _cachedEngineParams;

		private PeriodicForce _cachedPeriodic = new PeriodicForce();

		private Vector3 _lastAccel = Vector3.Zero;

		private float _bumpForce = 0f;

		public WheelDevice(FfbSettings settings)
		{
			//IL_004d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0057: Expected Obj, but got Unknown
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_0062: Expected Obj, but got Unknown
			_settings = settings;
		}

		public void ApplySettings(FfbSettings settings)
		{
			_settings = settings;
			_arcYon?.KonumAyarla(settings.InvertSteering);
		}

		public void CenterToNeutral()
		{
			lock (_lock)
			{
				if (!IsInitialized || ConstantForceEffect == null || _cachedEffectParams == null)
				{
					return;
				}
				try
				{
					JoystickState currentState = ((CustomDevice<JoystickState, RawJoystickState, JoystickUpdate>)(object)Joystick).GetCurrentState();
					// ARC: ortaya çeken kuvvet de öğrenilen yönlerle hesaplanır (kuvveti ters sette direksiyonu kenara itiyordu)
					ARC.RealFfb.DireksiyonYonu yon = ArcYon();
					float konum = yon.Konum(((float)currentState.X - 32767.5f) / 32767.5f);
					float value = (0f - konum) * 0.15f;
					value = Math.Clamp(value, 0f - _settings.MaxPidForce, _settings.MaxPidForce);
					_last = 0f;
					_lastError = 0f;
					_integralError = 0f;
					_cachedConstantForce.Magnitude = (int)(Math.Clamp(value, -1f, 1f) * 10000f * yon.Kuvvet);
					_cachedEffectParams.Parameters = (TypeSpecificParameters)(object)_cachedConstantForce;
					ConstantForceEffect.SetParameters(_cachedEffectParams, (EffectParameterFlags)256);
				}
				catch (Exception)
				{
				}
			}
		}

		// ARC: konum yönü ve kuvvet yönü ayrı öğrenilir (ARC.RealFfb.DireksiyonYonu). Kuvvet yönü direksiyonun adıyla
		// dosyada, konum yönü realffb_settings.json'daki InvertSteering'de saklanır (ARC.DriveAssist de onu okur).
		private ARC.RealFfb.DireksiyonYonu? _arcYon;

		/// <summary>Konum yönü öğrenilip değiştiğinde (yeni InvertSteering) çağrılır; eklenti ayarı kaydeder.</summary>
		public Action<bool>? ArcKonumDegisti;

		private static string ArcYonDosyasi => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ETS2LA", "arc.direksiyon_yon.txt");

		private ARC.RealFfb.DireksiyonYonu ArcYon()
		{
			if (_arcYon != null)
			{
				return _arcYon;
			}
			float kuvvet = 1f;
			try
			{
				foreach (string line in System.IO.File.ReadAllLines(ArcYonDosyasi))
				{
					string[] p = line.Split('|');
					if (p.Length == 2 && p[0] == DeviceName)
					{
						kuvvet = (p[1].Trim() == "-1") ? (-1f) : 1f;
					}
				}
			}
			catch
			{
			}
			_arcYon = new ARC.RealFfb.DireksiyonYonu(_settings.InvertSteering, kuvvet);
			Logger.Info($"ARC direksiyon: {DeviceName} kuvvet yönü {kuvvet}, konum ters {_settings.InvertSteering}");
			return _arcYon;
		}

		private void ArcYonuKaydet()
		{
			try
			{
				List<string> list = (System.IO.File.Exists(ArcYonDosyasi) ? System.IO.File.ReadAllLines(ArcYonDosyasi).ToList() : new List<string>());
				list.RemoveAll((string l) => l.StartsWith(DeviceName + "|"));
				list.Add($"{DeviceName}|{((ArcYon().Kuvvet < 0f) ? "-1" : "1")}");
				System.IO.File.WriteAllLines(ArcYonDosyasi, list);
			}
			catch
			{
			}
		}

		private EffectParameters CreateLegacyEffectParams()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0039: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Expected Obj, but got Unknown
			EffectParameters val = new EffectParameters
			{
				Flags = (EffectFlags)18,
				Duration = int.MaxValue,
				Gain = 10000,
				SamplePeriod = 0,
				TriggerButton = -1,
				TriggerRepeatInterval = 0,
				StartDelay = 0
			};
			val.SetAxes(new int[1], new int[1]);
			return val;
		}

		private EffectParameters CreateDriverSafeEffectParams()
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0009: Unknown result type (might be due to invalid IL or missing references)
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0019: Unknown result type (might be due to invalid IL or missing references)
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0039: Unknown result type (might be due to invalid IL or missing references)
			//IL_0041: Expected Obj, but got Unknown
			EffectParameters val = new EffectParameters
			{
				Flags = (EffectFlags)16,
				Duration = 10000,
				Gain = 10000,
				SamplePeriod = 0,
				TriggerButton = -1,
				TriggerRepeatInterval = 0,
				StartDelay = 0
			};
			val.SetAxes(new int[1], new int[1]);
			return val;
		}

		/// <param name="otopilot">ARC: otopilot direksiyonu sürüyor mu. Kuvvet yönü yalnız o zaman, konum yönü yalnız elle sürerken öğrenilir.</param>
		public void UpdateToAngle(float targetAngle, bool otopilot)
		{
			lock (_lock)
			{
				if (!IsInitialized || ConstantForceEffect == null || _effectUpdateDisabled)
				{
					return;
				}
				try
				{
					JoystickState currentState = ((CustomDevice<JoystickState, RawJoystickState, JoystickUpdate>)(object)Joystick).GetCurrentState();
					float num = ((float)currentState.X - 32767.5f) / 32767.5f;
					ARC.RealFfb.DireksiyonYonu yon = ArcYon();
					targetAngle = Math.Clamp(targetAngle, -1f, 1f);
					if (!otopilot && yon.KonumGozle(num, targetAngle))
					{
						_integralError = 0f;
						_last = 0f;
						Logger.Info($"ARC direksiyon: {DeviceName} konumu ters okunuyordu, düzeltildi (konum ters {yon.KonumTers}).");
						ArcKonumDegisti?.Invoke(yon.KonumTers);
					}
					float num2 = yon.Konum(num);
					float num3 = targetAngle - num2;
					_integralError += num3;
					_integralError = Math.Clamp(_integralError, 0f - _settings.MaxIntegral, _settings.MaxIntegral);
					if (Math.Sign(num3) != Math.Sign(_lastError))
					{
						_integralError *= 0.5f;
					}
					float num4 = num3 - _lastError;
					_lastError = num3;
					float num5 = num3 * _settings.Kp + _integralError * _settings.Ki + num4 * _settings.Kd;
					float num6 = Math.Abs(num3);
					if (_settings.CenterBoost > 0f && num6 > 0f && num6 < 0.18f)
					{
						float num7 = num6 / 0.18f;
						float num8 = (float)Math.Sign(num3) * (num7 * _settings.CenterBoost);
						num5 += num8;
					}
					num5 = Math.Clamp(num5, 0f - _settings.MaxPidForce, _settings.MaxPidForce);
					if (otopilot && yon.KuvvetGozle(num2, num3, num5, Environment.TickCount64 / 1000.0))
					{
						_integralError = 0f;
						_last = 0f;
						ArcYonuKaydet();
						Logger.Info($"ARC direksiyon: {DeviceName} ters dönüyordu, kuvvet yönü düzeltildi ({yon.Kuvvet}).");
					}
					num5 += _bumpForce;
					num5 = Math.Clamp(num5, 0f - _settings.MaxTotalForce, _settings.MaxTotalForce);
					int magnitude = (int)((_last = _last * _settings.Smoothing + num5 * (1f - _settings.Smoothing)) * 10000f * yon.Kuvvet);
					if (_cachedEffectParams == null)
					{
						_cachedEffectParams = CreateDriverSafeEffectParams();
					}
					_cachedConstantForce.Magnitude = magnitude;
					_cachedEffectParams.Parameters = (TypeSpecificParameters)(object)_cachedConstantForce;
					ConstantForceEffect.SetParameters(_cachedEffectParams, (EffectParameterFlags)256);
				}
				catch (Exception ex)
				{
					DateTime utcNow = DateTime.UtcNow;
					if ((utcNow - _lastForceErrorLog).TotalSeconds > 10.0)
					{
						Logger.Warn("Driver rejected force update for " + DeviceName + ": " + ex.Message, "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 184);
						_lastForceErrorLog = utcNow;
					}
					_effectUpdateDisabled = true;
				}
			}
		}

		public bool InitializeEffect()
		{
			//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
			//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f8: Expected Obj, but got Unknown
			//IL_010f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0116: Expected Obj, but got Unknown
			try
			{
				IList<EffectInfo> effects = ((Device)Joystick).GetEffects();
				foreach (EffectInfo item in effects)
				{
					if (item.Guid == EffectGuid.ConstantForce)
					{
						ConstantForceInfo = item;
						break;
					}
				}
				if (ConstantForceInfo == null)
				{
					Logger.Warn("No constant force effect found for " + DeviceName, "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 208);
					return false;
				}
				(string, EffectParameters)[] array = new (string, EffectParameters)[2]
				{
					("legacy", CreateLegacyEffectParams()),
					("safe", CreateDriverSafeEffectParams())
				};
				(string, EffectParameters)[] array2 = array;
				for (int i = 0; i < array2.Length; i++)
				{
					var (value, val) = array2[i];
					try
					{
						ConstantForce parameters = new ConstantForce
						{
							Magnitude = 0
						};
						val.Parameters = (TypeSpecificParameters)(object)parameters;
						Effect val2 = new Effect((Device)(object)Joystick, EffectGuid.ConstantForce, val);
						val2.Start();
						_cachedEffectParams = val;
						ConstantForceEffect = val2;
						IsInitialized = true;
						Logger.Success($"Initialized force feedback for {DeviceName} using {value} DirectInput profile", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 231);
						return true;
					}
					catch (Exception ex)
					{
						Logger.Warn($"Device {DeviceName} rejected {value} DirectInput profile: {ex.Message}", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 236);
						Effect? constantForceEffect = ConstantForceEffect;
						if (constantForceEffect != null)
						{
							((DisposeBase)constantForceEffect).Dispose();
						}
						ConstantForceEffect = null;
					}
				}
				IsInitialized = false;
				return false;
			}
			catch (Exception ex2)
			{
				Logger.Warn("Device " + DeviceName + " rejected DirectInput constant force effect: " + ex2.Message, "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 247);
				IsInitialized = false;
				Effect? constantForceEffect2 = ConstantForceEffect;
				if (constantForceEffect2 != null)
				{
					((DisposeBase)constantForceEffect2).Dispose();
				}
				ConstantForceEffect = null;
				return false;
			}
		}

		public void InitializeEngineEffect()
		{
			//IL_0065: Unknown result type (might be due to invalid IL or missing references)
			//IL_006a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0072: Unknown result type (might be due to invalid IL or missing references)
			//IL_007e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0087: Expected Obj, but got Unknown
			//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bc: Expected Obj, but got Unknown
			try
			{
				IList<EffectInfo> effects = ((Device)Joystick).GetEffects();
				if (!effects.Any((EffectInfo x) => x.Guid == EffectGuid.Sine))
				{
					Logger.Warn("Sine wave effect not supported by " + DeviceName + " - engine vibration disabled", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 262);
					return;
				}
				PeriodicForce parameters = new PeriodicForce
				{
					Magnitude = 0,
					Period = 100000,
					Phase = 0
				};
				_cachedEngineParams = CreateDriverSafeEffectParams();
				_cachedEngineParams.Parameters = (TypeSpecificParameters)(object)parameters;
				EngineEffect = new Effect((Device)(object)Joystick, EffectGuid.Sine, _cachedEngineParams);
				EngineEffect.Start();
				Logger.Info("Initialized engine vibration for " + DeviceName, "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 278);
			}
			catch (Exception ex)
			{
				Logger.Warn("Failed to initialize engine vibration: " + ex.Message, "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 282);
			}
		}

		public void UpdateTelemetry(float rpm, float speed, Vector3 acceleration)
		{
			lock (_lock)
			{
				if (_settings.EnableBumpEffects)
				{
					float y = acceleration.Y;
					float num = Math.Abs(y - _lastAccel.Y);
					if (num > 0.05f)
					{
						float num2 = Math.Clamp(num * _settings.BumpSensitivity, 0f, 0.2f);
						if (DateTime.Now.Ticks % 2 == 0)
						{
							num2 = 0f - num2;
						}
						_bumpForce += num2;
						_bumpForce = Math.Clamp(_bumpForce, 0f - _settings.MaxBumpForce, _settings.MaxBumpForce);
					}
				}
				_bumpForce *= 0.85f;
				_lastAccel = acceleration;
				if (!_settings.EnableEngineVibration || EngineEffect == null || _cachedEngineParams == null)
				{
					return;
				}
				try
				{
					int magnitude = 0;
					int period = 100000;
					if (rpm > 100f)
					{
						period = (int)Math.Clamp(60000000f / rpm, 1000f, 200000f);
						float num3 = 0.05f;
						if (rpm < 700f)
						{
							num3 += 0.15f * (1f - (rpm - 300f) / 400f);
						}
						if (rpm > 1500f)
						{
							num3 += 0.1f * ((rpm - 1500f) / 1000f);
						}
						magnitude = (int)(Math.Clamp(num3, 0f, 0.4f) * 10000f * _settings.EngineVibrationScale);
					}
					_cachedPeriodic.Magnitude = magnitude;
					_cachedPeriodic.Period = period;
					_cachedEngineParams.Parameters = (TypeSpecificParameters)(object)_cachedPeriodic;
					EngineEffect.SetParameters(_cachedEngineParams, (EffectParameterFlags)256);
				}
				catch
				{
				}
			}
		}

		public void StopEffect()
		{
			lock (_lock)
			{
				try
				{
					if (IsInitialized && ConstantForceEffect != null && _cachedEffectParams != null)
					{
						_cachedConstantForce.Magnitude = 0;
						_cachedEffectParams.Parameters = (TypeSpecificParameters)(object)_cachedConstantForce;
						ConstantForceEffect.SetParameters(_cachedEffectParams, (EffectParameterFlags)256);
					}
					IsInitialized = false;
					Effect? constantForceEffect = ConstantForceEffect;
					if (constantForceEffect != null)
					{
						constantForceEffect.Stop();
					}
					Effect? constantForceEffect2 = ConstantForceEffect;
					if (constantForceEffect2 != null)
					{
						((DisposeBase)constantForceEffect2).Dispose();
					}
					ConstantForceEffect = null;
					Effect? engineEffect = EngineEffect;
					if (engineEffect != null)
					{
						engineEffect.Stop();
					}
					Effect? engineEffect2 = EngineEffect;
					if (engineEffect2 != null)
					{
						((DisposeBase)engineEffect2).Dispose();
					}
					EngineEffect = null;
				}
				catch (Exception)
				{
				}
			}
		}

		public void Dispose()
		{
			StopEffect();
			try
			{
				if (Joystick != null)
				{
					try
					{
						((Device)Joystick).Properties.AutoCenter = true;
						Logger.Info("Re-enabled auto-center for " + DeviceName, "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 372);
					}
					catch
					{
					}
				}
				Joystick joystick = Joystick;
				if (joystick != null)
				{
					((Device)joystick).Unacquire();
				}
				Joystick joystick2 = Joystick;
				if (joystick2 != null)
				{
					((DisposeBase)joystick2).Dispose();
				}
				Logger.Info("Disposed wheel: " + DeviceName, "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 379);
			}
			catch (Exception)
			{
			}
		}
	}
	public class ForceFeedback : Plugin
	{
		private delegate bool EnumWindowsProc(nint hWnd, nint lParam);

		private List<WheelDevice> _wheels = new List<WheelDevice>();

		public float TargetAngle = 0f;

		private float _lastRpm = 0f;

		private float _lastSpeed = 0f;

		private Vector3 _lastAcceleration = Vector3.Zero;

		private nint _windowHandle = IntPtr.Zero;

		private int _scanRetryCount = 0;

		private const int MaxScanRetries = 300;

		private bool _isScanning = false;

		private readonly object _scanLock = new object();

		private SettingsHandler? _settingsHandler;

		private FfbSettings _settings = new FfbSettings();

		private const string SettingsFilename = "realffb_settings.json";

		public override float TickRate => 60f;

		public override PluginInformation Info
		{
			get
			{
				//IL_0000: Unknown result type (might be due to invalid IL or missing references)
				//IL_0005: Unknown result type (might be due to invalid IL or missing references)
				//IL_0011: Unknown result type (might be due to invalid IL or missing references)
				//IL_001d: Unknown result type (might be due to invalid IL or missing references)
				//IL_0029: Unknown result type (might be due to invalid IL or missing references)
				//IL_0035: Unknown result type (might be due to invalid IL or missing references)
				//IL_0041: Unknown result type (might be due to invalid IL or missing references)
				//IL_004e: Expected Obj, but got Unknown
				return new PluginInformation
				{
					Id = "zkhan4509.realforcefeedback",
					Name = "Real Force Feedback",
					Description = "Recreates force feedback effects from ETS2/ATS As well as it fixes the wheel turning the opposite direction when using ETS2LA",
					Version = "1.0.0",
					SupportedETS2LA = "*",
					AuthorName = "Zkhan4509"
				};
			}
		}

		[DllImport("user32.dll")]
		private static extern nint GetForegroundWindow();

		[DllImport("user32.dll")]
		private static extern nint GetDesktopWindow();

		[DllImport("kernel32.dll")]
		private static extern nint GetConsoleWindow();

		[DllImport("user32.dll")]
		private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, nint lParam);

		[DllImport("user32.dll")]
		private static extern bool IsWindowVisible(nint hWnd);

		[DllImport("user32.dll")]
		private static extern int GetWindowThreadProcessId(nint hWnd, out int lpdwProcessId);

		private nint GetWindowHandle()
		{
			int currentProcessId = Process.GetCurrentProcess().Id;
			nint consoleHandle = GetConsoleWindow();
			nint found = IntPtr.Zero;
			EnumWindows((nint hWnd, nint _) =>
			{
				if (!IsWindowVisible(hWnd))
				{
					return true;
				}
				if (hWnd == consoleHandle)
				{
					return true;
				}
				GetWindowThreadProcessId(hWnd, out var lpdwProcessId);
				if (lpdwProcessId == currentProcessId)
				{
					found = hWnd;
					return false;
				}
				return true;
			}, IntPtr.Zero);
			if (found != IntPtr.Zero)
			{
				Logger.Info($"Using app window handle: {found}", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 455);
				return found;
			}
			nint foregroundWindow = GetForegroundWindow();
			if (foregroundWindow != IntPtr.Zero)
			{
				return foregroundWindow;
			}
			nint desktopWindow = GetDesktopWindow();
			if (desktopWindow != IntPtr.Zero)
			{
				return desktopWindow;
			}
			Logger.Warn("No valid window handle found for force feedback. Will retry on next scan.", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 464);
			return IntPtr.Zero;
		}

		private void ScanForWheels()
		{
			//IL_0219: Expected Obj, but got Unknown
			//IL_0198: Expected Obj, but got Unknown
			lock (_scanLock)
			{
				if (_isScanning)
				{
					return;
				}
				_isScanning = true;
			}
			try
			{
				List<Joystick> connectedJoysticks = SharpDXControlsBackend.Current._connectedJoysticks;
				Logger.Info($"Found {connectedJoysticks.Count} connected joysticks in ETS2LA controls backend.", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 479);
				foreach (Joystick joystick in connectedJoysticks)
				{
					if (_wheels.Any((WheelDevice w) => w.InstanceGuid == ((Device)joystick).Information.InstanceGuid))
					{
						continue;
					}
					try
					{
						if (_windowHandle != IntPtr.Zero)
						{
							goto IL_0163;
						}
						_windowHandle = GetWindowHandle();
						if (_windowHandle == IntPtr.Zero)
						{
							Logger.Warn("Cannot initialize force feedback: no valid window handle available.", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 493);
							continue;
						}
						Logger.Info($"Using window handle: {_windowHandle}", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 496);
						goto IL_0163;
						IL_0163:
						try
						{
							((Device)joystick).Unacquire();
						}
						catch
						{
						}
						try
						{
							((Device)joystick).SetCooperativeLevel(_windowHandle, (CooperativeLevel)9);
						}
						catch (SharpDXException ex)
						{
							SharpDXException ex2 = ex;
							Logger.Warn($"Exclusive access failed (0x{((Exception)(object)ex2).HResult:X8}), retrying in non-exclusive mode", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 507);
							try
							{
								try
								{
									((Device)joystick).Unacquire();
								}
								catch
								{
								}
								((Device)joystick).SetCooperativeLevel(_windowHandle, (CooperativeLevel)10);
								goto end_IL_0196;
							}
							catch (SharpDXException ex3)
							{
								SharpDXException ex4 = ex3;
								Logger.Warn($"Non-exclusive access also failed (0x{((Exception)(object)ex4).HResult:X8}), skipping device until retry", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 515);
								_windowHandle = IntPtr.Zero;
							}
							continue;
							end_IL_0196:;
						}
						((Device)joystick).Acquire();
						try
						{
							((Device)joystick).Properties.AutoCenter = false;
						}
						catch (Exception)
						{
						}
						WheelDevice wheelDevice = new WheelDevice(_settings)
						{
							Joystick = joystick,
							DeviceName = ((Device)joystick).Information.InstanceName,
							InstanceGuid = ((Device)joystick).Information.InstanceGuid,
							ArcKonumDegisti = ArcKonumKaydet
						};
						if (!wheelDevice.InitializeEffect())
						{
							Logger.Warn("Skipping unsupported wheel: " + wheelDevice.DeviceName, "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 538);
							continue;
						}
						wheelDevice.InitializeEngineEffect();
						_wheels.Add(wheelDevice);
						wheelDevice.CenterToNeutral();
						Logger.Info("Added wheel: " + wheelDevice.DeviceName, "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 545);
					}
					catch (Exception ex6)
					{
						Logger.Warn("Could not add device " + ((Device)joystick).Information.InstanceName + ": " + ex6.Message, "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 549);
					}
				}
			}
			catch (Exception ex7)
			{
				Logger.Error("Error scanning for wheels: " + ex7.Message, "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 555);
			}
			finally
			{
				lock (_scanLock)
				{
					_isScanning = false;
				}
			}
		}

		public override void Init()
		{
			base.Init();
			Logger.Info("ForceFeedback plugin Init() called", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 569);
			ScanForWheels();
		}

		public override void OnEnable()
		{
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0028: Expected Obj, but got Unknown
			base.OnEnable();
			Logger.Info("ForceFeedback plugin OnEnable() called", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 576);
			_settingsHandler = new SettingsHandler();
			_settings = _settingsHandler.Load<FfbSettings>("realffb_settings.json");
			_settingsHandler.RegisterListener<FfbSettings>("realffb_settings.json", (Action<FfbSettings>)OnSettingsChanged);
			Events.Current.Subscribe<float>("ForceFeedback.Output", (Action<float>)OnControlEvent);
			Events.Current.Subscribe<GameTelemetryData>(GameTelemetry.Current.EventString, (Action<GameTelemetryData>)OnTelemetry);
			ScanForWheels();
		}

		public override void OnDisable()
		{
			base.OnDisable();
			Events.Current.Unsubscribe<float>("ForceFeedback.Output", (Action<float>)OnControlEvent);
			Events.Current.Unsubscribe<GameTelemetryData>(GameTelemetry.Current.EventString, (Action<GameTelemetryData>)OnTelemetry);
			SettingsHandler? settingsHandler = _settingsHandler;
			if (settingsHandler != null)
			{
				settingsHandler.UnregisterListener<FfbSettings>("realffb_settings.json", (Action<FfbSettings>)OnSettingsChanged);
			}
			SettingsHandler? settingsHandler2 = _settingsHandler;
			if (settingsHandler2 != null)
			{
				settingsHandler2.Dispose();
			}
			_settingsHandler = null;
			NotificationHandler.Current.CloseNotification("ForceFeedback.Debug");
			DisposeResources();
		}

		public void OnControlEvent(float steering)
		{
			TargetAngle = steering;
		}

		public void OnTelemetry(GameTelemetryData data)
		{
			_lastRpm = data.truckFloat.engineRpm;
			_lastSpeed = data.truckFloat.speed;
			_lastAcceleration = data.truckVector.acceleration;
			if (data.truckFloat != null)
			{
				TargetAngle = data.truckFloat.gameSteer;
			}
		}

		// ARC: öğrenilen konum yönü ayara yazılır; ARC.DriveAssist müdahale algılamasında aynı ayarı okur.
		private void ArcKonumKaydet(bool ters)
		{
			if (_settings.InvertSteering == ters)
			{
				return;
			}
			_settings.InvertSteering = ters;
			_settingsHandler?.Save("realffb_settings.json", _settings);
		}

		private void OnSettingsChanged(FfbSettings data)
		{
			_settings = data;
			foreach (WheelDevice wheel in _wheels)
			{
				wheel.ApplySettings(data);
			}
			Logger.Info("RealFFB settings updated", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 622);
		}

		public override void Tick()
		{
			try
			{
				if (_wheels.Count == 0 && _scanRetryCount < 300 && !_isScanning)
				{
					_scanRetryCount++;
					_windowHandle = IntPtr.Zero;
					Logger.Info($"Retrying wheel scan (attempt {_scanRetryCount}/{300})...", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 633);
					ScanForWheels();
				}
				List<WheelDevice> list = _wheels.ToList();
				bool otopilot = ETS2LA.State.ApplicationState.Current.EnableAssists;
				foreach (WheelDevice item in list)
				{
					item.UpdateToAngle(TargetAngle, otopilot);
					item.UpdateTelemetry(_lastRpm, _lastSpeed, _lastAcceleration);
				}
			}
			catch (Exception ex)
			{
				Logger.Error("Error in ForceFeedback Tick: " + ex.Message, "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 645);
			}
		}

		private void DisposeResources()
		{
			Logger.Info("Disposing force feedback resources - centering and unlocking wheels...", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 651);
			foreach (WheelDevice wheel in _wheels)
			{
				wheel.Dispose();
			}
			_wheels.Clear();
			_windowHandle = IntPtr.Zero;
			_scanRetryCount = 0;
			Logger.Info("Force feedback resources disposed.", "C:\\Users\\Tumppi066\\Documents\\GitHub\\Ziak-ETS2LA\\RealForceFeedback\\Program.cs", 659);
		}
	}
}
