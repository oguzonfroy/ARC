using System;

namespace ARC.RealFfb;

/// <summary>
///  Direksiyon setinde iki yön birbirinden ayrı öğrenilir (eskiden ikisi de tek "InvertSteering" ayarına bağlıydı;
///  kuvveti ters çalışan sette ayarı ne yapsan direksiyon ya dayanağa kaçıyor ya da aynalanmış açıya oturuyordu):
///  <list type="bullet">
///   <item><b>Konum yönü</b>: ham eksen (sağ +) oyunun direksiyon yönüne (gameSteer, sol +) göre ters mi. Elle sürerken oyunun
///   direksiyonu fiziksel direksiyonu izler; ikisinin işareti karşılaştırılır.</item>
///   <item><b>Kuvvet yönü</b>: +1 / -1, markaya göre değişir. Otopilotta direksiyon hedefe değil hedeften uzağa gidiyorsa
///   kuvvet ters demektir, çevrilir. Yalnız otopilotta öğrenilir: elle sürerken sürücünün eli direksiyonu kuvvetin tersine
///   çevirebilir, bu yanlışlıkla "ters" sanılmasın.</item>
///  </list>
///  Saf hesap: cihaz okumaz, oyunsuz test edilir.
/// </summary>
public sealed class DireksiyonYonu
{
    public const int KonumEsik = 45;   // 60 Hz'de ~0,75 sn tutarlı elle direksiyon
    public const int KuvvetEsik = 8;   // 60 Hz'de ~0,13 sn: müdahale algılaması otopilotu kapatmadan önce
    const float KonumOlu = 0.15f, OyunOlu = 0.1f;

    public bool KonumTers { get; private set; }
    public float Kuvvet { get; private set; }

    int _konumOy, _kuvvetYanlis;
    float _onceki;
    bool _oncekiVar;
    double _sonCevirme = double.NegativeInfinity;

    public DireksiyonYonu(bool konumTers, float kuvvet)
    {
        KonumTers = konumTers;
        Kuvvet = kuvvet < 0f ? -1f : 1f;
    }

    /// <summary>Kullanıcı ayarı elle değiştirdiyse: öğrenme o değerden yeniden başlar.</summary>
    public void KonumAyarla(bool ters)
    {
        if (ters == KonumTers) return;
        KonumTers = ters;
        _konumOy = 0;
    }

    /// <summary>Ham eksen değerini oyun yönüne çevirir.</summary>
    public float Konum(float ham) => KonumTers ? -ham : ham;

    /// <summary>Elle sürerken her kare. Konum yönü değiştiyse true (kaydedilmeli).</summary>
    /// <param name="ham">Direksiyonun ham ekseni, -1..1 (sağ +).</param>
    /// <param name="oyun">Oyunun direksiyonu (gameSteer), -1..1.</param>
    public bool KonumGozle(float ham, float oyun)
    {
        _oncekiVar = false;
        _kuvvetYanlis = 0;
        if (MathF.Abs(ham) < KonumOlu || MathF.Abs(oyun) < OyunOlu) return false;
        var zit = MathF.Sign(ham) != MathF.Sign(oyun);
        _konumOy = Math.Clamp(_konumOy + (zit ? 1 : -1), -KonumEsik, KonumEsik);
        bool yeni = _konumOy >= KonumEsik || (_konumOy > -KonumEsik && KonumTers);
        if (yeni == KonumTers) return false;
        KonumTers = yeni;
        return true;
    }

    /// <summary>Otopilotta her kare. Kuvvet yönü çevrildiyse true (kaydedilmeli, PID birikimi sıfırlanmalı).</summary>
    /// <param name="konum">Direksiyon, oyun yönünde (<see cref="Konum"/>).</param>
    /// <param name="hata">Hedef - konum.</param>
    /// <param name="kuvvet">Uygulanan PID kuvveti (yönsüz), -1..1.</param>
    /// <param name="zaman">Saniye; iki çevirme arasında en az 1 sn olur.</param>
    public bool KuvvetGozle(float konum, float hata, float kuvvet, double zaman)
    {
        if (!_oncekiVar)
        {
            _onceki = konum;
            _oncekiVar = true;
            return false;
        }
        var hareket = konum - _onceki;
        _onceki = konum;
        if (MathF.Abs(hata) < 0.06f || MathF.Abs(hareket) < 0.0015f || MathF.Abs(kuvvet) < 0.05f) return false;
        // Kuvvet hatayı kapatacak yöne itiyor; direksiyon tersine gidiyorsa kuvvet yönü yanlıştır.
        _kuvvetYanlis = MathF.Sign(hareket) != MathF.Sign(hata) ? _kuvvetYanlis + 1 : Math.Max(0, _kuvvetYanlis - 2);
        if (_kuvvetYanlis < KuvvetEsik || zaman - _sonCevirme < 1.0) return false;
        Kuvvet = -Kuvvet;
        _kuvvetYanlis = 0;
        _sonCevirme = zaman;
        return true;
    }
}
