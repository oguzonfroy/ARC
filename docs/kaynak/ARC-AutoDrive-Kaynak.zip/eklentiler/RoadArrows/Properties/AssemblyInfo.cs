using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("ARC.RoadArrows")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+efdd7cd6b328e43bbe303d82352082fe1a16e996")]
[assembly: AssemblyProduct("ARC.RoadArrows")]
[assembly: AssemblyTitle("ARC.RoadArrows")]
[assembly: AssemblyVersion("1.0.0.0")]
