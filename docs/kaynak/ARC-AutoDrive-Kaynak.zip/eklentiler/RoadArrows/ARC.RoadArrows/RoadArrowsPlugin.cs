using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Numerics;
using System.Threading;
using ETS2LA.Backend;
using ETS2LA.Backend.Events;
using ETS2LA.Game.SDK;
using ETS2LA.Game.Telemetry;
using ETS2LA.Logging;
using ETS2LA.Overlay;
using ETS2LA.Overlay.AR;
using ETS2LA.Shared;
using PathLib;
using TruckLib;

namespace ARC.RoadArrows;

public class RoadArrowsPlugin : Plugin
{
	private const string RendererName = "ARCRoadArrows";

	private const int TickMs = 50;

	private volatile PlannedPathData? pathfindingPath;

	private long pathfindingStamp;

	private volatile GameTelemetryData? telemetry;

	private volatile NavigationData? navigation;

	private volatile Arrow[] arrows = Array.Empty<Arrow>();

	private volatile bool running;

	private bool rendererRegistered;

	private DateTime plannerRetry = DateTime.MinValue;

	private float odometer;

	private Vector3? lastTruck;

	private readonly VisualRoute visualRoute = new VisualRoute();

	private readonly Action<PlannedPathData> onPath;

	private readonly Action<GameTelemetryData> onTelemetry;

	private readonly Action<NavigationData> onNavigation;

	private string sonTeshis = "";

	private DateTime sonTeshisZamani;

	public override PluginInformation Info
	{
		get
		{
			PluginInformation pluginInformation = new PluginInformation { Name = "", Description = "", Version = "", Id = "" };
			pluginInformation.Id = "arc.roadarrows";
			pluginInformation.Name = "ARC Yol Okları";
			pluginInformation.Description = "GPS rotasına göre yolun üstüne Forza tarzı beyaz yönlendirme okları çizer. Gösterge Paneli > Sürüş bölümünden açılıp kapanır.";
			pluginInformation.Version = "1.1.0";
			pluginInformation.AuthorName = "ARC Studio";
			pluginInformation.Tags = new string[2] { "Visualization", "Navigation" };
			pluginInformation.HideEnableDisableButton = true;
			pluginInformation.DependsOn = new List<PluginDependency>
			{
				new PluginDependency
				{
					Id = "tumppi066.pathlib"
				}
			};
			return pluginInformation;
		}
	}

	private bool plannerFailed => DateTime.Now < plannerRetry;

	public static bool Enabled
	{
		get
		{
			if (OverlaySettingsHandler.Current.GetSettings().ShowRoadArrows)
			{
				return !ArcLisans.Kilitli;
			}
			return false;
		}
	}

	public RoadArrowsPlugin()
	{
		onPath = (PlannedPathData data) =>
		{
			pathfindingPath = data;
			Interlocked.Exchange(ref pathfindingStamp, Stopwatch.GetTimestamp());
		};
		onTelemetry = (GameTelemetryData data) =>
		{
			telemetry = data;
		};
		onNavigation = (NavigationData data) =>
		{
			navigation = data;
		};
	}

	public override void Init()
	{
		base.Init();
		Events.Current.Subscribe("Pathfinding.PlannedPathData", onPath);
		Events.Current.Subscribe(GameTelemetry.Current.EventString, onTelemetry);
		Events.Current.Subscribe(NavigationProvider.Current.EventString, onNavigation);
		running = true;
		Thread thread = new Thread(Loop);
		thread.IsBackground = true;
		thread.Name = "ARC Yol Okları";
		thread.Start();
	}

	public override void Shutdown()
	{
		running = false;
		Events.Current.Unsubscribe("Pathfinding.PlannedPathData", onPath);
		Events.Current.Unsubscribe(GameTelemetry.Current.EventString, onTelemetry);
		Events.Current.Unsubscribe(NavigationProvider.Current.EventString, onNavigation);
		if (rendererRegistered)
		{
			OverlayHandler.Current.AR?.UnregisterRenderCallback("ARCRoadArrows");
		}
		base.Shutdown();
	}

	private void Loop()
	{
		while (running)
		{
			try
			{
				RegisterRendererOnce();
				Update();
			}
			catch (Exception ex)
			{
				Logger.Error("ARC Yol Okları: " + ex.Message, "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\Plugins\\ARC.RoadArrows\\RoadArrowsPlugin.cs", 101);
				arrows = Array.Empty<Arrow>();
			}
			Thread.Sleep(50);
		}
	}

	private void RegisterRendererOnce()
	{
		if (!rendererRegistered && OverlayHandler.Current.AR != null)
		{
			OverlayHandler.Current.AR.RegisterRenderCallback(new ARRenderCallback
			{
				Definition = new ARRendererDefinition
				{
					Name = "ARCRoadArrows"
				},
				Render3D = Render
			});
			rendererRegistered = true;
		}
	}

	private PlannedPathData? CurrentPath(GameTelemetryData t)
	{
		PlannedPathData plannedPathData = pathfindingPath;
		bool flag = Stopwatch.GetElapsedTime(Interlocked.Read(in pathfindingStamp)).TotalSeconds < 1.0;
		if (((plannedPathData != null) & flag) && !plannedPathData.HasError && plannedPathData.PlannedPath.Count > 0)
		{
			visualRoute.Reset();
			return plannedPathData;
		}
		if (plannerFailed || !VisualRoute.PathfindingAvailable)
		{
			return null;
		}
		try
		{
			return visualRoute.Update(t, navigation);
		}
		catch (Exception ex) when ((ex is FileNotFoundException || ex is FileLoadException || ex is TypeLoadException) ? true : false)
		{
			plannerRetry = DateTime.Now.AddSeconds(5.0);
			Teshis("Pathfinding henüz yüklü değil, 5 sn sonra yeniden denenecek (" + ex.Message + ")");
			return null;
		}
	}

	private void Teshis(string durum)
	{
		if (!(durum == sonTeshis) || !(DateTime.Now - sonTeshisZamani < TimeSpan.FromSeconds(10L)))
		{
			sonTeshis = durum;
			sonTeshisZamani = DateTime.Now;
			Logger.Info("ARC Yol Okları: " + durum, "C:\\Users\\oguzs\\arc-harita\\ets2la\\ETS2LA-main\\Plugins\\ARC.RoadArrows\\RoadArrowsPlugin.cs", 155);
		}
	}

	private void Update()
	{
		GameTelemetryData gameTelemetryData = telemetry ?? GameTelemetry.Current.GetCurrentData();
		RoadArrowsSettings current = RoadArrowsSettings.Current;
		if (!Enabled || gameTelemetryData == null || gameTelemetryData.paused)
		{
			arrows = Array.Empty<Arrow>();
			lastTruck = null;
			if (!Enabled)
			{
				visualRoute.Reset();
			}
			else
			{
				Teshis((gameTelemetryData == null) ? "telemetri yok" : "oyun duraklatılmış");
			}
			return;
		}
		PlannedPathData plannedPathData = CurrentPath(gameTelemetryData);
		if (plannedPathData == null || plannedPathData.PlannedPath.Count == 0)
		{
			arrows = Array.Empty<Arrow>();
			RoadArrowsPlugin roadArrowsPlugin = this;
			string durum;
			if (plannerFailed)
			{
				durum = "rota planlayıcı başlatılamadı";
			}
			else
			{
				durum = ((!VisualRoute.PathfindingAvailable) ? "Pathfinding derlemesi bulunamadı" : ("rota yok (" + visualRoute.LastState + ")"));
			}
			roadArrowsPlugin.Teshis(durum);
			return;
		}
		Vector3 vector = gameTelemetryData.truckPlacement.coordinate.ToVector3();
		Vector3? vector2 = lastTruck;
		if (vector2.HasValue)
		{
			Vector3 valueOrDefault = vector2.GetValueOrDefault();
			float num = Vector2.Distance(new Vector2(vector.X, vector.Z), new Vector2(valueOrDefault.X, valueOrDefault.Z));
			if (num < 50f)
			{
				odometer = (odometer + num) % 100000f;
			}
		}
		lastTruck = vector;
		float totalLength = plannedPathData.TotalLength;
		float num2 = plannedPathData.GetFactorForPoint(vector) * totalLength;
		float max = Math.Min(current.MaxDistance, totalLength - num2 - 4f);
		List<Arrow> list = new List<Arrow>();
		foreach (float item in ArrowLayout.Distances(odometer, current.Spacing, current.StartDistance, max))
		{
			OrientedPoint? orientedPoint = plannedPathData.InterpolateDist(num2 + item);
			OrientedPoint? orientedPoint2 = plannedPathData.InterpolateDist(num2 + item + 4f);
			if (!orientedPoint.HasValue || !orientedPoint2.HasValue)
			{
				break;
			}
			float num3 = ArrowLayout.Fade(item, current.StartDistance, current.MaxDistance, current.Opacity);
			if (!(num3 <= 0.01f))
			{
				Arrow? arrow = ArrowLayout.Build(orientedPoint.Value.Position, orientedPoint2.Value.Position, current.Size, num3, item);
				if (arrow.HasValue)
				{
					Arrow valueOrDefault2 = arrow.GetValueOrDefault();
					list.Add(valueOrDefault2);
				}
			}
		}
		arrows = list.ToArray();
		Teshis($"{arrows.Length} ok çiziliyor (rota {totalLength:F0} m, {((plannedPathData == pathfindingPath) ? "Pathfinding" : "görsel planlayıcı")})");
	}

	private readonly long baslangic = Stopwatch.GetTimestamp();

	private static void Katman(ARRenderer aR, Arrow arrow, float olcek, float kalinlik, uint renk, float yukseklik)
	{
		if ((renk >> 24) < 3)
		{
			return;
		}
		var (sol, sag) = ArrowLayout.Chevron(arrow, olcek, kalinlik, yukseklik);
		// ARC: oklar artık oyunun içinde çizilir; veri ARC.DriveAssist üzerinden gider.
		float a = (renk >> 24) / 255f, b = ((renk >> 16) & 0xFF) / 255f, g = ((renk >> 8) & 0xFF) / 255f, r = (renk & 0xFF) / 255f;
		foreach (Vector3[] parca in new[] { sol, sag })
		{
			for (int k = 0; k < 4; k++)
			{
				arcOklar.AddRange(new[] { parca[k].X, parca[k].Y, parca[k].Z });
			}
			arcOklar.AddRange(new[] { r, g, b, a });
		}
	}

	private static readonly List<float> arcOklar = new List<float>();

	private void Render()
	{
		arcOklar.Clear();
		try
		{
			RenderIc();
		}
		finally
		{
			ETS2LA.Backend.Events.Events.Current.Publish("ARC.Hud.Arrows", arcOklar.ToArray());
		}
	}

	private void RenderIc()
	{
		Arrow[] array = arrows;
		if (array.Length != 0 && Enabled)
		{
			ARRenderer aR = OverlayHandler.Current.AR;
			uint rgb = ArrowLayout.ParseRgb(OverlaySettingsHandler.Current.GetSettings().RoadArrowColor);
			uint parlak = ArrowLayout.Mix(rgb, 16777215u, 0.6f);
			uint koyu = ArrowLayout.Mix(rgb, 0u, 0.85f);
			// Oklar boyunca ileri doğru akan yumuşak bir ışık dalgası
			float zaman = (float)Stopwatch.GetElapsedTime(baslangic).TotalSeconds;
			for (int num = array.Length - 1; num >= 0; num--)
			{
				Arrow arrow = array[num];
				float dalga = 0.5f + 0.5f * MathF.Sin(arrow.Distance * 0.32f - zaman * 5.5f);
				float a = arrow.Alpha;
				// 1) yumuşak gölge: yolda okunurluğu artırır
				Katman(aR, arrow, 1.1f, 1.7f, ArrowLayout.Color(koyu, a * 0.42f), -0.01f);
				// 2) dış parıltı: dalga geçerken güçlenir
				Katman(aR, arrow, 1.3f, 2.7f, ArrowLayout.Color(rgb, a * (0.1f + 0.2f * dalga)), 0f);
				// 3) gövde
				Katman(aR, arrow, 1f, 1f, ArrowLayout.Color(rgb, a * (0.82f + 0.18f * dalga)), 0.005f);
				// 4) iç parlak çizgi
				Katman(aR, arrow, 0.9f, 0.32f, ArrowLayout.Color(parlak, a * (0.55f + 0.45f * dalga)), 0.01f);
			}
		}
	}
}
