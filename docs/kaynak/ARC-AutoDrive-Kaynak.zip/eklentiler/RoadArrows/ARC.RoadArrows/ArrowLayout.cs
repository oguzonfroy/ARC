using System;
using System.Collections.Generic;
using System.Globalization;
using System.Numerics;

namespace ARC.RoadArrows;

public static class ArrowLayout
{
	public const float HeightAboveRoad = 0.06f;

	public const float LookAhead = 4f;

	// Ok şekli (boyut 1 için, metre): uzunluk, genişlik ve kol kalınlığı — küçük ama görünür (önceki boyutun ~1/3ü)
	private const float Uzunluk = 0.42f;

	private const float Genislik = 0.70f;

	private const float Kalinlik = 0.13f;

	public static List<float> Distances(float odometer, float spacing, float start, float max)
	{
		List<float> list = new List<float>();
		float num = ((odometer + start) % spacing + spacing) % spacing;
		for (float num2 = start + ((num == 0f) ? 0f : (spacing - num)); num2 <= max; num2 += spacing)
		{
			list.Add(num2);
		}
		return list;
	}

	public static Arrow? Build(Vector3 point, Vector3 ahead, float size, float alpha, float distance)
	{
		Vector3 ileri = ahead - point;
		ileri.Y *= 0.5f;
		if (ileri.LengthSquared() < 0.0001f)
		{
			return null;
		}
		ileri = Vector3.Normalize(ileri);
		Vector3 sag = Vector3.Cross(Vector3.UnitY, ileri);
		if (sag.LengthSquared() < 1E-06f)
		{
			return null;
		}
		sag = Vector3.Normalize(sag);
		return new Arrow(point + new Vector3(0f, HeightAboveRoad, 0f), ileri, sag, size, alpha, distance);
	}

	// Tek bir V (chevron) katmanının iki kolunu üretir. olcek: genel büyüklük, kalinlikCarpani: kol kalınlığı.
	public static (Vector3[] Sol, Vector3[] Sag) Chevron(Arrow a, float olcek, float kalinlikCarpani, float yukseklik = 0f)
	{
		float boy = Uzunluk * a.Size * olcek;
		float en = Genislik * a.Size * olcek;
		float kalinlik = Kalinlik * a.Size * kalinlikCarpani;
		float fazla = (kalinlik - Kalinlik * a.Size) * 0.5f;
		Vector3 merkez = a.Center + new Vector3(0f, yukseklik, 0f);
		Vector3 uc = merkez + a.Forward * (boy / 2f + fazla);
		Vector3 geri = -a.Forward * kalinlik;
		Vector3 solKol = merkez - a.Forward * (boy / 2f - fazla) + a.Right * (en / 2f + fazla);
		Vector3 sagKol = merkez - a.Forward * (boy / 2f - fazla) - a.Right * (en / 2f + fazla);
		return (new Vector3[4]
		{
			uc,
			solKol,
			solKol + geri,
			uc + geri
		}, new Vector3[4]
		{
			uc,
			sagKol,
			sagKol + geri,
			uc + geri
		});
	}

	public static float Fade(float d, float start, float max, float opacity)
	{
		float num = Math.Clamp((d - start) / 4f + 0.35f, 0f, 1f);
		float num2 = Math.Clamp((max - d) / (max * 0.35f), 0f, 1f);
		return opacity * num * num2 * num2;
	}

	public static uint White(float alpha)
	{
		return Color(16777215u, alpha);
	}

	// ImGui renkleri ABGR sırasındadır (0xAABBGGRR). Ayardaki renk #RRGGBB olduğu için kırmızı ile mavi yer değiştirilir.
	// Eskiden bu çevrim yapılmadığı için kırmızı seçilince mavi, mavi seçilince turuncu görünüyordu.
	public static uint Color(uint rgb, float alpha)
	{
		uint r = (rgb >> 16) & 0xFF;
		uint g = (rgb >> 8) & 0xFF;
		uint b = rgb & 0xFF;
		return ((uint)Math.Clamp(alpha * 255f, 0f, 255f) << 24) | (b << 16) | (g << 8) | r;
	}

	public static uint Mix(uint rgb, uint other, float t)
	{
		t = Math.Clamp(t, 0f, 1f);
		uint Kanal(int kaydir)
		{
			float a = (rgb >> kaydir) & 0xFF;
			float b = (other >> kaydir) & 0xFF;
			return (uint)Math.Clamp(a + (b - a) * t, 0f, 255f);
		}
		return (Kanal(16) << 16) | (Kanal(8) << 8) | Kanal(0);
	}

	public static uint ParseRgb(string? hex)
	{
		string text = (hex ?? "").Trim().TrimStart('#');
		if (text.Length == 3)
		{
			text = $"{text[0]}{text[0]}{text[1]}{text[1]}{text[2]}{text[2]}";
		}
		if (text.Length != 6 || !uint.TryParse(text, NumberStyles.HexNumber, null, out var result))
		{
			return 16777215u;
		}
		return result;
	}
}
