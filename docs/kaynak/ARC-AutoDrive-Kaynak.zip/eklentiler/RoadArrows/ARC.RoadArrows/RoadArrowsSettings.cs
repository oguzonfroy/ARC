using System;
using ETS2LA.Settings;

namespace ARC.RoadArrows;

[Serializable]
public class RoadArrowsSettings
{
	[NonSerialized]
	private static readonly Lazy<RoadArrowsSettings> _instance = new Lazy<RoadArrowsSettings>(() => new RoadArrowsSettings(loadSettings: true));

	public float Spacing = 9f;

	public float StartDistance = 7f;

	public float MaxDistance = 90f;

	public float Size = 1f;

	public float Opacity = 0.85f;

	[NonSerialized]
	private SettingsHandler? _settingsHandler;

	public static RoadArrowsSettings Current => _instance.Value;

	public RoadArrowsSettings()
	{
	}

	public RoadArrowsSettings(bool loadSettings)
	{
		if (loadSettings)
		{
			_settingsHandler = new SettingsHandler();
			RoadArrowsSettings roadArrowsSettings = _settingsHandler.Load<RoadArrowsSettings>("arc.roadarrows.json");
			if (roadArrowsSettings != null)
			{
				Spacing = Math.Clamp(roadArrowsSettings.Spacing, 3f, 30f);
				StartDistance = Math.Clamp(roadArrowsSettings.StartDistance, 2f, 40f);
				MaxDistance = Math.Clamp(roadArrowsSettings.MaxDistance, 20f, 200f);
				Size = Math.Clamp(roadArrowsSettings.Size, 0.4f, 2.5f);
				Opacity = Math.Clamp(roadArrowsSettings.Opacity, 0.1f, 1f);
			}
		}
	}

	public void Save()
	{
		_settingsHandler?.Save("arc.roadarrows.json", this);
	}
}
