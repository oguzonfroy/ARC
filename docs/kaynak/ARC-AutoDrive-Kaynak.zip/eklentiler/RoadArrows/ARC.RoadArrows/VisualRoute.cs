using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Runtime.Loader;
using ETS2LA.Game;
using ETS2LA.Game.Data;
using ETS2LA.Game.PpdFiles;
using ETS2LA.Game.SDK;
using ETS2LA.Game.SiiFiles;
using ETS2LA.Game.Telemetry;
using ETS2LA.Shared;
using ETS2LA.State;
using PathLib;
using Pathfinding.Utils;
using TruckLib;
using TruckLib.ScsMap;

namespace ARC.RoadArrows;

internal sealed class VisualRoute
{
	private const int PlanLength = 6;

	private const float MaxOffPath = 7f;

	private MapData? map;

	private Installation? loadedGame;

	private IReadOnlyList<Node>? nearby;

	private readonly Stopwatch sinceMap = new Stopwatch();

	private readonly List<PlannedItem> plan = new List<PlannedItem>();

	public static bool PathfindingAvailable => AppDomain.CurrentDomain.GetAssemblies().Any((Assembly a) => a.GetName().Name == "Pathfinding");

	public string LastState { get; private set; } = "başlamadı";

	static VisualRoute()
	{
		AssemblyLoadContext loadContext = AssemblyLoadContext.GetLoadContext(typeof(VisualRoute).Assembly);
		if (loadContext == null)
		{
			return;
		}
		loadContext.Resolving += (AssemblyLoadContext _, AssemblyName ad) => (!(ad.Name == "Pathfinding")) ? null : AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault((Assembly a) => a.GetName().Name == "Pathfinding");
	}

	public void Reset()
	{
		plan.Clear();
	}

	public PlannedPathData? Update(GameTelemetryData t, NavigationData? nav)
	{
		if (!sinceMap.IsRunning || sinceMap.Elapsed.TotalSeconds > 5.0)
		{
			RefreshMap(t);
			sinceMap.Restart();
		}
		if (map == null || nearby == null || nearby.Count == 0)
		{
			plan.Clear();
			LastState = ((map == null) ? "harita verisi yok" : "yakında yol düğümü yok");
			return null;
		}
		Vector3 vector = t.truckPlacement.coordinate.ToVector3();
		if (plan.Count == 0)
		{
			PlannedItem plannedItem = PathfindingUtils.CreateFirstPlannedItem(nearby, vector, t.truckPlacement.rotation.ToVector3());
			if (plannedItem == null)
			{
				LastState = "tırın altında başlangıç yolu bulunamadı";
				return null;
			}
			plan.Add(plannedItem);
		}
		if (plan.Count < 6)
		{
			PlannedItem plannedItem2 = PathfindingUtils.CreateNextPlannedItem(plan, nav);
			if (plannedItem2 != null)
			{
				plan.Add(plannedItem2);
			}
		}
		float num = XZ(plan[0].Interpolate(plan[0].GetFactorFor(vector)), vector);
		float num2 = float.MaxValue;
		if (plan.Count > 1)
		{
			float factor = Math.Clamp(plan[1].GetFactorFor(vector), 0.01f, 0.99f);
			num2 = XZ(plan[1].Interpolate(factor), vector);
		}
		if (num2 < num && num2 < 7f)
		{
			plan.RemoveAt(0);
		}
		else if (num > 7f)
		{
			plan.Clear();
			LastState = $"tır rotadan {num:F1} m uzakta, yeniden kuruluyor";
			return null;
		}
		LastState = "hazır";
		return new PlannedPathData
		{
			PlannedPath = new List<PlannedItem>(plan),
			HasError = false
		};
	}

	private void RefreshMap(GameTelemetryData t)
	{
		Installation installation = ApplicationState.Current.RunningGame ?? GameHandler.Current.Installations.FirstOrDefault((Installation i) => i.IsParsed);
		if (installation == null)
		{
			return;
		}
		if (installation != loadedGame)
		{
			map = installation.GetMapData();
			IFileSystem fileSystem = installation.GetFileSystem();
			if (fileSystem != null)
			{
				SiiFileHandler.Current.SetFileSystem(fileSystem);
				PpdFileHandler.Current.SetFileSystem(fileSystem);
			}
			if (map != null)
			{
				loadedGame = installation;
			}
		}
		if (map != null)
		{
			Vector3Double coordinate = t.truckPlacement.coordinate;
			nearby = map.Nodes.Within(coordinate.X - 512.0, coordinate.Z - 512.0, coordinate.X + 512.0, coordinate.Z + 512.0);
		}
	}

	private static float XZ(OrientedPoint? p, Vector3 b)
	{
		if (!p.HasValue)
		{
			return float.MaxValue;
		}
		float num = p.Value.Position.X - b.X;
		float num2 = p.Value.Position.Z - b.Z;
		return MathF.Sqrt(num * num + num2 * num2);
	}
}
