using System.Numerics;

namespace ARC.RoadArrows;

// ARC: ok artık hazır köşe noktaları yerine konum + yön tutar; çizim katmanları (gölge, parıltı, gövde, parlak çizgi) çizerken üretilir.
public readonly record struct Arrow(Vector3 Center, Vector3 Forward, Vector3 Right, float Size, float Alpha, float Distance);
