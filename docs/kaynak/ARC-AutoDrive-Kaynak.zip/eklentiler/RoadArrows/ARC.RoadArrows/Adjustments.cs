using System;
using ETS2LA.Overlay;
using ETS2LA.UI.Shared.Components;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;

namespace ARC.RoadArrows;

[Route("/plugins/adjustments/arc.roadarrows")]
public class Adjustments : ComponentBase
{
	private static RoadArrowsSettings S => RoadArrowsSettings.Current;

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full p-5 px-8 gap-3");
		__builder.OpenComponent<SectionTitle>(2);
		__builder.AddComponentParameter(3, "Title", "Yol Okları");
		__builder.CloseComponent();
		__builder.AddMarkupContent(4, "\n\n    ");
		__builder.OpenComponent<Switch>(5);
		__builder.AddComponentParameter(6, "Title", "Yol yönlendirme okları");
		__builder.AddComponentParameter(7, "Description", "GPS rotası yolun üstünde Forza tarzı beyaz oklarla gösterilir. Yalnız görseldir, otonom sürüşü başlatmaz. Oyun 'Pencereli Tam Ekran' modunda olmalı.");
		__builder.AddComponentParameter(8, "Value", RuntimeHelpers.TypeCheck(OverlaySettingsHandler.Current.GetSettings().ShowRoadArrows));
		__builder.AddComponentParameter(9, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool v) =>
		{
			OverlaySettingsHandler.Current.GetSettings().ShowRoadArrows = v;
			OverlaySettingsHandler.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(10, "\n\n    ");
		__builder.OpenComponent<SectionTitle>(11);
		__builder.AddComponentParameter(12, "Class", "mt-6");
		__builder.AddComponentParameter(13, "Title", "Görünüm");
		__builder.CloseComponent();
		__builder.AddMarkupContent(14, "\n\n    ");
		__builder.OpenComponent<Slider>(15);
		__builder.AddComponentParameter(16, "Title", "Ok aralığı");
		__builder.AddComponentParameter(17, "Suffix", " m");
		__builder.AddComponentParameter(18, "Description", "İki ok arasındaki mesafe.");
		__builder.AddComponentParameter(19, "Min", RuntimeHelpers.TypeCheck(3f));
		__builder.AddComponentParameter(20, "Max", RuntimeHelpers.TypeCheck(30f));
		__builder.AddComponentParameter(21, "Step", RuntimeHelpers.TypeCheck(1f));
		__builder.AddComponentParameter(22, "Value", RuntimeHelpers.TypeCheck(S.Spacing));
		__builder.AddComponentParameter(23, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
		{
			Kaydet(() =>
			{
				S.Spacing = v;
			});
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(24, "\n\n    ");
		__builder.OpenComponent<Slider>(25);
		__builder.AddComponentParameter(26, "Title", "İlk ok mesafesi");
		__builder.AddComponentParameter(27, "Suffix", " m");
		__builder.AddComponentParameter(28, "Description", "İlk okun aracın önünde ne kadar uzakta başlayacağı.");
		__builder.AddComponentParameter(29, "Min", RuntimeHelpers.TypeCheck(2f));
		__builder.AddComponentParameter(30, "Max", RuntimeHelpers.TypeCheck(40f));
		__builder.AddComponentParameter(31, "Step", RuntimeHelpers.TypeCheck(1f));
		__builder.AddComponentParameter(32, "Value", RuntimeHelpers.TypeCheck(S.StartDistance));
		__builder.AddComponentParameter(33, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
		{
			Kaydet(() =>
			{
				S.StartDistance = v;
			});
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(34, "\n\n    ");
		__builder.OpenComponent<Slider>(35);
		__builder.AddComponentParameter(36, "Title", "Görüş mesafesi");
		__builder.AddComponentParameter(37, "Suffix", " m");
		__builder.AddComponentParameter(38, "Description", "Okların ufka doğru ne kadar uzağa kadar çizileceği. Uzak oklar yavaşça söner.");
		__builder.AddComponentParameter(39, "Min", RuntimeHelpers.TypeCheck(20f));
		__builder.AddComponentParameter(40, "Max", RuntimeHelpers.TypeCheck(200f));
		__builder.AddComponentParameter(41, "Step", RuntimeHelpers.TypeCheck(5f));
		__builder.AddComponentParameter(42, "Value", RuntimeHelpers.TypeCheck(S.MaxDistance));
		__builder.AddComponentParameter(43, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
		{
			Kaydet(() =>
			{
				S.MaxDistance = v;
			});
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(44, "\n\n    ");
		__builder.OpenComponent<Slider>(45);
		__builder.AddComponentParameter(46, "Title", "Ok boyutu");
		__builder.AddComponentParameter(47, "Suffix", "x");
		__builder.AddComponentParameter(48, "Description", "Okların büyüklüğü.");
		__builder.AddComponentParameter(49, "Min", RuntimeHelpers.TypeCheck(0.4f));
		__builder.AddComponentParameter(50, "Max", RuntimeHelpers.TypeCheck(2.5f));
		__builder.AddComponentParameter(51, "Step", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(52, "Value", RuntimeHelpers.TypeCheck(S.Size));
		__builder.AddComponentParameter(53, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
		{
			Kaydet(() =>
			{
				S.Size = v;
			});
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(54, "\n\n    ");
		__builder.OpenComponent<Slider>(55);
		__builder.AddComponentParameter(56, "Title", "Opaklık");
		__builder.AddComponentParameter(57, "Suffix", "%");
		__builder.AddComponentParameter(58, "Description", "Okların ne kadar belirgin görüneceği.");
		__builder.AddComponentParameter(59, "Min", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(60, "Max", RuntimeHelpers.TypeCheck(100f));
		__builder.AddComponentParameter(61, "Step", RuntimeHelpers.TypeCheck(5f));
		__builder.AddComponentParameter(62, "Value", RuntimeHelpers.TypeCheck(S.Opacity * 100f));
		__builder.AddComponentParameter(63, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float v) =>
		{
			Kaydet(() =>
			{
				S.Opacity = v / 100f;
			});
		})));
		__builder.CloseComponent();
		__builder.CloseElement();
	}

	private void Kaydet(Action degistir)
	{
		degistir();
		S.Save();
	}
}
