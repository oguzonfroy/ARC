using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using ETS2LA.Game.Data;
using ETS2LA.Game.SDK;
using ETS2LA.Logging;
using ETS2LA.Shared;
using PathLib;
using TruckLib;
using TruckLib.ScsMap;

namespace Pathfinding.Utils;

public static class PathfindingUtils
{
	public static double DistanceTo(Vector3Double a, Vector3Double b)
	{
		double num = a.X - b.X;
		double num2 = a.Z - b.Z;
		return Math.Sqrt(num * num + num2 * num2);
	}

	public static double DistanceTo(Vector3 a, Vector3Double b)
	{
		double num = (double)a.X - b.X;
		double num2 = (double)a.Z - b.Z;
		return Math.Sqrt(num * num + num2 * num2);
	}

	public static double DistanceTo(Vector3Double a, Vector3 b)
	{
		double num = a.X - (double)b.X;
		double num2 = a.Z - (double)b.Z;
		return Math.Sqrt(num * num + num2 * num2);
	}

	public static double DistanceTo(Vector3 a, Vector3 b)
	{
		double num = a.X - b.X;
		double num2 = a.Z - b.Z;
		return Math.Sqrt(num * num + num2 * num2);
	}

	public static double DistanceToWithHeight(Vector3 a, Vector3 b)
	{
		double num = a.X - b.X;
		double num2 = a.Y - b.Y;
		double num3 = a.Z - b.Z;
		return Math.Sqrt(num * num + num2 * num2 + num3 * num3);
	}

	public static float DistanceTo(PlannedItem item, Vector3Double position)
	{
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		IParsedItem item2 = item.item;
		ParsedRoad val = (ParsedRoad)(object)((item2 is ParsedRoad) ? item2 : null);
		if (val == null)
		{
			ParsedRoadList val2 = (ParsedRoadList)(object)((item2 is ParsedRoadList) ? item2 : null);
			if (val2 == null)
			{
				if (item2 is ParsedPrefab)
				{
					PrefabPath prefabPath = item.prefabPath;
					if (prefabPath == null)
					{
						return float.MaxValue;
					}
					OrientedPoint? val3 = prefabPath.Interpolate(prefabPath.GetFactorForPoint(position.ToVector3()), 0f);
					if (!val3.HasValue)
					{
						return float.MaxValue;
					}
					OrientedPoint value = val3.Value;
					return (float)DistanceTo(position, value.Position);
				}
				return float.MaxValue;
			}
			float closestFactorFor = GetClosestFactorFor((IParsedItem)(object)val2, position.ToVector3());
			Tuple<Side, int> lane = item.GetLane();
			OrientedPoint val4 = val2.InterpolateLane(closestFactorFor, (Side)((lane == null) ? 1 : ((int)lane.Item1)), item.GetLane()?.Item2 ?? 0, 0f);
			return (float)DistanceTo(position, val4.Position);
		}
		float closestFactorFor2 = GetClosestFactorFor((IParsedItem)(object)val, position.ToVector3());
		Tuple<Side, int> lane2 = item.GetLane();
		OrientedPoint val5 = val.InterpolateLane(closestFactorFor2, (Side)((lane2 == null) ? 1 : ((int)lane2.Item1)), item.GetLane()?.Item2 ?? 0, 0f);
		return (float)DistanceTo(position, val5.Position);
	}

	public static int GetClosestLane(ParsedRoad road, Vector3 position, float bestFactor)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		if (road.GetTotalLaneCount() == 0)
		{
			return -1;
		}
		int result = -1;
		double num = double.MaxValue;
		for (int i = 0; i < road.GetLaneCount((Side)1); i++)
		{
			OrientedPoint val = road.InterpolateLane(bestFactor, (Side)1, i, 0f);
			double num2 = DistanceTo(position, val.Position);
			if (num2 < num)
			{
				num = num2;
				result = i + 1;
			}
		}
		for (int j = 0; j < road.GetLaneCount((Side)0); j++)
		{
			OrientedPoint val2 = road.InterpolateLane(bestFactor, (Side)0, j, 0f);
			double num3 = DistanceTo(position, val2.Position);
			if (num3 < num)
			{
				num = num3;
				result = -(j + 1);
			}
		}
		return result;
	}

	private static List<(int Lane, double Distance)> LaneCandidates(ParsedRoad road, Vector3 position, float factor)
	{
		List<(int Lane, double Distance)> lanes = new List<(int Lane, double Distance)>();
		for (int i = 0; i < road.GetLaneCount((Side)1); i++)
		{
			lanes.Add((i + 1, DistanceTo(position, road.InterpolateLane(factor, (Side)1, i, 0f).Position)));
		}
		for (int j = 0; j < road.GetLaneCount((Side)0); j++)
		{
			lanes.Add((-(j + 1), DistanceTo(position, road.InterpolateLane(factor, (Side)0, j, 0f).Position)));
		}
		return lanes;
	}

	public static float GetClosestFactorFor(IParsedItem item, Vector3 position)
	{
		ParsedRoad val = (ParsedRoad)(object)((item is ParsedRoad) ? item : null);
		if (val == null)
		{
			ParsedRoadList val2 = (ParsedRoadList)(object)((item is ParsedRoadList) ? item : null);
			if (val2 != null)
			{
				return val2.GetFactorForPoint(position);
			}
			return 0f;
		}
		return val.GetFactorForPoint(position);
	}

	public static ParsedRoadWithDistance? GetBestNodeRoad(Node closestNode, Vector3 position)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Expected Obj, but got Unknown
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Expected Obj, but got Unknown
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Expected Obj, but got Unknown
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Expected Obj, but got Unknown
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Expected Obj, but got Unknown
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Expected Obj, but got Unknown
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		IMapObject forwardItem = closestNode.ForwardItem;
		IMapObject backwardItem = closestNode.BackwardItem;
		ParsedRoadWithDistance val = null;
		ParsedRoadWithDistance val2 = null;
		if (forwardItem is Road)
		{
			val = new ParsedRoadWithDistance(new ParsedRoad((Road)forwardItem));
			val.closestPointFactor = GetClosestFactorFor((IParsedItem)(object)val.road, position);
			OrientedPoint val3 = val.road.Interpolate(val.closestPointFactor);
			val.closestPointDistance = (float)DistanceToWithHeight(position, val3.Position);
		}
		if (backwardItem is Road)
		{
			val2 = new ParsedRoadWithDistance(new ParsedRoad((Road)backwardItem));
			val2.closestPointFactor = GetClosestFactorFor((IParsedItem)(object)val2.road, position);
			OrientedPoint val4 = val2.road.Interpolate(val2.closestPointFactor);
			val2.closestPointDistance = (float)DistanceToWithHeight(position, val4.Position);
		}
		if (val == null)
		{
			return val2;
		}
		if (val2 == null)
		{
			return val;
		}
		return (val.closestPointDistance < val2.closestPointDistance) ? val : val2;
	}

	public static List<Node> GetClosestNodes(Vector3 position, IReadOnlyList<Node> nodes, List<Type>? allowTypes, List<ulong>? ignoreUids, out double? closestDistance)
	{
		List<Tuple<Node, double>> list = new List<Tuple<Node, double>>();
		new List<Node>();
		foreach (Node node in nodes)
		{
			if ((allowTypes == null || (node.ForwardItem != null && allowTypes.Contains(((object)node.ForwardItem).GetType())) || (node.BackwardItem != null && allowTypes.Contains(((object)node.BackwardItem).GetType()))) && (ignoreUids == null || (node.Uid != 0L && !ignoreUids.Contains(node.Uid))))
			{
				double item = DistanceToWithHeight(position, node.Position);
				list.Add(new Tuple<Node, double>(node, item));
			}
		}
		list.Sort((Tuple<Node, double> a, Tuple<Node, double> b) => a.Item2.CompareTo(b.Item2));
		List<Node> result = list.Select((Tuple<Node, double> t) => t.Item1).ToList();
		closestDistance = ((list.Count > 0) ? new double?(list[0].Item2) : ((double?)null));
		return result;
	}

	public static ParsedRoadWithDistance? GetClosestRoad(Vector3 position, IReadOnlyList<Node> nodes, List<ulong>? ignoreUids = null)
	{
		List<Node> closestNodes = GetClosestNodes(position, nodes, new List<Type> { typeof(Road) }, ignoreUids, out var _);
		if (closestNodes.Count == 0)
		{
			return null;
		}
		ParsedRoadWithDistance val = null;
		for (int i = 0; i < closestNodes.Count; i++)
		{
			ParsedRoadWithDistance bestNodeRoad = GetBestNodeRoad(closestNodes[i], position);
			if (bestNodeRoad != null)
			{
				if (val == null)
				{
					val = bestNodeRoad;
				}
				else if (bestNodeRoad.closestPointDistance < val.closestPointDistance)
				{
					val = bestNodeRoad;
				}
			}
		}
		return val;
	}

	public static ParsedRoadList GetRoadListForRoad(ParsedRoad road)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Expected Obj, but got Unknown
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Expected Obj, but got Unknown
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Expected Obj, but got Unknown
		List<ParsedRoad> list = new List<ParsedRoad>();
		List<ParsedRoad> list2 = new List<ParsedRoad>();
		Road val = road.Road;
		while (true)
		{
			IMapItem backwardItem = ((PolylineItem)val).BackwardItem;
			Road val2 = (Road)(object)((backwardItem is Road) ? backwardItem : null);
			if (val2 == null)
			{
				break;
			}
			ParsedRoad item = new ParsedRoad(val2);
			list.Add(item);
			val = val2;
		}
		val = road.Road;
		while (true)
		{
			IMapItem forwardItem = ((PolylineItem)val).ForwardItem;
			Road val3 = (Road)(object)((forwardItem is Road) ? forwardItem : null);
			if (val3 == null)
			{
				break;
			}
			ParsedRoad item2 = new ParsedRoad(val3);
			list2.Add(item2);
			val = val3;
		}
		list.Reverse();
		return new ParsedRoadList(list.Concat(new List<ParsedRoad> { road }).Concat(list2).ToList());
	}

	public static PlannedItem? CreateFirstPlannedItem(IReadOnlyList<Node> nearbyNodes, Vector3 position, Vector3 rotation)
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0125: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Expected Obj, but got Unknown
		ParsedRoadWithDistance closestRoad = GetClosestRoad(position, nearbyNodes);
		if (closestRoad == null)
		{
			Logger.Warn("No road found near the truck's position. Cannot create a planned item for pathfinding.", "C:\\Users\\Tumppi066\\Documents\\GitHub\\ets2la-core-plugins\\Plugins\\Pathfinding\\Utils.cs", 233);
			return null;
		}
		if (closestRoad.closestPointFactor == 1f || closestRoad.closestPointFactor == 0f)
		{
			Logger.Warn("Closest road point is at the end of the road. Cannot create a planned item for pathfinding.", "C:\\Users\\Tumppi066\\Documents\\GitHub\\ets2la-core-plugins\\Plugins\\Pathfinding\\Utils.cs", 237);
			return null;
		}
		OrientedPoint val = closestRoad.road.Interpolate(closestRoad.closestPointFactor);
		Vector3 vector = MathExtensions.ToEulerDeg(val.Rotation);
		float num = rotation.X * 360f;
		if (num < 0f)
		{
			num += 360f;
		}
		float num2 = vector.Y - num;
		num2 = (num2 % 360f + 360f) % 360f;
		if (num2 > 180f)
		{
			num2 -= 360f;
		}
		Direction direction = (Direction)(Math.Abs(num2) > 100f ? 1 : 0);
		// ARC: en yakın şerit değil, tırın gidiş yönündeki şerit seçilir; yoksa düz yolda karşı şeride dönüyordu
		int closestLane = LaneSelector.Choose(LaneCandidates(closestRoad.road, position, closestRoad.closestPointFactor), (int)direction == 0, closestRoad.road.Road.LeftHandTraffic);
		if (closestLane == 0)
		{
			return null;
		}
		ParsedRoadList roadListForRoad = GetRoadListForRoad(closestRoad.road);
		return new PlannedItem
		{
			item = (IParsedItem)(object)roadListForRoad,
			startNode = roadListForRoad.StartNode,
			endNode = roadListForRoad.EndNode,
			laneIndex = closestLane,
			direction = direction
		};
	}

	public static void EnsureContinuity(List<PlannedItem> currentlyPlannedItems, PlannedItem newPlannedItem)
	{
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0371: Unknown result type (might be due to invalid IL or missing references)
		//IL_0354: Unknown result type (might be due to invalid IL or missing references)
		//IL_035a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0452: Unknown result type (might be due to invalid IL or missing references)
		//IL_0457: Unknown result type (might be due to invalid IL or missing references)
		//IL_0376: Unknown result type (might be due to invalid IL or missing references)
		//IL_0196: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		IParsedItem item = newPlannedItem.item;
		bool flag = ((item is ParsedRoad || item is ParsedRoadList) ? true : false);
		if (flag || currentlyPlannedItems.FirstOrDefault((PlannedItem val14) =>
		{
			IParsedItem item3 = val14.item;
			return (item3 is ParsedRoad || item3 is ParsedRoadList) ? true : false;
		}) == null)
		{
			return;
		}
		float num = currentlyPlannedItems.Where((PlannedItem val14) =>
		{
			IParsedItem item3 = val14.item;
			return (item3 is ParsedRoad || item3 is ParsedRoadList) ? true : false;
		}).Max((PlannedItem val14) => val14.GetLength());
		List<PlannedItem> list = currentlyPlannedItems.AsEnumerable().Reverse().ToList();
		PlannedItem val = newPlannedItem;
		int num2 = 0;
		foreach (PlannedItem item4 in list)
		{
			item = item4.item;
			ParsedRoadList val2 = (ParsedRoadList)(object)((item is ParsedRoadList) ? item : null);
			OrientedPoint val7;
			if (val2 == null)
			{
				if (item is ParsedPrefab)
				{
					IParsedItem item2 = val.item;
					ParsedRoadList val3 = (ParsedRoadList)(object)((item2 is ParsedRoadList) ? item2 : null);
					if (val3 != null && (val.GetLength() > 20f || val.GetLength() == num) && num2 != list.Count - 1)
					{
						Tuple<Side, int> targetLane = val.GetTargetLane();
						bool flag2 = false;
						if (targetLane != null)
						{
							OrientedPoint val4 = val3.InterpolateLane(0.01f, targetLane.Item1, targetLane.Item2, 0f);
							PrefabPath val5 = null;
							float num3 = float.MaxValue;
							PrefabPath[] otherPrefabPaths = item4.otherPrefabPaths;
							foreach (PrefabPath val6 in otherPrefabPaths)
							{
								if (!((double)val6.Length > (double?)item4.prefabPath?.Length * 1.6))
								{
									Vector3 position = val4.Position;
									val7 = val6.Interpolate(0.99f, 0f).Value;
									float num5 = Vector3.Distance(position, val7.Position);
									if (num5 < num3)
									{
										val5 = val6;
										num3 = num5;
									}
								}
							}
							if (val5 != null && val5 != item4.prefabPath)
							{
								item4.prefabPath = val5;
								val.laneIndex = val.targetLaneIndex;
								val.targetLaneIndex = 0;
								flag2 = true;
							}
						}
						if (!flag2)
						{
							PrefabPath prefabPath = item4.prefabPath;
							OrientedPoint val8;
							if (prefabPath == null)
							{
								val7 = default;
								val8 = val7;
							}
							else
							{
								val8 = prefabPath.Interpolate(0.99f, 0f).Value;
							}
							OrientedPoint val9 = val8;
							int bestLaneFor = val3.GetBestLaneFor(val9.Position, false, true);
							if (bestLaneFor != val.laneIndex)
							{
								val.targetLaneIndex = bestLaneFor;
							}
						}
					}
					if (val.item is ParsedPrefab && val.prefabPath != null && item4.prefabPath != null)
					{
						OrientedPoint value = val.prefabPath.Interpolate(0.01f, 0f).Value;
						OrientedPoint value2 = item4.prefabPath.Interpolate(0.99f, 0f).Value;
						if (Vector3.Distance(value.Position, value2.Position) > 4f)
						{
							PrefabPath val10 = null;
							PrefabPath[] otherPrefabPaths = item4.otherPrefabPaths;
							foreach (PrefabPath val11 in otherPrefabPaths)
							{
								Vector3 position2 = value.Position;
								val7 = val11.Interpolate(0.99f, 0f).Value;
								if (Vector3.Distance(position2, val7.Position) < 4f)
								{
									val10 = val11;
									break;
								}
							}
							if (val10 != null)
							{
								item4.prefabPath = val10;
							}
						}
					}
					val = item4;
				}
			}
			else
			{
				if (val.item is ParsedPrefab)
				{
					OrientedPoint? val12 = item4.Interpolate(0.99f, 0f, false);
					PrefabPath prefabPath2 = val.prefabPath;
					OrientedPoint? val13 = ((prefabPath2 != null) ? prefabPath2.Interpolate(0.01f, 0f) : ((OrientedPoint?)null));
					Vector3 value3;
					if (!val12.HasValue)
					{
						value3 = Vector3.Zero;
					}
					else
					{
						val7 = val12.GetValueOrDefault();
						value3 = val7.Position;
					}
					Vector3 value4;
					if (!val13.HasValue)
					{
						value4 = Vector3.Zero;
					}
					else
					{
						val7 = val13.GetValueOrDefault();
						value4 = val7.Position;
					}
					if (Vector3.Distance(value3, value4) > 4f)
					{
						Vector3 vector;
						if (!val13.HasValue)
						{
							vector = Vector3.Zero;
						}
						else
						{
							val7 = val13.GetValueOrDefault();
							vector = val7.Position;
						}
						int bestLaneFor2 = val2.GetBestLaneFor(vector, false, true);
						if (bestLaneFor2 != item4.laneIndex)
						{
							item4.targetLaneIndex = bestLaneFor2;
						}
					}
				}
				val = item4;
			}
			num2++;
		}
	}

	public static PlannedItem? CreateNextPlannedItem(List<PlannedItem> currentlyPlannedItems, NavigationData? navigationData)
	{
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03df: Expected Obj, but got Unknown
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Expected Obj, but got Unknown
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Invalid comparison between Unknown and I4
		//IL_040f: Unknown result type (might be due to invalid IL or missing references)
		//IL_048d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0494: Expected Obj, but got Unknown
		//IL_040a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0438: Unknown result type (might be due to invalid IL or missing references)
		//IL_043d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0136: Unknown result type (might be due to invalid IL or missing references)
		//IL_0141: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_044f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0454: Unknown result type (might be due to invalid IL or missing references)
		//IL_045c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0464: Unknown result type (might be due to invalid IL or missing references)
		//IL_0473: Unknown result type (might be due to invalid IL or missing references)
		//IL_047b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0482: Unknown result type (might be due to invalid IL or missing references)
		//IL_0483: Unknown result type (might be due to invalid IL or missing references)
		//IL_0485: Unknown result type (might be due to invalid IL or missing references)
		//IL_048b: Expected Obj, but got Unknown
		//IL_0540: Unknown result type (might be due to invalid IL or missing references)
		//IL_0545: Unknown result type (might be due to invalid IL or missing references)
		//IL_0550: Unknown result type (might be due to invalid IL or missing references)
		//IL_0555: Unknown result type (might be due to invalid IL or missing references)
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_058e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Expected Obj, but got Unknown
		//IL_05b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_05ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_05bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0516: Unknown result type (might be due to invalid IL or missing references)
		//IL_051d: Expected Obj, but got Unknown
		//IL_02fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0302: Unknown result type (might be due to invalid IL or missing references)
		//IL_030a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_032a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0332: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_0348: Unknown result type (might be due to invalid IL or missing references)
		//IL_0349: Unknown result type (might be due to invalid IL or missing references)
		//IL_034b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0352: Expected Obj, but got Unknown
		//IL_064c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0651: Unknown result type (might be due to invalid IL or missing references)
		//IL_0659: Unknown result type (might be due to invalid IL or missing references)
		//IL_0661: Unknown result type (might be due to invalid IL or missing references)
		//IL_0675: Unknown result type (might be due to invalid IL or missing references)
		//IL_067d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0685: Unknown result type (might be due to invalid IL or missing references)
		//IL_068c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0693: Unknown result type (might be due to invalid IL or missing references)
		//IL_0694: Unknown result type (might be due to invalid IL or missing references)
		//IL_0696: Unknown result type (might be due to invalid IL or missing references)
		//IL_069d: Expected Obj, but got Unknown
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0292: Unknown result type (might be due to invalid IL or missing references)
		if (currentlyPlannedItems.Count == 0)
		{
			return null;
		}
		PlannedItem val = currentlyPlannedItems.Last();
		IParsedItem item = val.item;
		ParsedRoadList val2 = (ParsedRoadList)(object)((item is ParsedRoadList) ? item : null);
		OrientedPoint value;
		if (val2 != null)
		{
			IMapItem val3 = (((int)val.direction == 0) ? ((PolylineItem)val2.Roads[val2.Roads.Count - 1].Road).ForwardItem : ((PolylineItem)val2.Roads[0].Road).BackwardItem);
			if (val3 != null)
			{
				if (!(val3 is Road))
				{
					Prefab val4 = (Prefab)(object)((val3 is Prefab) ? val3 : null);
					if (val4 != null)
					{
						ParsedPrefab val5 = new ParsedPrefab(val4);
						Node nodeInCommon = val5.GetNodeInCommon(val2);
						OrientedPoint? val6 = val.Interpolate((float)(((int)val.direction == 0) ? 1 : 0), 0f, false);
						if (!val6.HasValue)
						{
							return null;
						}
						Node val7 = null;
						if (navigationData != null)
						{
							foreach (INode node in val5.Prefab.Nodes)
							{
								if (((IMapObject)node).Uid != nodeInCommon.Uid && navigationData.Contains(((IMapObject)node).Uid))
								{
									val7 = (Node)node;
									break;
								}
							}
						}
						if (val7 == null)
						{
							value = val6.Value;
							Vector3 position = value.Position;
							value = val6.Value;
							val7 = val5.GetNodeMostInFront(position, value.Rotation, new List<Node> { nodeInCommon }, false);
						}
						if (val7.BackwardItem == null || val7.ForwardItem == null)
						{
							return null;
						}
						Direction direction;
						if (val7.BackwardItem.Uid == ((MapItem)val5.Prefab).Uid)
						{
							direction = (Direction)0;
						}
						else if (val7.ForwardItem.Uid == ((MapItem)val5.Prefab).Uid)
						{
							direction = (Direction)1;
						}
						else
						{
							direction = (Direction)0;
							Logger.Warn("Couldn't determine prefab path direction, defaulting to forward", "C:\\Users\\Tumppi066\\Documents\\GitHub\\ets2la-core-plugins\\Plugins\\Pathfinding\\Utils.cs", 436);
						}
						Node val8 = val7;
						value = val6.Value;
						var (list, list2) = val5.GetPathsFromNodeToNode(nodeInCommon, val8, value.Position);
						if (list.Count == 0 && list2.Count == 0)
						{
							return null;
						}
						PrefabPath prefabPath = ((list.Count > 0) ? list.First() : null);
						if (list2.Count != 0 && PathfindingSettings.Current.EnableLaneChanges)
						{
							List<PrefabPath> list3 = list2.Where((PrefabPath p) => p.Length + 5f < (prefabPath?.Length ?? float.MaxValue)).ToList();
							PrefabPath val9 = null;
							int targetLaneIndex = 0;
							int num = 999;
							foreach (PrefabPath item5 in list3)
							{
								value = item5.Interpolate(0.01f, 0f).Value;
								int bestLaneFor = val2.GetBestLaneFor(value.Position, false, true);
								int num2 = Math.Abs(bestLaneFor - val.laneIndex);
								if (num2 < num)
								{
									targetLaneIndex = bestLaneFor;
									num = num2;
									val9 = item5;
								}
							}
							if (val9 != null)
							{
								prefabPath = val9;
								val.targetLaneIndex = targetLaneIndex;
							}
						}
						if (prefabPath == null)
						{
							return null;
						}
						PlannedItem val10 = new PlannedItem
						{
							item = (IParsedItem)(object)val5,
							prefabPath = prefabPath,
							otherPrefabPaths = list.Concat(list2).ToArray(),
							startNode = nodeInCommon,
							endNode = val7,
							laneIndex = 0,
							lastItem = val,
							direction = direction
						};
						EnsureContinuity(currentlyPlannedItems, val10);
						return val10;
					}
					return null;
				}
				return null;
			}
			return null;
		}
		IParsedItem item2 = val.item;
		ParsedPrefab val11 = (ParsedPrefab)(object)((item2 is ParsedPrefab) ? item2 : null);
		if (val11 != null)
		{
			IMapObject val12 = ((val.endNode.ForwardItem.Uid == ((MapItem)val11.Prefab).Uid) ? val.endNode.BackwardItem : val.endNode.ForwardItem);
			if (val12 != null)
			{
				Road val13 = (Road)(object)((val12 is Road) ? val12 : null);
				if (val13 == null)
				{
					Prefab val14 = (Prefab)(object)((val12 is Prefab) ? val12 : null);
					if (val14 != null)
					{
						ParsedPrefab val15 = new ParsedPrefab(val14);
						Node nodeInCommon2 = val15.GetNodeInCommon(val11);
						PrefabPath prefabPath2 = val.prefabPath;
						OrientedPoint? val16 = ((prefabPath2 != null) ? prefabPath2.Interpolate(1f, 0f) : ((OrientedPoint?)null));
						if (!val16.HasValue)
						{
							return null;
						}
						Node val17 = null;
						if (navigationData != null)
						{
							foreach (INode node2 in val15.Prefab.Nodes)
							{
								if (((IMapObject)node2).Uid != nodeInCommon2.Uid && navigationData.Contains(((IMapObject)node2).Uid))
								{
									val17 = (Node)node2;
									break;
								}
							}
						}
						if (val17 == null)
						{
							value = val16.Value;
							Vector3 position2 = value.Position;
							value = val16.Value;
							val17 = val15.GetNodeMostInFront(position2, value.Rotation, new List<Node> { nodeInCommon2 }, false);
						}
						Direction direction2;
						if (nodeInCommon2.BackwardItem.Uid == ((MapItem)val11.Prefab).Uid)
						{
							direction2 = (Direction)0;
						}
						else
						{
							direction2 = ((nodeInCommon2.ForwardItem.Uid != ((MapItem)val11.Prefab).Uid) ? ((Direction)0) : ((Direction)1));
						}
						Node val18 = val17;
						value = val16.Value;
						(List<PrefabPath>, List<PrefabPath>) pathsFromNodeToNode = val15.GetPathsFromNodeToNode(nodeInCommon2, val18, value.Position);
						List<PrefabPath> item3 = pathsFromNodeToNode.Item1;
						List<PrefabPath> item4 = pathsFromNodeToNode.Item2;
						PrefabPath val19 = ((item3.Count > 0) ? item3.First() : null);
						if (item4.Count > 0 && val19 != null && PathfindingSettings.Current.EnableLaneChanges)
						{
							PrefabPath val20 = item4.First();
							if (val20.Length + 10f < val19.Length)
							{
								val19 = val20;
							}
						}
						else if (item4.Count > 0)
						{
							val19 = item4.First();
						}
						if (val19 == null)
						{
							return null;
						}
						PlannedItem val21 = new PlannedItem
						{
							item = (IParsedItem)(object)val15,
							prefabPath = val19,
							otherPrefabPaths = item3.Concat(item4).ToArray(),
							startNode = nodeInCommon2,
							endNode = val17,
							laneIndex = 0,
							lastItem = val,
							direction = direction2
						};
						EnsureContinuity(currentlyPlannedItems, val21);
						return val21;
					}
					return null;
				}
				ParsedRoadList roadListForRoad = GetRoadListForRoad(new ParsedRoad(val13));
				Node nodeInCommon3 = roadListForRoad.GetNodeInCommon(val11);
				IMapObject backwardItem = nodeInCommon3.BackwardItem;
				Prefab val22 = (Prefab)(object)((backwardItem is Prefab) ? backwardItem : null);
				Direction direction3 = ((val22 == null || val22 != val11.Prefab) ? ((Direction)1) : ((Direction)0));
				OrientedPoint? val23 = val.prefabPath.Interpolate(1f, 0f);
				int num3;
				if (!val23.HasValue)
				{
					num3 = -1;
				}
				else
				{
					value = val23.Value;
					num3 = roadListForRoad.GetBestLaneFor(value.Position, false, true);
				}
				int laneIndex = num3;
				return new PlannedItem
				{
					item = (IParsedItem)(object)roadListForRoad,
					startNode = nodeInCommon3,
					endNode = roadListForRoad.GetOtherNode(nodeInCommon3),
					laneIndex = laneIndex,
					lastItem = val,
					direction = direction3
				};
			}
			return null;
		}
		return null;
	}
}
