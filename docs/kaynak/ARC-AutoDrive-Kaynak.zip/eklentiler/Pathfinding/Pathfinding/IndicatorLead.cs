using System;
using System.Collections.Generic;

namespace Pathfinding;

/// <summary>Yaklaşan dönüş ya da şerit değişimi için sinyalin şimdi verilip verilmeyeceğine karar verir.</summary>
public static class IndicatorLead
{
    public const float MaxSeconds = 10f;
    const float MinSpeed = 3f;

    /// <summary>Açık sinyal yaklaşan manevrayla aynı yöndeyse kapatılmaz. Yön: -1 sol, +1 sağ, 0 kapalı.</summary>
    public static bool KeepSignal(int? plannedSide, int activeSide) => plannedSide.HasValue && plannedSide.Value == activeSide;

    /// <summary>Şerit değişimi, sinyal o yönde ayarlanan süre kadar yanmadan başlamaz. Yön: -1 sol, +1 sağ.</summary>
    /// <param name="signalSide">Şu an yanan sinyal (0 kapalı).</param>
    /// <param name="signalOnSeconds">Bu sinyalin kaç saniyedir yandığı.</param>
    public static bool ReadyToChange(int side, int signalSide, double signalOnSeconds, float seconds)
    {
        if (seconds <= 0f) return true;
        return signalSide == side && signalOnSeconds >= MathF.Min(seconds, MaxSeconds);
    }

    /// <param name="ahead">Yoldaki sıraya göre manevralar. Side: -1 sol, +1 sağ.</param>
    /// <param name="speed">Tırın hızı, m/s.</param>
    /// <param name="seconds">Manevradan kaç saniye önce sinyal verileceği; 0 ise erken sinyal yok.</param>
    /// <returns>Şimdi verilecek sinyalin yönü; yoksa null.</returns>
    /// <param name="heldReach">Sinyal yandığındaki erişim (m). Frende erişim kısalır; manevra geçilmeden sinyal sönmesin diye.</param>
    public static int? Choose(IEnumerable<(float Distance, int Side)> ahead, float speed, float seconds, float heldReach = 0f)
    {
        if (seconds <= 0f) return null;
        var reach = MathF.Max(Reach(speed, seconds), heldReach);
        foreach (var (distance, side) in ahead)
        {
            if (side != 0 && distance <= reach) return side;
        }
        return null;
    }

    /// <summary>Sonraki karede Choose'a verilecek tutulan erişim: sinyal varken büyür, manevra geçilince sıfırlanır.</summary>
    public static float NextHeldReach(int? side, float heldReach, float speed, float seconds) =>
        side.HasValue ? MathF.Max(heldReach, Reach(speed, seconds)) : 0f;

    /// <summary>Şerit değişiminden önce sinyalin kaç saniye yanması gerektiği. Yol, değişimi tam boyda sığdırıyorsa ayar;
    /// sığdırmıyorsa en az 1 sn (iki yanıp sönme); değişimin yarısı bile sığmıyorsa 0 (beklemek sapağı kaçırır).</summary>
    /// <param name="remaining">Yol parçasının bitimine kalan, m.</param>
    /// <param name="changeLength">Şerit değişiminin istediği yol, m.</param>
    public static float RequiredSeconds(float remaining, float changeLength, float seconds)
    {
        if (remaining >= changeLength) return seconds;
        return remaining >= changeLength * 0.5f ? MathF.Min(seconds, 1f) : 0f;
    }

    /// <summary>Bu hızda sinyalin manevradan kaç metre önce verileceği.</summary>
    public static float Reach(float speed, float seconds) => MathF.Max(MathF.Abs(speed), MinSpeed) * MathF.Min(seconds, MaxSeconds);
}
