using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using ETS2LA.Backend.Events;
using ETS2LA.Game;
using ETS2LA.Game.Data;
using ETS2LA.Game.Output;
using ETS2LA.Game.PpdFiles;
using ETS2LA.Game.SDK;
using ETS2LA.Game.SiiFiles;
using ETS2LA.Game.Telemetry;
using ETS2LA.Logging;
using ETS2LA.Shared;
using ETS2LA.State;
using PathLib;
using Pathfinding.Utils;
using TruckLib;
using TruckLib.Models.Ppd;
using TruckLib.ScsMap;

using BlinkerType = TruckLib.Models.Ppd.BlinkerType;

namespace Pathfinding;

public class PathfindingPlugin : Plugin
{
	private const int VIEW_DISTANCE = 512;

	public string EventId = "Pathfinding.PlannedPathData";

	private GameTelemetryData? telemetryData;

	private NavigationData? navigationData;

	private Installation? loadedInstallation;

	private MapData? mapData;

	private IReadOnlyList<Node>? nearbyNodes;

	private string lastFrameError = "";

	private bool didStartIndicate;

	private Stopwatch sinceLastIndicate = new Stopwatch();

	private Stopwatch sinceLastLaneChange = new Stopwatch();

	private List<PlannedItem> plannedPath = new List<PlannedItem>();

	// ARC: arkadan gelen araç koruması
	private const float HoldMinRemaining = 120f;
	private const double HoldMaxSeconds = 15.0;
	private const float YieldDrop = 2.8f;
	private const float YieldMinSpeed = 11f;
	private const double YieldReleaseSeconds = 1.5;
	private const long VehicleSampleMs = 250;
	private const float VehicleMaxSpeed = 70f;

	private const float PathTolerance = 3f;
	private const float RecoveryMargin = 1.5f;
	private float recoveryTolerance;

	private PlannedItem? heldLaneChange;
	private PlannedItem? releasedLaneChange;
	private int heldSide;
	private int signalSide;
	private float plannedReach;
	private readonly Stopwatch signalOn = new Stopwatch();
	private readonly Stopwatch heldFor = new Stopwatch();
	private readonly Stopwatch sinceOvertake = new Stopwatch();
	private bool yielding;
	private const double TurnYieldMaxSeconds = 15.0;
	private const float OvertakeLookAhead = 200f;
	private const float OvertakeMaxBend = 6f;
	private readonly Stopwatch turnYieldFor = new Stopwatch();
	private float yieldBase;
	private readonly Overtaker overtaker = new Overtaker();
	private readonly Stopwatch overtakeClock = Stopwatch.StartNew();
	private List<(Vector3 Position, Vector3 Velocity)> measuredVehicles = new List<(Vector3, Vector3)>();
	private PlannedItem? overtakeItem;
	private int overtakeSide;
	private int overtakeHomeLane;
	private int overtakeOutLane;
	private readonly Stopwatch overtakeLog = Stopwatch.StartNew();
	private OvertakeStage lastLoggedStage;
	private Vector3 lastTruckPosition;
	private Vector3 truckForward;
	private bool truckForwardKnown;
	private readonly Dictionary<short, (Vector3 Position, long Stamp, Vector3? Velocity)> vehicleSamples = new Dictionary<short, (Vector3, long, Vector3?)>();

	public override float TickRate => 30f;

	public override PluginInformation Info
	{
		get
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Expected Obj, but got Unknown
			PluginInformation val = new PluginInformation { Name = "", Description = "", Version = "", Id = "" };
			val.Name = "Pathfinding";
			val.Description = "This plugin publishes events containing parsed navigation data used by other plugins.";
			val.AuthorName = "Tumppi066";
			val.Version = "1.2.9";
			val.SupportedETS2LA = ">=3.4.36";
			val.Icon = "https://avatars.githubusercontent.com/u/162675991?s=128";
			val.Id = "tumppi066.pathfinding";
			val.Tags = new string[2] { "Utility", "Navigation" };
			val.Dependencies.Add("tumppi066.pathlib");
			return val;
		}
	}

	public override void OnEnable()
	{
		base.OnEnable();
		Events.Current.Subscribe<GameTelemetryData>(GameTelemetry.Current.EventString, (Action<GameTelemetryData>)((GameTelemetryData data) =>
		{
			telemetryData = data;
		}));
		Events.Current.Subscribe<NavigationData>(NavigationProvider.Current.EventString, (Action<NavigationData>)((NavigationData data) =>
		{
			navigationData = data;
		}));
		Task.Run((Action)MapUpdateThread);
		sinceLastLaneChange.Start();
		sinceLastIndicate.Start();
	}

	public void MapUpdateThread()
	{
		while (((Plugin)this)._IsRunning)
		{
			// ARC: tek bir hata bu döngüyü bitirirse yol çizgileri program yeniden açılana kadar gelmiyordu
			try
			{
				Thread.Sleep(mapData == null ? 1000 : 5000);
				RefreshMap();
			}
			catch (Exception ex)
			{
				Logger.Error("Harita yenilenemedi: " + ex);
				Thread.Sleep(1000);
			}
		}
	}

	private void RefreshMap()
	{
		Installation runningGame = ApplicationState.Current.RunningGame;
		if (runningGame == null)
		{
			return;
		}
		if (runningGame != loadedInstallation)
		{
			mapData = runningGame.GetMapData();
			IFileSystem fileSystem = runningGame.GetFileSystem();
			if (fileSystem != null)
			{
				SiiFileHandler.Current.SetFileSystem(fileSystem);
			}
			if (fileSystem != null)
			{
				PpdFileHandler.Current.SetFileSystem(fileSystem);
			}
			if (mapData != null)
			{
				loadedInstallation = runningGame;
			}
		}
		if (mapData != null && telemetryData != null)
		{
			Vector3Double coordinate = telemetryData.truckPlacement.coordinate;
			double num = coordinate.X - 512.0;
			double num2 = coordinate.X + 512.0;
			double num3 = coordinate.Z - 512.0;
			double num4 = coordinate.Z + 512.0;
			nearbyNodes = ((Map)mapData).Nodes.Within(num, num3, num2, num4);
		}
	}

	/// <summary>Yan şeritteki araçları değerlendirir; araç hızları konum farkından ölçülür.</summary>
	private RearGuardResult EvaluateRearGuard(Vector3 truck)
	{
		measuredVehicles = new List<(Vector3, Vector3)>();
		StateSettings settings = StateSettingsHandler.Current.GetSettings();
		if (!settings.WatchRearTraffic && !settings.OvertakeEnabled)
		{
			return default(RearGuardResult);
		}
		Vector3 move = truck - lastTruckPosition;
		move.Y = 0f;
		if (move.Length() > 0.5f)
		{
			if (move.Length() < 25f)
			{
				truckForward = Vector3.Normalize(move);
				truckForwardKnown = true;
			}
			lastTruckPosition = truck;
		}
		TrafficVehicle[]? vehicles = TrafficProvider.Current.GetCurrentTrafficData()?.vehicles;
		if (vehicles == null || !truckForwardKnown)
		{
			return default(RearGuardResult);
		}
		long now = Environment.TickCount64;
		HashSet<short> seen = new HashSet<short>();
		List<(Vector3 Position, Vector3 Velocity)> measured = new List<(Vector3, Vector3)>();
		foreach (TrafficVehicle vehicle in vehicles)
		{
			if (vehicle.Position == Vector3.Zero || vehicle.isTrailer)
			{
				continue;
			}
			seen.Add(vehicle.id);
			if (!vehicleSamples.TryGetValue(vehicle.id, out var sample))
			{
				vehicleSamples[vehicle.id] = (vehicle.Position, now, null);
				continue;
			}
			long elapsed = now - sample.Stamp;
			if (elapsed >= VehicleSampleMs)
			{
				Vector3 velocity = (vehicle.Position - sample.Position) / (elapsed / 1000f);
				sample = (vehicle.Position, now, (velocity.Length() <= VehicleMaxSpeed) ? velocity : null);
				vehicleSamples[vehicle.id] = sample;
			}
			if (sample.Velocity.HasValue)
			{
				measured.Add((vehicle.Position, sample.Velocity.Value));
			}
		}
		foreach (short id in new List<short>(vehicleSamples.Keys))
		{
			if (!seen.Contains(id))
			{
				vehicleSamples.Remove(id);
			}
		}
		int trailers = 0;
		foreach (TrailerInfo trailer in telemetryData.trailers)
		{
			if (trailer.comBool.attached)
			{
				trailers++;
			}
		}
		measuredVehicles = measured;
		return RearGuard.Evaluate(truck, truckForward, telemetryData.truckFloat.speed, measured, RearGuard.RearExtent(trailers));
	}

	private float RemainingOnFirstItem()
	{
		return (plannedPath.Count > 1) ? PathfindingUtils.DistanceTo(plannedPath[1], telemetryData.truckPlacement.coordinate) : float.MaxValue;
	}

	/// <summary>Yan şerit doluysa şerit değişimini, sinyal açık kalarak, boşalana kadar bekletir.</summary>
	private void UpdateLaneChangeHold(RearGuardResult guard)
	{
		PlannedItem first = plannedPath[0];
		int blinker = telemetryData.truckBool.blinkerRightActive ? 1 : (telemetryData.truckBool.blinkerLeftActive ? -1 : 0);
		if (blinker != signalSide)
		{
			signalSide = blinker;
			signalOn.Restart();
		}
		if (heldLaneChange != null && heldLaneChange != first)
		{
			heldLaneChange = null;
		}
		if (heldLaneChange == first)
		{
			// Kısa yolda bekleme süresini SignalReady kısaltır; trafik beklemesi yol bitmeye yakın bırakılır.
			bool trafficOk = !guard.Blocked(heldSide) || RemainingOnFirstItem() < HoldMinRemaining;
			if ((trafficOk && SignalReady(heldSide)) || heldFor.Elapsed.TotalSeconds > HoldMaxSeconds)
			{
				first.allowedToLaneChange = true;
				releasedLaneChange = first;
				heldLaneChange = null;
			}
			return;
		}
		if (first.targetLaneIndex == 0 || first == releasedLaneChange)
		{
			return;
		}
		int side = (first.item is ParsedRoad || first.item is ParsedRoadList) ? ManeuverSide(first) : 0;
		if (side != 0 && ((guard.Blocked(side) && RemainingOnFirstItem() >= HoldMinRemaining) || !SignalReady(side)))
		{
			// Hedef şerit durur, sinyal açık kalır; değişim başlangıcı serbest kalınca yeniden alınır.
			heldLaneChange = first;
			heldSide = side;
			first.allowedToLaneChange = false;
			heldFor.Restart();
		}
		else
		{
			releasedLaneChange = first;
		}
	}

	/// <summary>Şerit değişiminden önce sinyal ayarlanan süre kadar yandı mı. Sollama kendi sinyal süresini yönetir.</summary>
	private bool SignalReady(int side)
	{
		if (!PathfindingSettings.Current.EnableIndicators || overtaker.Stage is OvertakeStage.MovingOut or OvertakeStage.Returning)
		{
			return true;
		}
		float changeLength = 5f * MathF.Max(20f, telemetryData.truckFloat.speedLimit); // PathLib PlannedItem ile aynı boy
		float seconds = IndicatorLead.RequiredSeconds(RemainingOnFirstItem(), changeLength, StateSettingsHandler.Current.GetSettings().IndicatorLeadSeconds);
		return IndicatorLead.ReadyToChange(side, signalSide, signalOn.Elapsed.TotalSeconds, seconds);
	}

	/// <summary>Dönüş yönünde araç varsa kullanıcıyı uyarır; arkada araç yoksa yavaşlayıp o aracın geçmesini bekler.</summary>
	private bool UpdateTurnYield(RearGuardResult guard, int? plannedSide)
	{
		int side = plannedSide ?? ((plannedPath[0].item is ParsedPrefab) ? ManeuverSide(plannedPath[0]) : 0);
		if (side == 0 || !guard.TurnRisk(side))
		{
			turnYieldFor.Reset();
			return false;
		}
		if (!turnYieldFor.IsRunning)
		{
			turnYieldFor.Start();
			Events.Current.Publish<float>("ARC.Pathfinding.SideVehicle", guard.BehindClose ? side * 2f : side);
			Logger.Info($"ARC yan araç uyarısı: {(side < 0 ? "sol" : "sağ")}, arkada araç {guard.BehindClose}");
		}
		if (guard.BehindClose || turnYieldFor.Elapsed.TotalSeconds > TurnYieldMaxSeconds)
		{
			return false;
		}
		ApplicationState.Current.YieldSpeed(RearGuard.TurnYieldCap(telemetryData.truckFloat.speed, guard.SideSpeed(side)));
		return true;
	}

	/// <summary>Biri bizi sollarken hedef hızı kısa süre düşürür; geçip gidince eski hıza dönülür.</summary>
	private void UpdateOvertakeYield(RearGuardResult guard)
	{
		float speed = telemetryData.truckFloat.speed;
		if (guard.Overtaking && speed > YieldMinSpeed)
		{
			if (!yielding)
			{
				yielding = true;
				yieldBase = speed;
				Events.Current.Publish<float>("ARC.Pathfinding.OvertakeYield", speed);
			}
			sinceOvertake.Restart();
		}
		if (yielding && sinceOvertake.Elapsed.TotalSeconds > YieldReleaseSeconds)
		{
			yielding = false;
		}
		if (yielding)
		{
			ApplicationState.Current.YieldSpeed(MathF.Max(yieldBase - YieldDrop, YieldMinSpeed));
		}
	}

	private float XZDistance(Vector3 a, Vector3 b)
	{
		float num = a.X - b.X;
		float num2 = a.Z - b.Z;
		return MathF.Sqrt(num * num + num2 * num2);
	}

	public void IndicateLeft()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Expected Obj, but got Unknown
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Expected Obj, but got Unknown
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Expected Obj, but got Unknown
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Expected Obj, but got Unknown
		if (PathfindingSettings.Current.EnableIndicators)
		{
			ControlVariables variables = new ControlVariables
			{
				lblinker = true
			};
			ControlEvent val = new ControlEvent
			{
				ChannelDefinition = new ControlChannelDefinition
				{
					Id = "LaneAssist.IndicateLeft",
					Timeout = 0.1f
				},
				Properties = new ControlProperties
				{
					BooleanType = (ControlBooleanType)1
				},
				Variables = variables
			};
			Events.Current.Publish<ControlEvent>(GameOutput.Current.EventString, val);
			didStartIndicate = true;
			sinceLastIndicate.Restart();
		}
	}

	public void IndicateRight()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Expected Obj, but got Unknown
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Expected Obj, but got Unknown
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Expected Obj, but got Unknown
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Expected Obj, but got Unknown
		if (PathfindingSettings.Current.EnableIndicators)
		{
			ControlVariables variables = new ControlVariables
			{
				rblinker = true
			};
			ControlEvent val = new ControlEvent
			{
				ChannelDefinition = new ControlChannelDefinition
				{
					Id = "LaneAssist.IndicateRight",
					Timeout = 0.1f
				},
				Properties = new ControlProperties
				{
					BooleanType = (ControlBooleanType)1
				},
				Variables = variables
			};
			Events.Current.Publish<ControlEvent>(GameOutput.Current.EventString, val);
			didStartIndicate = true;
			sinceLastIndicate.Restart();
		}
	}

	public void ResetIndicators()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Expected Obj, but got Unknown
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Expected Obj, but got Unknown
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Expected Obj, but got Unknown
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Expected Obj, but got Unknown
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Expected Obj, but got Unknown
		if (!PathfindingSettings.Current.EnableIndicators || telemetryData == null)
		{
			return;
		}
		ControlVariables variables;
		if (telemetryData.truckBool.blinkerLeftActive)
		{
			variables = new ControlVariables
			{
				lblinker = true
			};
		}
		else
		{
			if (!telemetryData.truckBool.blinkerRightActive)
			{
				return;
			}
			variables = new ControlVariables
			{
				rblinker = true
			};
		}
		ControlEvent val = new ControlEvent
		{
			ChannelDefinition = new ControlChannelDefinition
			{
				Id = "LaneAssist.ResetIndicatorLeft",
				Timeout = 0.05f
			},
			Properties = new ControlProperties
			{
				BooleanType = (ControlBooleanType)1
			},
			Variables = variables
		};
		Events.Current.Publish<ControlEvent>(GameOutput.Current.EventString, val);
	}

	private void Indicate(int side)
	{
		if (side < 0)
		{
			IndicateLeft();
		}
		else
		{
			IndicateRight();
		}
	}

	private void StartOvertakeLaneChange(PlannedItem item, int lane)
	{
		item.targetLaneIndex = lane;
		releasedLaneChange = null;
		didStartIndicate = true;
		plannedPath.Clear();
		plannedPath.Add(item);
	}

	private static float DistanceToFactor(PlannedItem item, float distance)
	{
		return item.item is ParsedRoadList list ? list.DistanceToFactor(distance) : item.item is ParsedRoad road ? road.DistanceToFactor(distance) : 0f;
	}

	private bool StraightAhead(PlannedItem item, Vector3 truck)
	{
		float step = DistanceToFactor(item, OvertakeLookAhead / 2f) * (((int)item.direction == 1) ? -1f : 1f);
		float factor = item.GetFactorFor(truck);
		var near = item.Interpolate(factor, 0f, false);
		var middle = item.Interpolate(Math.Clamp(factor + step, 0f, 1f), 0f, false);
		var far = item.Interpolate(Math.Clamp(factor + step * 2f, 0f, 1f), 0f, false);
		return near.HasValue && middle.HasValue && far.HasValue
			&& Overtaker.Bend(near.Value.Position, middle.Value.Position, far.Value.Position) < OvertakeMaxBend;
	}

	/// <summary>Ayar açıksa yavaş aracı aynı yöndeki boş şeritten geçer. Kapalıyken hiçbir şeye dokunmaz.</summary>
	private void UpdateAutoOvertake(RearGuardResult sensed, int? plannedSide, Vector3 truck)
	{
		StateSettings settings = StateSettingsHandler.Current.GetSettings();
		float dt = MathF.Min((float)overtakeClock.Elapsed.TotalSeconds, 0.5f);
		overtakeClock.Restart();
		PlannedItem first = plannedPath[0];
		bool enabled = settings.OvertakeEnabled && ApplicationState.Current.EnableAssists && ApplicationState.Current.DrivingMode == DrivingMode.FullSelfDriving;
		if (!enabled || (overtaker.Stage >= OvertakeStage.MovingOut && first != overtakeItem))
		{
			if (overtaker.Stage != OvertakeStage.Idle)
			{
				overtaker.Reset(enabled ? Overtaker.FinishCooldown : 0f);
			}
			overtakeItem = null;
			return;
		}
		Road? road = first.item is ParsedRoad single ? single.Road : (first.item is ParsedRoadList list ? list.Roads[0].Road : null);
		int side = road == null ? 0 : (road.LeftHandTraffic ? 1 : -1);
		int laneCount = first.item is ParsedRoadList roads ? roads.GetLaneCount(first.laneIndex > 0 ? Side.Right : Side.Left)
			: (first.item is ParsedRoad one ? one.GetLaneCount(first.laneIndex > 0 ? Side.Right : Side.Left) : 0);
		int target = side == 0 ? 0 : Overtaker.TargetLane(first.laneIndex, (int)first.direction == 1, side, laneCount);
		float changeLength = 5f * MathF.Max(20f, telemetryData.truckFloat.speedLimit);
		float remaining = RemainingOnFirstItem();
		int activeSide = telemetryData.truckBool.blinkerRightActive ? 1 : (telemetryData.truckBool.blinkerLeftActive ? -1 : 0);
		int expectedSignal = overtaker.Stage == OvertakeStage.SignalingBack ? -overtakeSide : overtakeSide;
		// Kullanıcı sinyali kapatırsa sollamadan vazgeçilir.
		bool signalKept = !PathfindingSettings.Current.EnableIndicators || sinceLastIndicate.Elapsed.TotalSeconds < 1.5 || activeSide == expectedSignal;
		bool straight = StraightAhead(first, truck);
		bool canStart = target != 0 && first.targetLaneIndex == 0 && !plannedSide.HasValue && plannedPath.Count >= 2 && remaining >= changeLength * (overtaker.HoldsSignal ? 1.2f : 2f)
			&& plannedPath.Skip(1).All(p => p.targetLaneIndex == 0)
			&& (overtaker.HoldsSignal ? signalKept : straight && !didStartIndicate);
		bool backClear = first.targetLaneIndex == 0 && remaining >= changeLength * 1.5f && !sensed.Blocked(-overtakeSide) && !sensed.Near(-overtakeSide)
			&& (!plannedSide.HasValue || plannedSide == -overtakeSide) && (overtaker.Stage != OvertakeStage.SignalingBack || signalKept);
		var lead = Overtaker.FindLead(truck, truckForward, measuredVehicles);
		bool held = heldLaneChange == first;
		OvertakeCommand command = overtaker.Update(new OvertakeInput(true, settings.OvertakeWatchFirst, dt, lead.Found, lead.Distance, lead.Speed,
			telemetryData.truckFloat.speed, ApplicationState.Current.DesiredSpeed, canStart, !sensed.Blocked(side) && !sensed.Near(side), backClear,
			first.laneIndex == overtakeOutLane && first.targetLaneIndex == 0, first.laneIndex == overtakeHomeLane && first.targetLaneIndex == 0, held));
		if (overtaker.Stage != lastLoggedStage || (lead.Found && overtakeLog.Elapsed.TotalSeconds >= 5.0))
		{
			lastLoggedStage = overtaker.Stage;
			overtakeLog.Restart();
			Logger.Info($"ARC sollama: {overtaker.Stage}, önde {(lead.Found ? $"{lead.Distance:0} m {lead.Speed * 3.6f:0} km/s" : "yok")}, hedef {ApplicationState.Current.DesiredSpeed * 3.6f:0} km/s, tır {telemetryData.truckFloat.speed * 3.6f:0} km/s, şerit {first.laneIndex}>{target}/{laneCount}, kalan {MathF.Min(remaining, 99999f):0}/{changeLength * 2f:0} m, düz {straight}, planlı {plannedSide?.ToString() ?? "-"}, sinyal {didStartIndicate}/{activeSide}/{signalKept}, yan boş {!sensed.Blocked(side) && !sensed.Near(side)}, araç {measuredVehicles.Count}");
		}
		// Yalnız sollamanın kendi şerit değişimi; rota ya da kullanıcı şerit değişimi sinyal süresi için bekleyebilir.
		if (held && first == overtakeItem && overtaker.Stage is OvertakeStage.Idle or OvertakeStage.Passing)
		{
			// Şerit değişimi başlamadan yan şerit doldu: 15 sn bekleyip zorla geçmek yerine vazgeçilir.
			first.targetLaneIndex = 0;
			first.allowedToLaneChange = true;
			heldLaneChange = null;
		}
		if (overtaker.Stage == OvertakeStage.Idle)
		{
			overtakeItem = null; // biten sollamanın yolu, sonraki rota şerit değişimini iptal ettirmesin
		}
		switch (command)
		{
			case OvertakeCommand.Announce:
				overtakeSide = side;
				Indicate(side);
				Events.Current.Publish<float>("ARC.Pathfinding.AutoOvertake", side);
				break;
			case OvertakeCommand.MoveOut:
				overtakeItem = first;
				overtakeHomeLane = first.laneIndex;
				overtakeOutLane = target;
				StartOvertakeLaneChange(first, target);
				break;
			case OvertakeCommand.SignalBack:
				Indicate(-overtakeSide);
				break;
			case OvertakeCommand.MoveBack:
				StartOvertakeLaneChange(first, overtakeHomeLane);
				break;
		}
	}

	/// <summary>Planlanan yolda yaklaşan manevrayı bulur; sinyal zamanı geldiyse yönünü döner (-1 sol, +1 sağ).</summary>
	private int? PlannedIndicatorSide()
	{
		if (!PathfindingSettings.Current.EnableIndicators)
		{
			plannedReach = 0f;
			return null;
		}
		List<(float Distance, int Side)> ahead = new List<(float Distance, int Side)>();
		for (int i = 1; i < plannedPath.Count; i++)
		{
			int side = ManeuverSide(plannedPath[i]);
			if (side != 0)
			{
				ahead.Add((PathfindingUtils.DistanceTo(plannedPath[i], telemetryData.truckPlacement.coordinate), side));
			}
		}
		float speed = telemetryData.truckFloat.speed, seconds = StateSettingsHandler.Current.GetSettings().IndicatorLeadSeconds;
		int? side2 = IndicatorLead.Choose(ahead, speed, seconds, plannedReach);
		plannedReach = IndicatorLead.NextHeldReach(side2, plannedReach, speed, seconds);
		return side2;
	}

	private static int ManeuverSide(PlannedItem item)
	{
		if (item.item is ParsedPrefab)
		{
			PrefabPath prefabPath = item.prefabPath;
			if (prefabPath == null)
			{
				return 0;
			}
			var start = prefabPath.Interpolate(0.02f, 0f);
			if (!start.HasValue)
			{
				return 0;
			}
			NavCurve curve = prefabPath.GetCurrentCurve(start.Value.Position);
			for (int i = 0; i < 16 && curve != null; i++)
			{
				if ((int)curve.Blinker == 2)
				{
					return 1;
				}
				if ((int)curve.Blinker == 4)
				{
					return -1;
				}
				curve = prefabPath.GetNextCurve(curve);
			}
			return 0;
		}
		if (item.targetLaneIndex == 0 || item.GetLane() == null)
		{
			return 0;
		}
		int direction = ((int)item.direction == 1) ? -1 : 1;
		return (item.laneIndex - item.targetLaneIndex) * direction > 0 ? 1 : -1;
	}

	public bool CurrentPrefabNeedsBlinker(Vector3 truckPos)
	{
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Invalid comparison between Unknown and I4
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Invalid comparison between Unknown and I4
		if (!(plannedPath[0].item is ParsedPrefab))
		{
			return false;
		}
		PrefabPath prefabPath = plannedPath[0].prefabPath;
		if (prefabPath != null)
		{
			NavCurve currentCurve = prefabPath.GetCurrentCurve(truckPos);
			if (currentCurve != null)
			{
				NavCurve previousCurve = prefabPath.GetPreviousCurve(currentCurve);
				NavCurve nextCurve = prefabPath.GetNextCurve(currentCurve);
				List<BlinkerType> list = new List<BlinkerType> { currentCurve.Blinker };
				if (nextCurve != null)
				{
					list.Add(nextCurve.Blinker);
				}
				if (previousCurve != null)
				{
					list.Add(previousCurve.Blinker);
				}
				foreach (BlinkerType item in list)
				{
					if ((int)item != 2)
					{
						if ((int)item == 4)
						{
							return true;
						}
						continue;
					}
					return true;
				}
			}
		}
		return false;
	}

	public override void Tick()
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Expected Obj, but got Unknown
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Expected Obj, but got Unknown
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_032b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02df: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f7: Expected Obj, but got Unknown
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Expected Obj, but got Unknown
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_0129: Unknown result type (might be due to invalid IL or missing references)
		//IL_0134: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Expected Obj, but got Unknown
		//IL_0177: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0187: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_019f: Expected Obj, but got Unknown
		//IL_03c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0201: Unknown result type (might be due to invalid IL or missing references)
		//IL_0206: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_0229: Expected Obj, but got Unknown
		//IL_04d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_04d8: Invalid comparison between Unknown and I4
		//IL_0563: Unknown result type (might be due to invalid IL or missing references)
		//IL_0642: Unknown result type (might be due to invalid IL or missing references)
		//IL_0648: Invalid comparison between Unknown and I4
		//IL_0577: Unknown result type (might be due to invalid IL or missing references)
		//IL_075e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0764: Invalid comparison between Unknown and I4
		//IL_06a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0589: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_05aa: Invalid comparison between Unknown and I4
		//IL_05ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_05af: Invalid comparison between Unknown and I4
		//IL_090f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0914: Unknown result type (might be due to invalid IL or missing references)
		//IL_0925: Unknown result type (might be due to invalid IL or missing references)
		//IL_093b: Unknown result type (might be due to invalid IL or missing references)
		//IL_094c: Expected Obj, but got Unknown
		lastFrameError = "";
		if (!ApplicationState.Current.EnableAssists)
		{
			lastFrameError = "Assists are disabled.";
			plannedPath.Clear();
			Events.Current.Publish<PlannedPathData>("Pathfinding.PlannedPathData", new PlannedPathData
			{
				PlannedPath = new List<PlannedItem>(),
				HasError = true,
				ErrorMessage = lastFrameError
			});
			return;
		}
		if (telemetryData == null)
		{
			lastFrameError = "Waiting for telemetry data...";
			plannedPath.Clear();
			Events.Current.Publish<PlannedPathData>("Pathfinding.PlannedPathData", new PlannedPathData
			{
				PlannedPath = new List<PlannedItem>(),
				HasError = true,
				ErrorMessage = lastFrameError
			});
			return;
		}
		if (mapData == null)
		{
			lastFrameError = "Waiting for map data...";
			plannedPath.Clear();
			Events.Current.Publish<PlannedPathData>("Pathfinding.PlannedPathData", new PlannedPathData
			{
				PlannedPath = new List<PlannedItem>(),
				HasError = true,
				ErrorMessage = lastFrameError
			});
			return;
		}
		if (telemetryData.paused)
		{
			lastFrameError = "Game is paused.";
			Events.Current.Publish<PlannedPathData>("Pathfinding.PlannedPathData", new PlannedPathData
			{
				PlannedPath = new List<PlannedItem>(),
				HasError = true,
				ErrorMessage = lastFrameError
			});
			return;
		}
		if (nearbyNodes == null || nearbyNodes.Count == 0)
		{
			lastFrameError = "No nearby nodes found.";
			Events.Current.Publish<PlannedPathData>("Pathfinding.PlannedPathData", new PlannedPathData
			{
				PlannedPath = new List<PlannedItem>(),
				HasError = true,
				ErrorMessage = lastFrameError
			});
			return;
		}
		Vector3 vector = telemetryData.truckPlacement.coordinate.ToVector3();
		Vector3 rotation = telemetryData.truckPlacement.rotation.ToVector3();
		if (plannedPath.Count == 0)
		{
			PlannedItem val = PathfindingUtils.CreateFirstPlannedItem(nearbyNodes, vector, rotation);
			if (val == null)
			{
				lastFrameError = "No suitable starting road found for path planning.";
				Events.Current.Publish<PlannedPathData>("Pathfinding.PlannedPathData", new PlannedPathData
				{
					PlannedPath = new List<PlannedItem>(),
					HasError = true,
					ErrorMessage = lastFrameError
				});
				return;
			}
			plannedPath.Add(val);
			recoveryTolerance = LaneSelector.OwnSideReach + RecoveryMargin;
		}
		if (plannedPath.Count < PathfindingSettings.Current.PathLength)
		{
			try
			{
				PlannedItem val2 = PathfindingUtils.CreateNextPlannedItem(plannedPath, navigationData);
				if (val2 != null)
				{
					plannedPath.Add(val2);
				}
			}
			catch (Exception value)
			{
				Logger.Error($"Error while creating next planned item: {value}", "C:\\Users\\Tumppi066\\Documents\\GitHub\\ets2la-core-plugins\\Plugins\\Pathfinding\\Program.cs", 330);
			}
		}
		if (plannedPath.Count == 0)
		{
			lastFrameError = "No planned path available.";
			Events.Current.Publish<PlannedPathData>("Pathfinding.PlannedPathData", new PlannedPathData
			{
				PlannedPath = new List<PlannedItem>(),
				HasError = true,
				ErrorMessage = lastFrameError
			});
			return;
		}
		OrientedPoint value2 = plannedPath[0].Interpolate(plannedPath[0].GetFactorFor(vector), 0f, false).Value;
		float num = XZDistance(value2.Position, vector);
		float num2;
		if (plannedPath.Count <= 1)
		{
			num2 = float.MaxValue;
		}
		else
		{
			PlannedItem val3 = plannedPath[1];
			float num3;
			if (plannedPath[1].GetFactorFor(vector) == 0f)
			{
				num3 = 0.01f;
			}
			else
			{
				num3 = ((plannedPath[1].GetFactorFor(vector) == 1f) ? 0.99f : plannedPath[1].GetFactorFor(vector));
			}
			value2 = ((PlannedItem)val3).Interpolate(num3, 0f, false).Value;
			num2 = XZDistance(value2.Position, vector);
		}
		float num4 = num2;
		// ARC: rota yeni kurulduğunda tır kendi şeridinden uzak olabilir; yaklaştıkça tolerans daralır, uzaklaşırsa rota silinir.
		if (recoveryTolerance > 0f)
		{
			recoveryTolerance = MathF.Min(recoveryTolerance, num + RecoveryMargin);
			if (recoveryTolerance <= PathTolerance)
			{
				recoveryTolerance = 0f;
			}
		}
		float num5 = MathF.Max(PathTolerance, recoveryTolerance); // ARC: dorseli virajda hedef çizgi 1,5 m kayar; 2,2 m'de rota siliniyordu.
		if (num4 < num && num4 < num5)
		{
			plannedPath.RemoveAt(0);
		}
		else if (num > num5)
		{
			Logger.Warn($"Truck is too far from the planned path. Current distance: {num:F1}m. Clearing planned path.", "C:\\Users\\Tumppi066\\Documents\\GitHub\\ets2la-core-plugins\\Plugins\\Pathfinding\\Program.cs", 356);
			lastFrameError = $"Truck is too far from the planned path. ({num:F1}m)";
			plannedPath.Clear();
			return;
		}
		RearGuardResult sensedTraffic = EvaluateRearGuard(vector);
		RearGuardResult rearGuard = (StateSettingsHandler.Current.GetSettings().WatchRearTraffic || overtaker.Stage != OvertakeStage.Idle) ? sensedTraffic : default(RearGuardResult);
		UpdateLaneChangeHold(rearGuard);
		if (!didStartIndicate && plannedPath[0].targetLaneIndex != 0)
		{
			PlannedItem val4 = plannedPath[0];
			if (val4.GetLane() != null)
			{
				int num6 = val4.laneIndex - val4.targetLaneIndex;
				int num7 = 1;
				if ((int)val4.direction == 1)
				{
					num7 *= -1;
				}
				if (num6 * num7 > 0)
				{
					IndicateRight();
				}
				else
				{
					IndicateLeft();
				}
			}
		}
		if (!didStartIndicate && plannedPath[0].item is ParsedPrefab)
		{
			PrefabPath prefabPath = plannedPath[0].prefabPath;
			if (prefabPath != null)
			{
				NavCurve currentCurve = prefabPath.GetCurrentCurve(vector);
				if (currentCurve != null)
				{
					NavCurve previousCurve = prefabPath.GetPreviousCurve(currentCurve);
					NavCurve nextCurve = prefabPath.GetNextCurve(currentCurve);
					List<BlinkerType> list = new List<BlinkerType> { currentCurve.Blinker };
					if (nextCurve != null)
					{
						list.Add(nextCurve.Blinker);
					}
					if (previousCurve != null)
					{
						list.Add(previousCurve.Blinker);
					}
					foreach (BlinkerType item in list)
					{
						if ((int)item != 2)
						{
							if ((int)item == 4)
							{
								IndicateLeft();
							}
						}
						else
						{
							IndicateRight();
						}
					}
				}
			}
		}
		// ARC: sinyal kavşağa girerken değil, ayarlanan süre kadar önce verilir
		int? plannedSide = PlannedIndicatorSide();
		if (!UpdateTurnYield(rearGuard, plannedSide))
		{
			UpdateOvertakeYield(rearGuard);
		}
		UpdateAutoOvertake(sensedTraffic, plannedSide, vector);
		if (!didStartIndicate && plannedSide.HasValue && sinceLastIndicate.Elapsed.TotalSeconds > 0.25)
		{
			if (plannedSide.Value > 0)
			{
				IndicateRight();
			}
			else
			{
				IndicateLeft();
			}
		}
		if (telemetryData.truckBool.blinkerLeftActive && !didStartIndicate && sinceLastLaneChange.Elapsed.TotalSeconds > 1.0)
		{
			PlannedItem val5 = plannedPath[0];
			if (val5.GetLane() != null)
			{
				int laneIndex = val5.laneIndex;
				int num8 = 1;
				if ((int)val5.direction == 1)
				{
					num8 *= -1;
				}
				int value3 = (val5.targetLaneIndex = laneIndex + num8);
				Logger.Info($"Indicating lane change to the left, from lane index {laneIndex} to {value3} (dir: {val5.direction})", "C:\\Users\\Tumppi066\\Documents\\GitHub\\ets2la-core-plugins\\Plugins\\Pathfinding\\Program.cs", 421);
				didStartIndicate = true;
				plannedPath.Clear();
				plannedPath.Add(val5);
			}
		}
		else if (telemetryData.truckBool.blinkerRightActive && !didStartIndicate && sinceLastLaneChange.Elapsed.TotalSeconds > 1.0)
		{
			PlannedItem val6 = plannedPath[0];
			if (val6.GetLane() != null)
			{
				int laneIndex2 = val6.laneIndex;
				int num9 = -1;
				if ((int)val6.direction == 1)
				{
					num9 *= -1;
				}
				int value4 = (val6.targetLaneIndex = laneIndex2 + num9);
				Logger.Info($"Indicating lane change to the right, from lane index {laneIndex2} to {value4} (dir: {val6.direction})", "C:\\Users\\Tumppi066\\Documents\\GitHub\\ets2la-core-plugins\\Plugins\\Pathfinding\\Program.cs", 439);
				didStartIndicate = true;
				plannedPath.Clear();
				plannedPath.Add(val6);
			}
		}
		bool num10 = didStartIndicate && !telemetryData.truckBool.blinkerLeftActive && !telemetryData.truckBool.blinkerRightActive;
		// ARC: sinyal yalnızca yaklaşan manevra aynı yöndeyse açık tutulur; zıt yöndeyse kapanır, sonra doğru yöne verilir.
		int activeSide = telemetryData.truckBool.blinkerRightActive ? 1 : (telemetryData.truckBool.blinkerLeftActive ? -1 : 0);
		bool keepForPlanned = IndicatorLead.KeepSignal(plannedSide, activeSide) || overtaker.HoldsSignal;
		bool flag = (plannedPath[0].item is ParsedRoadList || plannedPath[0].item is ParsedRoad) && plannedPath[0].targetLaneIndex == 0 && didStartIndicate && !keepForPlanned;
		bool flag2 = plannedPath[0].item is ParsedPrefab && !CurrentPrefabNeedsBlinker(vector) && didStartIndicate && !keepForPlanned;
		bool flag3 = sinceLastIndicate.Elapsed.TotalSeconds < 1.0;
		if ((num10 | flag | flag2) && !flag3)
		{
			ResetIndicators();
			sinceLastLaneChange.Restart();
			sinceLastIndicate.Restart();
			didStartIndicate = false;
		}
		Events.Current.Publish<float>("ARC.Pathfinding.RecoveryTolerance", recoveryTolerance);
		Events.Current.Publish<PlannedPathData>("Pathfinding.PlannedPathData", new PlannedPathData
		{
			PlannedPath = new List<PlannedItem>(plannedPath),
			HasError = (lastFrameError != ""),
			ErrorMessage = lastFrameError
		});
	}
}
