using System.Collections.Generic;

namespace Pathfinding;

/// <summary>
///  Rota yeniden kurulurken şeridi seçer. Yalnız en yakın şeride bakmak, tır orta çizgiye yaklaştığında
///  karşı şeridi seçtiriyordu; önce tırın gidiş yönündeki şeritlere bakılır.
/// </summary>
public static class LaneSelector
{
    /// <summary>Kendi yönündeki şeride bundan uzaksa tır gerçekten karşı şerittedir.</summary>
    public const float OwnSideReach = 6f;

    /// <param name="lanes">Şeritler. Lane: artı "Right", eksi "Left" adlı taraf. Distance: tıra uzaklığı, metre.</param>
    /// <param name="forward">Tır yolun çizim yönünde mi gidiyor.</param>
    /// <param name="leftHandTraffic">Soldan trafik (Birleşik Krallık gibi).</param>
    /// <returns>Seçilen şerit; şerit yoksa -1.</returns>
    public static int Choose(IEnumerable<(int Lane, double Distance)> lanes, bool forward, bool leftHandTraffic)
    {
        // Oyun haritasında "Right" adlı (artı numaralı) şeritler yolun çizim yönüne göre gerçekte soldadır (74.696 yolun hepsinde
        // ölçüldü). Sağdan trafikte ileri giden tır bu yüzden eksi numaralı şeritlerdedir.
        var wantedPositive = forward == leftHandTraffic;
        int nearest = -1, own = 0;
        double nearestDistance = double.MaxValue, ownDistance = double.MaxValue;
        foreach (var (lane, distance) in lanes)
        {
            if (distance < nearestDistance)
            {
                nearestDistance = distance;
                nearest = lane;
            }
            if (lane > 0 == wantedPositive && distance < ownDistance)
            {
                ownDistance = distance;
                own = lane;
            }
        }
        return own != 0 && ownDistance <= OwnSideReach ? own : nearest;
    }
}
