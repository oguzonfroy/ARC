using System;
using System.Collections.Generic;
using System.Numerics;

namespace Pathfinding;

public readonly record struct RearGuardResult(bool LeftBlocked, bool RightBlocked, bool Overtaking,
    bool LeftTurnRisk = false, bool RightTurnRisk = false, float LeftSpeed = 0f, float RightSpeed = 0f, bool BehindClose = false,
    bool LeftNear = false, bool RightNear = false)
{
    public bool Near(int side) => side < 0 ? LeftNear : side > 0 && RightNear;
    public bool Blocked(int side) => side < 0 ? LeftBlocked : side > 0 && RightBlocked;
    public bool TurnRisk(int side) => side < 0 ? LeftTurnRisk : side > 0 && RightTurnRisk;
    public float SideSpeed(int side) => side < 0 ? LeftSpeed : RightSpeed;
}

/// <summary>
///  Yan şeritte yanımızda olan ya da arkadan hızla yaklaşan aracı bulur. Saf hesap: oyun okumaz.
///  Araçların hızı, oyundaki yön verisine güvenmemek için konum farkından ölçülür.
/// </summary>
public static class RearGuard
{
    const float SameLane = 1.8f;
    const float AdjacentLanes = 9f;
    const float Reach = 80f;
    const float MinMovingSpeed = 1f;
    public const float AlongsideRear = -20f;
    public const float AlongsideFront = 10f;
    const float TurnFront = 20f;
    const float NearFront = 40f;
    const float BehindReach = 25f;
    const float TurnYieldMargin = 2.8f;
    const float TurnCrawlSpeed = 2f;
    const float OvertakeRear = -30f;
    const float OvertakeFront = 16f;
    const float WarningSeconds = 6f;
    const float MinClosing = 0.5f;
    const float OvertakeClosing = 1f;

    /// <param name="truck">Tırın konumu.</param>
    /// <param name="forward">Tırın gidiş yönü (birim; Y kullanılmaz).</param>
    /// <param name="truckSpeed">Tırın hızı, m/s.</param>
    /// <param name="vehicles">Çevredeki araçların konumu ve ölçülen hız vektörü.</param>
    /// <param name="alongsideRear">Araç boyuna göre arka sınır (eksi metre): dorsesiz kısa, çift dorseli uzun.</param>
    /// <summary>Tırın boyuna göre arka sınır, eksi metre.</summary>
    public static float RearExtent(int trailers) => trailers <= 0 ? -9f : trailers == 1 ? AlongsideRear : -30f;

    /// <summary>Dönüşte yandaki aracın önüne geçmemek için hedef hız. Durmaz: sıfır hedef hız kontrolünü kapatır.</summary>
    public static float TurnYieldCap(float truckSpeed, float sideSpeed) =>
        MathF.Max(MathF.Min(truckSpeed, sideSpeed - TurnYieldMargin), TurnCrawlSpeed);

    public static RearGuardResult Evaluate(Vector3 truck, Vector3 forward, float truckSpeed, IEnumerable<(Vector3 Position, Vector3 Velocity)> vehicles, float alongsideRear = AlongsideRear)
    {
        var right = new Vector3(-forward.Z, 0f, forward.X);
        bool left = false, rightSide = false, overtaking = false, leftTurn = false, rightTurn = false, behind = false;
        bool leftNear = false, rightNear = false;
        float leftSpeed = float.MaxValue, rightSpeed = float.MaxValue;
        foreach (var (position, velocity) in vehicles)
        {
            var offset = position - truck;
            offset.Y = 0f;
            if (offset.Length() > Reach) continue;
            var along = Vector3.Dot(velocity, forward);
            var lateral = Vector3.Dot(offset, right);
            var side = MathF.Abs(lateral);
            var ahead = Vector3.Dot(offset, forward);
            // Duran araç da şeridi doldurur; yalnızca karşı yönden geleni saymayız.
            if (along > -MinMovingSpeed && side >= SameLane && side <= AdjacentLanes && ahead >= alongsideRear && ahead <= NearFront)
            {
                if (lateral < 0f) leftNear = true;
                else rightNear = true;
            }
            if (along < MinMovingSpeed) continue;
            if (side < SameLane)
            {
                behind |= ahead < alongsideRear && ahead >= alongsideRear - BehindReach;
                continue;
            }
            if (side > AdjacentLanes) continue;

            var closing = along - truckSpeed;
            var alongside = ahead >= alongsideRear && ahead <= AlongsideFront;
            var arriving = ahead < alongsideRear && closing > MinClosing && (alongsideRear - ahead) / closing < WarningSeconds;
            if (alongside || arriving)
            {
                if (lateral < 0f) left = true;
                else rightSide = true;
            }
            if ((ahead >= alongsideRear && ahead <= TurnFront) || arriving)
            {
                if (lateral < 0f)
                {
                    leftTurn = true;
                    leftSpeed = MathF.Min(leftSpeed, along);
                }
                else
                {
                    rightTurn = true;
                    rightSpeed = MathF.Min(rightSpeed, along);
                }
            }
            if (ahead >= OvertakeRear && ahead <= OvertakeFront && closing > OvertakeClosing) overtaking = true;
        }
        return new RearGuardResult(left, rightSide, overtaking, leftTurn, rightTurn, leftSpeed, rightSpeed, behind, leftNear, rightNear);
    }
}
