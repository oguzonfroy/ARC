using System;
using System.Collections.Generic;
using System.Numerics;

namespace Pathfinding;

public enum OvertakeStage { Idle, Watching, Announcing, MovingOut, Passing, SignalingBack, Returning }

public enum OvertakeCommand { None, Announce, MoveOut, SignalBack, MoveBack }

public readonly record struct OvertakeInput(bool Enabled, bool WatchFirst, float Dt, bool HasLead, float LeadDistance, float LeadSpeed,
    float TruckSpeed, float TargetSpeed, bool CanStart, bool OutClear, bool BackClear, bool OnOutLane, bool OnHomeLane, bool Held = false);

/// <summary>Otomatik sollamanın karar akışı. Saf hesap: oyun okumaz, yalnızca ne zaman ne yapılacağını söyler.</summary>
public sealed class Overtaker
{
    public const float WatchSeconds = 5f;
    public const float AnnounceSeconds = 3.5f;
    public const float BackSignalSeconds = 2f;
    public const float FinishCooldown = 30f;
    const float SameLane = 1.8f;
    const float LeadReach = 70f;
    const float MinLeadSpeed = 3f;
    const float MinTruckSpeed = 8f;
    // Haber verildikten sonra öndekinin arkasında yavaşlamak sollamayı iptal etmesin.
    const float AnnouncedMinTruckSpeed = 5f;
    const float SlowerBy = 2.8f;
    // TruckersMP'de 250 ms'lik hız ölçümü 15 km/s zıplıyor: tek ölçüme bakılmaz.
    const float SpeedingUpBy = 2f;
    const float LeadSmoothSeconds = 1.5f;
    const float LostGrace = 1.5f;
    const float LaneChangeTimeout = 20f;
    const float MinPassSeconds = 2f;
    // Uyarı kutusunun 8 sn bekleme süresinden uzun: yeniden denemede uyarı görünmeden sollama başlamasın.
    const float CancelCooldown = 10f;

    float _timer, _cooldown, _watchBase, _leadAvg, _lostFor;
    bool _hasAvg;

    public OvertakeStage Stage { get; private set; }

    public bool HoldsSignal => Stage is OvertakeStage.Announcing or OvertakeStage.SignalingBack;

    public void Reset(float cooldown = 0f)
    {
        Stage = OvertakeStage.Idle;
        _timer = 0f;
        _lostFor = 0f;
        _hasAvg = false;
        _cooldown = cooldown;
    }

    static bool SpeedInRange(float speed, float target) => speed >= MinLeadSpeed && speed <= target - SlowerBy;

    bool LeadSlow(in OvertakeInput i, float minTruckSpeed = MinTruckSpeed) =>
        i.HasLead && i.LeadDistance <= LeadReach && i.TruckSpeed >= minTruckSpeed && SpeedInRange(_leadAvg, i.TargetSpeed);

    bool Wanted(in OvertakeInput i) => i.Enabled && i.CanStart && LeadSlow(i);

    OvertakeCommand Enter(OvertakeStage stage, OvertakeCommand command = OvertakeCommand.None)
    {
        Stage = stage;
        _timer = 0f;
        _lostFor = 0f;
        return command;
    }

    public OvertakeCommand Update(in OvertakeInput i)
    {
        _cooldown = MathF.Max(0f, _cooldown - i.Dt);
        _timer += i.Dt;
        if (i.HasLead)
        {
            _leadAvg = _hasAvg ? _leadAvg + (i.LeadSpeed - _leadAvg) * MathF.Min(1f, i.Dt / LeadSmoothSeconds) : i.LeadSpeed;
            _hasAvg = true;
        }
        else if (Stage == OvertakeStage.Idle)
        {
            _hasAvg = false;
        }
        switch (Stage)
        {
            case OvertakeStage.Idle:
                // Ortalama geriden gelir: yeni araç ya da duran araç için anlık hız da uymalı.
                if (_cooldown > 0f || !Wanted(i) || !SpeedInRange(i.LeadSpeed, i.TargetSpeed)) return OvertakeCommand.None;
                if (i.WatchFirst)
                {
                    _watchBase = _leadAvg;
                    return Enter(OvertakeStage.Watching);
                }
                return i.OutClear ? Enter(OvertakeStage.Announcing, OvertakeCommand.Announce) : OvertakeCommand.None;

            case OvertakeStage.Watching:
                var wanted = Wanted(i);
                _lostFor = wanted ? 0f : _lostFor + i.Dt;
                if (_lostFor > LostGrace)
                {
                    Reset();
                    return OvertakeCommand.None;
                }
                if (_leadAvg > _watchBase + SpeedingUpBy)
                {
                    _watchBase = _leadAvg;
                    _timer = 0f;
                    return OvertakeCommand.None;
                }
                _watchBase = MathF.Min(_watchBase, _leadAvg);
                return _timer >= WatchSeconds && wanted && i.OutClear ? Enter(OvertakeStage.Announcing, OvertakeCommand.Announce) : OvertakeCommand.None;

            case OvertakeStage.Announcing:
                _lostFor = LeadSlow(i, AnnouncedMinTruckSpeed) ? 0f : _lostFor + i.Dt;
                if (!i.Enabled || !i.CanStart || !i.OutClear || _lostFor > LostGrace)
                {
                    Reset(CancelCooldown);
                    return OvertakeCommand.None;
                }
                return _timer >= AnnounceSeconds ? Enter(OvertakeStage.MovingOut, OvertakeCommand.MoveOut) : OvertakeCommand.None;

            case OvertakeStage.MovingOut:
                if (i.Held)
                {
                    Reset(CancelCooldown);
                    return OvertakeCommand.None;
                }
                if (i.OnOutLane) return Enter(OvertakeStage.Passing);
                if (_timer > LaneChangeTimeout) Reset(FinishCooldown);
                return OvertakeCommand.None;

            case OvertakeStage.Passing:
                if (!i.OnOutLane)
                {
                    Reset(FinishCooldown);
                    return OvertakeCommand.None;
                }
                return _timer >= MinPassSeconds && i.BackClear ? Enter(OvertakeStage.SignalingBack, OvertakeCommand.SignalBack) : OvertakeCommand.None;

            case OvertakeStage.SignalingBack:
                if (!i.OnOutLane)
                {
                    Reset(FinishCooldown);
                    return OvertakeCommand.None;
                }
                if (!i.BackClear) return Enter(OvertakeStage.Passing);
                return _timer >= BackSignalSeconds ? Enter(OvertakeStage.Returning, OvertakeCommand.MoveBack) : OvertakeCommand.None;

            case OvertakeStage.Returning:
                if (i.Held) return Enter(OvertakeStage.Passing);
                if (i.OnHomeLane || _timer > LaneChangeTimeout) Reset(FinishCooldown);
                return OvertakeCommand.None;
        }
        return OvertakeCommand.None;
    }

    /// <summary>Yolun bükülmesi: b noktasının a-c doğrusuna uzaklığı, metre. Tırın anlık yönünden etkilenmez.</summary>
    public static float Bend(Vector3 a, Vector3 b, Vector3 c)
    {
        var chord = new Vector2(c.X - a.X, c.Z - a.Z);
        var point = new Vector2(b.X - a.X, b.Z - a.Z);
        var length = chord.Length();
        return length < 1f ? point.Length() : MathF.Abs(chord.X * point.Y - chord.Y * point.X) / length;
    }

    /// <summary>Kendi şeridimizde önümüzdeki en yakın araç. Duran araç da sayılır: kuyruğun başını sollamaya kalkmayalım.</summary>
    public static (bool Found, float Distance, float Speed) FindLead(Vector3 truck, Vector3 forward, IEnumerable<(Vector3 Position, Vector3 Velocity)> vehicles)
    {
        var right = new Vector3(-forward.Z, 0f, forward.X);
        (bool Found, float Distance, float Speed) lead = (false, float.MaxValue, 0f);
        foreach (var (position, velocity) in vehicles)
        {
            var offset = position - truck;
            offset.Y = 0f;
            var ahead = Vector3.Dot(offset, forward);
            if (ahead <= 0f || ahead > LeadReach || ahead >= lead.Distance || MathF.Abs(Vector3.Dot(offset, right)) >= SameLane) continue;
            var along = Vector3.Dot(velocity, forward);
            if (along >= -1f) lead = (true, ahead, along);
        }
        return lead;
    }

    /// <summary>Sollama şeridinin numarası; o yönde şerit yoksa 0. Karşı yöne geçmez.</summary>
    public static int TargetLane(int laneIndex, bool backward, int side, int laneCount)
    {
        var step = (side < 0 ? 1 : -1) * (backward ? -1 : 1);
        var target = laneIndex + step;
        return target == 0 || Math.Sign(target) != Math.Sign(laneIndex) || Math.Abs(target) > laneCount ? 0 : target;
    }
}
