using System;
using ETS2LA.Settings;

namespace Pathfinding;

[Serializable]
public class PathfindingSettings
{
	[NonSerialized]
	private static readonly Lazy<PathfindingSettings> _instance = new Lazy<PathfindingSettings>(() => new PathfindingSettings(loadSettings: true));

	public bool EnableIndicators = true;

	public bool EnableLaneChanges = true;

	public int PathLength = 5;

	[NonSerialized]
	private SettingsHandler? _settingsHandler;

	public static PathfindingSettings Current => _instance.Value;

	public PathfindingSettings(bool loadSettings = false)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Expected Obj, but got Unknown
		if (loadSettings)
		{
			_settingsHandler = new SettingsHandler();
			PathfindingSettings pathfindingSettings = _settingsHandler.Load<PathfindingSettings>("tumppi066.pathfinding.json");
			if (pathfindingSettings != null)
			{
				EnableIndicators = pathfindingSettings.EnableIndicators;
				EnableLaneChanges = pathfindingSettings.EnableLaneChanges;
				PathLength = pathfindingSettings.PathLength;
			}
		}
	}

	public PathfindingSettings()
	{
	}

	public void Save()
	{
		SettingsHandler? settingsHandler = _settingsHandler;
		if (settingsHandler != null)
		{
			settingsHandler.Save<PathfindingSettings>("tumppi066.pathfinding.json", this);
		}
	}
}
