using System;
using ETS2LA.Translations;
using ETS2LA.UI.Shared.Components;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;

namespace Pathfinding;

[Route("/plugins/adjustments/tumppi066.pathfinding")]
public class Adjustments : ComponentBase
{
	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full p-5 px-8 gap-3");
		__builder.OpenComponent<Switch>(2);
		__builder.AddComponentParameter(3, "Title", RuntimeHelpers.TypeCheck(T._("Enable Indicators", Array.Empty<object>())));
		__builder.AddComponentParameter(4, "Description", RuntimeHelpers.TypeCheck(T._("Enable or disable the use of indicators when changing lanes.", Array.Empty<object>())));
		__builder.AddComponentParameter(5, "Value", RuntimeHelpers.TypeCheck(PathfindingSettings.Current.EnableIndicators));
		__builder.AddComponentParameter(6, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			PathfindingSettings.Current.EnableIndicators = value;
			PathfindingSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(7, "\r\n\r\n    ");
		__builder.OpenComponent<Switch>(8);
		__builder.AddComponentParameter(9, "Title", RuntimeHelpers.TypeCheck(T._("Enable Lane Changes", Array.Empty<object>())));
		__builder.AddComponentParameter(10, "Description", RuntimeHelpers.TypeCheck(T._("Enable or disable lane changes.", Array.Empty<object>())));
		__builder.AddComponentParameter(11, "Value", RuntimeHelpers.TypeCheck(PathfindingSettings.Current.EnableLaneChanges));
		__builder.AddComponentParameter(12, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			PathfindingSettings.Current.EnableLaneChanges = value;
			PathfindingSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(13, "\r\n\r\n    ");
		__builder.OpenComponent<Slider>(14);
		__builder.AddComponentParameter(15, "Title", RuntimeHelpers.TypeCheck(T._("Path Length", Array.Empty<object>())));
		__builder.AddComponentParameter(16, "Description", RuntimeHelpers.TypeCheck(T._("The number of items ahead of the vehicle to consider for pathfinding. More items will result in a longer path, but may also increase computation time.", Array.Empty<object>())));
		__builder.AddComponentParameter(17, "Value", RuntimeHelpers.TypeCheck((float)PathfindingSettings.Current.PathLength));
		__builder.AddComponentParameter(18, "Min", RuntimeHelpers.TypeCheck(1f));
		__builder.AddComponentParameter(19, "Max", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(20, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			PathfindingSettings.Current.PathLength = (int)Math.Round(value);
			PathfindingSettings.Current.Save();
		})));
		__builder.CloseComponent();
		__builder.CloseElement();
	}
}
