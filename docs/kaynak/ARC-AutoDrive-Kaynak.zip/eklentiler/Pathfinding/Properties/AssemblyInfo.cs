using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("Pathfinding")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+c62ffdb3010dae2a08155125c4031abb108e479a")]
[assembly: AssemblyProduct("Pathfinding")]
[assembly: AssemblyTitle("Pathfinding")]
[assembly: AssemblyVersion("1.0.0.0")]
