using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("PathLib")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+a8bd1083696df148836fa2289593c9c7e11ee2c8")]
[assembly: AssemblyProduct("PathLib")]
[assembly: AssemblyTitle("PathLib")]
[assembly: AssemblyVersion("1.0.0.0")]
