using System;
using System.Collections.Generic;
using System.Numerics;
using ETS2LA.Game.Data;
using ETS2LA.Game.Telemetry;
using ETS2LA.Logging;
using TruckLib;
using TruckLib.ScsMap;

namespace PathLib;

public class PlannedItem
{
	public required IParsedItem item;

	public PrefabPath? prefabPath;

	public PrefabPath[] otherPrefabPaths = Array.Empty<PrefabPath>();

	public List<ParsedRoad>? connectedRoads;

	public PlannedItem? lastItem;

	public required Node startNode;

	public required Node endNode;

	public required int laneIndex;

	public int targetLaneIndex;

	public required Direction direction;

	private float laneChangeStartFactor = float.NaN;

	public bool allowedToLaneChange = true;

	private bool LaneChangeStartUninitialized => float.IsNaN(laneChangeStartFactor);

	public Tuple<Side, int>? GetLane()
	{
		return GetLane(laneIndex);
	}

	public Tuple<Side, int>? GetLane(int index)
	{
		if (index == 0)
		{
			return null;
		}
		IParsedItem parsedItem = this.item;
		if (!(parsedItem is ParsedPrefab))
		{
			if (!(parsedItem is ParsedRoad parsedRoad))
			{
				if (parsedItem is ParsedRoadList parsedRoadList)
				{
					int totalLaneCount = parsedRoadList.GetTotalLaneCount();
					if (totalLaneCount == 0)
					{
						return null;
					}
					Side item = ((index >= 0) ? Side.Right : Side.Left);
					int num = Math.Abs(index) - 1;
					if (num >= totalLaneCount)
					{
						return null;
					}
					return new Tuple<Side, int>(item, num);
				}
				return null;
			}
			int totalLaneCount2 = parsedRoad.GetTotalLaneCount();
			if (totalLaneCount2 == 0)
			{
				return null;
			}
			Side item2 = ((index >= 0) ? Side.Right : Side.Left);
			int num2 = Math.Abs(index) - 1;
			if (num2 >= totalLaneCount2)
			{
				return null;
			}
			return new Tuple<Side, int>(item2, num2);
		}
		return null;
	}

	public Tuple<Side, int>? GetTargetLane()
	{
		IParsedItem parsedItem = item;
		if (!(parsedItem is ParsedPrefab))
		{
			if (!(parsedItem is ParsedRoad parsedRoad))
			{
				if (!(parsedItem is ParsedRoadList parsedRoadList))
				{
					return null;
				}
				if (targetLaneIndex > parsedRoadList.GetLaneCount(Side.Right) || targetLaneIndex < -parsedRoadList.GetLaneCount(Side.Left))
				{
					Logger.Warn($"Target lane index {targetLaneIndex} is out of bounds for the current road, resetting to 0.", "C:\\Users\\Tumppi066\\Documents\\GitHub\\ets2la-core-plugins\\Libraries\\PathLib\\Classes.cs", 123);
					targetLaneIndex = 0;
					laneChangeStartFactor = float.NaN;
				}
			}
			else if (targetLaneIndex > parsedRoad.GetLaneCount(Side.Right) || targetLaneIndex < -parsedRoad.GetLaneCount(Side.Left))
			{
				Logger.Warn($"Target lane index {targetLaneIndex} is out of bounds for the current road, resetting to 0.", "C:\\Users\\Tumppi066\\Documents\\GitHub\\ets2la-core-plugins\\Libraries\\PathLib\\Classes.cs", 116);
				targetLaneIndex = 0;
				laneChangeStartFactor = float.NaN;
			}
			if (targetLaneIndex != 0)
			{
				return GetLane(targetLaneIndex);
			}
			return null;
		}
		return null;
	}

	private float SmoothInOut(float x)
	{
		return x * x * (3f - 2f * x);
	}

	public Tuple<Side, float> GenerateLaneChange(float factor, bool affectLaneChange = false)
	{
		Tuple<Side, int> lane = GetLane();
		if (lane == null)
		{
			return new Tuple<Side, float>(Side.Right, 0f);
		}
		Tuple<Side, int> targetLane = GetTargetLane();
		if (targetLane == null)
		{
			return new Tuple<Side, float>(lane.Item1, lane.Item2);
		}
		if (lane.Equals(targetLane))
		{
			targetLaneIndex = 0;
			laneChangeStartFactor = float.NaN;
			return new Tuple<Side, float>(lane.Item1, lane.Item2);
		}
		if (lane.Item1 != targetLane.Item1)
		{
			Logger.Warn($"Refusing lane change from {lane.Item1} lane {lane.Item2} to {targetLane.Item1} lane {targetLane.Item2}, crossing sides is not supported.", "C:\\Users\\Tumppi066\\Documents\\GitHub\\ets2la-core-plugins\\Libraries\\PathLib\\Classes.cs", 153);
			targetLaneIndex = 0;
			laneChangeStartFactor = float.NaN;
			return new Tuple<Side, float>(lane.Item1, lane.Item2);
		}
		if (!allowedToLaneChange)
		{
			laneChangeStartFactor = float.NaN;
			return new Tuple<Side, float>(lane.Item1, lane.Item2);
		}
		if (LaneChangeStartUninitialized)
		{
			laneChangeStartFactor = GetFactorFor(GameTelemetry.Current.GetCurrentData().truckPlacement.coordinate.ToVector3());
		}
		float distance = 5f * Math.Max(20f, GameTelemetry.Current.GetCurrentData().truckFloat.speedLimit);
		float num = 0f;
		IParsedItem parsedItem = this.item;
		if (!(parsedItem is ParsedRoad parsedRoad))
		{
			if (parsedItem is ParsedRoadList parsedRoadList)
			{
				num = parsedRoadList.DistanceToFactor(distance);
			}
		}
		else
		{
			num = parsedRoad.DistanceToFactor(distance);
		}
		bool flag = direction == Direction.Backward;
		float num2 = (flag ? laneChangeStartFactor : (1f - laneChangeStartFactor));
		if (num2 < num)
		{
			num = num2;
		}
		if ((!flag && factor > laneChangeStartFactor + num) || (flag && factor < laneChangeStartFactor - num))
		{
			if (affectLaneChange)
			{
				Logger.Info($"Completed lane change to index {targetLaneIndex} from {laneIndex}.", "C:\\Users\\Tumppi066\\Documents\\GitHub\\ets2la-core-plugins\\Libraries\\PathLib\\Classes.cs", 188);
				laneIndex = targetLaneIndex;
				targetLaneIndex = 0;
				laneChangeStartFactor = float.NaN;
			}
			return new Tuple<Side, float>(targetLane.Item1, targetLane.Item2);
		}
		if (num <= 0f)
		{
			return new Tuple<Side, float>(lane.Item1, lane.Item2);
		}
		float value = (flag ? ((laneChangeStartFactor - factor) / num) : ((factor - laneChangeStartFactor) / num));
		value = SmoothInOut(Math.Clamp(value, 0f, 1f));
		float item = (float)lane.Item2 + (float)(targetLane.Item2 - lane.Item2) * value;
		return new Tuple<Side, float>(targetLane.Item1, item);
	}

	public OrientedPoint? Interpolate(float factor, float additionalOffset = 0f, bool affectLaneChange = false)
	{
		IParsedItem parsedItem = this.item;
		if (!(parsedItem is ParsedRoad parsedRoad))
		{
			if (!(parsedItem is ParsedRoadList parsedRoadList))
			{
				if (parsedItem is ParsedPrefab)
				{
					return prefabPath?.Interpolate(factor, additionalOffset);
				}
				return null;
			}
			Tuple<Side, float> tuple = GenerateLaneChange(factor, affectLaneChange);
			Side item = tuple.Item1;
			float item2 = tuple.Item2;
			return parsedRoadList.InterpolateBetweenLanes(factor, item, item2, additionalOffset);
		}
		Tuple<Side, float> tuple2 = GenerateLaneChange(factor, affectLaneChange);
		Side item3 = tuple2.Item1;
		float item4 = tuple2.Item2;
		return parsedRoad.InterpolateBetweenLanes(factor, item3, item4, additionalOffset);
	}

	public float GetFactorFor(Vector3 position)
	{
		IParsedItem parsedItem = item;
		if (!(parsedItem is ParsedRoad parsedRoad))
		{
			if (!(parsedItem is ParsedRoadList parsedRoadList))
			{
				if (parsedItem is ParsedPrefab)
				{
					if (prefabPath == null)
					{
						return 0f;
					}
					return prefabPath.GetFactorForPoint(position);
				}
				return 0f;
			}
			return parsedRoadList.GetFactorForPoint(position);
		}
		return parsedRoad.GetFactorForPoint(position);
	}

	public float GetLength()
	{
		IParsedItem parsedItem = item;
		if (!(parsedItem is ParsedRoad parsedRoad))
		{
			if (!(parsedItem is ParsedRoadList parsedRoadList))
			{
				if (parsedItem is ParsedPrefab)
				{
					return prefabPath?.Length ?? 0f;
				}
				return 0f;
			}
			return parsedRoadList.TotalLength;
		}
		return parsedRoad.Road.Length;
	}
}
