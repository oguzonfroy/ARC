using ETS2LA.Shared;

namespace PathLib;

public class PathLib : LibraryPlugin
{
	public override PluginInformation Info => new PluginInformation
	{
		Name = "PathLib",
		Description = "This plugin provides pathfinding related utilities and data structures for other plugins to use.",
		AuthorName = "Tumppi066",
		Version = "1.2.8",
		SupportedETS2LA = ">=3.3.36",
		Icon = "https://avatars.githubusercontent.com/u/162675991?s=128",
		Id = "tumppi066.pathlib"
	};
}
