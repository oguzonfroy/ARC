namespace PathLib;

public enum FrenetVehicleCategory
{
	Behind,
	InFront,
	Adjacent
}
