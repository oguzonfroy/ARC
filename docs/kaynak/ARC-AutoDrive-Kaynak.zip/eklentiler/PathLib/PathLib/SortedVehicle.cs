using ETS2LA.Game.SDK;

namespace PathLib;

public struct SortedVehicle
{
	public BaseVehicle Vehicle { get; set; }

	public double PathFactor { get; set; }

	public double LateralOffset { get; set; }

	public double RelativePathFactor { get; set; }

	public FrenetVehicleCategory Category { get; set; }
}
