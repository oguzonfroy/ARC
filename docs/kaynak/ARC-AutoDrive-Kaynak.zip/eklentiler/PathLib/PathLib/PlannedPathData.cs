using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using ETS2LA.Game.Data;
using ETS2LA.Game.SDK;
using TruckLib;

namespace PathLib;

public class PlannedPathData
{
	public required List<PlannedItem> PlannedPath;

	public required bool HasError;

	public string? ErrorMessage;

	public float TotalLength
	{
		get
		{
			float num = 0f;
			List<PlannedItem> plannedPath = PlannedPath;
			for (int i = 0; i < plannedPath.Count; i++)
			{
				num += plannedPath[i].GetLength();
			}
			return num;
		}
	}

	public PlannedItem GetItemForFactor(float factor)
	{
		float num = factor * TotalLength;
		float num2 = 0f;
		foreach (PlannedItem item in PlannedPath)
		{
			if (num2 + item.GetLength() >= num - 1f)
			{
				return item;
			}
			num2 += item.GetLength();
		}
		return PlannedPath[PlannedPath.Count - 1];
	}

	public float FactorToItemFactor(float factor, PlannedItem item)
	{
		float num = factor * TotalLength;
		float num2 = 0f;
		foreach (PlannedItem item2 in PlannedPath)
		{
			if (num2 + item2.GetLength() >= num - 1f)
			{
				float num3 = (num - num2) / item2.GetLength();
				if (item2.item is ParsedRoadList && item2.direction == Direction.Backward)
				{
					num3 = 1f - num3;
				}
				return num3;
			}
			num2 += item2.GetLength();
		}
		return 1f;
	}

	public OrientedPoint? Interpolate(float factor, float additionalOffset = 0f, bool affectLaneChange = false)
	{
		if (PlannedPath == null || PlannedPath.Count == 0)
		{
			return null;
		}
		PlannedItem itemForFactor = GetItemForFactor(factor);
		float num = FactorToItemFactor(factor, itemForFactor);
		if (num >= 1f || num <= 0f)
		{
			return null;
		}
		return itemForFactor.Interpolate(num, additionalOffset, affectLaneChange);
	}

	public OrientedPoint? InterpolateDist(float dist, float additionalOffset = 0f, bool affectLaneChange = false)
	{
		if (PlannedPath == null || PlannedPath.Count == 0)
		{
			return null;
		}
		float factor = dist / TotalLength;
		return Interpolate(factor, additionalOffset, affectLaneChange);
	}

	public float GetFactorForPoint(Vector3 position)
	{
		if (PlannedPath == null || PlannedPath.Count == 0)
		{
			return 0f;
		}
		float num = float.MaxValue;
		float result = 0f;
		float num2 = 0f;
		foreach (PlannedItem item in PlannedPath)
		{
			float length = item.GetLength();
			float num3 = item.GetFactorFor(position);
			OrientedPoint? orientedPoint = item.Interpolate(num3);
			if (!orientedPoint.HasValue || !orientedPoint.HasValue)
			{
				continue;
			}
			float num4 = Vector3.Distance(orientedPoint.Value.Position, position);
			if (num4 < num)
			{
				num = num4;
				if (item.item is ParsedRoadList && item.direction == Direction.Backward)
				{
					num3 = 1f - num3;
				}
				result = (num2 + num3 * length) / TotalLength;
			}
			num2 += length;
		}
		return result;
	}

	public List<OrientedPoint> GeneratePath(float from = 0f)
	{
		List<OrientedPoint> list = new List<OrientedPoint>();
		for (float num = from * TotalLength; num < TotalLength; num += 1.5f)
		{
			if (num > TotalLength)
			{
				num = TotalLength;
			}
			float num2 = num / TotalLength;
			if (num2 >= 1f)
			{
				num2 = 0.9999f;
			}
			OrientedPoint? orientedPoint = Interpolate(num2);
			if (orientedPoint.HasValue && orientedPoint.HasValue)
			{
				list.Add(orientedPoint.Value);
			}
		}
		return list;
	}

	public List<SortedVehicle> OrderVehiclesBasedOnSignificance(List<BaseVehicle> vehicles, Vector3 truckPosition, float centerlineTolerance = 2.25f)
	{
		List<SortedVehicle> list = new List<SortedVehicle>();
		double num = GetFactorForPoint(truckPosition);
		foreach (BaseVehicle vehicle in vehicles)
		{
			if (vehicle.Position == Vector3.Zero)
			{
				continue;
			}
			double num2 = GetFactorForPoint(vehicle.Position);
			if (num2 == 1.0 || num2 == 0.0)
			{
				continue;
			}
			double relativePathFactor = num2 - num;
			try
			{
				OrientedPoint? orientedPoint = Interpolate((float)num2);
				if (orientedPoint.HasValue && orientedPoint.HasValue)
				{
					Vector3 vector = vehicle.Position - orientedPoint.Value.Position;
					list.Add(new SortedVehicle
					{
						Vehicle = vehicle,
						PathFactor = num2,
						LateralOffset = vector.Length(),
						RelativePathFactor = relativePathFactor
					});
				}
			}
			catch
			{
			}
		}
		return list.OrderByDescending((SortedVehicle v) =>
		{
			if (v.RelativePathFactor < 0.0)
			{
				v.Category = FrenetVehicleCategory.Behind;
				return 0;
			}
			if (v.RelativePathFactor >= 0.0 && Math.Abs(v.LateralOffset) <= (double)centerlineTolerance)
			{
				v.Category = FrenetVehicleCategory.InFront;
				return 3;
			}
			if (v.RelativePathFactor >= 0.0 && Math.Abs(v.LateralOffset) <= (double)(centerlineTolerance * 3f))
			{
				v.Category = FrenetVehicleCategory.Adjacent;
				return 2;
			}
			return 1;
		}).ThenBy((SortedVehicle v) => Math.Abs(v.RelativePathFactor)).ToList();
	}

	public List<ParsedSemaphore> GetNextSemaphores(Vector3 position)
	{
		foreach (PlannedItem item in PlannedPath)
		{
			if (item == null)
			{
				return new List<ParsedSemaphore>();
			}
			if (item.item is ParsedPrefab)
			{
				PrefabPath prefabPath = item.prefabPath;
				if (prefabPath == null)
				{
					return new List<ParsedSemaphore>();
				}
				float factor = prefabPath.GetFactorForPoint(position);
				List<ParsedSemaphore> semaphores = prefabPath.GetSemaphores();
				semaphores = semaphores.Where((ParsedSemaphore s) => prefabPath.GetFactorForPoint(s.GetCurveStartWorldCoordinates().Position) >= factor).ToList();
				semaphores.Sort((ParsedSemaphore a, ParsedSemaphore b) =>
				{
					Vector3 position2 = a.GetCurveStartWorldCoordinates().Position;
					Vector3 position3 = b.GetCurveStartWorldCoordinates().Position;
					float num = Vector3.Distance(position, position2);
					float value = Vector3.Distance(position, position3);
					return num.CompareTo(value);
				});
				if (semaphores.Count > 0)
				{
					return semaphores;
				}
			}
		}
		return new List<ParsedSemaphore>();
	}
}
