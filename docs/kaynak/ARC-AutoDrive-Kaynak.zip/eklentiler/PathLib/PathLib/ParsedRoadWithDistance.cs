using ETS2LA.Game.Data;

namespace PathLib;

public class ParsedRoadWithDistance
{
	public ParsedRoad road;

	public float closestPointFactor;

	public float closestPointDistance;

	public ParsedRoadWithDistance(ParsedRoad road)
	{
		this.road = road;
	}
}
