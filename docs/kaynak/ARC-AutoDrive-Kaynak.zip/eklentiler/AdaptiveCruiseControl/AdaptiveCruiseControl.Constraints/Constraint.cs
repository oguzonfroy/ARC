using System;

namespace AdaptiveCruiseControl.Constraints;

public abstract class Constraint
{
	public class ConstraintLogData
	{
		public string ConstraintName { get; set; } = "Unnamed Constraint";

		public float MaxAcceleration { get; set; }
	}

	protected float lastMaxAccel;

	public string Id { get; } = Guid.NewGuid().ToString();

	public abstract string Name { get; }

	public abstract string Status { get; set; }

	public abstract float GetMaxAcceleration();

	public virtual void Shutdown()
	{
	}

	public float CalculateNeededAccel(float vCurrent, float vTarget, float distance, float speedMargin = 2f)
	{
		if (distance <= 0f)
		{
			if (!(vCurrent <= 0.1f))
			{
				return 0f - ACCSettings.Current.MaxDecel;
			}
			return 0f;
		}
		if (vTarget <= 0f && vCurrent <= 0.1f)
		{
			return 0f;
		}
		float num = MathF.Sqrt(MathF.Max(0f, vTarget * vTarget + 2f * ACCSettings.Current.ComfortDecel * distance));
		if (vCurrent <= num - speedMargin)
		{
			return float.NaN;
		}
		float num2 = MathF.Max((vTarget * vTarget - vCurrent * vCurrent) / (2f * distance), 0f - ACCSettings.Current.MaxDecel);
		if (vCurrent >= num)
		{
			return MathF.Min(num2, 0f);
		}
		float num3 = (vCurrent - (num - speedMargin)) / speedMargin;
		return MathF.Min(num2 * num3, 0f);
	}

	public abstract ConstraintLogData GetLogData();
}
