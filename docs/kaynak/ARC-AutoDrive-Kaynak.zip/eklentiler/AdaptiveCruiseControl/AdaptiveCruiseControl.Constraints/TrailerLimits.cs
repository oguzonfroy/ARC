using System;

namespace AdaptiveCruiseControl.Constraints;

/// <summary>Dorseli sürüşte hız sınırları: dorse ve yük arttıkça virajda daha yavaş, önde daha uzak.</summary>
public static class TrailerLimits
{
    const float FullLoadKg = 25000f;
    const float MinLateral = 1.5f;

    static float Load(float cargoKg) => Math.Clamp(cargoKg / FullLoadKg, 0f, 1f);

    /// <summary>Virajda izin verilen yanal ivme, m/s². Dorse yoksa ayardaki değer aynen kullanılır.</summary>
    public static float LateralAcceleration(float baseValue, int trailers, float cargoKg)
    {
        if (trailers <= 0) return baseValue;
        var factor = 0.85f - 0.25f * Load(cargoKg);
        if (trailers > 1) factor *= 0.9f;
        return MathF.Min(baseValue, MathF.Max(baseValue * factor, MinLateral));
    }

    /// <summary>Önündeki araçla takip süresinin çarpanı.</summary>
    public static float FollowingFactor(int trailers, float cargoKg) => trailers <= 0 ? 1f : 1.1f + 0.3f * Load(cargoKg);
}
