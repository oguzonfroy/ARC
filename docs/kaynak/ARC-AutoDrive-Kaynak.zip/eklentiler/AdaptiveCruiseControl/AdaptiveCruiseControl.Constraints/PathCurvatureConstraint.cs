using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using ETS2LA.Backend.Events;
using ETS2LA.Game.Telemetry;
using ETS2LA.State;
using PathLib;
using TruckLib;

namespace AdaptiveCruiseControl.Constraints;

public class PathCurvatureConstraint : Constraint
{
	private struct PointData
	{
		public float MaxAccel;

		public float Radius;

		public float Distance;

		public float Velocity;

		public float VelocityClamped;
	}

	public class PathCurvatureConstraintLogData : ConstraintLogData
	{
		public float BindingRadius { get; set; }

		public float BindingDistance { get; set; }

		public float BindingRawTarget { get; set; }

		public float BindingClampedTarget { get; set; }

		public PathCurvatureConstraintLogData()
		{
			ConstraintName = "Path Curvature";
		}
	}

	private const float MaxEffectAt = 10f;

	private float MinEvalDistance = 5f;

	private float PointSpacing = 1.5f;

	private PlannedPathData? plannedPathData;

	private float bRadius = float.NaN;

	private float bDist = float.NaN;

	private float bVelRaw = float.NaN;

	private float bVelClamped = float.NaN;

	private GameTelemetryData? telemetryData;

	public override string Name => "Path Curvature";

	public override string Status { get; set; } = "Based on upcoming path curvature.";

	public PathCurvatureConstraint()
	{
		telemetryData = GameTelemetry.Current.GetCurrentData();
		Events.Current.Subscribe("Pathfinding.PlannedPathData", (PlannedPathData data) =>
		{
			plannedPathData = data;
		});
	}

	private float GetCurvatureRadius(Vector3 a, Vector3 b, Vector3 c)
	{
		float x = a.X;
		float z = a.Z;
		float x2 = b.X;
		float z2 = b.Z;
		float x3 = c.X;
		float z3 = c.Z;
		float num = 0.5f * Math.Abs(x * (z2 - z3) + x2 * (z3 - z) + x3 * (z - z2));
		if (num < 0.01f)
		{
			return float.MaxValue;
		}
		float num2 = MathF.Sqrt(MathF.Pow(x2 - x, 2f) + MathF.Pow(z2 - z, 2f));
		float num3 = MathF.Sqrt(MathF.Pow(x3 - x2, 2f) + MathF.Pow(z3 - z2, 2f));
		float num4 = MathF.Sqrt(MathF.Pow(x - x3, 2f) + MathF.Pow(z - z3, 2f));
		return num2 * num3 * num4 / (4f * num);
	}

	private float CalculateNeededAccel(float vCurrent, float vTarget, float distance)
	{
		if (distance <= 0f)
		{
			if (!(vCurrent <= 0.1f))
			{
				return 0f - ACCSettings.Current.MaxDecel;
			}
			return 0f;
		}
		if (vTarget <= 0f && vCurrent <= 0.1f)
		{
			return 0f;
		}
		distance = Math.Max(distance, 2f);
		float x = MathF.Max((vTarget * vTarget - vCurrent * vCurrent) / (2f * distance), 0f - ACCSettings.Current.MaxDecel);
		float num = (ApplicationState.Current.DesiredSpeed - vCurrent) * ACCSettings.Current.ProportionalGain;
		float num2 = MathF.Min(x, num);
		float maxDistance = ACCSettings.Current.MaxDistance;
		float num3;
		if (maxDistance <= 10f)
		{
			num3 = ((distance <= 10f) ? 1f : 0f);
		}
		else
		{
			num3 = Math.Clamp((maxDistance - distance) / (maxDistance - 10f), 0f, 1f);
		}
		num3 *= num3 * (3f - 2f * num3);
		return num + (num2 - num) * num3;
	}

	private float GetDesiredSpeedAccel(float currentSpeed)
	{
		return (ApplicationState.Current.DesiredSpeed - currentSpeed) * ACCSettings.Current.ProportionalGain;
	}

	public override float GetMaxAcceleration()
	{
		float num = float.NaN;
		lastMaxAccel = float.NaN;
		bRadius = float.NaN;
		bDist = float.NaN;
		bVelRaw = float.NaN;
		bVelClamped = float.NaN;
		if (telemetryData == null)
		{
			lastMaxAccel = 0f;
			return lastMaxAccel;
		}
		float speed = telemetryData.truckFloat.speed;
		float desiredSpeedAccel = GetDesiredSpeedAccel(speed);
		if (plannedPathData == null || plannedPathData.PlannedPath.Count == 0)
		{
			lastMaxAccel = desiredSpeedAccel;
			Status = $"Target {(double)ApplicationState.Current.DesiredSpeed * 3.6:F1}km/h | accel {lastMaxAccel:F2}";
			return lastMaxAccel;
		}
		float factorForPoint = plannedPathData.GetFactorForPoint(telemetryData.truckPlacement.coordinate.ToVector3());
		List<OrientedPoint> list = plannedPathData.GeneratePath(factorForPoint);
		if (list.Count < 3)
		{
			lastMaxAccel = desiredSpeedAccel;
			Status = $"Target {(double)ApplicationState.Current.DesiredSpeed * 3.6:F1}km/h | accel {lastMaxAccel:F2}";
			return lastMaxAccel;
		}
		float maxLateralAcceleration = TrailerLimits.LateralAcceleration(ACCSettings.Current.MaxLateralAcceleration, telemetryData.trailers.Count((TrailerInfo t) => t.comBool.attached), (float)telemetryData.configUI.unitCount * telemetryData.configFloat.unitMass);
		float maxDistance = ACCSettings.Current.MaxDistance;
		int num2 = Math.Max(ACCSettings.Current.PointStep, (int)(10f / PointSpacing));
		int num3 = Math.Min(list.Count - 2 * num2, (int)(maxDistance / PointSpacing));
		if (num3 <= 0)
		{
			lastMaxAccel = desiredSpeedAccel;
			Status = $"Target {(double)ApplicationState.Current.DesiredSpeed * 3.6:F1}km/h | accel {lastMaxAccel:F2}";
			return lastMaxAccel;
		}
		PointData[] array = new PointData[num3];
		for (int i = 0; i < num3; i++)
		{
			try
			{
				float num4 = (float)i * PointSpacing;
				if (num4 < MinEvalDistance)
				{
					continue;
				}
				Vector3 position = list[i].Position;
				Vector3 position2 = list[i + num2].Position;
				Vector3 position3 = list[i + 2 * num2].Position;
				float num5 = GetCurvatureRadius(position, position2, position3);
				if (!(num5 > ACCSettings.Current.MaxRadius) && !(num5 <= 0f))
				{
					if (ACCSettings.Current.ProgressiveCurvature)
					{
						float num6 = 1f + Math.Clamp(num5 / ACCSettings.Current.MaxRadius, 0f, 0.66f);
						num5 *= num6;
					}
					float num7 = MathF.Sqrt(maxLateralAcceleration * num5);
					float num8 = Math.Max(ACCSettings.Current.MinSpeed, num7);
					float maxAccel = CalculateNeededAccel(speed, num8, num4);
					array[i] = new PointData
					{
						MaxAccel = maxAccel,
						Radius = num5,
						Distance = num4,
						Velocity = num7,
						VelocityClamped = num8
					};
				}
			}
			catch
			{
			}
		}
		List<PointData> list2 = (from p in array
			where p.MaxAccel != 0f && !float.IsNaN(p.MaxAccel)
			orderby p.MaxAccel
			select p).Take(4).ToList();
		if (list2.Count > 0)
		{
			num = list2.Average((PointData p) => p.MaxAccel);
			bRadius = list2.Average((PointData p) => p.Radius);
			bDist = list2.Average((PointData p) => p.Distance);
			bVelRaw = list2.Average((PointData p) => p.Velocity);
			bVelClamped = list2.Average((PointData p) => p.VelocityClamped);
			Status = $"R={bRadius:F0}m @ {bDist:F0}m | target {(double)bVelClamped * 3.6:F1}km/h (raw {(double)bVelRaw * 3.6:F1}km/h) | accel {num:F2}";
		}
		else
		{
			num = desiredSpeedAccel;
			Status = $"Target {(double)ApplicationState.Current.DesiredSpeed * 3.6:F1}km/h | accel {num:F2}";
		}
		if (float.IsNaN(num) || float.IsInfinity(num))
		{
			num = desiredSpeedAccel;
		}
		lastMaxAccel = num;
		return lastMaxAccel;
	}

	public override ConstraintLogData GetLogData()
	{
		return new PathCurvatureConstraintLogData
		{
			MaxAcceleration = lastMaxAccel,
			BindingRadius = bRadius,
			BindingDistance = bDist,
			BindingRawTarget = bVelRaw,
			BindingClampedTarget = bVelClamped
		};
	}
}
