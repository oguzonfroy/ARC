using System;
using System.Collections.Generic;
using System.Numerics;

namespace AdaptiveCruiseControl.Constraints;

/// <summary>
///  Kavşak tanıma, oyuna bağımlı değil. ETS2'de birçok kavşakta levha ya da ışık yoktur; bu yüzden kavşak, yol
///  parçasının (prefab) kendi şeritlerinden tanınır: bizim şeridimizi ortasından kesen başka bir şerit varsa orada
///  karşı trafik vardır. Ayrılma (ortak başlangıç) ve birleşme (bizim şeride uçtan katılma) kesişme sayılmaz, bu
///  yüzden otoyol giriş ve çıkışları yakalanmaz. Noktalar üstten görünüm (x, z).
/// </summary>
public static class JunctionRules
{
	/// <param name="margin">Kesişmenin iki şeridin de uçlarından en az bu kadar (metre) içeride olması gerekir.</param>
	public static bool IsConflictJunction(IReadOnlyList<Vector2> ours, IEnumerable<IReadOnlyList<Vector2>> others, float margin = 3f)
	{
		if (ours.Count < 2)
		{
			return false;
		}
		float[] oursAt = Cumulative(ours);
		foreach (IReadOnlyList<Vector2> other in others)
		{
			if (other.Count >= 2 && CrossesInside(ours, oursAt, other, Cumulative(other), margin))
			{
				return true;
			}
		}
		return false;
	}

	static bool CrossesInside(IReadOnlyList<Vector2> a, float[] aAt, IReadOnlyList<Vector2> b, float[] bAt, float margin)
	{
		float aLen = aAt[^1], bLen = bAt[^1];
		for (int i = 0; i + 1 < a.Count; i++)
		{
			for (int j = 0; j + 1 < b.Count; j++)
			{
				if (!Intersect(a[i], a[i + 1], b[j], b[j + 1], out float t, out float u))
				{
					continue;
				}
				float sa = aAt[i] + t * (aAt[i + 1] - aAt[i]);
				float sb = bAt[j] + u * (bAt[j + 1] - bAt[j]);
				if (sa > margin && sa < aLen - margin && sb > margin && sb < bLen - margin)
				{
					return true;
				}
			}
		}
		return false;
	}

	static float[] Cumulative(IReadOnlyList<Vector2> p)
	{
		var at = new float[p.Count];
		for (int i = 1; i < p.Count; i++)
		{
			at[i] = at[i - 1] + Vector2.Distance(p[i - 1], p[i]);
		}
		return at;
	}

	/// <summary>İki doğru parçası kesişiyorsa t ve u (0..1, uçlar dahil) parçalar üzerindeki yerdir.</summary>
	static bool Intersect(Vector2 p, Vector2 p2, Vector2 q, Vector2 q2, out float t, out float u)
	{
		Vector2 r = p2 - p, s = q2 - q;
		float den = r.X * s.Y - r.Y * s.X;
		t = u = 0f;
		if (MathF.Abs(den) < 1e-6f)
		{
			return false; // paralel ya da çakışık: kesişme sayılmaz
		}
		Vector2 d = q - p;
		t = (d.X * s.Y - d.Y * s.X) / den;
		u = (d.X * r.Y - d.Y * r.X) / den;
		const float eps = 1e-4f;
		return t >= -eps && t <= 1f + eps && u >= -eps && u <= 1f + eps;
	}
}
