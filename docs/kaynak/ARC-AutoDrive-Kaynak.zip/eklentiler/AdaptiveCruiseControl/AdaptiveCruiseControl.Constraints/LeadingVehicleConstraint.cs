using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using ETS2LA.Backend.Events;
using ETS2LA.Game.SDK;
using ETS2LA.Game.Telemetry;
using ETS2LA.Overlay;
using ETS2LA.Overlay.AR;
using ETS2LA.Settings.Global;
using ETS2LA.Shared;
using ETS2LA.State;
using Hexa.NET.ImGui;
using PathLib;

namespace AdaptiveCruiseControl.Constraints;

public class LeadingVehicleConstraint : Constraint
{
	public class LeadingVehicleConstraintLogData : ConstraintLogData
	{
		public LeadingVehicleConstraintLogData()
		{
			ConstraintName = "Leading Vehicle";
		}
	}

	private Dictionary<FollowingDistanceOption, float> followingDistances = new Dictionary<FollowingDistanceOption, float>
	{
		{
			FollowingDistanceOption.Near,
			1f
		},
		{
			FollowingDistanceOption.Normal,
			1.5f
		},
		{
			FollowingDistanceOption.Far,
			2f
		}
	};

	private ARRenderCallback aRRenderCallback;

	private string tempStatus = "";

	private TrafficData? trafficData;

	private ParkedVehicleData? parkedVehicleData;

	private GameTelemetryData? telemetryData;

	private PlannedPathData? plannedPathData;

	private List<SortedVehicle> sortedVehicles = new List<SortedVehicle>();

	private BaseVehicle? leadingVehicle;

	private Vector3 leadingVehiclePosition = Vector3.Zero;

	private KalmanFilter3D leadingVehicleCorner1 = new KalmanFilter3D(0.005f, 0.05f);

	private KalmanFilter3D leadingVehicleCorner2 = new KalmanFilter3D(0.005f, 0.05f);

	private KalmanFilter3D leadingVehicleCorner3 = new KalmanFilter3D(0.005f, 0.05f);

	private KalmanFilter3D leadingVehicleCorner4 = new KalmanFilter3D(0.005f, 0.05f);

	private string lastSpeedStr = "";

	private string lastDistStr = "";

	private Stopwatch lastStrUpdateStopwatch = new Stopwatch();

	public override string Name => "Leading Vehicle";

	public override string Status { get; set; } = "No status";

	public LeadingVehicleConstraint()
	{
		trafficData = TrafficProvider.Current.GetCurrentTrafficData();
		parkedVehicleData = ParkedVehiclesProvider.Current.GetCurrentParkedVehicleData();
		telemetryData = GameTelemetry.Current.GetCurrentData();
		Events.Current.Subscribe("Pathfinding.PlannedPathData", (PlannedPathData data) =>
		{
			plannedPathData = data;
		});
		aRRenderCallback = new ARRenderCallback
		{
			Definition = new ARRendererDefinition
			{
				Name = "ACC Leading Vehicle Visualization"
			},
			Render3D = RenderAR
		};
		OverlayHandler.Current.AR.RegisterRenderCallback(aRRenderCallback);
		lastStrUpdateStopwatch.Start();
	}

	public void UpdateSortedVehicles()
	{
		if (plannedPathData != null && telemetryData != null)
		{
			List<BaseVehicle> list = new List<BaseVehicle>();
			if (trafficData != null)
			{
				list.AddRange(trafficData.vehicles);
			}
			if (parkedVehicleData != null)
			{
				list.AddRange(parkedVehicleData.vehicles);
			}
			sortedVehicles = plannedPathData.OrderVehiclesBasedOnSignificance(list, telemetryData.truckPlacement.coordinate.ToVector3(), ACCSettings.Current.CenterlineTolerance);
			tempStatus += $"Sorted {sortedVehicles.Count} vehicles. ";
		}
	}

	public float GetFollowingDistance()
	{
		if (ACCSettings.Current.OverrideFollowingDistance)
		{
			return ACCSettings.Current.FollowingDistanceOverride;
		}
		FollowingDistanceOption followingDistance = AssistanceSettings.Current.FollowingDistance;
		return followingDistances[followingDistance];
	}

	public float GetOtherVehicleSpeed(BaseVehicle vehicle)
	{
		if (!(vehicle is ParkedVehicle))
		{
			if (!(vehicle is TrafficTrailer trafficTrailer))
			{
				if (vehicle is TrafficVehicle trafficVehicle)
				{
					return trafficVehicle.speed;
				}
				return 0f;
			}
			return trafficTrailer.parent.speed;
		}
		return 0f;
	}

	public float GetRelativeSpeedToVehicle(BaseVehicle vehicle)
	{
		float num = telemetryData?.truckFloat.speed ?? 0f;
		float otherVehicleSpeed = GetOtherVehicleSpeed(vehicle);
		return num - otherVehicleSpeed;
	}

	public float GetDistanceToVehicle(BaseVehicle vehicle)
	{
		if (telemetryData == null)
		{
			return float.MaxValue;
		}
		if (vehicle is TrafficVehicle { trailer_count: >0 } trafficVehicle)
		{
			return Vector3.Distance(trafficVehicle.trailers[trafficVehicle.trailer_count - 1].Position, telemetryData.truckPlacement.coordinate.ToVector3()) - trafficVehicle.trailers[trafficVehicle.trailer_count - 1].Size.Z / 2f;
		}
		return Vector3.Distance(vehicle.Position, telemetryData.truckPlacement.coordinate.ToVector3()) - vehicle.Size.Z / 2f;
	}

	private float NoLimit(string reason)
	{
		leadingVehicle = null;
		Status = tempStatus + reason;
		return float.NaN;
	}

	public override float GetMaxAcceleration()
	{
		lastMaxAccel = float.NaN;
		tempStatus = "";
		if (telemetryData == null || plannedPathData == null)
		{
			return NoLimit("No telemetry or planned path. ");
		}
		UpdateSortedVehicles();
		SortedVehicle sortedVehicle = sortedVehicles.FirstOrDefault();
		if (sortedVehicle.Vehicle == null)
		{
			return NoLimit("\nNo significant vehicle. ");
		}
		if (sortedVehicle.RelativePathFactor < 0.0 || Math.Abs(sortedVehicle.LateralOffset) > (double)ACCSettings.Current.CenterlineTolerance)
		{
			return NoLimit($"\nMost significant vehicle is not in front ({sortedVehicle.Category}). s={sortedVehicle.RelativePathFactor:F1}m, d={sortedVehicle.LateralOffset:F1}m. ");
		}
		leadingVehicle = sortedVehicle.Vehicle;
		float speed = telemetryData.truckFloat.speed;
		float num = Math.Max(GetDistanceToVehicle(leadingVehicle), 0.1f);
		float followingDistance = GetFollowingDistance() * TrailerLimits.FollowingFactor(telemetryData.trailers.Count((TrailerInfo t) => t.comBool.attached), (float)telemetryData.configUI.unitCount * telemetryData.configFloat.unitMass);
		float relativeSpeedToVehicle = GetRelativeSpeedToVehicle(leadingVehicle);
		float num2 = Math.Max((float)ACCSettings.Current.StandstillGap + speed * followingDistance + speed * relativeSpeedToVehicle / (2f * MathF.Sqrt(ACCSettings.Current.ComfortAccel * ACCSettings.Current.ComfortDecel)), ACCSettings.Current.StandstillGap) / num;
		float num3 = ACCSettings.Current.ComfortAccel * (1f - num2 * num2);
		if (speed < 0.05f)
		{
			num3 = Math.Max(num3, 0f);
		}
		num3 = Math.Clamp(num3, 0f - ACCSettings.Current.MaxDecel, ACCSettings.Current.MaxAccel);
		tempStatus += $"\nFollowing: gap {num:F1}m, closing {relativeSpeedToVehicle:F1} m/s";
		Status = tempStatus;
		lastMaxAccel = num3;
		return num3;
	}

	public override ConstraintLogData GetLogData()
	{
		return new LeadingVehicleConstraintLogData
		{
			MaxAcceleration = lastMaxAccel
		};
	}

	private void ResetLeadingVehicleCorners()
	{
		leadingVehicleCorner1.Reset();
		leadingVehicleCorner2.Reset();
		leadingVehicleCorner3.Reset();
		leadingVehicleCorner4.Reset();
	}

	private void RenderAR()
	{
		if (!ACCSettings.Current.RenderLeadingVehicle)
		{
			return;
		}
		bool num = plannedPathData == null || plannedPathData.PlannedPath.Count == 0;
		bool flag = telemetryData == null;
		bool flag2 = leadingVehicle == null;
		if (num | flag | flag2)
		{
			Events.Current.Publish<BaseVehicle>("AdaptiveCruiseControl.LeadingVehicle", null);
			ResetLeadingVehicleCorners();
			return;
		}
		ImGui.PushFont(OverlayHandler.Current.Fonts[(FontStyle)5], OverlaySettingsHandler.Current.GetSettings().BaseFontSize);
		try
		{
			BaseVehicle baseVehicle = leadingVehicle;
			if (Vector3.Distance(baseVehicle.Position, leadingVehiclePosition) > 10f)
			{
				ResetLeadingVehicleCorners();
			}
			leadingVehiclePosition = baseVehicle.Position;
			if (leadingVehicle is TrafficVehicle { trailer_count: >0 } trafficVehicle)
			{
				baseVehicle = trafficVehicle.trailers[trafficVehicle.trailer_count - 1];
			}
			ARRenderer aR = OverlayHandler.Current.AR;
			List<Vector3> cornersOnGround = baseVehicle.GetCornersOnGround();
			ARCoordinate aRCoordinate = new ARCoordinate(leadingVehicleCorner3.Update(cornersOnGround[2]));
			ARCoordinate aRCoordinate2 = new ARCoordinate(aRCoordinate.OffsetToVector3() + new Vector3(0f, 1f, 0f));
			ARCoordinate aRCoordinate3 = new ARCoordinate(leadingVehicleCorner4.Update(cornersOnGround[3]));
			ARCoordinate aRCoordinate4 = new ARCoordinate(aRCoordinate3.OffsetToVector3() + new Vector3(0f, 1f, 0f));
			ARCoordinate aRCoordinate5 = new ARCoordinate(leadingVehicleCorner1.Update((cornersOnGround[2] + cornersOnGround[3]) / 2f));
			if (OverlaySettingsHandler.Current.GetSettings().SimplifiedGraphics)
			{
				aR.Draw3DLine(aRCoordinate, aRCoordinate2, 4294967108u, 2f);
				aR.Draw3DLine(aRCoordinate3, aRCoordinate4, 4294967108u, 2f);
				aR.Draw3DLine(aRCoordinate2, aRCoordinate4, 4294967108u, 2f);
			}
			else
			{
				aR.Draw3DLineWithGradient(new _003C_003Ez__ReadOnlyArray<ARCoordinate>(new ARCoordinate[2] { aRCoordinate3, aRCoordinate }), new _003C_003Ez__ReadOnlyArray<ARCoordinate>(new ARCoordinate[2] { aRCoordinate4, aRCoordinate2 }), 8960853u);
			}
			if (lastStrUpdateStopwatch.ElapsedMilliseconds > 333)
			{
				lastSpeedStr = $"{UnitConversions.FromScientificUnits(UnitType.Speed, GetOtherVehicleSpeed(baseVehicle), ApplicationState.Current.DisplayUnits):F0} {UnitConversions.GetUnitAbbreviation(UnitType.Speed, ApplicationState.Current.DisplayUnits)}";
				lastDistStr = $"{UnitConversions.FromScientificUnits(UnitType.Distance, GetDistanceToVehicle(baseVehicle), ApplicationState.Current.DisplayUnits):F0} {UnitConversions.GetUnitAbbreviation(UnitType.Distance, ApplicationState.Current.DisplayUnits)}";
				lastStrUpdateStopwatch.Restart();
			}
			aR.Draw3DText(new ARCoordinate(aRCoordinate5.OffsetToVector3()), lastSpeedStr + "      " + lastDistStr, 3991793151u, 0.5f, -1.1f, 757935564u, 1195853772u, 2f, 7f, 5f, 3f);
			Events.Current.Publish("AdaptiveCruiseControl.LeadingVehicle", baseVehicle);
		}
		catch
		{
		}
		ImGui.PopFont();
	}

	public override void Shutdown()
	{
		base.Shutdown();
		OverlayHandler.Current.AR.UnregisterRenderCallback(aRRenderCallback.Definition.Name);
	}
}
