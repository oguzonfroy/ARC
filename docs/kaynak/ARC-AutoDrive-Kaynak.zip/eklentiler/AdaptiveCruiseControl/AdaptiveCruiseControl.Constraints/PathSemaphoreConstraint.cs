using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using ETS2LA.Backend.Events;
using ETS2LA.Game.Data;
using ETS2LA.Game.SDK;
using ETS2LA.Game.Telemetry;
using ETS2LA.Overlay;
using ETS2LA.Overlay.AR;
using ETS2LA.Settings.Global;
using PathLib;
using TruckLib;

namespace AdaptiveCruiseControl.Constraints;

public class PathSemaphoreConstraint : Constraint
{
	public class PathSemaphoreConstraintLogData : ConstraintLogData
	{
		public float Distance { get; set; }

		public PathSemaphoreConstraintLogData()
		{
			ConstraintName = "Path Semaphore";
		}
	}

	private Dictionary<FollowingDistanceOption, float> followingDistances = new Dictionary<FollowingDistanceOption, float>
	{
		{
			FollowingDistanceOption.Near,
			1f
		},
		{
			FollowingDistanceOption.Normal,
			1.5f
		},
		{
			FollowingDistanceOption.Far,
			2f
		}
	};

	private ARRenderCallback arRenderCallback;

	private string tempStatus = "";

	private PlannedPathData? plannedPathData;

	private GameTelemetryData? telemetryData;

	private SemaphoreData? semaphoreData;

	private Semaphore? targetSemaphore;

	private ParsedSemaphore? targetParsedSemaphore;

	private float distance = float.NaN;

	private float lastSpeed;

	public override string Name => "Path Semaphore";

	public override string Status { get; set; } = "Based on upcoming path semaphores.";

	public PathSemaphoreConstraint()
	{
		telemetryData = GameTelemetry.Current.GetCurrentData();
		semaphoreData = SemaphoreProvider.Current.GetCurrentData();
		Events.Current.Subscribe("Pathfinding.PlannedPathData", (PlannedPathData data) =>
		{
			plannedPathData = data;
		});
		arRenderCallback = new ARRenderCallback
		{
			Definition = new ARRendererDefinition
			{
				Name = "ACC Path Semaphores",
				Alpha = 0.8f
			},
			Render3D = RenderAR
		};
		OverlayHandler.Current.AR.RegisterRenderCallback(arRenderCallback);
	}

	private Semaphore? GetClosestGate()
	{
		if (semaphoreData == null)
		{
			return null;
		}
		if (plannedPathData == null || telemetryData == null)
		{
			return null;
		}
		float factorForPoint = plannedPathData.GetFactorForPoint(telemetryData.truckPlacement.coordinate.ToVector3());
		if (factorForPoint < 0f || factorForPoint > 1f)
		{
			return null;
		}
		float num = float.MaxValue;
		Semaphore result = null;
		Semaphore[] semaphores = semaphoreData.semaphores;
		foreach (Semaphore semaphore in semaphores)
		{
			if (semaphore.type == SemaphoreType.GATE)
			{
				float factorForPoint2 = plannedPathData.GetFactorForPoint(semaphore.GetWorldCoordinates());
				if (factorForPoint2 < num && factorForPoint2 > factorForPoint && Vector3.Distance(semaphore.GetWorldCoordinates(), plannedPathData.Interpolate(factorForPoint2).HasValue ? plannedPathData.Interpolate(factorForPoint2).Value.Position : Vector3.Zero) < 4f)
				{
					num = factorForPoint2;
					result = semaphore;
				}
			}
		}
		return result;
	}

	private Semaphore? GetSemaphoreForParsedSemaphore(ParsedSemaphore parsedSemaphore)
	{
		if (semaphoreData == null)
		{
			return null;
		}
		float num = float.MaxValue;
		Semaphore result = null;
		Semaphore[] semaphores = semaphoreData.semaphores;
		foreach (Semaphore semaphore in semaphores)
		{
			if (semaphore.id == parsedSemaphore.Semaphore.SemaphoreId)
			{
				float num2 = Vector3.Distance(semaphore.GetWorldCoordinates(), parsedSemaphore.GetWorldOrientedPoint().Position);
				if (num2 < num)
				{
					num = num2;
					result = semaphore;
				}
			}
		}
		if (num > 10f)
		{
			tempStatus += $"Closest semaphore is {num:F1}m away, which is too far to be relevant.";
			return null;
		}
		return result;
	}

	public float GetTimeToCollision(float distance)
	{
		if (telemetryData == null)
		{
			return float.MaxValue;
		}
		float speed = telemetryData.truckFloat.speed;
		if (speed <= 0.1f)
		{
			return 999f;
		}
		return distance / speed;
	}

	public float GetDistanceToSemaphore(Semaphore semaphore)
	{
		if (telemetryData == null)
		{
			return float.MaxValue;
		}
		return Vector3.Distance(semaphore.GetWorldCoordinates(), telemetryData.truckPlacement.coordinate.ToVector3());
	}

	public float GetDistanceToSemaphoreCurveStart()
	{
		if (telemetryData == null)
		{
			return float.MaxValue;
		}
		if (targetParsedSemaphore == null)
		{
			if (plannedPathData == null || targetSemaphore == null)
			{
				return float.MaxValue;
			}
			float factorForPoint = plannedPathData.GetFactorForPoint(targetSemaphore.GetWorldCoordinates());
			if (factorForPoint < 0f || factorForPoint > 1f)
			{
				return float.MaxValue;
			}
			return Vector3.Distance(plannedPathData.Interpolate(factorForPoint).Value.Position, telemetryData.truckPlacement.coordinate.ToVector3());
		}
		float val = Vector3.Distance(targetParsedSemaphore.GetCurveStartWorldCoordinates().Position, telemetryData.truckPlacement.coordinate.ToVector3());
		float val2 = Vector3.Distance(targetParsedSemaphore.GetCurveEndWorldCoordinates().Position, telemetryData.truckPlacement.coordinate.ToVector3());
		return Math.Min(val, val2);
	}

	private float NoLimit(string reason)
	{
		Status = tempStatus + reason;
		return float.NaN;
	}

	public override float GetMaxAcceleration()
	{
		tempStatus = "";
		distance = float.NaN;
		lastMaxAccel = float.NaN;
		targetSemaphore = null;
		lastSpeed = float.MaxValue;
		if (plannedPathData == null || telemetryData == null || plannedPathData.PlannedPath.Count <= 0)
		{
			return NoLimit("No planned path or telemetry data.");
		}
		Semaphore closestGate = GetClosestGate();
		ParsedSemaphore parsedSemaphore = plannedPathData.GetNextSemaphores(telemetryData.truckPlacement.coordinate.ToVector3()).FirstOrDefault();
		if (parsedSemaphore == null && closestGate == null)
		{
			targetParsedSemaphore = null;
			return NoLimit("No upcoming semaphores.");
		}
		Semaphore semaphore = null;
		if (parsedSemaphore != null)
		{
			targetParsedSemaphore = parsedSemaphore;
			semaphore = GetSemaphoreForParsedSemaphore(parsedSemaphore);
		}
		if (closestGate != null)
		{
			if (semaphore != null)
			{
				float num = Vector3.Distance(closestGate.GetWorldCoordinates(), telemetryData.truckPlacement.coordinate.ToVector3());
				float num2 = Vector3.Distance(semaphore.GetWorldCoordinates(), telemetryData.truckPlacement.coordinate.ToVector3());
				if (num < num2)
				{
					semaphore = closestGate;
					targetParsedSemaphore = null;
				}
			}
			else
			{
				semaphore = closestGate;
				targetParsedSemaphore = null;
			}
		}
		if (semaphore == null)
		{
			return NoLimit("No relevant upcoming semaphores.");
		}
		switch (semaphore.type)
		{
		case SemaphoreType.TRAFFICLIGHT:
			if (!AssistanceSettings.Current.EnabledTrafficRules.Contains(TrafficRule.TrafficLights))
			{
				targetSemaphore = semaphore;
				return NoLimit("Traffic lights are ignored, no need to slow down.");
			}
			if (semaphore.state != 2 && semaphore.state != 1)
			{
				return NoLimit($"Next traffic light is green or changing to green ({(TrafficLightState)semaphore.state}), no need to slow down.");
			}
			break;
		case SemaphoreType.GATE:
			if (!AssistanceSettings.Current.EnabledTrafficRules.Contains(TrafficRule.Gates))
			{
				targetSemaphore = semaphore;
				return NoLimit("Gates are ignored, no need to slow down.");
			}
			if (semaphore.state != 1 && semaphore.state != 0)
			{
				return NoLimit("Next gate is open, no need to slow down.");
			}
			break;
		}
		Status = tempStatus;
		targetSemaphore = semaphore;
		lastSpeed = telemetryData.truckFloat.speed;
		distance = GetDistanceToSemaphoreCurveStart() - ACCSettings.Current.StoppingDistance;
		if (distance <= 0f)
		{
			lastMaxAccel = -2f;
			return lastMaxAccel;
		}
		lastMaxAccel = CalculateNeededAccel(lastSpeed, 0f, distance);
		return lastMaxAccel;
	}

	public override ConstraintLogData GetLogData()
	{
		return new PathSemaphoreConstraintLogData
		{
			MaxAcceleration = lastMaxAccel,
			Distance = distance
		};
	}

	private void RenderAR()
	{
		if (semaphoreData == null)
		{
			return;
		}
		ARRenderer aR = OverlayHandler.Current.AR;
		Semaphore[] semaphores = semaphoreData.semaphores;
		foreach (Semaphore semaphore in semaphores)
		{
			bool flag = targetSemaphore != null && semaphore.GetWorldCoordinates() == targetSemaphore.GetWorldCoordinates();
			uint color = (flag ? semaphore.GetColor() : 858993663u);
			if ((ACCSettings.Current.RenderAllSemaphores || flag) && !(!ACCSettings.Current.RenderTargetSemaphore & flag))
			{
				aR.Draw3DText(semaphore.GetWorldCoordinates() + Vector3.UnitY * 2f, $"{semaphore.time_remaining:F1}s", color, 0.5f);
			}
		}
		if (targetParsedSemaphore != null && lastSpeed < float.MaxValue)
		{
			OrientedPoint curveStartWorldCoordinates = targetParsedSemaphore.GetCurveStartWorldCoordinates();
			Vector3 vector = targetParsedSemaphore.GetCurveEndWorldCoordinates().Position - targetParsedSemaphore.GetCurveStartWorldCoordinates().Position;
			Vector3 vector2 = Vector3.Normalize(Vector3.Cross(vector, Vector3.UnitY));
			vector = Vector3.Normalize(vector);
			ARCoordinate aRCoordinate = new ARCoordinate(curveStartWorldCoordinates.Position + vector2 * 2.25f);
			ARCoordinate aRCoordinate2 = new ARCoordinate(curveStartWorldCoordinates.Position - vector2 * 2.25f);
			ARCoordinate aRCoordinate3 = new ARCoordinate(curveStartWorldCoordinates.Position + vector2 * 2.25f - vector * 2.5f);
			ARCoordinate aRCoordinate4 = new ARCoordinate(curveStartWorldCoordinates.Position - vector2 * 2.25f - vector * 2.5f);
			if (OverlaySettingsHandler.Current.GetSettings().SimplifiedGraphics)
			{
				aR.Draw3DLine(aRCoordinate2, aRCoordinate, 4284901119u, 2f);
			}
			else
			{
				aR.Draw3DLineWithGradient(new _003C_003Ez__ReadOnlyArray<ARCoordinate>(new ARCoordinate[2] { aRCoordinate2, aRCoordinate }), new _003C_003Ez__ReadOnlyArray<ARCoordinate>(new ARCoordinate[2] { aRCoordinate4, aRCoordinate3 }), 4284901119u);
			}
			Events.Current.Publish("AdaptiveCruiseControl.TargetParsedSemaphore", targetParsedSemaphore);
		}
		else
		{
			Events.Current.Publish<ParsedSemaphore>("AdaptiveCruiseControl.TargetParsedSemaphore", null);
		}
	}

	public override void Shutdown()
	{
		base.Shutdown();
		OverlayHandler.Current.AR.UnregisterRenderCallback(arRenderCallback.Definition.Name);
	}
}
