using System;
using System.Collections.Generic;
using System.Numerics;
using ETS2LA.Backend.Events;
using ETS2LA.Game.Data;
using ETS2LA.Game.Telemetry;
using ETS2LA.State;
using PathLib;
using TruckLib;

namespace AdaptiveCruiseControl.Constraints;

/// <summary>
///  ARC: ışıksız kavşağa hız düşürerek girer. Levha ya da ışık aranmaz (çoğu kavşakta yoktur); kavşak, rotadaki
///  yol parçasının şeritlerinden tanınır (<see cref="JunctionRules"/>). Işıklı kavşakları PathSemaphoreConstraint
///  yönetir. Karşı trafiğe yol vermez, yalnız yavaşlar.
/// </summary>
public class PathJunctionConstraint : Constraint
{
	public class PathJunctionConstraintLogData : ConstraintLogData
	{
		public float Distance { get; set; }

		public PathJunctionConstraintLogData()
		{
			ConstraintName = "Path Junction";
		}
	}

	private const float LookAhead = 200f;

	private const int Samples = 16;

	private PlannedPathData? plannedPathData;

	private readonly GameTelemetryData? telemetryData;

	/// <summary>Aynı yol parçası her karede yeniden incelenmesin diye.</summary>
	private readonly Dictionary<PrefabPath, bool> isJunction = new Dictionary<PrefabPath, bool>(ReferenceEqualityComparer.Instance);

	private float distance = float.NaN;

	public override string Name => "Path Junction";

	public override string Status { get; set; } = "Slows down before unsignalled junctions.";

	public PathJunctionConstraint()
	{
		telemetryData = GameTelemetry.Current.GetCurrentData();
		Events.Current.Subscribe("Pathfinding.PlannedPathData", (PlannedPathData data) =>
		{
			plannedPathData = data;
		});
	}

	private float NoLimit(string reason)
	{
		Status = reason;
		distance = float.NaN;
		lastMaxAccel = float.NaN;
		return float.NaN;
	}

	public override float GetMaxAcceleration()
	{
		float target = StateSettingsHandler.Current.GetSettings().JunctionSpeed;
		if (!(target > 0f) || float.IsInfinity(target)) // ayar dosyası elle bozulmuş olabilir (NaN, eksi)
		{
			return NoLimit("Junction slowdown is off.");
		}
		PlannedPathData? path = plannedPathData;
		if (path == null || telemetryData == null || path.PlannedPath.Count == 0)
		{
			return NoLimit("No planned path or telemetry data.");
		}
		float total = path.TotalLength;
		float here = path.GetFactorForPoint(telemetryData.truckPlacement.coordinate.ToVector3()) * total;
		float speed = telemetryData.truckFloat.speed;
		float start = 0f;
		foreach (PlannedItem item in path.PlannedPath)
		{
			float length = item.GetLength();
			float end = start + length;
			if (start - here > LookAhead)
			{
				break;
			}
			if (end > here && item.prefabPath != null && IsJunction(item))
			{
				distance = MathF.Max(0f, start - here);
				if (distance <= 0f)
				{
					// Kavşağın içindeyken hızlanma; hedefin üstündeyse yumuşakça yavaşla.
					Status = "Inside an unsignalled junction.";
					lastMaxAccel = speed > target + 1f ? -1f : float.NaN;
					return lastMaxAccel;
				}
				Status = $"Unsignalled junction in {distance:F0} m.";
				lastMaxAccel = CalculateNeededAccel(speed, target, distance);
				return lastMaxAccel;
			}
			start = end;
		}
		return NoLimit("No unsignalled junction ahead.");
	}

	private bool IsJunction(PlannedItem item)
	{
		PrefabPath own = item.prefabPath!;
		if (isJunction.TryGetValue(own, out bool known))
		{
			return known;
		}
		bool result = false;
		try
		{
			// Işıklı kavşak PathSemaphoreConstraint'in işi; yeşilde gereksiz yavaşlamasın.
			if (item.item is ParsedPrefab prefab && prefab.Prefab.Nodes.Count >= 3 && own.GetSemaphores().Count == 0)
			{
				var others = new List<IReadOnlyList<Vector2>>();
				foreach (PrefabPath other in item.otherPrefabPaths)
				{
					if (!ReferenceEquals(other, own))
					{
						others.Add(Sample(other));
					}
				}
				result = JunctionRules.IsConflictJunction(Sample(own), others);
			}
		}
		catch (Exception)
		{
			result = false; // haritada eksik veri: kavşak sayma, hız kuralını bozma
		}
		if (isJunction.Count > 512)
		{
			isJunction.Clear();
		}
		isJunction[own] = result;
		return result;
	}

	private static List<Vector2> Sample(PrefabPath path)
	{
		var points = new List<Vector2>(Samples + 1);
		for (int i = 0; i <= Samples; i++)
		{
			OrientedPoint? p = path.Interpolate((float)i / Samples);
			if (p.HasValue)
			{
				points.Add(new Vector2(p.Value.Position.X, p.Value.Position.Z));
			}
		}
		return points;
	}

	public override ConstraintLogData GetLogData()
	{
		return new PathJunctionConstraintLogData
		{
			MaxAcceleration = lastMaxAccel,
			Distance = distance
		};
	}
}
