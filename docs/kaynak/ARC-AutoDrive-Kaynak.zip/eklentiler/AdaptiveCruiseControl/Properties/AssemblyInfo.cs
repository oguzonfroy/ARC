using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: AssemblyCompany("AdaptiveCruiseControl")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0+ddff0611e681248b3f9abdfecd4415475f9c0bbe")]
[assembly: AssemblyProduct("AdaptiveCruiseControl")]
[assembly: AssemblyTitle("AdaptiveCruiseControl")]
[assembly: AssemblyVersion("1.0.0.0")]
