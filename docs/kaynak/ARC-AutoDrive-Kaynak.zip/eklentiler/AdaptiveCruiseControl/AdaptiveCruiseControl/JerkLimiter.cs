using System;

namespace AdaptiveCruiseControl;

public class JerkLimiter
{
	private float tickRate;

	private float _lastTargetValue;

	private bool _jerkLimiterInitialized;

	public float maxJerk { get; set; }

	public JerkLimiter(int tickRate, float maxJerk)
	{
		this.tickRate = tickRate;
		this.maxJerk = maxJerk;
	}

	public float Update(float targetValue)
	{
		if (!_jerkLimiterInitialized)
		{
			_lastTargetValue = targetValue;
			_jerkLimiterInitialized = true;
			return targetValue;
		}
		float value = targetValue - _lastTargetValue;
		float num = maxJerk * (1f / tickRate);
		if (Math.Abs(value) > num)
		{
			targetValue = _lastTargetValue + (float)Math.Sign(value) * num;
		}
		_lastTargetValue = targetValue;
		return targetValue;
	}

	public void Reset()
	{
		_jerkLimiterInitialized = false;
		_lastTargetValue = 0f;
	}
}
