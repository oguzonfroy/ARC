using System;
using System.Collections.Generic;
using ETS2LA.Settings;

namespace AdaptiveCruiseControl;

[Serializable]
public class ACCSettings
{
	[NonSerialized]
	private static readonly Lazy<ACCSettings> _instance = new Lazy<ACCSettings>(() => new ACCSettings(loadSettings: true));

	public List<string> IgnoredConstraints = new List<string>();

	public float MaxAccel = 4f;

	public float MaxDecel = 3.5f;

	public float ComfortAccel = 1.5f;

	public float ComfortDecel = 2f;

	public float ProportionalGain = 0.5f;

	public int StandstillGap = 10;

	public bool OverrideFollowingDistance;

	public float FollowingDistanceOverride = 2f;

	public float CenterlineTolerance = 3f;

	public bool RenderLeadingVehicle = true;

	public float MaxLateralAcceleration = 3f;

	public bool ProgressiveCurvature = true;

	public float MinSpeed = 4.166667f;

	public float MaxDistance = 300f;

	public float MaxRadius = 150f;

	public int PointStep = 3;

	public float StoppingDistance = 5f;

	public bool RenderAllSemaphores = true;

	public bool RenderTargetSemaphore = true;

	[NonSerialized]
	private SettingsHandler? _settingsHandler;

	public static ACCSettings Current => _instance.Value;

	public ACCSettings(bool loadSettings = false)
	{
		if (loadSettings)
		{
			_settingsHandler = new SettingsHandler();
			ACCSettings aCCSettings = _settingsHandler.Load<ACCSettings>("tumppi066.adaptivecruisecontrol.v2.json");
			if (aCCSettings != null)
			{
				IgnoredConstraints = aCCSettings.IgnoredConstraints;
				StandstillGap = aCCSettings.StandstillGap;
				OverrideFollowingDistance = aCCSettings.OverrideFollowingDistance;
				FollowingDistanceOverride = aCCSettings.FollowingDistanceOverride;
				CenterlineTolerance = aCCSettings.CenterlineTolerance;
				RenderLeadingVehicle = aCCSettings.RenderLeadingVehicle;
				MaxLateralAcceleration = aCCSettings.MaxLateralAcceleration;
				MinSpeed = aCCSettings.MinSpeed;
				MaxDistance = aCCSettings.MaxDistance;
				MaxRadius = aCCSettings.MaxRadius;
				PointStep = aCCSettings.PointStep;
				StoppingDistance = aCCSettings.StoppingDistance;
				RenderAllSemaphores = aCCSettings.RenderAllSemaphores;
				RenderTargetSemaphore = aCCSettings.RenderTargetSemaphore;
			}
		}
	}

	public ACCSettings()
	{
	}

	public void Save()
	{
		_settingsHandler?.Save("tumppi066.adaptivecruisecontrol.v2.json", this);
	}
}
