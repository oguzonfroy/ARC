using System.Collections.Generic;
using ETS2LA.UI.Shared.Components;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.CompilerServices;
using Microsoft.AspNetCore.Components.Rendering;

namespace AdaptiveCruiseControl;

[Route("/plugins/adjustments/tumppi066.adaptivecruisecontrol")]
public class Adjustments : ComponentBase
{
	private List<string> IgnoredConstraints
	{
		get
		{
			return ACCSettings.Current.IgnoredConstraints;
		}
		set
		{
			ACCSettings.Current.IgnoredConstraints = value;
			ACCSettings.Current.Save();
		}
	}

	private float MaxAccel
	{
		get
		{
			return ACCSettings.Current.MaxAccel;
		}
		set
		{
			ACCSettings.Current.MaxAccel = value;
			ACCSettings.Current.Save();
		}
	}

	private float MaxDecel
	{
		get
		{
			return ACCSettings.Current.MaxDecel;
		}
		set
		{
			ACCSettings.Current.MaxDecel = value;
			ACCSettings.Current.Save();
		}
	}

	private float ComfortAccel
	{
		get
		{
			return ACCSettings.Current.ComfortAccel;
		}
		set
		{
			ACCSettings.Current.ComfortAccel = value;
			ACCSettings.Current.Save();
		}
	}

	private float ComfortDecel
	{
		get
		{
			return ACCSettings.Current.ComfortDecel;
		}
		set
		{
			ACCSettings.Current.ComfortDecel = value;
			ACCSettings.Current.Save();
		}
	}

	private float ProportionalGain
	{
		get
		{
			return ACCSettings.Current.ProportionalGain;
		}
		set
		{
			ACCSettings.Current.ProportionalGain = value;
			ACCSettings.Current.Save();
		}
	}

	private int StandstillGap
	{
		get
		{
			return ACCSettings.Current.StandstillGap;
		}
		set
		{
			ACCSettings.Current.StandstillGap = value;
			ACCSettings.Current.Save();
		}
	}

	private bool OverrideFollowingDistance
	{
		get
		{
			return ACCSettings.Current.OverrideFollowingDistance;
		}
		set
		{
			ACCSettings.Current.OverrideFollowingDistance = value;
			ACCSettings.Current.Save();
		}
	}

	public float FollowingDistanceOverride
	{
		get
		{
			return ACCSettings.Current.FollowingDistanceOverride;
		}
		set
		{
			ACCSettings.Current.FollowingDistanceOverride = value;
			ACCSettings.Current.Save();
		}
	}

	public float CenterlineTolerance
	{
		get
		{
			return ACCSettings.Current.CenterlineTolerance;
		}
		set
		{
			ACCSettings.Current.CenterlineTolerance = value;
			ACCSettings.Current.Save();
		}
	}

	public bool RenderLeadingVehicle
	{
		get
		{
			return ACCSettings.Current.RenderLeadingVehicle;
		}
		set
		{
			ACCSettings.Current.RenderLeadingVehicle = value;
			ACCSettings.Current.Save();
		}
	}

	public float MaxLateralAcceleration
	{
		get
		{
			return ACCSettings.Current.MaxLateralAcceleration;
		}
		set
		{
			ACCSettings.Current.MaxLateralAcceleration = value;
			ACCSettings.Current.Save();
		}
	}

	public float MinSpeed
	{
		get
		{
			return ACCSettings.Current.MinSpeed;
		}
		set
		{
			ACCSettings.Current.MinSpeed = value;
			ACCSettings.Current.Save();
		}
	}

	public float MaxDistance
	{
		get
		{
			return ACCSettings.Current.MaxDistance;
		}
		set
		{
			ACCSettings.Current.MaxDistance = value;
			ACCSettings.Current.Save();
		}
	}

	public float MaxRadius
	{
		get
		{
			return ACCSettings.Current.MaxRadius;
		}
		set
		{
			ACCSettings.Current.MaxRadius = value;
			ACCSettings.Current.Save();
		}
	}

	public int PointStep
	{
		get
		{
			return ACCSettings.Current.PointStep;
		}
		set
		{
			ACCSettings.Current.PointStep = value;
			ACCSettings.Current.Save();
		}
	}

	public float StoppingDistance
	{
		get
		{
			return ACCSettings.Current.StoppingDistance;
		}
		set
		{
			ACCSettings.Current.StoppingDistance = value;
			ACCSettings.Current.Save();
		}
	}

	public bool RenderAllSemaphores
	{
		get
		{
			return ACCSettings.Current.RenderAllSemaphores;
		}
		set
		{
			ACCSettings.Current.RenderAllSemaphores = value;
			ACCSettings.Current.Save();
		}
	}

	public bool RenderTargetSemaphore
	{
		get
		{
			return ACCSettings.Current.RenderTargetSemaphore;
		}
		set
		{
			ACCSettings.Current.RenderTargetSemaphore = value;
			ACCSettings.Current.Save();
		}
	}

	protected override void BuildRenderTree(RenderTreeBuilder __builder)
	{
		__builder.OpenElement(0, "div");
		__builder.AddAttribute(1, "class", "flex flex-col w-full p-5 px-8 gap-3");
		__builder.OpenComponent<SectionTitle>(2);
		__builder.AddComponentParameter(3, "Title", RuntimeHelpers.TypeCheck("Acceleration Settings"));
		__builder.CloseComponent();
		__builder.AddMarkupContent(4, "\r\n    ");
		__builder.OpenComponent<Slider>(5);
		__builder.AddComponentParameter(6, "Title", RuntimeHelpers.TypeCheck("Maximum Acceleration (m/s²)"));
		__builder.AddComponentParameter(7, "Description", RuntimeHelpers.TypeCheck("The maximum acceleration rate in m/s² that ACC should target."));
		__builder.AddComponentParameter(8, "Value", RuntimeHelpers.TypeCheck(MaxAccel));
		__builder.AddComponentParameter(9, "Min", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(10, "Max", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(11, "Step", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(12, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			MaxAccel = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(13, "\r\n    ");
		__builder.OpenComponent<Slider>(14);
		__builder.AddComponentParameter(15, "Title", RuntimeHelpers.TypeCheck("Maximum Deceleration (m/s²)"));
		__builder.AddComponentParameter(16, "Description", RuntimeHelpers.TypeCheck("The maximum deceleration rate in m/s² that ACC should target."));
		__builder.AddComponentParameter(17, "Value", RuntimeHelpers.TypeCheck(MaxDecel));
		__builder.AddComponentParameter(18, "Min", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(19, "Max", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(20, "Step", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(21, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			MaxDecel = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(22, "\r\n    ");
		__builder.OpenComponent<Slider>(23);
		__builder.AddComponentParameter(24, "Title", RuntimeHelpers.TypeCheck("Comfort Acceleration (m/s²)"));
		__builder.AddComponentParameter(25, "Description", RuntimeHelpers.TypeCheck("The typical comfortable acceleration rate in m/s² that ACC should target."));
		__builder.AddComponentParameter(26, "Value", RuntimeHelpers.TypeCheck(ComfortAccel));
		__builder.AddComponentParameter(27, "Min", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(28, "Max", RuntimeHelpers.TypeCheck(5f));
		__builder.AddComponentParameter(29, "Step", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(30, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			ComfortAccel = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(31, "\r\n    ");
		__builder.OpenComponent<Slider>(32);
		__builder.AddComponentParameter(33, "Title", RuntimeHelpers.TypeCheck("Comfort Deceleration (m/s²)"));
		__builder.AddComponentParameter(34, "Description", RuntimeHelpers.TypeCheck("The typical comfortable deceleration rate in m/s² that ACC should target."));
		__builder.AddComponentParameter(35, "Value", RuntimeHelpers.TypeCheck(ComfortDecel));
		__builder.AddComponentParameter(36, "Min", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(37, "Max", RuntimeHelpers.TypeCheck(5f));
		__builder.AddComponentParameter(38, "Step", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(39, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			ComfortDecel = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(40, "\r\n    ");
		__builder.OpenComponent<Slider>(41);
		__builder.AddComponentParameter(42, "Title", RuntimeHelpers.TypeCheck("Proportional Gain"));
		__builder.AddComponentParameter(43, "Description", RuntimeHelpers.TypeCheck("Determines how aggressively ACC will attempt to reach the target speed."));
		__builder.AddComponentParameter(44, "Value", RuntimeHelpers.TypeCheck(ProportionalGain));
		__builder.AddComponentParameter(45, "Min", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(46, "Max", RuntimeHelpers.TypeCheck(2f));
		__builder.AddComponentParameter(47, "Step", RuntimeHelpers.TypeCheck(0.01f));
		__builder.AddComponentParameter(48, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			ProportionalGain = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(49, "\r\n\r\n    ");
		__builder.OpenComponent<SectionTitle>(50);
		__builder.AddComponentParameter(51, "Title", RuntimeHelpers.TypeCheck("Leading Vehicle Constraint"));
		__builder.CloseComponent();
		__builder.AddMarkupContent(52, "\r\n    ");
		__builder.OpenComponent<Switch>(53);
		__builder.AddComponentParameter(54, "Title", RuntimeHelpers.TypeCheck("Enabled"));
		__builder.AddComponentParameter(55, "Description", RuntimeHelpers.TypeCheck("Determines whether or not adaptive cruise control should slow down for the leading vehicle. Disabling this will cause ETS2LA to ignore other vehicles on the road."));
		__builder.AddComponentParameter(56, "Value", RuntimeHelpers.TypeCheck(!IgnoredConstraints.Contains("Leading Vehicle")));
		__builder.AddComponentParameter(57, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			ToggleConstraint("Leading Vehicle", value);
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(58, "\r\n    ");
		__builder.OpenComponent<Slider>(59);
		__builder.AddComponentParameter(60, "Title", RuntimeHelpers.TypeCheck("Standstill Gap (m)"));
		__builder.AddComponentParameter(61, "Description", RuntimeHelpers.TypeCheck("The distance in meters to maintain from the leading vehicle when stopped."));
		__builder.AddComponentParameter(62, "Value", RuntimeHelpers.TypeCheck((float)StandstillGap));
		__builder.AddComponentParameter(63, "Min", RuntimeHelpers.TypeCheck(5f));
		__builder.AddComponentParameter(64, "Max", RuntimeHelpers.TypeCheck(30f));
		__builder.AddComponentParameter(65, "Step", RuntimeHelpers.TypeCheck(1f));
		__builder.AddComponentParameter(66, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			StandstillGap = (int)value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(67, "\r\n    ");
		__builder.OpenComponent<Switch>(68);
		__builder.AddComponentParameter(69, "Title", RuntimeHelpers.TypeCheck("Override Following Distance"));
		__builder.AddComponentParameter(70, "Description", RuntimeHelpers.TypeCheck(""));
		__builder.AddComponentParameter(71, "Value", RuntimeHelpers.TypeCheck(OverrideFollowingDistance));
		__builder.AddComponentParameter(72, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			OverrideFollowingDistance = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(73, "\r\n    ");
		__builder.OpenComponent<Slider>(74);
		__builder.AddComponentParameter(75, "Title", RuntimeHelpers.TypeCheck("Following Distance Override (s)"));
		__builder.AddComponentParameter(76, "Description", RuntimeHelpers.TypeCheck("The time in seconds to maintain from the leading vehicle when moving. This will only be used if 'Override Following Distance' is enabled, otherwise the global following distance setting will be used."));
		__builder.AddComponentParameter(77, "Value", RuntimeHelpers.TypeCheck(FollowingDistanceOverride));
		__builder.AddComponentParameter(78, "Min", RuntimeHelpers.TypeCheck(0.5f));
		__builder.AddComponentParameter(79, "Max", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(80, "Step", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(81, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			FollowingDistanceOverride = value;
		})));
		__builder.AddComponentParameter(82, "Class", RuntimeHelpers.TypeCheck(OverrideFollowingDistance ? "" : "opacity-30 pointer-events-none"));
		__builder.CloseComponent();
		__builder.AddMarkupContent(83, "\r\n    ");
		__builder.OpenComponent<Slider>(84);
		__builder.AddComponentParameter(85, "Title", RuntimeHelpers.TypeCheck("Centerline Tolerance (m)"));
		__builder.AddComponentParameter(86, "Description", RuntimeHelpers.TypeCheck("How far from the centerline of the road the leading vehicle can be before it is ignored. Most roads in the game have a width of 4.5m."));
		__builder.AddComponentParameter(87, "Value", RuntimeHelpers.TypeCheck(CenterlineTolerance));
		__builder.AddComponentParameter(88, "Min", RuntimeHelpers.TypeCheck(0.5f));
		__builder.AddComponentParameter(89, "Max", RuntimeHelpers.TypeCheck(4.5f));
		__builder.AddComponentParameter(90, "Step", RuntimeHelpers.TypeCheck(0.05f));
		__builder.AddComponentParameter(91, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			CenterlineTolerance = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(92, "\r\n    ");
		__builder.OpenComponent<Switch>(93);
		__builder.AddComponentParameter(94, "Title", "Render Leading Vehicle");
		__builder.AddComponentParameter(95, "Description", RuntimeHelpers.TypeCheck("Determines whether or not the leading vehicle should be rendered in the overlay."));
		__builder.AddComponentParameter(96, "Value", RuntimeHelpers.TypeCheck(RenderLeadingVehicle));
		__builder.AddComponentParameter(97, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			RenderLeadingVehicle = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(98, "\r\n\r\n    ");
		__builder.OpenComponent<SectionTitle>(99);
		__builder.AddComponentParameter(100, "Title", RuntimeHelpers.TypeCheck("Path Curvature Constraint"));
		__builder.CloseComponent();
		__builder.AddMarkupContent(101, "\r\n    ");
		__builder.OpenComponent<Switch>(102);
		__builder.AddComponentParameter(103, "Title", RuntimeHelpers.TypeCheck("Enabled"));
		__builder.AddComponentParameter(104, "Description", RuntimeHelpers.TypeCheck("Determines whether or not adaptive cruise control should consider the curvature of the road. Disabling this will cause ETS2LA to ignore turns and curves in the road."));
		__builder.AddComponentParameter(105, "Value", RuntimeHelpers.TypeCheck(!IgnoredConstraints.Contains("Path Curvature")));
		__builder.AddComponentParameter(106, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			ToggleConstraint("Path Curvature", value);
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(107, "\r\n    ");
		__builder.OpenComponent<Slider>(108);
		__builder.AddComponentParameter(109, "Title", RuntimeHelpers.TypeCheck("Max Lateral Acceleration (m/s²)"));
		__builder.AddComponentParameter(110, "Description", RuntimeHelpers.TypeCheck("The max amount of sideways force that the constraint should allow. Higher values will allow for faster cornering, while lower values will cause the vehicle to slow down more in curves."));
		__builder.AddComponentParameter(111, "Value", RuntimeHelpers.TypeCheck(MaxLateralAcceleration));
		__builder.AddComponentParameter(112, "Min", RuntimeHelpers.TypeCheck(0.5f));
		__builder.AddComponentParameter(113, "Max", RuntimeHelpers.TypeCheck(5f));
		__builder.AddComponentParameter(114, "Step", RuntimeHelpers.TypeCheck(0.1f));
		__builder.AddComponentParameter(115, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			MaxLateralAcceleration = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(116, "\r\n    ");
		__builder.OpenComponent<Switch>(117);
		__builder.AddComponentParameter(118, "Title", RuntimeHelpers.TypeCheck("Progressive Curvature"));
		__builder.AddComponentParameter(119, "Description", RuntimeHelpers.TypeCheck("If enabled, the constraint will scale the max lateral acceleration. Effectively, slight turns will affect less than usual, while sharp turns will affect more."));
		__builder.AddComponentParameter(120, "Value", RuntimeHelpers.TypeCheck(ACCSettings.Current.ProgressiveCurvature));
		__builder.AddComponentParameter(121, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			ACCSettings.Current.ProgressiveCurvature = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(122, "\r\n    ");
		__builder.OpenComponent<Slider>(123);
		__builder.AddComponentParameter(124, "Title", "Minimum Speed (m/s)");
		__builder.AddComponentParameter(125, "Description", RuntimeHelpers.TypeCheck("The lowest speed that the constraint should target. This is useful for preventing extremely slow speeds when turning."));
		__builder.AddComponentParameter(126, "Value", RuntimeHelpers.TypeCheck(MinSpeed));
		__builder.AddComponentParameter(127, "Min", RuntimeHelpers.TypeCheck(2f));
		__builder.AddComponentParameter(128, "Max", RuntimeHelpers.TypeCheck(25f));
		__builder.AddComponentParameter(129, "Step", RuntimeHelpers.TypeCheck(1f));
		__builder.AddComponentParameter(130, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			MinSpeed = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(131, "\r\n    ");
		__builder.OpenComponent<Slider>(132);
		__builder.AddComponentParameter(133, "Title", RuntimeHelpers.TypeCheck("Max Distance (m)"));
		__builder.AddComponentParameter(134, "Description", RuntimeHelpers.TypeCheck("The maximum point distance to consider when calculating max acceleration. Low values can cause sudden braking while high values can cause braking noise."));
		__builder.AddComponentParameter(135, "Value", RuntimeHelpers.TypeCheck(MaxDistance));
		__builder.AddComponentParameter(136, "Min", RuntimeHelpers.TypeCheck(50f));
		__builder.AddComponentParameter(137, "Max", RuntimeHelpers.TypeCheck(500f));
		__builder.AddComponentParameter(138, "Step", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(139, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			MaxDistance = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(140, "\r\n    ");
		__builder.OpenComponent<Slider>(141);
		__builder.AddComponentParameter(142, "Title", RuntimeHelpers.TypeCheck("Max Curvature Radius (m)"));
		__builder.AddComponentParameter(143, "Description", RuntimeHelpers.TypeCheck("The minimum radius of curvature to consider when calculating max acceleration. Higher values may cause slowdowns in curves that don't matter, while lower values may cause oversteer."));
		__builder.AddComponentParameter(144, "Value", RuntimeHelpers.TypeCheck(MaxRadius));
		__builder.AddComponentParameter(145, "Min", RuntimeHelpers.TypeCheck(50f));
		__builder.AddComponentParameter(146, "Max", RuntimeHelpers.TypeCheck(500f));
		__builder.AddComponentParameter(147, "Step", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(148, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			MaxRadius = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(149, "\r\n    ");
		__builder.OpenComponent<Slider>(150);
		__builder.AddComponentParameter(151, "Title", RuntimeHelpers.TypeCheck("Point Step"));
		__builder.AddComponentParameter(152, "Description", RuntimeHelpers.TypeCheck("The number of points to skip when calculating the curvature. Higher values will cause less accurate calculations, while lower values will cause more phantom braking due to data noise."));
		__builder.AddComponentParameter(153, "Value", RuntimeHelpers.TypeCheck((float)PointStep));
		__builder.AddComponentParameter(154, "Min", RuntimeHelpers.TypeCheck(1f));
		__builder.AddComponentParameter(155, "Max", RuntimeHelpers.TypeCheck(10f));
		__builder.AddComponentParameter(156, "Step", RuntimeHelpers.TypeCheck(1f));
		__builder.AddComponentParameter(157, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			PointStep = (int)value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(158, "\r\n\r\n    ");
		__builder.OpenComponent<SectionTitle>(159);
		__builder.AddComponentParameter(160, "Title", RuntimeHelpers.TypeCheck("Path Semaphores Constraint"));
		__builder.CloseComponent();
		__builder.AddMarkupContent(161, "\r\n    ");
		__builder.OpenComponent<Switch>(162);
		__builder.AddComponentParameter(163, "Title", RuntimeHelpers.TypeCheck("Enabled"));
		__builder.AddComponentParameter(164, "Description", RuntimeHelpers.TypeCheck("Determines whether or not adaptive cruise control should consider the path semaphores. Disabling this will cause ETS2LA to ignore traffic lights and gates."));
		__builder.AddComponentParameter(165, "Value", RuntimeHelpers.TypeCheck(!IgnoredConstraints.Contains("Path Semaphores")));
		__builder.AddComponentParameter(166, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			ToggleConstraint("Path Semaphores", value);
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(167, "\r\n    ");
		__builder.OpenComponent<Slider>(168);
		__builder.AddComponentParameter(169, "Title", RuntimeHelpers.TypeCheck("Stopping Distance (m)"));
		__builder.AddComponentParameter(170, "Description", RuntimeHelpers.TypeCheck("The distance to maintain from the target semaphore (traffic light or gate) when stopping."));
		__builder.AddComponentParameter(171, "Value", RuntimeHelpers.TypeCheck(StoppingDistance));
		__builder.AddComponentParameter(172, "Min", RuntimeHelpers.TypeCheck(2f));
		__builder.AddComponentParameter(173, "Max", RuntimeHelpers.TypeCheck(30f));
		__builder.AddComponentParameter(174, "Step", RuntimeHelpers.TypeCheck(1f));
		__builder.AddComponentParameter(175, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (float value) =>
		{
			StoppingDistance = value;
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(176, "\r\n    ");
		__builder.OpenComponent<Switch>(177);
		__builder.AddComponentParameter(178, "Title", RuntimeHelpers.TypeCheck("Render All Semaphores"));
		__builder.AddComponentParameter(179, "Description", RuntimeHelpers.TypeCheck("Determines whether or not all semaphores (traffic lights and gates) should be rendered in the overlay."));
		__builder.AddComponentParameter(180, "Value", RuntimeHelpers.TypeCheck(RenderAllSemaphores));
		__builder.AddComponentParameter(181, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			ToggleRenderAllSemaphores(value);
		})));
		__builder.CloseComponent();
		__builder.AddMarkupContent(182, "\r\n    ");
		__builder.OpenComponent<Switch>(183);
		__builder.AddComponentParameter(184, "Title", RuntimeHelpers.TypeCheck("Render Target Semaphore"));
		__builder.AddComponentParameter(185, "Description", RuntimeHelpers.TypeCheck("Determines whether or not the target semaphore (traffic light or gate) should be rendered in the overlay."));
		__builder.AddComponentParameter(186, "Value", RuntimeHelpers.TypeCheck(RenderTargetSemaphore));
		__builder.AddComponentParameter(187, "ValueChanged", RuntimeHelpers.TypeCheck(EventCallback.Factory.Create(this, (bool value) =>
		{
			RenderTargetSemaphore = value;
		})));
		__builder.CloseComponent();
		__builder.CloseElement();
	}

	private void ToggleConstraint(string constraintName, bool value)
	{
		if (value && IgnoredConstraints.Contains(constraintName))
		{
			IgnoredConstraints.Remove(constraintName);
			ACCSettings.Current.Save();
		}
		else if (!value && !IgnoredConstraints.Contains(constraintName))
		{
			IgnoredConstraints.Add(constraintName);
			ACCSettings.Current.Save();
		}
	}

	private void ToggleRenderAllSemaphores(bool value)
	{
		RenderAllSemaphores = value;
		if (value)
		{
			RenderTargetSemaphore = true;
		}
	}
}
