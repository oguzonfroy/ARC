using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using AdaptiveCruiseControl.Constraints;
using ETS2LA.Backend.Events;
using ETS2LA.Game.Output;
using ETS2LA.Game.SDK;
using ETS2LA.Game.Telemetry;
using ETS2LA.Overlay;
using ETS2LA.Settings.Global;
using ETS2LA.Shared;
using ETS2LA.State;
using ETS2LA.Translations;
using Hexa.NET.ImGui;
using PIDLib;
using TruckLib;

namespace AdaptiveCruiseControl;

public class AdaptiveCruiseControlPlugin : Plugin
{
	private bool dataLoggerEnabled;

	private GameTelemetryData? telemetryData;

	public List<Constraint> constraints = new List<Constraint>();

	private WindowDefinition windowDefinition = new WindowDefinition
	{
		Title = "ACC Constraints"
	};

	private WindowDefinition tuningWindowDefinition = new WindowDefinition
	{
		Title = "ACC Tuning"
	};

	private Dictionary<AccelerationResponseOption, PIDController> accelerationPids = new Dictionary<AccelerationResponseOption, PIDController>
	{
		{
			AccelerationResponseOption.Slow,
			new PIDController(0.9f, 0.05f, 0.1f, derivateFromActual: true, 1f, 0f, 0.5f)
		},
		{
			AccelerationResponseOption.Normal,
			new PIDController(0.9f, 0.05f, 0.1f, derivateFromActual: true, 1f, 0f, 0.5f)
		},
		{
			AccelerationResponseOption.Fast,
			new PIDController(0.9f, 0.05f, 0.1f, derivateFromActual: true, 1f, 0f, 0.5f)
		}
	};

	private Dictionary<AccelerationResponseOption, PIDController> decelerationPids = new Dictionary<AccelerationResponseOption, PIDController>
	{
		{
			AccelerationResponseOption.Slow,
			new PIDController(0.1f, 0.4f, 0.07f, derivateFromActual: true, 2f, 0f, 0.5f)
		},
		{
			AccelerationResponseOption.Normal,
			new PIDController(0.1f, 0.4f, 0.07f, derivateFromActual: true, 2f, 0f, 0.5f)
		},
		{
			AccelerationResponseOption.Fast,
			new PIDController(0.1f, 0.4f, 0.07f, derivateFromActual: true, 2f, 0f, 0.5f)
		}
	};

	private Dictionary<AccelerationResponseOption, float> jerkLimits = new Dictionary<AccelerationResponseOption, float>
	{
		{
			AccelerationResponseOption.Slow,
			1f
		},
		{
			AccelerationResponseOption.Normal,
			1.5f
		},
		{
			AccelerationResponseOption.Fast,
			2f
		}
	};

	private PIDController? accelerationPID;

	private PIDController? decelerationPID;

	private DataLogger? dataLogger;

	private JerkLimiter? jerkLimiter;

	private KalmanFilter inputAccelerationKalmanFilter = new KalmanFilter(0.01f, 0.67f);

	public float DryMass = 9500f;

	public float DragCoefficient = 3f;

	public float StaticFriction = 500f;

	public float MaxEngineForce = 45000f;

	public float MaxBrakingForce = 90000f;

	public float EngineBrakeCoefficient = 1000f;

	private float currentSpeed;

	private float currentAcceleration;

	private float targetAcceleration;

	private float dragFeedforward;

	private float pitchFeedforward;

	private float pidOutput;

	private float pedalOutput;

	private Dictionary<string, float> constraintValues = new Dictionary<string, float>();

	private bool windowRegistered;

	public override PluginInformation Info
	{
		get
		{
			PluginInformation pluginInformation = new PluginInformation { Name = "", Description = "", Version = "", Id = "" };
			pluginInformation.Name = T._("Adaptive Cruise Control");
			pluginInformation.Description = T._("This plugin provides adaptive cruise control features.");
			pluginInformation.AuthorName = "Tumppi066, DylanBPY";
			pluginInformation.Version = "2.1.1";
			pluginInformation.AppVersionSupport.LowerBound = "2026.11.5250";
			pluginInformation.Icon = "https://avatars.githubusercontent.com/u/162675991?s=128";
			pluginInformation.Id = "tumppi066.adaptivecruisecontrol";
			pluginInformation.Tags = new string[3] { "Acceleration", "Assists", "AEB" };
			pluginInformation.DependsOn.Add(new PluginDependency
			{
				Id = "tumppi066.pathfinding"
			});
			pluginInformation.DependsOn.Add(new PluginDependency
			{
				Id = "tumppi066.pathlib"
			});
			pluginInformation.DependsOn.Add(new PluginDependency
			{
				Id = "tumppi066.pidlib"
			});
			return pluginInformation;
		}
	}

	public override float TickRate => 20f;

	public override void OnEnable()
	{
		base.OnEnable();
		OverlayHandler.Current.RegisterWindow(windowDefinition, DrawOverlay);
		constraints.Add(new LeadingVehicleConstraint());
		constraints.Add(new PathCurvatureConstraint());
		constraints.Add(new PathSemaphoreConstraint());
		constraints.Add(new PathJunctionConstraint());
		if (dataLoggerEnabled)
		{
			dataLogger = new DataLogger();
		}
	}

	public override void Init()
	{
		base.Init();
		telemetryData = GameTelemetry.Current.GetCurrentData();
		accelerationPID = accelerationPids[AssistanceSettings.Current.AccelerationResponse];
		decelerationPID = decelerationPids[AssistanceSettings.Current.AccelerationResponse];
		jerkLimiter = new JerkLimiter((int)TickRate, jerkLimits[AssistanceSettings.Current.AccelerationResponse]);
	}

	public void Reset()
	{
		inputAccelerationKalmanFilter.Reset();
		accelerationPID?.Reset();
		decelerationPID?.Reset();
		jerkLimiter?.Reset();
		dataLogger?.Reset();
	}

	public float EvaluateConstraints()
	{
		float num = float.MaxValue;
		foreach (Constraint constraint in constraints)
		{
			if (ACCSettings.Current.IgnoredConstraints.Contains(constraint.Name))
			{
				constraintValues[constraint.Name] = float.NaN;
				continue;
			}
			float maxAcceleration = constraint.GetMaxAcceleration();
			constraintValues[constraint.Name] = maxAcceleration;
			num = Math.Min(num, float.IsNaN(maxAcceleration) ? float.MaxValue : maxAcceleration);
		}
		return Math.Clamp(num, -3f, 2f);
	}

	public override void Tick()
	{
		if (telemetryData == null)
		{
			pedalOutput = 0f;
			return;
		}
		if (ApplicationState.Current.DrivingMode == DrivingMode.LaneAssistOnly || ApplicationState.Current.DesiredSpeed == 0f || !ApplicationState.Current.EnableAssists || telemetryData.paused)
		{
			Reset();
			return;
		}
		currentSpeed = telemetryData.truckFloat.speed;
		float num = 0f - telemetryData.truckVector.acceleration.Z;
		currentAcceleration = inputAccelerationKalmanFilter.Update(num);
		float rawTargetAccelerationRaw = (targetAcceleration = EvaluateConstraints());
		if ((double)targetAcceleration <= 0.1 && (double)targetAcceleration >= -0.5 && currentSpeed < 0.5f)
		{
			targetAcceleration = -0.5f;
			return;
		}
		float num2 = (float)telemetryData.configUI.unitCount * telemetryData.configFloat.unitMass + DryMass;
		float x = CameraProvider.Current.GetCurrentData().truckRotation.ToEuler().X;
		dragFeedforward = DragCoefficient * currentSpeed * currentSpeed * (float)Math.Sign(currentSpeed);
		pitchFeedforward = num2 * 9.81f * MathF.Sin(x);
		float num3 = num2 * targetAcceleration + dragFeedforward + pitchFeedforward + StaticFriction * (float)Math.Sign(currentSpeed);
		if (targetAcceleration >= 0f)
		{
			PIDController? pIDController = accelerationPID;
			pidOutput = ((pIDController != null) ? (pIDController.Update(targetAcceleration, currentAcceleration) * num2) : 0f);
			decelerationPID?.Reset();
		}
		else
		{
			PIDController? pIDController2 = decelerationPID;
			pidOutput = ((pIDController2 != null) ? (pIDController2.Update(targetAcceleration, currentAcceleration) * num2) : 0f);
			accelerationPID?.Reset();
		}
		float num4 = pidOutput + num3;
		ControlVariables controlVariables = new ControlVariables();
		if (num4 >= 0f)
		{
			pedalOutput = Math.Clamp(num4 / MaxEngineForce, 0f, 1f);
			controlVariables.aforward = pedalOutput;
			PIDController? pIDController3 = accelerationPID;
			if (pIDController3 != null)
			{
				pIDController3.DontBuildIntegral = pedalOutput == 1f || currentSpeed >= ApplicationState.Current.DesiredSpeed;
			}
		}
		else
		{
			pedalOutput = 0f - Math.Clamp((0f - num4) / MaxBrakingForce, 0f, 1f);
			controlVariables.abackward = pedalOutput;
			PIDController? pIDController4 = accelerationPID;
			if (pIDController4 != null)
			{
				pIDController4.DontBuildIntegral = currentSpeed < 1f;
			}
			PIDController? pIDController5 = decelerationPID;
			if (pIDController5 != null)
			{
				pIDController5.DontBuildIntegral = currentSpeed < 1f;
			}
		}
		ControlEvent data = new ControlEvent
		{
			ChannelDefinition = new ControlChannelDefinition
			{
				Id = "AdaptiveCruiseControl.Acceleration",
				Timeout = 0.2f
			},
			Properties = new ControlProperties(),
			Variables = controlVariables
		};
		Events.Current.Publish(GameOutput.Current.EventString, data);
		if (!dataLoggerEnabled || dataLogger == null)
		{
			return;
		}
		List<object> list = new List<object>();
		foreach (Constraint constraint in constraints)
		{
			list.Add(constraint.GetLogData());
		}
		if (dataLogger.shouldUpdate(1f / TickRate))
		{
			dataLogger.Update(new ACCLogData
			{
				RawTargetAccelerationRaw = rawTargetAccelerationRaw,
				TargetAcceleration = targetAcceleration,
				RawTruckAcceleration = num,
				TruckAcceleration = currentAcceleration,
				TruckSpeed = currentSpeed,
				TruckX = telemetryData.truckPlacement.coordinate.X,
				TruckZ = telemetryData.truckPlacement.coordinate.Z,
				DragFeedforward = dragFeedforward,
				PitchFeedforward = pitchFeedforward,
				TotalForce = num3,
				PIDOutput = pidOutput,
				PedalOutput = pedalOutput,
				Constraints = list
			});
		}
	}

	private string SpeedToString(float speed)
	{
		Units displayUnits = ApplicationState.Current.DisplayUnits;
		return $"{UnitConversions.FromScientificUnits(UnitType.Speed, speed, displayUnits):0.##} {UnitConversions.GetUnitAbbreviation(UnitType.Speed, displayUnits)}";
	}

	private void DrawOverlay()
	{
		ImGui.Text(T._("Current Speed: {0}", SpeedToString(currentSpeed)));
		ImGui.Text("Desired Speed: " + SpeedToString(ApplicationState.Current.DesiredSpeed));
		ImGui.Text("Current Acceleration: " + currentAcceleration.ToString("F3") + " m/s²");
		ImGui.Text("Target Acceleration: " + targetAcceleration.ToString("F3") + " m/s²");
		ImGui.Separator();
		ImGui.Spacing();
		foreach (Constraint constraint in constraints)
		{
			KeyValuePair<string, float> keyValuePair = constraintValues.FirstOrDefault((KeyValuePair<string, float> kv) => kv.Key == constraint.Name);
			string text = (float.IsNaN(keyValuePair.Value) ? "N/A" : (keyValuePair.Value.ToString("F3") + " m/s²"));
			ImGui.Text(keyValuePair.Key + ": " + text);
			ImGui.TextColored(new Vector4(0.7f, 0.7f, 0.7f, 0.7f), constraint.Status);
			ImGui.Spacing();
		}
		ImGui.Spacing();
		ImGui.Separator();
		ImGui.Spacing();
		float num = Math.Clamp(pedalOutput, -1f, 1f);
		Vector4 col = ((num >= 0f) ? new Vector4(0.3f, 0.75f, 0.35f, 1f) : new Vector4(0.85f, 0.35f, 0.3f, 1f));
		ImGui.PushStyleColor(ImGuiCol.PlotHistogram, col);
		ImGui.ProgressBar(Math.Abs(num), new Vector2(-1f, 0f), (num * 100f).ToString("F1") + "%");
		ImGui.PopStyleColor();
		ImGui.Button(T._("Toggle PID Visualization"), new Vector2(170f, 25f));
		if (ImGui.IsItemClicked())
		{
			windowRegistered = !windowRegistered;
			if (windowRegistered)
			{
				accelerationPID?.RegisterWindow();
				decelerationPID?.RegisterWindow();
			}
			else
			{
				accelerationPID?.UnregisterWindow();
				decelerationPID?.UnregisterWindow();
			}
		}
	}

	private void DrawTuningWindow()
	{
		ImGui.SliderFloat("Dry Mass", ref DryMass, 0f, 15000f);
		ImGui.SliderFloat("Drag Coefficient", ref DragCoefficient, 0f, 20f);
		ImGui.SliderFloat("Static Friction", ref StaticFriction, 0f, 2000f);
		ImGui.SliderFloat("Max Engine Force", ref MaxEngineForce, 0f, 150000f);
		ImGui.SliderFloat("Max Braking Force", ref MaxBrakingForce, 0f, 150000f);
		ImGui.Text("Drag Feedforward: " + dragFeedforward.ToString("F4"));
		ImGui.Text("Pitch Feedforward: " + pitchFeedforward.ToString("F4"));
		ImGui.Spacing();
		ImGui.Separator();
		ImGui.Spacing();
		float v = accelerationPID?.Kp ?? 0f;
		float v2 = accelerationPID?.Ki ?? 0f;
		float v3 = accelerationPID?.Kd ?? 0f;
		float v4 = accelerationPID?.IntegralClamp ?? 0f;
		float v5 = decelerationPID?.Kp ?? 0f;
		float v6 = decelerationPID?.Ki ?? 0f;
		float v7 = decelerationPID?.Kd ?? 0f;
		float v8 = decelerationPID?.IntegralClamp ?? 0f;
		ImGui.Text("Acceleration PID Parameters");
		if (ImGui.SliderFloat("Kp", ref v, 0f, 10f))
		{
			PIDController? pIDController = accelerationPID;
			if (pIDController != null)
			{
				pIDController.Kp = v;
			}
		}
		if (ImGui.SliderFloat("Ki", ref v2, 0f, 2f))
		{
			PIDController? pIDController2 = accelerationPID;
			if (pIDController2 != null)
			{
				pIDController2.Ki = v2;
			}
		}
		if (ImGui.SliderFloat("Kd", ref v3, 0f, 1f))
		{
			PIDController? pIDController3 = accelerationPID;
			if (pIDController3 != null)
			{
				pIDController3.Kd = v3;
			}
		}
		if (ImGui.SliderFloat("Integral Clamp", ref v4, 0f, 10f))
		{
			PIDController? pIDController4 = accelerationPID;
			if (pIDController4 != null)
			{
				pIDController4.IntegralClamp = v4;
			}
		}
		ImGui.Text("Don't Build Integral: " + accelerationPID?.DontBuildIntegral.ToString());
		ImGui.Spacing();
		ImGui.Text("Deceleration PID Parameters");
		if (ImGui.SliderFloat("Kp##decel", ref v5, 0f, 10f))
		{
			PIDController? pIDController5 = decelerationPID;
			if (pIDController5 != null)
			{
				pIDController5.Kp = v5;
			}
		}
		if (ImGui.SliderFloat("Ki##decel", ref v6, 0f, 2f))
		{
			PIDController? pIDController6 = decelerationPID;
			if (pIDController6 != null)
			{
				pIDController6.Ki = v6;
			}
		}
		if (ImGui.SliderFloat("Kd##decel", ref v7, 0f, 1f))
		{
			PIDController? pIDController7 = decelerationPID;
			if (pIDController7 != null)
			{
				pIDController7.Kd = v7;
			}
		}
		if (ImGui.SliderFloat("Integral Clamp##decel", ref v8, 0f, 10f))
		{
			PIDController? pIDController8 = decelerationPID;
			if (pIDController8 != null)
			{
				pIDController8.IntegralClamp = v8;
			}
		}
		ImGui.Text("Don't Build Integral: " + decelerationPID?.DontBuildIntegral.ToString());
		ImGui.Spacing();
		ImGui.Text("PID Output: " + pidOutput.ToString("F4"));
		if (ImGui.Button("Reset"))
		{
			Reset();
		}
	}

	public override void OnDisable()
	{
		base.OnDisable();
		accelerationPID?.UnregisterWindow();
		decelerationPID?.UnregisterWindow();
		OverlayHandler.Current.UnregisterWindow(windowDefinition);
		OverlayHandler.Current.UnregisterWindow(tuningWindowDefinition);
		foreach (Constraint constraint in constraints)
		{
			constraint.Shutdown();
		}
	}

	public override void Shutdown()
	{
		base.Shutdown();
		foreach (Constraint constraint in constraints)
		{
			constraint.Shutdown();
		}
		ACCSettings.Current.Save();
	}
}
