using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace AdaptiveCruiseControl;

public class DataLogger
{
	private string dataRootFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal), "ETS2LA", "ACC Logs");

	private string? _filePath;

	private float elapedTime;

	private float lastTime;

	private JsonSerializerOptions options = new JsonSerializerOptions
	{
		NumberHandling = JsonNumberHandling.AllowNamedFloatingPointLiterals,
		WriteIndented = true
	};

	public bool shouldUpdate(float deltaTime)
	{
		elapedTime += deltaTime;
		if (elapedTime - lastTime > 0.25f)
		{
			lastTime = elapedTime;
			return true;
		}
		return false;
	}

	public void Update(ACCLogData logData)
	{
		logData.ElapsedTime = elapedTime;
		if (_filePath == null)
		{
			Directory.CreateDirectory(dataRootFolder);
			_filePath = Path.Combine(dataRootFolder, $"acc_log_{DateTime.Now:yyyyMMdd_HHmmss}.jsonl");
		}
		string text = JsonSerializer.Serialize(logData, options);
		File.AppendAllText(_filePath, text + Environment.NewLine);
	}

	public void Reset()
	{
		_filePath = null;
		elapedTime = 0f;
	}
}
