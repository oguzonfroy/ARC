using System.Collections.Generic;

namespace AdaptiveCruiseControl;

public class ACCLogData
{
	public float ElapsedTime { get; set; }

	public float RawTargetAccelerationRaw { get; set; }

	public float TargetAcceleration { get; set; }

	public float RawTruckAcceleration { get; set; }

	public float TruckAcceleration { get; set; }

	public float TruckSpeed { get; set; }

	public double TruckX { get; set; }

	public double TruckZ { get; set; }

	public float DragFeedforward { get; set; }

	public float PitchFeedforward { get; set; }

	public float TotalForce { get; set; }

	public float PIDOutput { get; set; }

	public float PedalOutput { get; set; }

	public IEnumerable<object> Constraints { get; set; } = new List<object>();
}
