using System.Diagnostics;

namespace ETS2LA.Game.Output;

// Check https://github.com/ETS2LA/scs-sdk-controller
// for more information about how the SDK works.
public class ControlVariables
{
    public float? j_left;
    public float? j_right;
    public float? j_up;
    public float? j_down;
    public bool? selectfcs;
    public bool? back;
    public bool? skip;
    public bool? scrol_up;
    public bool? scrol_dwn;
    public bool? mapzoom_in;
    public bool? mapzoom_out;
    public bool? trs_zoom_in;
    public bool? trs_zoom_out;
    public bool? joy_nav_prv;
    public bool? joy_nav_nxt;
    public bool? joy_sec_prv;
    public bool? joy_sec_nxt;
    public float? scroll_j_x;
    public float? scroll_j_y;
    public bool? shortcut_1;
    public bool? shortcut_2;
    public bool? shortcut_3;
    public bool? shortcut_4;
    public bool? pause;
    public bool? screenshot;
    public bool? cam1;
    public bool? cam2;
    public bool? cam3;
    public bool? cam4;
    public bool? cam5;
    public bool? cam6;
    public bool? cam7;
    public bool? cam8;
    public bool? camcycle;
    public bool? camreset;
    public bool? camrotate;
    public bool? camzoomin;
    public bool? camzoomout;
    public bool? camzoom;
    public bool? camfwd;
    public bool? camback;
    public bool? camleft;
    public bool? camright;
    public bool? camup;
    public bool? camdown;
    public bool? lookleft;
    public bool? lookright;
    public bool? camlr;
    public bool? camud;
    public float? j_cam_lk_lr;
    public float? j_cam_lk_ud;
    public float? j_cam_mv_lr;
    public float? j_cam_mv_ud;
    public float? j_trzoom_in;
    public float? j_trzoom_out;
    public float? j_mappan_x;
    public float? j_mappan_y;
    public float? j_mapzom_in;
    public float? j_mapzom_out;
    public bool? lookpos1;
    public bool? lookpos2;
    public bool? lookpos3;
    public bool? lookpos4;
    public bool? lookpos5;
    public bool? lookpos6;
    public bool? lookpos7;
    public bool? lookpos8;
    public bool? lookpos9;
    public bool? looksteer;
    public bool? lookblink;
    public float? steering;
    public float? aforward;
    public float? abackward;
    public float? clutch;
    public bool? activate;
    public bool? menu;
    public bool? ignitionoff;
    public bool? ignitionon;
    public bool? ignitionstrt;
    public bool? attach;
    public bool? frontsuspup;
    public bool? frontsuspdwn;
    public bool? rearsuspup;
    public bool? rearsuspdwn;
    public bool? suspreset;
    public bool? horn;
    public bool? airhorn;
    public bool? lighthorn;
    public bool? beacon;
    public bool? motorbrake;
    public bool? engbraketog;
    public bool? engbrakeup;
    public bool? engbrakedwn;
    public bool? trailerbrake;
    public bool? retarderup;
    public bool? retarderdown;
    public bool? retarder0;
    public bool? retarder1;
    public bool? retarder2;
    public bool? retarder3;
    public bool? retarder4;
    public bool? retarder5;
    public bool? liftaxle;
    public bool? liftaxlet;
    public bool? slideaxlefwd;
    public bool? slideaxlebwd;
    public bool? slideaxleman;
    public bool? diflock;
    public bool? rwinopen;
    public bool? rwinclose;
    public bool? lwinopen;
    public bool? lwinclose;
    public bool? engbrakeauto;
    public bool? retarderauto;
    public bool? embrake;
    public bool? laneassmode;
    public bool? tranpwrmode;
    public bool? parkingbrake;
    public bool? wipers;
    public bool? wipersback;
    public bool? wipers0;
    public bool? wipers1;
    public bool? wipers2;
    public bool? wipers3;
    public bool? wipers4;
    public bool? cruiectrl;
    public bool? cruiectrlinc;
    public bool? cruiectrldec;
    public bool? cruiectrlres;
    public bool? accmode;
    public bool? laneassist;
    public bool? light;
    public bool? lightoff;
    public bool? lightpark;
    public bool? lighton;
    public bool? hblight;
    public bool? lblinker;
    public bool? lblinkerh;
    public bool? rblinker;
    public bool? rblinkerh;
    public bool? flasher4way;
    public bool? showmirrors;
    public bool? showhud;
    public bool? navmap;
    public bool? photo_mode;
    public bool? quicksave;
    public bool? quickload;
    public bool? radio;
    public bool? radionext;
    public bool? radioprev;
    public bool? radioup;
    public bool? radiodown;
    public bool? display;
    public bool? quickpark;
    public bool? dashmapzoom;
    public bool? tripreset;
    public bool? sb_activate;
    public bool? sb_swap;
    public bool? infotainment;
    public bool? photores;
    public bool? photomove;
    public bool? phototake;
    public bool? photofwd;
    public bool? photobwd;
    public bool? photoleft;
    public bool? photoright;
    public bool? photoup;
    public bool? photodown;
    public bool? photorolll;
    public bool? photorollr;
    public bool? photosman;
    public bool? photo_opts;
    public bool? photosnap;
    public bool? photo_hctrl;
    public bool? photonames;
    public bool? photozoomout;
    public bool? photozoomin;
    public float? phot_z_j_out;
    public float? phot_z_j_in;
    public bool? album_pgup;
    public bool? album_pgdn;
    public bool? album_itup;
    public bool? album_itdn;
    public bool? album_itlf;
    public bool? album_itrg;
    public bool? album_ithm;
    public bool? album_iten;
    public bool? album_itac;
    public bool? album_itop;
    public bool? album_itdl;
    public bool? camwalk_for;
    public bool? camwalk_back;
    public bool? camwalk_righ;
    public bool? camwalk_left;
    public bool? camwalk_run;
    public bool? camwalk_jump;
    public bool? camwalk_crou;
    public bool? camwalk_lr;
    public bool? camwalk_ud;
    public bool? gearup;
    public bool? geardown;
    public bool? gear0;
    public bool? geardrive;
    public bool? gearreverse;
    public bool? gearuphint;
    public bool? geardownhint;
    public bool? transemi;
    public bool? drive;
    public bool? reverse;
    public bool? cmirrorsel;
    public bool? fmirrorsel;
    public bool? mirroryawl;
    public bool? mirroryawr;
    public bool? mirrorpitu;
    public bool? mirrorpitl;
    public bool? mirrorreset;
    public bool? quicksel1;
    public bool? quicksel2;
    public bool? quicksel3;
    public bool? quicksel4;
    public bool? quicksel5;
    public bool? quicksel6;
    public bool? quicksel7;
    public bool? quicksel8;
    public bool? mpptt;
    public bool? replayhidec;
    public bool? gearsel1on;
    public bool? gearsel1off;
    public bool? gearsel1tgl;
    public bool? gearsel2on;
    public bool? gearsel2off;
    public bool? gearsel2tgl;
    public bool? gear1;
    public bool? gear2;
    public bool? gear3;
    public bool? gear4;
    public bool? gear5;
    public bool? gear6;
    public bool? gear7;
    public bool? gear8;
    public bool? gear9;
    public bool? gear10;
    public bool? gear11;
    public bool? gear12;
    public bool? gear13;
    public bool? gear14;
    public bool? gear15;
    public bool? gear16;
    public bool? adjuster;
    public bool? advpage0;
    public bool? advpage1;
    public bool? advpage2;
    public bool? advpage3;
    public bool? advpage4;
    public bool? advpagen;
    public bool? advpagep;
    public bool? advmouse;
    public bool? advetamode;
    public bool? gar_man;
    public bool? advzoomin;
    public bool? advzoomout;
    public bool? assistact1;
    public bool? assistact2;
    public bool? assistact3;
    public bool? assistact4;
    public bool? assistact5;
    public bool? adj_seats;
    public bool? adj_mirrors;
    public bool? adj_lights;
    public bool? adj_uimirror;
    public bool? chat_act;
    public bool? quick_chat;
    public bool? cycl_zoom;
    public bool? name_tags;
    public bool? headreset;
    public bool? menustereo;
}

public class ControlChannelDefinition
{
    public required string Id;
    /// <summary>
    ///  This timeout controls the time after ETS2LA will throw out this channel
    ///  when calculating float weights. Please adjust the timeout to make it long enough
    ///  for the plugin to send new values. <br/>
    ///  **Note that you can clear a channel by sending an empty ControlVariables event.**
    /// </summary>
    public float Timeout = 0.2f;
}

public enum ControlBooleanType
{
    Direct,
    TrueToToggle,
}

public class ControlProperties
{
    /// <summary>
    ///  By default ETS2LA will directly write the boolean values to memory.
    ///  However many controls in ETS2 require a toggle, meaning it turns on and then off.
    ///  ETS2LA can do this automatically, and setting this to TrueToToggle will make it so that
    ///  all True booleans will be toggled on, and then toggle off after a short delay, 
    ///  simulating a button press rather than a button hold.
    /// </summary>
    public ControlBooleanType BooleanType = ControlBooleanType.Direct;

    /// <summary>
    ///  ETS2LA will average all incoming event values from each plugin.
    ///  This weight value can be used to make some plugins more influential than others,
    ///  for example an AEB plugin needs to be able to override the brake input from another plugin.
    /// </summary>
    public float Weight = 1.0f;
}

public class ControlEvent
{
    public required ControlChannelDefinition ChannelDefinition;
    public ControlProperties Properties = new ControlProperties();
    public ControlVariables Variables = new ControlVariables();
}

/// <summary>
///  **Internal class do not use.**
/// </summary>
public class ControlChannel
{
    /// <summary>
    ///  **Internal class do not use.**
    /// </summary>
    public required ControlChannelDefinition Definition;

    /// <summary>
    ///  **Internal class do not use.**
    /// </summary>
    public required ControlProperties Properties;
    
    /// <summary>
    ///  **Internal class do not use.**
    /// </summary>
    public required ControlVariables Variables;
    
    /// <summary>
    ///  **Internal class do not use.**
    /// </summary>
    public Stopwatch LastUpdate = Stopwatch.StartNew();
    
    /// <summary>  
    ///  **Internal class do not use.**
    /// </summary>
    public bool BoolsProcessed = false;
}