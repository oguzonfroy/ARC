namespace ETS2LA.UI;

/// <summary>
///  ARC: ilk açılıştaki tanıtım ve "Nasıl Kurulur" sayfası aynı adımları kullanır.
///  Yol: adımın düğmesinin açtığı sayfa (null ise düğme yok).
/// </summary>
public static class ArcRehber
{
    public record Adim(string Baslik, string Aciklama, string[] Maddeler, string? Yol, string? Dugme);

    public static readonly Adim[] Adimlar =
    {
        new("Hoş geldin!",
            "ETS2 Auto Drive tırını senin yerine sürer: şeridi takip eder, hızı ayarlar ve rotana göre döner. " +
            "Başlamadan önce birkaç şeyi bir kez kurman gerekiyor, 2 dakikanı alır.",
            new[] { "Bu tanıtımı istediğin an \"Atla\" ile geçebilirsin.",
                    "Adımları sonra yan menüdeki \"Nasıl Kurulur\" sayfasında da bulursun." },
            null, null),
        new("1. Oyun eklentisini kur",
            "Program oyunla bu eklenti sayesinde konuşur. Oyun kapalıyken bir kez kurman yeterli.",
            new[] { "Oyunu (ETS2 / ATS) kapat.",
                    "Ayarlar → Oyun SDK'sı sayfasını aç.",
                    "Oyununun yanındaki \"SDK'ları Kur\" düğmesine bas.",
                    "Oyun güncellenirse bu adımı tekrarla." },
            "/settings/sdk", "Oyun SDK'sını aç"),
        new("2. Sürüş eklentilerini indir",
            "Direksiyonu ve hızı yöneten parçalar ayrı eklentidir, Katalog'dan indirilir.",
            new[] { "Yan menüden Katalog'u aç.",
                    "Şu üçünü bul ve \"Kur\" de: Şerit Takibi, Adaptif Hız Sabitleyici, Rota Bulma.",
                    "Kurulum bitince üstte çıkan \"Şimdi Yeniden Başlat\" düğmesine bas." },
            "/plugins/catalogue", "Katalog'u aç"),
        new("3. Eklentileri aç",
            "İndirilen eklentiler kendiliğinden çalışmaz, bir kez açman gerekir.",
            new[] { "Yan menüden Yönetici'yi aç.",
                    "Şerit Takibi, Adaptif Hız Sabitleyici ve Rota Bulma'da \"Etkinleştir\"e bas.",
                    "Yanlarında \"Açık\" yazmalı." },
            "/plugins/manager", "Yönetici'yi aç"),
        new("4. Yola çık",
            "Her şey hazır. Oyunda sürüşü şöyle başlatırsın:",
            new[] { "Oyunu aç, haritadan (M) gideceğin yere rota ver.",
                    "Tırı bir şeridin ortasına al.",
                    "Gösterge Paneli'nden sürüş modunu seç ve \"Sürüşü başlat\"a bas (ya da oyunda ↓).",
                    "Durdurmak için ← tuşu. Insert ile bu pencereyi oyunun içinde gösterip gizlersin." },
            "/", "Gösterge Paneli'ne git"),
    };
}
