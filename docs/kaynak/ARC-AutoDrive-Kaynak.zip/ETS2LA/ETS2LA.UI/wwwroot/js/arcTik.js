// ARC: menüde düğmeye basınca kısa, yumuşak bir tık sesi (dosya yok, WebAudio ile üretilir).
// Ayarlar > Ses > "Menü tıklama sesi" ile açılıp kapanır (C# tarafı arcTikSesiAyarla'yı çağırır).
(function () {
    let acik = true;
    let ses = null;

    window.arcTikSesiAyarla = function (deger) { acik = !!deger; };

    function tik() {
        try {
            ses = ses || new (window.AudioContext || window.webkitAudioContext)();
            const t = ses.currentTime;
            const osc = ses.createOscillator();
            const kazanc = ses.createGain();
            osc.type = "sine";
            osc.frequency.setValueAtTime(1400, t);
            osc.frequency.exponentialRampToValueAtTime(700, t + 0.04);
            kazanc.gain.setValueAtTime(0.0001, t);
            kazanc.gain.exponentialRampToValueAtTime(0.05, t + 0.004);   // kısık: rahatsız etmesin
            kazanc.gain.exponentialRampToValueAtTime(0.0001, t + 0.06);
            osc.connect(kazanc).connect(ses.destination);
            osc.start(t);
            osc.stop(t + 0.07);
        } catch (_) { }
    }

    document.addEventListener("pointerdown", function (e) {
        if (!acik || e.button !== 0) return;
        if (e.target.closest("button, a, [role=button], .arc-menu, .cursor-pointer, input[type=checkbox]")) tik();
    }, true);
})();
