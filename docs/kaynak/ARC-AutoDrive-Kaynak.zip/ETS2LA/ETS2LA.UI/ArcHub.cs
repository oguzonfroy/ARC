using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using ETS2LA.Controls;
using ETS2LA.State;

namespace ETS2LA.UI;

/// <summary>
///  ARC Studio bağlantısı: program yalnız ARC Hub'dan (lisans doğrulandıktan sonra) açılır,
///  "Oyun Değiştir" ile Hub'a döner ve menü tuşuyla pencere gizlenip gösterilir.
/// </summary>
public static class ArcHub
{
    // ARC her açılışta yeni bir oturum anahtarı yazar ve aynısını ortam değişkeniyle verir
    static readonly string OturumDosyasi = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ARC Studio", "ets2_oturum.key");

    /// <summary>ARC Hub'ı yeniden açan komut (exe ve argümanlar); ARC'tan açılmadıysa null.</summary>
    public static string[]? HubKomutu { get; } = KomutuOku();

    static string[]? KomutuOku()
    {
        try { return JsonSerializer.Deserialize<string[]>(Environment.GetEnvironmentVariable("ARC_HUB_KOMUTU") ?? ""); }
        catch { return null; }
    }

    static readonly string[] LauncherAdlari = { "TruckersMP-Launcher.exe", "Launcher.exe" };

    /// <summary>TruckersMP launcher'ının yolu: önce elle seçilen, sonra varsayılan klasör, Windows kaydı ve Program Files.</summary>
    public static string? TruckersMpBul()
    {
        var klasorler = new List<string>
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TruckersMP")
        };
#if WINDOWS
        // Başka klasöre kurulduysa konumu Windows'un "Uygulamalar" kaydından okunur
        foreach (var kok in new[] { Microsoft.Win32.Registry.CurrentUser, Microsoft.Win32.Registry.LocalMachine })
        foreach (var yol in new[] { @"Software\Microsoft\Windows\CurrentVersion\Uninstall", @"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall" })
        {
            using var liste = kok.OpenSubKey(yol);
            foreach (var ad in liste?.GetSubKeyNames() ?? Array.Empty<string>())
            {
                using var kayit = liste!.OpenSubKey(ad);
                if ((kayit?.GetValue("DisplayName") as string)?.Contains("TruckersMP", StringComparison.OrdinalIgnoreCase) == true
                    && kayit.GetValue("InstallLocation") is string konum && konum.Length > 0)
                    klasorler.Add(konum);
            }
        }
#endif
        foreach (var ozel in new[] { Environment.SpecialFolder.ProgramFiles, Environment.SpecialFolder.ProgramFilesX86 })
            klasorler.Add(Path.Combine(Environment.GetFolderPath(ozel), "TruckersMP Launcher"));

        var secilen = WindowSettings.Current.TruckersMPPath;
        if (File.Exists(secilen)) return secilen;
        return klasorler
            .SelectMany(k => LauncherAdlari.Select(a => Path.Combine(k, a)))
            .FirstOrDefault(File.Exists);
    }

    public static bool HubdanAcildi()
    {
        var anahtar = Environment.GetEnvironmentVariable("ARC_OTURUM");
        try { return !string.IsNullOrEmpty(anahtar) && File.ReadAllText(OturumDosyasi).Trim() == anahtar; }
        catch { return false; }
    }

    public static void OyunDegistir()
    {
        if (HubKomutu is not { Length: > 0 }) return;
        var bilgi = new ProcessStartInfo(HubKomutu[0]) { UseShellExecute = false };
        foreach (var arguman in HubKomutu.Skip(1)) bilgi.ArgumentList.Add(arguman);
        bilgi.ArgumentList.Add("--hub");
        Process.Start(bilgi);
        var pencere = UserInterface.Current.Window;
        pencere?.Invoke(() => pencere.Close());
    }

    const string LisansAdresi = "https://vzibpccxwknhakzgmxfy.supabase.co/rest/v1/rpc/license_expiry";
    const string LisansApiAnahtari = "<ANAHTAR>";
    const int LisansKontrolMs = 5 * 60 * 1000;

    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int MessageBoxW(IntPtr hWnd, string text, string caption, uint type);

    public static void LisansIzlemeyiBaslat()
    {
        var key = Environment.GetEnvironmentVariable("ARC_LISANS");
        var cihaz = Environment.GetEnvironmentVariable("ARC_CIHAZ");
        if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(cihaz)) return;
        Task.Factory.StartNew(() => LisansIzle(key, cihaz), TaskCreationOptions.LongRunning);
    }

    /// <summary>Süre dolunca programı kapatır. İnternet yoksa çalışmaya devam eder: bitiş önceden öğrenildiyse
    /// sayaç (saat ayarından etkilenmez) yine tam vaktinde kapatır.</summary>
    static void LisansIzle(string key, string cihaz)
    {
        using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
        var govde = JsonSerializer.Serialize(new { p_key = key, p_hwid = cihaz });
        long? sonTarih = null;
        long sonrakiKontrol = 0;
        while (sonTarih is null || Environment.TickCount64 < sonTarih)
        {
            if (Environment.TickCount64 >= sonrakiKontrol)
            {
                sonrakiKontrol = Environment.TickCount64 + LisansKontrolMs;
                try
                {
                    using var istek = new HttpRequestMessage(HttpMethod.Post, LisansAdresi)
                    {
                        Content = new StringContent(govde, Encoding.UTF8, "application/json")
                    };
                    istek.Headers.Add("apikey", LisansApiAnahtari);
                    using var yanit = http.Send(istek);
                    yanit.EnsureSuccessStatusCode();
                    using var akis = yanit.Content.ReadAsStream();
                    var bitis = JsonSerializer.Deserialize<DateTimeOffset?>(akis);
                    sonTarih = bitis is null ? null
                        : Environment.TickCount64 + (long)(bitis.Value - (yanit.Headers.Date ?? DateTimeOffset.UtcNow)).TotalMilliseconds;
                }
                catch (Exception e) when (e is HttpRequestException or TaskCanceledException or JsonException) { }
            }
            Thread.Sleep(1000);
        }

        // Kamyon sürücüsüz kalmasın: otonom hemen bırakılır, kapanmadan önce oyuncu uyarılır
        ApplicationState.Current.SetAssistsEnabled(false);
        new Thread(() => MessageBoxW(IntPtr.Zero, "Lisans süren doldu, otonom sürüş kapatıldı ve program kapanıyor.\n\nYenilemek için Discord'dan bize yaz.",
                                     "ARC ETS2 Auto Drive", 0x30 | 0x40000)) { IsBackground = true }.Start(); // MB_ICONWARNING | MB_TOPMOST
        Thread.Sleep(6000);
        var pencere = UserInterface.Current.Window;
        try { pencere?.Invoke(() => pencere.Close()); } catch { }
        Thread.Sleep(8000); // pencere kapatılamadıysa
        Environment.Exit(0);
    }

    public static ControlDefinition Menu { get; } = new ControlDefinition
    {
        Id = "ARC.Menu",
        Name = "ARC Menü",
        Description = "Oyun içindeyken ETS2 Auto Drive penceresini gösterir ve gizler.",
        DefaultKeybind = "Insert",
        Type = ControlType.Boolean
    };

    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hWnd);

    public static void MenuTusunuBagla()
    {
        ControlsBackend.Current.RegisterControl(Menu);
        ControlsBackend.Current.On(Menu.Id, (_, e) =>
        {
            if (!(bool)e.NewValue) return; // yalnız basışta
            var pencere = UserInterface.Current.Window;
            pencere?.Invoke(() =>
            {
                // Windows arka plandaki programın öne geçmesini engellediği için gösterirken pencere oyunun
                // üstünde tutulur; gizlerken kullanıcının "üstte tut" ayarına dönülür
                if (pencere.Minimized)
                {
                    pencere.SetMinimized(false);
                    pencere.SetTopMost(true);
                    SetForegroundWindow(pencere.WindowHandle);
                }
                else
                {
                    pencere.SetTopMost(WindowSettings.Current.StayOnTop);
                    pencere.SetMinimized(true);
                }
            });
        });
    }
}
