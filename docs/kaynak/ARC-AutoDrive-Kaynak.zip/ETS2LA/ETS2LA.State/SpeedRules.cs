namespace ETS2LA.State;

/// <summary>Hedef hız kuralları; oyunsuz denenebilsin diye ayrı durur. Hızlar m/s.</summary>
public static class SpeedRules
{
    /// <summary>Üst hız kapalıyken sınırsız yolda hedef: 250 km/s, yani tırın çıkabildiği en yüksek hız.</summary>
    public const float Unlimited = 250f / 3.6f;

    /// <summary>Bunun altındaki hızlarda (park alanı, tesis) sınırsız yol hızına geçilmez: yaklaşık 40 km/s.</summary>
    public const float MinCruiseSpeed = 11f;

    /// <summary>Kullanıcının üst hızını uygular; 0 üst hız yok demektir.</summary>
    public static float Cap(float desired, float maximum) => maximum > 0f && desired > maximum ? maximum : desired;

    /// <summary>Sınırsız yolda hedef hız: çubuktaki değer, o 0 ise Maksimum Hız, o da kapalıysa sınırsız.</summary>
    public static float NoLimitTarget(float setting, float maximum) => setting > 0f ? Cap(setting, maximum) : maximum > 0f ? maximum : Unlimited;

    /// <summary>Sürüş açılırken hedef hız. Sınırsız hız kartı açıksa hemen sınırsız hedef; kart kapalı ama yolda sınır yoksa
    /// seyir halindeyken sınırsız hedef, değilse tırın hızı kullanılır.</summary>
    public static float Engage(float limitWithOffsets, float truckSpeed, float fallback, float noLimitTarget = 0f, bool unlimitedCard = false)
    {
        if (limitWithOffsets > 0f) return limitWithOffsets;
        if (noLimitTarget > 0f && (unlimitedCard || truckSpeed >= MinCruiseSpeed)) return noLimitTarget;
        return MathF.Max(truckSpeed, fallback);
    }

    /// <summary>
    ///  Sınırsız hedefe ne zaman geçilir. Kart açıkken (oyuncu sınırsızı seçti) hemen: eskiden burada da tırın 40 km/s'yi
    ///  geçmesi bekleniyordu, hedef 36 km/s'de kaldığında tır hiç 40'a çıkamadığı için sınırsız hiç devreye girmiyordu.
    ///  Kart kapalıyken yalnız sınırı olmayan yolda: oyun sınırı bir anlık 0 gösterebildiği için 3 sn, park alanı gibi yavaş
    ///  yerlerde geçilmesin diye de seyir hızı beklenir.
    /// </summary>
    public static bool NoLimitReady(bool unlimitedCard, long sinceMs, float truckSpeed) =>
        unlimitedCard || (sinceMs >= 3000 && truckSpeed >= MinCruiseSpeed);

    /// <summary>Sollanırken geçici olarak hedef hızı düşürür; 0 geçici sınır yok demektir.</summary>
    public static float Yield(float desired, float yieldCap) => yieldCap > 0f && yieldCap < desired ? yieldCap : desired;
}
