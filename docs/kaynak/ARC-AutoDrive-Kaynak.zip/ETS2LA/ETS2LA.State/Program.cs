﻿using ETS2LA.Controls;
using ETS2LA.Controls.Defaults;
using ETS2LA.Backend.Events;
using ETS2LA.Game.Telemetry;
using ETS2LA.Settings.Global;
using ETS2LA.Game;
using ETS2LA.Game.Data;
using ETS2LA.Game.SiiFiles;
using ETS2LA.Game.PpdFiles;
using ETS2LA.Logging;
using ETS2LA.Notifications;
using static ETS2LA.Translations.T;
using ETS2LA.Game.PmdFiles;
using ETS2LA.Audio;

using System.Collections.Generic;

namespace ETS2LA.State;

public enum DrivingMode
{
    AdaptiveCruiseControlOnly,
    FullSelfDriving,
    LaneAssistOnly
}

/// <summary>
///  This state contains the most important ETS2LA variables. Most plugins
///  will use it to follow the user's preferences and read the game data.
/// </summary>
public class ApplicationState
{
    private static readonly Lazy<ApplicationState> _instance = new(() => new ApplicationState());
    public static ApplicationState Current => _instance.Value;
    private volatile bool shutdown = false;

    public ApplicationState()
    {

        Events.Current.Subscribe<GameTelemetryData>(GameTelemetry.Current.EventString, HandleTelemetryUpdate);
        Events.Current.Subscribe<float>("TelemetryEvents.SpeedLimitChanged", HandleSpeedLimitChanged);

        ControlsBackend.Current.On(DefaultControls.Cancel.Id, HandleCancel);
        ControlsBackend.Current.On(DefaultControls.Increase.Id, HandleIncrease);
        ControlsBackend.Current.On(DefaultControls.Decrease.Id, HandleDecrease);

        assistanceSettings = AssistanceSettings.Current;

        StateSettingsHandler.Current.OnSettingsChanged += HandleSettingsChanged;
        HandleSettingsChanged(StateSettingsHandler.Current.GetSettings());
    }

    private void HandleSettingsChanged(StateSettings newStateSettings)
    {
        stateSettings = newStateSettings;
        DisplayUnits = newStateSettings.DisplayUnits;
    }

    private void HandleTelemetryUpdate(GameTelemetryData data)
    {
        latestTelemetryData = data;
        // ARC: üst hız her durumda geçerli: sürüşü açarken ya da ayar sürüş sırasında değişince de
        ApplyNoLimitSpeed(data.truckFloat.speedLimit, data.truckFloat.speed);
        _desiredSpeed = SpeedRules.Cap(_desiredSpeed, AssistanceSettings.Current.MaximumSpeed);
        if (data.sdkActive)
        {
            IsGameRunning = true;
            RunningGameType = data.scsValues.game == "ETS2" ? GameType.EuroTruckSimulator2
                                                            : GameType.AmericanTruckSimulator;
            RunningGameVersion = data.scsValues.versionMajor.ToString() + "."
                               + data.scsValues.versionMinor.ToString();

            if (RunningGame != null && RunningGame.Type != RunningGameType)
            {
                Logger.Info(_("Detected a switch to {0}, waiting for its game data to be parsed.", RunningGameType));
                Installation oldGame = RunningGame;
                RunningGame = null;
                // Unload in the background so the forced GC doesn't
                // stall the telemetry thread.
                Task.Run(oldGame.ClearParsedData);
            }

            if (RunningGame == null && (parsingTask == null || parsingTask.IsCompleted))
                // This function will run until game data is successfully parsed.
                parsingTask = WaitForParseSuccessful();
        }
        else
        {
            IsGameRunning = false;
        }
    }

    public void Shutdown()
    {
        shutdown = true;
    }
    


    // MARK: Self-Driving Related
    // NOTE: This class is organized by *category* and not variable/function type.
    //       This makes the most sense to avoid having lots of variables back to back
    //       far from the relevant functions. It is slightly unconventional though.
    //       Follow the marks :+1:



    /// <summary>
    ///  Defines the level of driving assistance the user wants.
    /// </summary>
    public DrivingMode DrivingMode { get; set; } = DrivingMode.FullSelfDriving;
    public Dictionary<DrivingMode, string> DrivingModeTranslation = new Dictionary<DrivingMode, string>
    {
        { DrivingMode.AdaptiveCruiseControlOnly, _("Adaptive Cruise Control Only") },
        { DrivingMode.FullSelfDriving, _("Full Self-Driving") },
        { DrivingMode.LaneAssistOnly, _("Lane Assist Only") }
    };

    /// <summary>
    ///  This value will determine whether assists are enabled or not.
    /// </summary>
    public bool EnableAssists { get; set; } = false;

    /// <summary>
    ///  This value will be used by the longitudinal assist to determine the target speed. This value does
    ///  not take into account any environmental factors. That will either be provided by plugins, or the
    ///  user will have to take care of it themselves. <br/><br/>
    ///  **This value is in scientific units, that is m/s.**
    /// </summary>
    public float DesiredSpeed
    {
        get => Environment.TickCount64 < Interlocked.Read(ref _yieldUntil) ? SpeedRules.Yield(_desiredSpeed, _yieldCap) : _desiredSpeed;
        set => _desiredSpeed = value;
    }

    private float _desiredSpeed = 0.0f;
    private float _yieldCap = 0f;
    private long _yieldUntil = 0;
    private float _appliedNoLimitSpeed = 0f;
    private long _noLimitSince = 0;

    /// <summary>
    ///  ARC: sollanırken hedef hızı kısa süreliğine düşürür. Çağrı kesilince yarım saniyede kendiliğinden biter.
    /// </summary>
    public void YieldSpeed(float cap)
    {
        _yieldCap = cap;
        Interlocked.Exchange(ref _yieldUntil, Environment.TickCount64 + 500);
    }

    /// <summary>
    ///  This value will determine the currently used units for any values shown in the UI. This value
    ///  is automatically changed by ETS2LA, either when the user sets it in the settings, or when we
    ///  detect a change in the game's units. This unit should determine the units used everywhere, e.g.
    ///  the units used when increasing and decreasing the target speed. (+-1 mph/kph/ms) <br/><br/>
    ///  **Use UnitConversions.FromScientificUnits and UnitConversions.ToScientificUnits to convert values to and from the current display units.**
    /// </summary>
    public Units DisplayUnits { get; set; } = Units.Metric;
    public Dictionary<Units, string> DisplayUnitsTranslation = new Dictionary<Units, string>
    {
        { Units.Metric, _("Metric") },
        { Units.Imperial, _("Imperial") },
        { Units.Scientific, _("Scientific") }
    };

    // Internal value to keep track of the latest telemetry we received.
    private GameTelemetryData latestTelemetryData = new();
    private AssistanceSettings assistanceSettings;
    private StateSettings stateSettings;
    private float lastSpeedLimit = 0f;

    // The functions below are for handling control events.
    // If determining what they do is hard via code, then take a look at the 
    // example at https://docs.ets2la.com/docs/Rewrite/UserInput#how-to-listen-to-registered-controls

    private void RoundToNearestUnit()
    {
        switch (DisplayUnits)
        {
            case Units.Metric:
                _desiredSpeed = (float)(Math.Round(_desiredSpeed * 3.6) / 3.6); // Round to nearest km/h
                break;
            case Units.Imperial:
                _desiredSpeed = (float)(Math.Round(_desiredSpeed * 2.237) / 2.237); // Round to nearest mph
                break;
            case Units.Scientific:
                _desiredSpeed = (float)Math.Round(_desiredSpeed); // Round to nearest m/s
                break;
        }
    }

    private void ApplyLimits()
    {
        float maxSpeed = AssistanceSettings.Current.MaximumSpeed;
        if (_desiredSpeed > maxSpeed && maxSpeed > 0)
        {
            _desiredSpeed = maxSpeed;
            AudioHandler.Current.Play(DefaultAudio.Refuse, 1, overrideCurrent: true);
        }
        else if (_desiredSpeed < 0)
        {
            _desiredSpeed = 0;
            AudioHandler.Current.Play(DefaultAudio.Refuse, 1, overrideCurrent: true);
        }
    }

    private float SnapTo10s(float increase)
    {
        if (!stateSettings.SnapTo10s)
            return _desiredSpeed + increase;

        float currentSpeedInDisplayUnits = UnitConversions.FromScientificUnits(UnitType.Speed, _desiredSpeed, DisplayUnits);
        float newSpeedInDisplayUnits = currentSpeedInDisplayUnits + UnitConversions.FromScientificUnits(UnitType.Speed, increase, DisplayUnits);
        // When increasing by 2 from 37 we go:
        // 37 -> 39 -> 40 -> 42 -> 44
        float currentSpeed10s = (float)(Math.Floor((currentSpeedInDisplayUnits + 0.1f) / 10) * 10);
        float newSpeed10s = (float)(Math.Floor((newSpeedInDisplayUnits + 0.1f) / 10) * 10);
        
        if (currentSpeed10s != newSpeed10s && newSpeed10s > currentSpeed10s)
        {
            return UnitConversions.ToScientificUnits(UnitType.Speed, newSpeed10s, DisplayUnits);
        }
        else
        {
            return _desiredSpeed + increase;
        }
    }

    private float ApplyOffsets(float speedlimit)
    {
        speedlimit += speedlimit * stateSettings.DesiredSpeedPercentageOffset / 100;
        speedlimit += stateSettings.DesiredSpeedStaticOffset;
        return speedlimit;
    }

    private float NoLimitTarget() => SpeedRules.NoLimitTarget(StateSettingsHandler.Current.GetSettings().NoLimitSpeed, AssistanceSettings.Current.MaximumSpeed);

    private float EngageSpeed()
    {
        bool card = !AssistanceSettings.Current.EnabledTrafficRules.Contains(TrafficRule.Speedlimits);
        float limit = card ? 0f : latestTelemetryData.truckFloat.speedLimit;
        return SpeedRules.Engage(limit > 0 ? ApplyOffsets(limit) : 0f, latestTelemetryData.truckFloat.speed, stateSettings.FallbackSpeed, NoLimitTarget(), card);
    }

    // ARC: sınırsız yolda limit kalkar, hedef çubuktaki hıza ya da azami hıza çıkar. Oyun sınırı bir anlık 0 gösterebildiği için
    // 3 sn beklenir; park alanı gibi yavaş yerlerde uygulanmaz. Ayar değişince yenilenir, tuşla yapılan ince ayarı ezmez.
    private void ApplyNoLimitSpeed(float speedLimit, float truckSpeed)
    {
        // Sınırsız hız kartı açıksa (hız sınırı kuralı kapalı) her yol sınırsız sayılır.
        bool card = !AssistanceSettings.Current.EnabledTrafficRules.Contains(TrafficRule.Speedlimits);
        bool applies = _desiredSpeed > 0 && (speedLimit <= 0 || card);
        if (!applies)
        {
            _noLimitSince = 0;
            _appliedNoLimitSpeed = 0f;
            return;
        }
        long now = Environment.TickCount64;
        if (_noLimitSince == 0)
            _noLimitSince = now;

        float target = NoLimitTarget();
        if (_appliedNoLimitSpeed == target || !SpeedRules.NoLimitReady(card, now - _noLimitSince, truckSpeed))
            return;

        _appliedNoLimitSpeed = target;
        lastSpeedLimit = target;
        _desiredSpeed = target;
    }

    private void HandleSpeedLimitChanged(float newSpeedLimit)
    {
        if (!AssistanceSettings.Current.EnabledTrafficRules.Contains(TrafficRule.Speedlimits))
            return;
        
        if (_desiredSpeed == 0)
            return;

        // ARC: sınır yoksa (0) seçili hız korunur; eskiden 30 km/s'ye düşüyordu
        if (newSpeedLimit <= 0)
            return;

        newSpeedLimit = ApplyOffsets(newSpeedLimit);

        float offset = 0;
        if (lastSpeedLimit != 0)
            offset = _desiredSpeed - lastSpeedLimit;

        // ARC: üst hız kapalıyken (0) de oyuncunun tabelaya eklediği fark korunur, yoksa seçtiği hız her tabelada silinir
        float maxSpeed = AssistanceSettings.Current.MaximumSpeed;
        bool wasBelowLimit = maxSpeed <= 1 || lastSpeedLimit < maxSpeed;
        lastSpeedLimit = newSpeedLimit;
        _desiredSpeed = newSpeedLimit + (wasBelowLimit ? offset : 0);
        RoundToNearestUnit();
        ApplyLimits();

        NotificationHandler.Current.SendNotification(new Notification
        {
            Id = "ApplicationState.SpeedLimitChanged",
            Title = _("Speed limit changed"),
            Content = _("New limit {0} {1}", (int)Math.Round(UnitConversions.FromScientificUnits(UnitType.Speed, newSpeedLimit, DisplayUnits), 0), UnitConversions.GetUnitAbbreviation(UnitType.Speed, DisplayUnits))
        });
    }

    private void HandleCancel(object sender, ControlChangeEventArgs e)
    {
        bool b = (bool)e.NewValue;
        if(b == true) return; // key down event

        if (EnableAssists) 
        {
            AudioHandler.Current.Play(DefaultAudio.Disengage, 1, overrideCurrent: true);
            EnableAssists = false;
            NotificationHandler.Current.CloseNotification("ApplicationState.DesiredSpeedChanged");
            NotificationHandler.Current.SendNotification(new Notification
            {
                Id = "ApplicationState.AssistStatus",
                Title = _("Assists Disabled"),
                Content = _("All driving assists have been disabled."),
                CloseAfter = 2,
            });
        }
        else
        {
            DrivingMode += 1;
            if (DrivingMode > DrivingMode.LaneAssistOnly)
                DrivingMode = DrivingMode.AdaptiveCruiseControlOnly;
            
            NotificationHandler.Current.SendNotification(new Notification
            {
                Id = "ApplicationState.DrivingModeChanged",
                Title = DrivingModeTranslation[DrivingMode],
                Content = _("Driving mode changed, press Cancel/MODE again to cycle through the modes.")
            });

            switch (DrivingMode)
            {
                case DrivingMode.AdaptiveCruiseControlOnly:
                    AudioHandler.Current.Play(DefaultAudio.PreAlert, 1, overrideCurrent: true);
                    break;
                case DrivingMode.FullSelfDriving:
                    AudioHandler.Current.Play(DefaultAudio.SoftWarning, 1, overrideCurrent: true);
                    break;
                case DrivingMode.LaneAssistOnly:
                    AudioHandler.Current.Play(DefaultAudio.PreAlert, 1, overrideCurrent: true);
                    break;
            }
        }
    }

    CancellationTokenSource? increaseHeldToken;
    CancellationTokenSource? decreaseHeldToken;
    private void KeybindHeldLoop(CancellationToken token, float mult)
    {
        bool firstRun = true;
        while (!token.IsCancellationRequested)
        {
            switch (DisplayUnits)
            {
                case Units.Metric:
                    float increaseMetric = UnitConversions.ToScientificUnits(UnitType.Speed, stateSettings.SpeedControlStepSize, Units.Metric);
                    _desiredSpeed = SnapTo10s(increaseMetric * mult);
                    break;
                case Units.Imperial:
                    float increaseImperial = UnitConversions.ToScientificUnits(UnitType.Speed, stateSettings.SpeedControlStepSize, Units.Imperial);
                    _desiredSpeed = SnapTo10s(increaseImperial * mult);
                    break;
                case Units.Scientific:
                    _desiredSpeed += stateSettings.SpeedControlStepSize * mult;
                    break;
            }

            RoundToNearestUnit();
            ApplyLimits();

            NotificationHandler.Current.SendNotification(new Notification
            {
                Id = "ApplicationState.DesiredSpeedChanged",
                Title = Math.Round(UnitConversions.FromScientificUnits(UnitType.Speed, _desiredSpeed, DisplayUnits), 0).ToString() + " " + UnitConversions.GetUnitAbbreviation(UnitType.Speed, DisplayUnits),
                Content = _("Target speed changed. Current speedlimit: {0} {1}. Offsets are carried over on speedlimit change.", (int)Math.Round(UnitConversions.FromScientificUnits(UnitType.Speed, lastSpeedLimit, DisplayUnits), 0), UnitConversions.GetUnitAbbreviation(UnitType.Speed, DisplayUnits)),
                CloseAfter = 2,
            });

            if (firstRun)
            {
                firstRun = false;
                Thread.Sleep(500);
            }
            else
            {
                Thread.Sleep(200);
            }
        }
    }

    private void HandleIncrease(object sender, ControlChangeEventArgs e)
    {
        bool b = (bool)e.NewValue;
        if(b == true)
        {
            increaseHeldToken = new CancellationTokenSource();
            // Token burada alınır: kısa basışta görev başlamadan bırakma kaynağı kapatabilir
            var token = increaseHeldToken.Token;
            Task.Run(() => KeybindHeldLoop(token, 1.0f));
        }
        else
        {
            increaseHeldToken?.Cancel();
            increaseHeldToken?.Dispose();
            increaseHeldToken = null;
        }

        // RES
        if (!EnableAssists)
        {
            // SET if speed too low compared to current speed
            // to avoid an "AEB" like event.
            if (latestTelemetryData.truckFloat.speed > _desiredSpeed + 5 / 3.6f)
            {
                _desiredSpeed = latestTelemetryData.truckFloat.speed;
            }
            // SET if speed is 0
            if (_desiredSpeed == 0)
            {
                _desiredSpeed = EngageSpeed();
            }

            EnableAssists = true;
            AudioHandler.Current.Play(DefaultAudio.Engage, 1, overrideCurrent: true);
            NotificationHandler.Current.SendNotification(new Notification
            {
                Id = "ApplicationState.AssistStatus",
                Title = _("Assists Enabled"),
                Content = _("All driving assists have been enabled."),
                CloseAfter = 2,
            });
            return;
        }
    }

    private void HandleDecrease(object sender, ControlChangeEventArgs e)
    {
        bool b = (bool)e.NewValue;
        if(b == true)
        {
            decreaseHeldToken = new CancellationTokenSource();
            // Token burada alınır: kısa basışta görev başlamadan bırakma kaynağı kapatabilir
            var token = decreaseHeldToken.Token;
            Task.Run(() => KeybindHeldLoop(token, -1.0f));
        }
        else
        {
            decreaseHeldToken?.Cancel();
            decreaseHeldToken?.Dispose();
            decreaseHeldToken = null;
        }

        Set();
    }

    // ARC: uygulamadaki menüden sürüşü açıp kapatmak için (tuşla aynı davranış: açarken SET, kapatırken Cancel)
    public void SetAssistsEnabled(bool enabled)
    {
        if (enabled == EnableAssists) return;
        if (enabled) Set();
        else HandleCancel(this, new ControlChangeEventArgs(false, DefaultControls.Cancel));
    }

    private void Set()
    {
        // SET
        if (!EnableAssists)
        {
            if (assistanceSettings.SetSpeedBehaviourOption == SetSpeedBehaviour.CurrentSpeed)
                _desiredSpeed = latestTelemetryData.truckFloat.speed;
            else if (assistanceSettings.SetSpeedBehaviourOption == SetSpeedBehaviour.SpeedLimit)
                _desiredSpeed = EngageSpeed();

            EnableAssists = true;
            AudioHandler.Current.Play(DefaultAudio.Engage, 1, overrideCurrent: true);
            NotificationHandler.Current.SendNotification(new Notification
            {
                Id = "ApplicationState.AssistStatus",
                Title = _("Assists Enabled"),
                Content = _("All driving assists have been enabled."),
                CloseAfter = 2,
            });
            return;
        }
    }



    // MARK: Map Data Related



    public bool IsGameRunning { get; set; } = false;
    public GameType? RunningGameType { get; set; }
    public string? RunningGameVersion { get; set; }
    private Task? parsingTask;
    public Installation? RunningGame { get; set; }

    private async Task WaitForParseSuccessful()
    {
        while (!shutdown)
        {
            foreach(Installation install in GameHandler.Current.Installations)
            {
                if (RunningGame != null)
                    break;

                if(install.Type == RunningGameType)
                {
                    // ARC: harita yükleme oyunun günlük dosyasına bakıyordu. O dosya güncel değilse (TruckersMP gibi)
                    // harita hiç yüklenmiyor ve hiçbir şey çalışmıyordu. Tır dünyadaysa oyun zaten çalışıyordur.
                    var coordinate = latestTelemetryData.truckPlacement.coordinate;
                    bool forceBefore = DataSettings.Current.ForceMapLoad;
                    if (coordinate.X != 0 || coordinate.Z != 0)
                        DataSettings.Current.ForceMapLoad = true;
                    bool success = await Task.Run(() => install.Parse());
                    DataSettings.Current.ForceMapLoad = forceBefore;
                    // The user might have switched games while we were parsing,
                    // in that case throw the now stale data away.
                    if (success && install.Type == RunningGameType)
                    {
                        RunningGame = install;
                        SiiFileHandler.Current.SetFileSystem(RunningGame.GetFileSystem());
                        PpdFileHandler.Current.SetFileSystem(RunningGame.GetFileSystem());
                        PmdFileHandler.Current.SetFileSystem(RunningGame.GetFileSystem());
                    }
                    else if (success)
                        install.ClearParsedData();
                }
            }

            if (RunningGame != null && RunningGame.Type == RunningGameType)
                break;

            await Task.Delay(5000);
        }
    }
}
