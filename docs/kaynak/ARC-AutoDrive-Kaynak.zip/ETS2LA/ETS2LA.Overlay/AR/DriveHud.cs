using ETS2LA.Game;
using ETS2LA.Game.Data;
using ETS2LA.Game.SDK;
using ETS2LA.Logging;

using System.Numerics;
using TruckLib.ScsMap;

namespace ETS2LA.Overlay.AR;

/// <summary>
///  ARC: Öndeki araçların bilgisini eklentilerden bağımsız çizer, bu yüzden otonom sürüş
///  kapalıyken de çalışır. Gösterge Paneli'ndeki anahtar OverlaySettings.ShowDriveHud'u değiştirir.
/// </summary>
public class DriveHud
{
    private const float PathLength = 120f;
    private const float PathStep = 5f;
    private const float MaxLaneDistance = 6f;
    private const float LeadTolerance = 3f;
    private const float LabelDistance = 150f;
    private const float LabelSideDistance = 15f;
    private const uint LeadColor = 0x38BDF8FF;
    private const uint OtherColor = 0xA78BFAFF;

    private readonly Dictionary<Road, ParsedRoad> parsedRoads = new();
    private List<Road>? roads;
    private MapData? roadsMap;

    // Çizilmez (şeridi otopilotta eklenti çiziyor); virajda hangi aracın kendi şeridimizde olduğunu bulmak için
    private List<Vector3> path = new();
    private Vector3 lastPosition;
    private Vector3 heading;
    private DateTime nextPathUpdate = DateTime.MinValue;
    private DateTime nextDiagnostic = DateTime.MinValue;
    private bool errorLogged;

    public void Register()
    {
        OverlayHandler.Current.AR.RegisterRenderCallback(new ARRenderCallback
        {
            Definition = new ARRendererDefinition { Name = "ARC Drive HUD", Alpha = 1f },
            Render3D = Render
        });
    }

    private void Render()
    {
        if (!OverlaySettingsHandler.Current.GetSettings().ShowDriveHud) return;

        // Her karede hata yazıp logu doldurmasın diye yalnız ilk hata kaydedilir
        try
        {
            var truck = CameraProvider.Current.GetCurrentData().truckPosition;
            UpdateHeading(truck);
            if (heading == Vector3.Zero) return;

            if (DateTime.UtcNow >= nextPathUpdate)
            {
                nextPathUpdate = DateTime.UtcNow.AddMilliseconds(200);
                path = BuildPath(truck);
            }
            DrawVehicles(truck);
        }
        catch (Exception ex)
        {
            if (errorLogged) return;
            errorLogged = true;
            Logger.Error($"ARC Drive HUD: {ex}");
        }
    }

    // shortcut: yön harekete göre bulunur, tır hiç kıpırdamadan önce bir şey çizilmez ve geri giderken ters yöne bakar; gerekirse kamera dönüşünden hesaplanmalı
    private void UpdateHeading(Vector3 truck)
    {
        var moved = truck - lastPosition;
        moved.Y = 0;
        if (moved.Length() < 0.5f) return;
        lastPosition = truck;
        if (moved.Length() < 50f) heading = Vector3.Normalize(moved); // ışınlanma/profil değişiminde yön bozulmasın
    }

    private ParsedRoad Parsed(Road road)
    {
        if (!parsedRoads.TryGetValue(road, out var parsed))
            parsedRoads[road] = parsed = new ParsedRoad(road);
        return parsed;
    }

    private List<Road>? GetRoads()
    {
        // Harita ayrıştırılırken MapItems değişir, ancak bittikten sonra okunabilir
        var map = GameHandler.Current.Installations.Where(i => i.IsParsed).Select(i => i.GetMapData()).FirstOrDefault(m => m != null);
        if (map == null) return null;
        if (map != roadsMap)
        {
            roads = map.MapItems.Values.OfType<Road>().ToList();
            roadsMap = map;
            parsedRoads.Clear();
        }
        return roads;
    }

    private List<Vector3> BuildPath(Vector3 truck)
    {
        var points = new List<Vector3>();
        var all = GetRoads();
        if (all == null) return points;

        // En yakın şeridi bul
        ParsedRoad? current = null;
        float t = 0, best = MaxLaneDistance;
        Side side = Side.Right;
        int laneIndex = 0;
        foreach (var road in all)
        {
            var middle = (road.Node.Position + road.ForwardNode.Position) / 2;
            if (Vector3.Distance(middle, truck) > road.Length / 2 + MaxLaneDistance) continue;

            var parsed = Parsed(road);
            float factor = parsed.GetFactorForPoint(truck);
            int lane = parsed.GetBestLaneFor(truck, false, true);
            if (lane == 0) continue;
            var laneSide = lane < 0 ? Side.Left : Side.Right;
            int index = Math.Abs(lane) - 1;
            if (index >= parsed.GetLaneCount(laneSide)) continue;

            float distance = Vector3.Distance(parsed.InterpolateLane(factor, laneSide, index).Position, truck);
            if (distance < best)
            {
                (best, current, t, side, laneIndex) = (distance, parsed, factor, laneSide, index);
            }
        }
        if (current == null) return points;

        // Road.Node -> ForwardNode yönü tırın yönüyle aynı mı?
        var towardEnd = current.Road.ForwardNode.Position - current.Road.Node.Position;
        bool forward = Vector3.Dot(towardEnd, heading) > 0;

        // shortcut: kavşakta (prefab) şerit biter; rota boyunca devam etmesi için kavşak yollarının da izlenmesi gerekir
        float walked = 0;
        while (walked < PathLength)
        {
            float length = Math.Max(current.Road.Length, 1f);
            points.Add(current.InterpolateLane(Math.Clamp(t, 0f, 1f), side, laneIndex).Position);
            walked += PathStep;
            t += (forward ? 1 : -1) * PathStep / length;
            if (t >= 0 && t <= 1) continue;

            var next = forward ? current.Road.ForwardItem as Road : current.Road.BackwardItem as Road;
            if (next == null) break;
            // Harita bazı yolları ters tanımlıyor; yön bozulacaksa burada dur
            if ((forward ? next.Node : next.ForwardNode) != (forward ? current.Road.ForwardNode : current.Road.Node)) break;

            current = Parsed(next);
            if (laneIndex >= current.GetLaneCount(side)) break;
            t = forward ? 0 : 1;
        }
        return points;
    }

    private bool IsInLane(TrafficVehicle vehicle, Vector3 toVehicle, float ahead) =>
        // Şerit biliniyorsa viraj da hesaba katılır, yoksa düz ileriye bakılır
        path.Count > 1
            ? path.Any(p => Vector3.Distance(new Vector3(p.X, vehicle.Position.Y, p.Z), vehicle.Position) < LeadTolerance)
            : (toVehicle - heading * ahead).Length() < LeadTolerance;

    private void DrawVehicles(Vector3 truck)
    {
        var vehicles = TrafficProvider.Current.GetCurrentTrafficData()?.vehicles;
        if (vehicles == null) return;

        var AR = OverlayHandler.Current.AR;
        TrafficVehicle? lead = null;
        float leadDistance = float.MaxValue;
        int labeled = 0;
        float nearest = float.MaxValue, nearestSpeed = 0;
        foreach (var vehicle in vehicles)
        {
            // TruckersMP dorseleri ayrı kayıt olarak gönderir; her tıra tek yazı çıksın
            if (vehicle.Position == Vector3.Zero || vehicle.isTrailer) continue;
            var toVehicle = vehicle.Position - truck;
            toVehicle.Y = 0;
            if (toVehicle.Length() < nearest) (nearest, nearestSpeed) = (toVehicle.Length(), vehicle.speed);
            float ahead = Vector3.Dot(toVehicle, heading);
            if (ahead < 3f || ahead > LabelDistance) continue;
            if ((toVehicle - heading * ahead).Length() > LabelSideDistance) continue;

            labeled++;
            bool inLane = IsInLane(vehicle, toVehicle, ahead);
            if (inLane && ahead < leadDistance) (lead, leadDistance) = (vehicle, ahead);
            AR.Draw3DText(
                new ARCoordinate(vehicle.Position + new Vector3(0, vehicle.Size.Y / 2 + 0.5f, 0)),
                $"{vehicle.speed * 3.6f:0} km/sa\n{ahead:0} m",
                0xFFFFFFFF, xFactor: 0.5f, yFactor: 1f,
                bgColor: 0x0F0B1ACC, bgBorderColor: inLane ? LeadColor : OtherColor,
                bgPaddingX: 8f, bgPaddingY: 5f, bgRounding: 6f);
        }

        if (lead != null)
            AR.Draw3DPolygon(lead.GetCornersOnGround().Select(c => new ARCoordinate(c)).ToArray(), LeadColor, thickness: 2f);

        // TruckersMP'de araç verisi denemesi için: gelen veri log dosyasından okunabilsin
        if (DateTime.UtcNow < nextDiagnostic) return;
        nextDiagnostic = DateTime.UtcNow.AddSeconds(15);
        Logger.Info($"ARC Drive HUD: {vehicles.Count(v => v.Position != Vector3.Zero)} araç, {vehicles.Count(v => v.isTMP)} TMP, en yakın {nearest:0} m {nearestSpeed * 3.6f:0} km/sa, yazılan {labeled}, şerit {path.Count} nokta, öndeki {(lead == null ? "yok" : $"{leadDistance:0} m")}");
    }
}
