// Much of this file is based on the Hexa.NET.ImGui example code. See the relevant example here:
// https://github.com/HexaEngine/Hexa.NET.ImGui/blob/main/Examples/ExampleGLFWOpenGL3/Program.cs

using Hexa.NET.GLFW;
using Hexa.NET.ImGui;
using Hexa.NET.ImPlot;
using Hexa.NET.ImGui.Backends.GLFW;
using Hexa.NET.ImGui.Backends.OpenGL3;
using Hexa.NET.OpenGL;
using HexaGen.Runtime;
using GLFWwindowPtr = Hexa.NET.GLFW.GLFWwindowPtr;

using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;
using System.Numerics;
using System.Diagnostics;
using ETS2LA.Shared;

using ETS2LA.Logging;
using ETS2LA.Controls;
using ETS2LA.Overlay.Window;
using ETS2LA.Overlay.AR;
using ETS2LA.ML;
using ETS2LA.ML.Vision;
using ETS2LA.Game.Telemetry;
using ETS2LA.State;
using ETS2LA.Translations;
using static ETS2LA.Translations.T;

namespace ETS2LA.Overlay;

#if WINDOWS
    public static class NativeMethods
    {
        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod", SetLastError = true)]
        public static extern uint TimeBeginPeriod(uint uMilliseconds);

        [DllImport("winmm.dll", EntryPoint = "timeEndPeriod", SetLastError = true)]
        public static extern uint TimeEndPeriod(uint uMilliseconds);

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT { public int X, Y; }

        [DllImport("user32.dll")]
        public static extern bool GetCursorPos(out POINT point);

        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern int GetWindowTextW(IntPtr hWnd, System.Text.StringBuilder text, int maxCount);
    }
#endif

public enum FontStyle
{
    Regular,
    Medium,
    SemiBold,
    Bold
}

public class OverlayHandler
{
    private static readonly Lazy<OverlayHandler> _instance = new(() => new OverlayHandler());
    public static OverlayHandler Current => _instance.Value;

    public ControlDefinition Interact = new ControlDefinition
    {   
        Id = "ETS2LA.Overlay.Interact",
        Name = _("Overlay Interaction"),
        Description = _("When this key is held, the overlay will receive mouse input and allow you to interact with it. NOTE: Interaction with items below the overlay is not possible during this time."),
        DefaultKeybind = "RightAlt",
        Type = ControlType.Boolean
    };

    public ARRenderer AR;
    private OverlaySettings overlaySettings;

    private bool isInteracting = false;
    private bool hasInteracted = false;
    private float bgOpacityTarget = 0.0f;
    private bool shutdown = false;
    private List<float> frameTimes = new List<float>();
    private List<double> remainingMs = new List<double>();
    
    private List<InternalWindow> windows = new();
    private List<(Vector2 Min, Vector2 Max)> windowRects = new();
    public Dictionary<FontStyle, ImFontPtr> Fonts = new Dictionary<FontStyle, ImFontPtr>();

    public bool IsOverlayFocused => isInteracting;
    public float AverageFrameTime => frameTimes.Count > 0 ? frameTimes.Average() : 0f;
    public float AverageRemainingTime => remainingMs.Count > 0 ? (float)remainingMs.Average() : 0f;

    public float OverlayWidth => GLFW.GetVideoMode(GLFW.GetPrimaryMonitor()).Width;
    public float OverlayHeight => GLFW.GetVideoMode(GLFW.GetPrimaryMonitor()).Height;
    public float OverlayMonitorRefreshRate => GLFW.GetVideoMode(GLFW.GetPrimaryMonitor()).RefreshRate;

    private string glslVersion = "#version 150";
    private GLFWwindowPtr glfwWindow;
    private ImGuiContextPtr imGuiContext;
    private ImPlotContextPtr ImPlotContext;
    private ImGuiIOPtr io;
    private GL gl;

    public OverlayHandler()
    {
        ControlsBackend.Current.RegisterControl(Interact);
        ControlsBackend.Current.On(Interact.Id, HandleInput);
        overlaySettings = OverlaySettingsHandler.Current.GetSettings();
        OverlaySettingsHandler.Current.OnSettingsUpdated += OnOverlaySettingsUpdated;

        Task.Factory.StartNew(RenderLoop, TaskCreationOptions.LongRunning);
        
        windows.Add(new ConsoleWindow());
        windows.Add(new DemoWindow());
        windows.Add(new StateWindow());

        if (MLSettings.Current.RenderVisionCameras)
            windows.Add(new VisionCamerasWindow());

        foreach (var window in windows)
            window.IsWindowOpen = overlaySettings.OpenWindows.Contains(window.Definition.Title);
    }

    // ARC: uygulamadaki "Oyun içi pencereler" listesi için
    public List<(string Title, bool Open)> GetWindows()
    {
        lock (windows)
            return windows.Where(w => w is not DemoWindow).Select(w => (w.Definition.Title, w.IsWindowOpen)).ToList();
    }

    private List<InternalWindow> Snapshot()
    {
        lock (windows) return windows.ToList();
    }

    public bool PerformanceVisible
    {
        get => overlaySettings.ShowPerformance;
        set { overlaySettings.ShowPerformance = value; OverlaySettingsHandler.Current.Save(); }
    }

    public void SetWindowOpen(string title, bool open)
    {
        lock (windows)
            foreach (var window in windows.Where(w => w.Definition.Title == title))
                window.IsWindowOpen = open;

        overlaySettings.OpenWindows.Remove(title);
        if (open) overlaySettings.OpenWindows.Add(title);
        OverlaySettingsHandler.Current.Save();
    }

    private void OnOverlaySettingsUpdated(OverlaySettings newSettings)
    {
        overlaySettings = newSettings;
    }

    private void HandleInput(object sender, ControlChangeEventArgs e)
    {
        bool b = (bool)e.NewValue;
        if (overlaySettings.OverlayInteractionIsToggle)
        {
            if (b && !hasInteracted)
            {
                isInteracting = !isInteracting;
                hasInteracted = true;
            }
            else if (!b && hasInteracted)
            {
                hasInteracted = false;
            }
        }
        else
        {
            if (b == isInteracting) { return; }
            isInteracting = b;
        }
    }

    private void RenderLoop()
    {
        if (overlaySettings.DisableOverlay)
        {
            Logger.Error(_("Overlay is disabled in settings, skipping initialization."));
            AR = new ARRenderer(null); // null renderer, won't actually do anything
            return;
        }

        if(!InitGLFW())
        {
            Logger.Error(_("Failed to initialize overlay, OpenGL initialization failed."));
            return;
        }
        GLFW.MakeContextCurrent(glfwWindow);
        gl = new GL(new BindingsContext(glfwWindow));

        if (MLSettings.Current.RenderVisionCameras)
            VisionHandler.Current.Initialize(gl);
        
        if (!InitImGui())
        {
            Logger.Error(_("Failed to initialize overlay, ImGui initialization failed."));
            return;
        }

        #if WINDOWS
            // 1ms sleep accuracy on windows
            // Linux is fine from the get go
            NativeMethods.TimeBeginPeriod(1);
        #endif

        Stopwatch fs = Stopwatch.StartNew();
        int targetFramerate = (int)OverlayMonitorRefreshRate;
        double interval = 1000.0 / targetFramerate;
        double next = fs.Elapsed.TotalMilliseconds;
        double start = fs.Elapsed.TotalMilliseconds;

        while (GLFW.WindowShouldClose(glfwWindow) == 0 && !shutdown)
        {
            if (overlaySettings.LimitFramerate)
                interval = 1000.0 / overlaySettings.MaxFramerate;
            else
                interval = 1000.0 / targetFramerate;

            start = fs.Elapsed.TotalMilliseconds;
            if (next < start)
                next = start;
            
            next += interval;

            if (!isInteracting && !CursorOverWindow()) {
                // This has to be called each frame to properly update the flags.
                // For whatever reason they are set back to default. Shouldn't affect
                // performance, it's just weird...
                ImGui.GetPlatformIO().Viewports[0].Flags |= ImGuiViewportFlags.NoInputs;
                bgOpacityTarget = 0.0f;

                # if LINUX
                    GLFW.SetWindowAttrib(glfwWindow, GLFW.GLFW_MOUSE_PASSTHROUGH, 1);
                # endif
            }
            else  {
                bgOpacityTarget = isInteracting ? 0.5f : 0.0f;
                # if LINUX
                    GLFW.SetWindowAttrib(glfwWindow, GLFW.GLFW_MOUSE_PASSTHROUGH, 0);
                # endif
            }

            GLFW.PollEvents();

            // Skip rendering if we're minimized, though this should actually
            // never happen for the overlay.
            if (GLFW.GetWindowAttrib(glfwWindow, GLFW.GLFW_ICONIFIED) != 0)
            {
                ImGuiImplGLFW.Sleep(10);
                continue;
            }

            GLFW.MakeContextCurrent(glfwWindow);

            ImGuiImplOpenGL3.NewFrame();
            ImGuiImplGLFW.NewFrame();
            ImGui.NewFrame();

            // This renders the virtual cameras into their respective framebuffers.
            if (MLSettings.Current.RenderVisionCameras)
                VisionHandler.Current.Render();

            gl.Viewport(0, 0, (int)OverlayWidth, (int)OverlayHeight);

            // The actual rendering is happening here,
            // all other calls are just setup.
            try { 
                if (AR == null) 
                {
                    AR = new ARRenderer(gl);
                    new DriveHud().Register();

                    if (MLSettings.Current.RenderVisionCameras)
                    {
                        VisionCamerasARRenderer renderer = new VisionCamerasARRenderer();
                        renderer.Register();
                    }
                }
                bool paused = GameTelemetry.Current.GetCurrentData().paused;
                if (overlaySettings.RenderAR && (!overlaySettings.DontRenderWhenPaused || !paused)) AR.Render(); 
            }
            catch (Exception ex) {
                Logger.Error(_("Error in AR rendering: {0}", ex.Message));
            }

            try { OnUIRender(); }
            catch (Exception ex) {
                Logger.Error(_("Error rendering overlay: {0}", ex.Message));
            }
            // ---

            ImGui.Render();

            gl.ClearColor(0f, 0f, 0f, bgOpacityTarget);
            gl.Clear(GLClearBufferMask.ColorBufferBit);

            try { AR.RenderShaders(); } 
            catch (Exception ex) {
                Logger.Error(_("Error in AR OpenGL pass: {0}", ex.Message));
            }
            
            ImGuiImplOpenGL3.RenderDrawData(ImGui.GetDrawData());

            if ((io.ConfigFlags & ImGuiConfigFlags.ViewportsEnable) != 0)
            {
                ImGui.UpdatePlatformWindows();
                ImGui.RenderPlatformWindowsDefault();
            }

            GLFW.SwapInterval(0); // disable vsync
            GLFW.SwapBuffers(glfwWindow);

            double remaining = next - fs.Elapsed.TotalMilliseconds;
            if (remaining > 1.0)
                Thread.Sleep((int)(remaining - 1));
            while (fs.Elapsed.TotalMilliseconds < next)
                Thread.SpinWait(10);
            
            frameTimes.Add((float)(fs.Elapsed.TotalMilliseconds - start));
            if (frameTimes.Count > targetFramerate) { frameTimes.RemoveAt(0); }
            
            remainingMs.Add(remaining);
            if (remainingMs.Count > targetFramerate) { remainingMs.RemoveAt(0); }
        }

        ImGuiImplOpenGL3.Shutdown();
        ImGuiImplOpenGL3.SetCurrentContext(null);
        ImGuiImplGLFW.Shutdown();
        ImGuiImplGLFW.SetCurrentContext(null);
        ImGui.DestroyContext();
        gl.Dispose();

        // Clean up and terminate GLFW
        GLFW.DestroyWindow(glfwWindow);
        GLFW.Terminate();
    }

    // ARC: fare bir oyun içi pencerenin üstündeyse tıklama ona gider, gerisi oyuna geçer.
    // Sürüş sırasında fare direksiyon/bakış için kullanıldığından hepsi oyunda kalır (sağ Alt ile yine alınır).
    private bool CursorOverWindow()
    {
        # if WINDOWS
            if (!NativeMethods.GetCursorPos(out var cursor)) return false;
            var pos = new Vector2(cursor.X - 1, cursor.Y - 1); // katman ekranda (1,1) konumunda
            const float grip = 8f; // boyutlandırma kenarı pencerenin biraz dışından da tutulur
            bool held = ImGui.IsMouseDown(ImGuiMouseButton.Left) || ImGui.IsMouseDown(ImGuiMouseButton.Right);
            if (!held && !windowRects.Any(r => pos.X >= r.Min.X - grip && pos.Y >= r.Min.Y - grip
                                            && pos.X <= r.Max.X + grip && pos.Y <= r.Max.Y + grip))
                return false;

            var title = new System.Text.StringBuilder(64);
            NativeMethods.GetWindowTextW(NativeMethods.GetForegroundWindow(), title, title.Capacity);
            bool gameInFront = title.ToString().StartsWith("Euro Truck Simulator 2") || title.ToString().StartsWith("American Truck Simulator");
            if (gameInFront && !GameTelemetry.Current.GetCurrentData().paused) return false;

            // Katman fareyi yeni almaya başladıysa Windows konumu bildirmez; ilk tıklama boşa gitmesin
            io.AddMousePosEvent(pos.X, pos.Y);
            return true;
        # else
            return false;
        # endif
    }

    private void RememberWindowRect()
    {
        var min = ImGui.GetWindowPos();
        windowRects.Add((min, min + ImGui.GetWindowSize()));
    }

    private void OnUIRender()
    {
        windowRects.Clear();

        if (isInteracting)
        {
            ImGui.Begin(_("Interaction Mode"), ImGuiWindowFlags.NoDecoration | ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoBackground);
            ImGui.SetWindowPos(new Vector2(OverlayWidth / 2 - 60, 10), ImGuiCond.Always);
            ImGui.TextColored(new Vector4(0.5f, 0.5f, 0.5f, 1f), _("Interaction Mode"));

            ImGui.Spacing();
            try
            {
                foreach (var window in Snapshot()) {
                    bool isOpen = window.IsWindowOpen;
                    Vector4 color = isOpen ? new Vector4(0.5f, 0.6f, 0.5f, 1f) : new Vector4(0.6f, 0.5f, 0.5f, 1f);

                    ImGui.TextColored(color, isOpen ? "[X]" : "[   ]");
                    ImGui.SameLine();
                    ImGui.TextColored(color, L(window.Definition.Title));
        
                    if (ImGui.IsItemHovered())
                    {
                        ImGui.SetTooltip(_("Click to {0} this window", isOpen ? _("hide") : _("show")));
                    }
                    if (ImGui.IsItemClicked())
                    {
                        SetWindowOpen(window.Definition.Title, !window.IsWindowOpen);
                    }
                }
            } catch (Exception ex)
            {
                Logger.Error(_("Error rendering interaction mode window controls: {0}", ex.Message));
            }
            ImGui.End();
        }

        foreach (InternalWindow window in Snapshot())
            RenderOverlayWindow(window);

        if (!overlaySettings.ShowPerformance) return;

        ImGui.SetNextWindowPos(new Vector2(OverlayWidth - 10, 10), ImGuiCond.Always, new Vector2(1f, 0f));
        ImGui.Begin(_("Performance Overlay"), ImGuiWindowFlags.NoDecoration | ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoBackground);

        var fps = (AverageFrameTime > 0) ? (int)(1 / (AverageFrameTime / 1000f)) : 0;
        int freePercentage;
        if (overlaySettings.LimitFramerate)
            freePercentage = (int)(AverageRemainingTime / (1000f / overlaySettings.MaxFramerate) * 100f);
        else
            freePercentage = (int)(AverageRemainingTime / (1000f / OverlayMonitorRefreshRate) * 100f);
        
        ImGui.TextColored(new Vector4(1f,1f,1f,0.5f), $"{(int)(1/(AverageFrameTime / 1000f))}");
        ImGui.TextColored(new Vector4(1f,1f,1f,0.5f), $"{freePercentage}%%");
        if (ImGui.IsItemHovered())
        {
            ImGui.SetTooltip(_("Overlay free CPU time percentage"));
        }

        ImGui.End();
    }

    private void RenderOverlayWindow(InternalWindow window)
    {
            try
            {
                if (!window.IsWindowOpen) { return; }
                if (window.Definition.NoWindow.GetValueOrDefault(false))
                {
                    window.Render();
                    return;
                }

                // Plugin developer has set the width and height, these get applied
                // once each startup. Use ImGuiWindowFlags to disallow movement.
                if (window.Definition.Width.HasValue || window.Definition.Height.HasValue)
                {
                    var width = window.Definition.Width.GetValueOrDefault(480);
                    var height = window.Definition.Height.GetValueOrDefault(320);
                    if (width > 0 && height > 0)
                        ImGui.SetNextWindowSize(new Vector2(width, height), ImGuiCond.FirstUseEver); // ARC: kullanıcının verdiği boyut korunur
                }

                // Plugin developer has set a sizing function, this is continuous
                // throughout the lifecycle of the window.
                if (window.Definition.SizingFunction.HasValue && window.Definition.SizingFunction.Value != null)
                {
                    var (width, height) = window.Definition.SizingFunction.Value();
                    ImGui.SetNextWindowSize(new Vector2(width, height), ImGuiCond.Always);
                }

                ImGui.SetNextWindowBgAlpha(window.Definition.Alpha.GetValueOrDefault(0.72f));
                var windowFlags = window.Definition.Flags.GetValueOrDefault(ImGuiWindowFlags.None);
                ImGui.Begin(L(window.Definition.Title) + "###" + window.Definition.Title, windowFlags);

                // ARC: sabit (konsol gibi) pencereler tıklama almaz; başlığın altında ARC vurgu çizgisi
                if ((windowFlags & (ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoInputs | ImGuiWindowFlags.NoTitleBar)) == 0)
                {
                    RememberWindowRect();
                    var titleBottom = ImGui.GetWindowPos() + new Vector2(0, ImGui.GetFrameHeight());
                    uint accent = ImGui.GetColorU32(new Vector4(0.545f, 0.361f, 0.965f, 1f));
                    uint faded = ImGui.GetColorU32(new Vector4(0.545f, 0.361f, 0.965f, 0f));
                    ImGui.GetWindowDrawList().AddRectFilledMultiColor(titleBottom, titleBottom + new Vector2(ImGui.GetWindowWidth(), 2f), accent, faded, faded, accent);
                }

                // Plugin developer has set X and Y values, these are applied
                // once each startup. Use ImGuiWindowFlags to disallow resizing.
                if (window.Definition.X.HasValue || window.Definition.Y.HasValue)
                {
                    int x = window.Definition.X.GetValueOrDefault((int)(OverlayWidth / 2));
                    int y = window.Definition.Y.GetValueOrDefault((int)(OverlayHeight / 2));
                    if (x >= 0 && y >= 0)
                    {
                        ImGui.SetWindowPos(new Vector2(x, y), ImGuiCond.Once);
                    }
                } 
                // If no X and Y are set, then for the first time we'll open this window
                // at the center of the screen.
                else
                {
                    // ARC: pencerenin ortası ekranın ortasına gelir, köşesi ekran dışında kalmaz
                    int x = (int)(OverlayWidth - ImGui.GetWindowWidth()) / 2;
                    int y = (int)(OverlayHeight - ImGui.GetWindowHeight()) / 2;
                    if (x >= 0 && y >= 0)
                    {
                        ImGui.SetWindowPos(new Vector2(x, y), ImGuiCond.FirstUseEver);
                    }
                }

                // Plugin developer has set a location function, this is continuous
                // throughout the lifecycle of the window.
                if (window.Definition.LocationFunction.HasValue && window.Definition.LocationFunction.Value != null)
                {
                    var (x, y) = window.Definition.LocationFunction.Value();
                    ImGui.SetWindowPos(new Vector2(x, y), ImGuiCond.Always);
                }

                var isCollapsed = ImGui.IsWindowCollapsed();
                if (isCollapsed) {
                    ImGui.End(); 
                    return; 
                }

                try
                {
                    RenderWindowContextMenu(window);
                } catch (Exception ex)
                {
                    Logger.Error(_("Error rendering context menu for window {0}: {1}", window.Definition.Title, ex.Message));
                }

                try
                {
                    window.Render();
                } catch (Exception ex)
                {
                    Logger.Error(_("Error rendering window {0}: {1}", window.Definition.Title, ex.Message));
                }

                ImGui.End();
            }
            catch (Exception ex)
            {
                try { ImGui.End(); }
                catch { }
                Logger.Error(_("Error rendering window {0}: {1}", window.Definition.Title, ex.Message));
            }
    }

    private unsafe void RenderWindowContextMenu(InternalWindow window)
    {
        if (ImGui.BeginPopupContextWindow((byte*)0, ImGuiPopupFlags.MouseButtonRight))
        {
            RememberWindowRect();
            window.RenderContextMenu();
            if (ImGui.MenuItem(_("Close")))
            {
                SetWindowOpen(window.Definition.Title, false);
            }
            ImGui.EndPopup();
        }
    }

    // ARC: uygulamanın koyu mor paleti (ETS2LA.UI/wwwroot/css/input.css)
    private static void ApplyArcTheme(ImGuiStylePtr style)
    {
        static Vector4 Hex(uint rgb, float a = 1f) => new(((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f, a);

        style.WindowRounding = 12f;
        style.ChildRounding = 8f;
        style.PopupRounding = 8f;
        style.FrameRounding = 6f;
        style.GrabRounding = 6f;
        style.ScrollbarRounding = 6f;
        style.WindowBorderSize = 1f;
        style.WindowPadding = new Vector2(12f, 10f);
        style.FramePadding = new Vector2(8f, 6f);
        style.ScrollbarSize = 10f;

        var colors = style.Colors;
        colors[(int)ImGuiCol.Text] = Hex(0xECE9F5);
        colors[(int)ImGuiCol.TextDisabled] = Hex(0x8A83A0);
        colors[(int)ImGuiCol.WindowBg] = Hex(0x13111A);
        colors[(int)ImGuiCol.ChildBg] = Hex(0x13111A, 0f);
        colors[(int)ImGuiCol.PopupBg] = Hex(0x171320, 0.96f);
        colors[(int)ImGuiCol.Border] = Hex(0x8B5CF6, 0.35f);
        colors[(int)ImGuiCol.TitleBg] = Hex(0x1F1833, 0.75f);
        colors[(int)ImGuiCol.TitleBgActive] = Hex(0x2A1F45, 0.85f);
        colors[(int)ImGuiCol.TitleBgCollapsed] = Hex(0x1F1833, 0.6f);
        colors[(int)ImGuiCol.FrameBg] = Hex(0x1C1827, 0.8f);
        colors[(int)ImGuiCol.FrameBgHovered] = Hex(0x2A1F45);
        colors[(int)ImGuiCol.FrameBgActive] = Hex(0x4C1D95);
        colors[(int)ImGuiCol.Button] = Hex(0x2A1F45);
        colors[(int)ImGuiCol.ButtonHovered] = Hex(0x4C1D95);
        colors[(int)ImGuiCol.ButtonActive] = Hex(0x8B5CF6);
        colors[(int)ImGuiCol.Header] = Hex(0x2A1F45);
        colors[(int)ImGuiCol.HeaderHovered] = Hex(0x4C1D95);
        colors[(int)ImGuiCol.HeaderActive] = Hex(0x8B5CF6);
        colors[(int)ImGuiCol.CheckMark] = Hex(0xA78BFA);
        colors[(int)ImGuiCol.SliderGrab] = Hex(0x8B5CF6);
        colors[(int)ImGuiCol.SliderGrabActive] = Hex(0xA78BFA);
        colors[(int)ImGuiCol.Separator] = Hex(0x2C2340);
        colors[(int)ImGuiCol.ScrollbarBg] = Hex(0x13111A, 0f);
        colors[(int)ImGuiCol.ScrollbarGrab] = Hex(0x2C2340);
        colors[(int)ImGuiCol.ScrollbarGrabHovered] = Hex(0x4C1D95);
        colors[(int)ImGuiCol.ScrollbarGrabActive] = Hex(0x8B5CF6);
        colors[(int)ImGuiCol.ResizeGrip] = Hex(0x8B5CF6, 0.45f);
        colors[(int)ImGuiCol.ResizeGripHovered] = Hex(0xA78BFA, 0.8f);
        colors[(int)ImGuiCol.ResizeGripActive] = Hex(0xA78BFA);
    }

    private bool InitImGui()
    {
        imGuiContext = ImGui.CreateContext();
        ImGui.SetCurrentContext(imGuiContext);
        
        ImPlot.SetImGuiContext(imGuiContext);
        ImPlotContext = ImPlot.CreateContext();
        ImPlot.SetCurrentContext(ImPlotContext);

        io = ImGui.GetIO();
        io.ConfigFlags |= ImGuiConfigFlags.NavEnableKeyboard;     // Enable Keyboard Controls
        io.ConfigFlags |= ImGuiConfigFlags.NavEnableGamepad;      // Enable Gamepad Controls
        io.ConfigFlags |= ImGuiConfigFlags.DockingEnable;         // Enable Docking
        if (OverlaySettingsHandler.Current.GetSettings().SupportMultipleViewports)
            io.ConfigFlags |= ImGuiConfigFlags.ViewportsEnable;       // Enable Multi-Viewport / Platform Windows

        // Tweak our styling just a little
        ImGui.StyleColorsDark();
        var style = ImGui.GetStyle();
        ApplyArcTheme(style);

        // ARC: konum ve boyut kalıcı olsun; Program Files'a yazılamadığı için ayarların yanında tutulur
        unsafe
        {
            io.IniFilename = (byte*)Marshal.StringToCoTaskMemUTF8(Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ETS2LA", "imgui.ini"));
        }

        // And then we scale by the monitor DPI
        var mon = GLFW.GetPrimaryMonitor();
        float mainScale = ImGuiImplGLFW.GetContentScaleForMonitor(Unsafe.BitCast<Hexa.NET.GLFW.GLFWmonitorPtr, Hexa.NET.ImGui.Backends.GLFW.GLFWmonitorPtr>(mon));

        style.ScaleAllSizes(mainScale);
        style.FontScaleDpi = mainScale;
        io.ConfigDpiScaleFonts = true;
        io.ConfigDpiScaleViewports = true;

        Language language = StateSettingsHandler.Current.GetSettings().DisplayLanguage;
        string fontName = "Geist";

        switch (language.EnglishName)
        {
            case "Japanese":
                fontName = "NotoSansJP";
                break;
            case "Chinese (Simplified)":
                fontName = "NotoSansSC";
                break;
            case "Chinese (Traditional)":
                fontName = "NotoSansTC";
                break;
            case "Korean":
                fontName = "NotoSansKR";
                break;
            case "Thai":
                fontName = "NotoSansThai";
                break;
            case "Vietnamese":
                fontName = "NotoSans";
                break;
            default:
                break;
        }

        // ARC: kurulum paketi küçük kalsın diye büyük CJK yazı tipleri pakette yok; yoksa NotoSans kullanılır
        if (!Directory.Exists(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Fonts", fontName)))
            fontName = "NotoSans";

        List<Tuple<FontStyle, string>> fonts = new List<Tuple<FontStyle, string>>()
        {
            new Tuple<FontStyle, string>(FontStyle.Medium, Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Fonts", $"{fontName}", $"{fontName}-Medium.ttf")),
            new Tuple<FontStyle, string>(FontStyle.Regular, Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Fonts", $"{fontName}", $"{fontName}-Regular.ttf")),
            new Tuple<FontStyle, string>(FontStyle.SemiBold, Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Fonts", $"{fontName}", $"{fontName}-SemiBold.ttf")),
            new Tuple<FontStyle, string>(FontStyle.Bold, Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Assets", "Fonts", $"{fontName}", $"{fontName}-Bold.ttf")),
        };

        // Set fonts
        unsafe
        {
            for (int i = 0; i < fonts.Count; i++)
            {
                string fontPath = fonts[i].Item2;
                if (!File.Exists(fontPath))
                {
                    Logger.Error(_("Font file not found at {0}", fontPath));
                    continue;
                }
                ImFont* font = io.Fonts.AddFontFromFileTTF(fontPath, overlaySettings.BaseFontSize);
                ImFontPtr fontPtr = new ImFontPtr(font);
                Fonts[fonts[i].Item1] = fontPtr;
            }
        }

        ImGuiImplGLFW.SetCurrentContext(imGuiContext);
        if (!ImGuiImplGLFW.InitForOpenGL(Unsafe.BitCast<GLFWwindowPtr, Hexa.NET.ImGui.Backends.GLFW.GLFWwindowPtr>(glfwWindow), true))
        {
            Logger.Error(_("Failed to init ImGui Impl GLFW"));
            GLFW.Terminate();
            return false;
        }

        ImGuiImplOpenGL3.SetCurrentContext(imGuiContext);
        if (!ImGuiImplOpenGL3.Init(glslVersion))
        {
            Logger.Error(_("Failed to init ImGui Impl OpenGL3"));
            GLFW.Terminate();
            return false;
        }

        gl.Enable(GLEnableCap.Blend);
        gl.BlendFunc(GLBlendingFactor.SrcAlpha, GLBlendingFactor.OneMinusSrcAlpha);
        gl.ClearColor(0f, 0f, 0f, 0f); // Transparent background
        return true;
    }

    private bool InitGLFW()
    {
        unsafe
        {
            GLFW.SetErrorCallback((error, description) =>
            {
                # if DEBUG
                Logger.Error(_("GLFW Error {0}: {1}", error, Utils.DecodeStringUTF8(description)));
                # endif
            });
        }

        unsafe
        {
            Logger.Info(_("Initializing GLFW Version: {0}", Utils.DecodeStringUTF8(GLFW.GetVersionString())));
        }

        // This code sets the platform to X11 instead of wayland. This only needs to be
        // done inside vscode for whatever reason. https://github.com/opentk/opentk/issues/1823
        string? sessionType = Environment.GetEnvironmentVariable("XDG_SESSION_TYPE");
        string? useWayland = Environment.GetEnvironmentVariable("GLFW_USE_WAYLAND");
        if (sessionType == "wayland" && useWayland == "0")
        {
            GLFW.InitHint(GLFW.GLFW_PLATFORM, GLFW.GLFW_PLATFORM_X11);
        }

        Logger.Info(_("Initializing GLFW..."));
        GLFW.Init();
        GLFW.WindowHint(GLFW.GLFW_CONTEXT_VERSION_MAJOR, 3);
        GLFW.WindowHint(GLFW.GLFW_CONTEXT_VERSION_MINOR, 2);
        GLFW.WindowHint(GLFW.GLFW_OPENGL_PROFILE, GLFW.GLFW_OPENGL_CORE_PROFILE);  // 3.2+ only

        # if LINUX
            GLFW.WindowHint(GLFW.GLFW_CONTEXT_CREATION_API, GLFW.GLFW_EGL_CONTEXT_API);
        # endif

        GLFW.WindowHint(GLFW.GLFW_TRANSPARENT_FRAMEBUFFER, 1);  // Transparent
        GLFW.WindowHint(GLFW.GLFW_DECORATED, 0);                // No window decorations
        GLFW.WindowHint(GLFW.GLFW_FLOATING, 1);                 // Always on top
        GLFW.WindowHint(GLFW.GLFW_FOCUSED, 0);                  // Start unfocused
        GLFW.WindowHint(GLFW.GLFW_FOCUS_ON_SHOW, 0);            // Start unfocused
        
        var mon = GLFW.GetPrimaryMonitor();
        int width, height;
        width = GLFW.GetVideoMode(mon).Width;
        height = GLFW.GetVideoMode(mon).Height;

        // NOTE: Width and height set to screen-2
        // If they are set to the screen size, windows does some optimizations that cause the window
        // to go full black when focused. Setting these to -2 seems to prevent that.
        glfwWindow = GLFW.CreateWindow(width - 2, height - 2, "ARC ETS2 Auto Drive Overlay", null, null);
        if (glfwWindow.IsNull)
        {
            Logger.Error(_("Failed to create GLFW window"));
            GLFW.Terminate();
            return false;
        }

        # if WINDOWS
        GLFW.SetWindowPos(glfwWindow, 1, 1);
        # endif

        return true;
    }

    public void RegisterWindow(WindowDefinition def, Action renderAction, Optional<Action> renderContextMenuAction = default)
    {
        if (overlaySettings.DisableOverlay)
        {
            Logger.Warn(_("Overlay is disabled in settings, skipping window registration for {0}.", def.Title));
            return;
        }

        foreach (var window in windows)
        {
            if (window.Definition.Title == def.Title)
            {
                window.Definition = def;
                window.Render = renderAction;
                window.RenderContextMenu = renderContextMenuAction.GetValueOrDefault(() => { });
                return;
            }
        }
        
        var newWindow = new ExternalWindow(def, renderAction, renderContextMenuAction.GetValueOrDefault(() => { }));
        // ARC: eklentinin istediği açılış durumu (def.Open) yok sayılır, kullanıcı uygulamadan açar
        newWindow.IsWindowOpen = overlaySettings.OpenWindows.Contains(def.Title);

        lock (windows) windows.Add(newWindow);
    }

    public void UnregisterWindow(WindowDefinition def)
    {
        lock (windows) windows.RemoveAll(w => w.Definition.Title == def.Title);
    }

    public void OpenWindow(string windowName)
    {
        // ARC: eklentiler pencereyi kendiliğinden açamaz; açma kararı kullanıcının (SetWindowOpen)
    }

    public void CloseWindow(string windowName)
    {
        var window = windows.FirstOrDefault(w => w.Definition.Title == windowName);
        if (window != null)
        {
            window.IsWindowOpen = false;
        }
    }

    public void Shutdown()
    {
        shutdown = true;
        VisionHandler.Current.Shutdown();
    }
}
