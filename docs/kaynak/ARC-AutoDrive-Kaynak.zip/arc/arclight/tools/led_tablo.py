"""Oyun dosyalarındaki kamyon iç modellerinden (.pmg 0x15) LED tablosunu üretir: src/trucks.txt.

Modelin orijini sürücünün başının varsayılan yeridir (x sağ, y yukarı, z geri), arclight'ın kabin uzayıyla aynı.
Her satır: sdk_kimligi  sol sag on arka zemin tavan_alt omuz panel  (metre).
"""
import glob
import os
import re
import struct
import sys

KOK = sys.argv[1] if len(sys.argv) > 1 else r"C:\Users\oguzs\arc-harita\oyun_dosyalari"
CIKTI = os.path.join(os.path.dirname(__file__), "..", "src", "trucks.txt")
ARAC = os.path.join(KOK, "base_vehicle", "vehicle", "truck")

# Model klasörü -> SDK kimlikleri (def/vehicle/truck altındaki adlar).
KIMLIK = {
    "daf_xf": ["daf.xf"], "daf_xf_euro6": ["daf.xf_euro6"], "daf_2021": ["daf.2021"], "daf_xd": ["daf.xd"],
    "iveco_hiway": ["iveco.hiway"], "iveco_stralis": ["iveco.stralis"],
    "man_tgx": ["man.tgx"], "man_tgx_euro6": ["man.tgx_euro6"],
    "mercedes_actros_2009": ["mercedes.actros"], "mercedes_actros_2014": ["mercedes.actros2014"], "mercedes_actors_2014": ["mercedes.actros2014"],
    "renault_magnum_2009": ["renault.magnum"], "renault_premium": ["renault.premium"], "renault_t": ["renault.t"], "renault_etech_t": ["renault.etech_t"],
    "scania_2016": ["scania.s_2016", "scania.r_2016"], "scania_rcab_2009": ["scania.r", "scania.streamline"],
    "volvo_fh16_2009": ["volvo.fh16"], "volvo_fh16_2012": ["volvo.fh16_2012"], "volvo_fh_2021": ["volvo.fh_2021"], "volvo_fh_2024": ["volvo.fh_2024"],
}


def noktalar(yol):
    b = open(yol, "rb").read()
    if len(b) < 0x80 or b[0] != 0x15 or b[1:4] != b"gmP":
        return []
    adet = struct.unpack_from("<i", b, 4)[0]
    parca = struct.unpack_from("<I", b, 0x48 + 3 * 4)[0]
    out = []
    for i in range(adet):
        r = struct.unpack_from("<25I", b, parca + i * 100)
        kose, adim, konum = r[1], r[15], r[16]
        if not 12 <= adim <= 128 or konum + kose * adim > len(b):
            continue
        for k in range(0, kose, max(1, kose // 400)):
            out.append(struct.unpack_from("<3f", b, konum + k * adim))
    return out


def kes(p, ad, a, b):
    return [q[ad] for q in p if a <= q[1] <= b]


def yuzde(d, o):
    d = sorted(d)
    return d[min(len(d) - 1, int(len(d) * o))]


def hesapla(yollar):
    p = []
    for y in yollar:
        p += noktalar(y)
    if len(p) < 200:
        return None
    y_ = [q[1] for q in p]
    zemin, tavan = yuzde(y_, 0.004), yuzde(y_, 0.996)
    zemin = max(zemin, -1.30)
    if not (0.45 < tavan < 1.9 and -1.9 < zemin < -0.5):
        print("  olcu disi", yollar[0], round(zemin, 2), round(tavan, 2))
        return None
    # Kabin kabuğu: omuz hizasındaki dış sınır (koltuklar dış sınırı değiştirmez).
    x = kes(p, 0, -0.45, 0.35)
    z = kes(p, 2, -0.45, 0.35)
    if len(x) < 50:
        return None
    sol, sag = yuzde(x, 0.005), yuzde(x, 0.995)
    on, arka = yuzde(z, 0.005), yuzde(z, 0.995)
    if sag - sol < 1.3:
        print("  dar", yollar[0], round(sol, 2), round(sag, 2))
        return None
    # Panel üstü: ön bölgedeki yüzeylerin üst sınırı (göğüs altı).
    pan = [q[1] for q in p if q[2] < on + 0.5 and sol + 0.2 < q[0] < sag - 0.2 and -0.7 < q[1] < 0.15]
    panel = yuzde(pan, 0.97) if len(pan) > 30 else -0.25
    # Bazı modeller iki yönlü parça taşır; sürücü tarafı duvarı başın 0,8 m ötesinde olamaz.
    sol = max(sol, -0.62)
    panel = min(max(panel, -0.42), -0.12)
    return sol, sag, on, arka, zemin, min(tavan, 1.3), -0.30, panel


satir = {}
eksik = []
for klasor in sorted(os.listdir(ARAC)):
    if klasor in ("share", "upgrade"):
        continue
    yol = os.path.join(ARAC, klasor, "interior")
    bulunan = []
    for y in glob.glob(os.path.join(yol, "**", "*.pmg"), recursive=True):
        parcalar = os.path.relpath(y, yol).lower().replace("\\", "/").split("/")
        ad = parcalar[-1]
        # Sag direksiyonlu (uk) aynali modeller, animasyon ve kabin disi parcalar govde olcusune girmez.
        if any(k.startswith("uk") or k in ("anim", "external") for k in parcalar[:-1]) or "anim" in ad or ad.endswith("_uk.pmg") or "_lod" in ad:
            continue
        bulunan.append(y)
    bulunan.sort()
    sonuc = hesapla(bulunan) if bulunan else None
    if sonuc is None:
        eksik.append(klasor)
        continue
    for kimlik in KIMLIK.get(klasor, [klasor.replace("_", ".", 1)]):
        satir["vehicle." + kimlik] = sonuc

with open(CIKTI, "w", encoding="ascii", newline="\n") as f:
    for k, v in sorted(satir.items()):
        f.write(k + " " + " ".join(f"{x:.3f}" for x in v) + "\n")

print("yazildi", len(satir), "eksik model:", eksik)
for k, v in sorted(satir.items()):
    print(k.ljust(30), " ".join(f"{x:6.2f}" for x in v))
