//! The drive HUD (lane ribbon, arrows, vehicle labels) drawn straight into the game's own frame at Present, with
//! the game's camera of that very frame. ETS2 Auto Drive only says what to draw, in world coordinates, through
//! the shared memory `Local\ARCHud`; there is no window on top of the game.

use std::ffi::c_void;
use std::sync::{LazyLock, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};

use windows::Win32::Foundation::CloseHandle;
use windows::Win32::Graphics::Direct3D::Fxc::D3DCompile;
use windows::Win32::Graphics::Direct3D::{D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST, ID3DBlob};
use windows::Win32::Graphics::Direct3D11::*;
use windows::Win32::Graphics::Dxgi::Common::{
    DXGI_FORMAT_R8_UNORM, DXGI_FORMAT_R32_FLOAT, DXGI_FORMAT_R32G32_FLOAT, DXGI_FORMAT_R32G32B32A32_FLOAT, DXGI_SAMPLE_DESC,
};
use windows::Win32::Graphics::Dxgi::IDXGISwapChain;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::Memory::{FILE_MAP_READ, MEMORY_MAPPED_VIEW_ADDRESS, MapViewOfFile, OpenFileMappingW};
use windows::core::{Interface, PCSTR, PCWSTR, s, w};

const SHADER: &str = r#"
Texture2D<float> atlas : register(t0);
SamplerState linearly : register(s0);
struct VI { float2 p : POSITION; float4 c : COLOR; float2 uv : TEXCOORD; float k : KIND; };
struct PI { float4 p : SV_Position; float4 c : COLOR; noperspective float2 uv : TEXCOORD; float k : KIND; };
PI vs(VI v) { PI o; o.p = float4(v.p, 0, 1); o.c = v.c; o.uv = v.uv; o.k = v.k; return o; }
float4 ps(PI i) : SV_Target {
    if (i.k > 1.5) {
        // The AR ribbon of the overlay (LineWithGradient), unchanged: a crisp outer line and a soft inward glow.
        float u = i.uv.x;
        float core = 1.0 - smoothstep(-1.0, -0.75, u);
        float glow = pow(1.0 - saturate((u + 0.75) / 1.75), 2.2) * 0.65;
        float total = saturate(core + glow);
        float fade = 1.0 - smoothstep(0.7, 1.0, i.uv.y);
        return float4(i.c.rgb + 0.35 * core, i.c.a * total * fade);
    }
    float a = i.k > 0.5 ? atlas.Sample(linearly, i.uv) : 1.0;
    return float4(i.c.rgb, i.c.a * a);
}
"#;

#[repr(C)]
#[derive(Clone, Copy)]
struct V {
    p: [f32; 2],
    c: [f32; 4],
    uv: [f32; 2],
    k: f32,
}

const MAX_VERTS: usize = 36000;
const ATLAS: (usize, usize) = (512, 288);
const CELL: (usize, usize) = (32, 48);
/// The font's height in the atlas: near the size it's drawn at, so small text stays crisp.
const FONT_HEIGHT: f32 = 26.0;

/// How far above the data's sender may be silent before nothing is drawn (milliseconds).
const STALE_MS: f64 = 1500.0;

// `Local\ARCHud`: magic, seq (odd while writing), counts, then the arrays (see `DriveHud.cs` of ARC.DriveAssist).
const MAGIC: u32 = 0x4855_4441;
const SIZE: usize = 256 * 1024;
const HEADER: usize = 48;
const POINT: usize = 40;
const MAX_POINTS: usize = 2000;
const QUAD: usize = 64;
const MAX_QUADS: usize = 512;
const LABEL: usize = 24;
const MAX_LABELS: usize = 64;

struct Camera {
    position: [f64; 3],
    rotation: [[f64; 3]; 3],
    projection: [[f32; 4]; 4],
}

fn normalize4(q: [f64; 4]) -> [f64; 4] {
    let n = q.iter().map(|v| v * v).sum::<f64>().sqrt();
    if n > 0.0 { q.map(|v| v / n) } else { [0.0, 0.0, 0.0, 1.0] }
}

/// TruckLib's `ToEuler`.
fn to_euler(q: [f64; 4]) -> [f64; 3] {
    let [x, y, z, w] = normalize4(q);
    let t = x * w - y * z;
    if t > 0.4995 {
        [std::f64::consts::FRAC_PI_2, 2.0 * y.atan2(x), 0.0]
    } else if t < -0.4995 {
        [-std::f64::consts::FRAC_PI_2, -2.0 * y.atan2(x), 0.0]
    } else {
        [
            (2.0 * (w * x - y * z)).asin(),
            (2.0 * w * y + 2.0 * z * x).atan2(1.0 - 2.0 * (x * x + y * y)),
            (2.0 * w * z + 2.0 * x * y).atan2(1.0 - 2.0 * (z * z + x * x)),
        ]
    }
}

fn from_yaw_pitch_roll(yaw: f64, pitch: f64, roll: f64) -> [f64; 4] {
    let (sr, cr) = (roll * 0.5).sin_cos();
    let (sp, cp) = (pitch * 0.5).sin_cos();
    let (sy, cy) = (yaw * 0.5).sin_cos();
    [cy * sp * cr + sy * cp * sr, sy * cp * cr - cy * sp * sr, cy * cp * sr - sy * sp * cr, cy * cp * cr + sy * sp * sr]
}

fn matrix_of(q: [f64; 4]) -> [[f64; 3]; 3] {
    let [x, y, z, w] = q;
    [
        [1.0 - 2.0 * (y * y + z * z), 2.0 * (x * y + z * w), 2.0 * (x * z - y * w)],
        [2.0 * (x * y - z * w), 1.0 - 2.0 * (x * x + z * z), 2.0 * (y * z + x * w)],
        [2.0 * (x * z + y * w), 2.0 * (y * z - x * w), 1.0 - 2.0 * (x * x + y * y)],
    ]
}

impl Camera {
    /// From `Local\ETS2LACameraProps` (`CameraProvider`'s layout), as ETS2 Auto Drive's AR renderer takes it.
    fn parse(b: &[u8]) -> Option<Camera> {
        let f = |o: usize| f32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]]);
        if b.len() < 100 {
            return None;
        }
        let (cx, cy) = (i16::from_le_bytes([b[16], b[17]]) as f64, i16::from_le_bytes([b[18], b[19]]) as f64);
        let q = [f(20) as f64, f(24) as f64, f(28) as f64, f(32) as f64];
        let e = to_euler([-q[0], -q[1], -q[2], q[3]]);
        let pi = std::f64::consts::PI;
        let rotation = matrix_of(from_yaw_pitch_roll(-e[1] + pi, -e[2] + pi, -e[0]));
        let projection: [[f32; 4]; 4] = std::array::from_fn(|r| std::array::from_fn(|c| f(36 + (r * 4 + c) * 4)));
        let position = [f(4) as f64 + 512.0 * cx, f(8) as f64, f(12) as f64 + 512.0 * cy];
        projection[0][0].is_finite().then_some(Camera { position, rotation, projection })
    }

    /// A world point in clip space: x, y, z, w (as `ARRenderer.WorldToScreen`, none behind the camera).
    fn clip(&self, world: [f32; 3]) -> Option<[f32; 4]> {
        let d: [f64; 3] = std::array::from_fn(|i| world[i] as f64 - self.position[i]);
        let r = &self.rotation;
        let v = [
            d[0] * r[0][0] + d[1] * r[0][1] + d[2] * r[0][2],
            d[0] * r[1][0] + d[1] * r[1][1] + d[2] * r[1][2],
            d[0] * r[2][0] + d[1] * r[2][1] + d[2] * r[2][2],
        ];
        let c: [f32; 4] = std::array::from_fn(|j| {
            let p = &self.projection[j];
            (v[0] * p[0] as f64 + v[1] * p[1] as f64 + v[2] * p[2] as f64 + p[3] as f64) as f32
        });
        (c[3] > 1.0).then_some(c)
    }

    fn distance(&self, world: [f32; 3]) -> f32 {
        let d: [f64; 3] = std::array::from_fn(|i| world[i] as f64 - self.position[i]);
        (d[0] * d[0] + d[1] * d[1] + d[2] * d[2]).sqrt() as f32
    }

    fn ndc(&self, world: [f32; 3]) -> Option<[f32; 2]> {
        self.clip(world).map(|c| [c[0] / c[3], c[1] / c[3]])
    }
}

struct Mapped(*const u8);
// SAFETY: a read-only view of shared memory, read only with the frame's mutex held.
unsafe impl Send for Mapped {}

fn open(name: PCWSTR) -> Option<Mapped> {
    // SAFETY: plain mapping calls; the view stays for the process's life (the handle isn't needed after mapping).
    unsafe {
        let handle = OpenFileMappingW(FILE_MAP_READ.0, false, name).ok()?;
        let view: MEMORY_MAPPED_VIEW_ADDRESS = MapViewOfFile(handle, FILE_MAP_READ, 0, 0, 0);
        let _ = CloseHandle(handle);
        (!view.Value.is_null()).then_some(Mapped(view.Value as *const u8))
    }
}

#[derive(Default)]
struct Scene {
    ribbon: Vec<([f32; 3], [f32; 3], [f32; 3], bool)>,
    quads: Vec<([[f32; 3]; 4], [f32; 4])>,
    labels: Vec<([f32; 3], f32, f32, bool)>,
    lead: Vec<[f32; 3]>,
    /// How far the ribbon turns to its second colour (0: never), and that colour.
    target: f32,
    second: [f32; 4],
    /// The labels' size against the overlay's 18 px text.
    label: f32,
}

fn f_at(b: &[u8], o: usize) -> f32 {
    f32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]])
}

fn u_at(b: &[u8], o: usize) -> usize {
    u32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]]) as usize
}

fn v3(b: &[u8], o: usize) -> [f32; 3] {
    [f_at(b, o), f_at(b, o + 4), f_at(b, o + 8)]
}

/// A colour of the overlay's: R, G, B, A from the top byte down.
fn rgba(c: u32) -> [f32; 4] {
    [(c >> 24) as f32 / 255.0, ((c >> 16) & 255) as f32 / 255.0, ((c >> 8) & 255) as f32 / 255.0, (c & 255) as f32 / 255.0]
}

fn parse_scene(b: &[u8], now_ms: f64) -> Option<Scene> {
    if b.len() < SIZE || u_at(b, 0) as u32 != MAGIC {
        return None;
    }
    let written = f64::from_le_bytes(b[24..32].try_into().ok()?);
    if !(now_ms - written).is_finite() || now_ms - written > STALE_MS {
        return None;
    }
    let (points, quads, labels, lead) = (u_at(b, 8).min(MAX_POINTS), u_at(b, 12).min(MAX_QUADS), u_at(b, 16).min(MAX_LABELS), u_at(b, 20).min(4));
    let label = f_at(b, 40);
    let label = if label > 0.0 { label.clamp(0.4, 1.5) } else { 0.7 };
    let mut s = Scene { label, target: f_at(b, 32), second: rgba(u32::from_le_bytes([b[36], b[37], b[38], b[39]])), ..Scene::default() };
    let mut o = HEADER;
    for i in 0..points {
        let p = o + i * POINT;
        s.ribbon.push((v3(b, p), v3(b, p + 12), v3(b, p + 24), f_at(b, p + 36) > 0.5));
    }
    o += MAX_POINTS * POINT;
    for i in 0..quads {
        let p = o + i * QUAD;
        s.quads.push(([v3(b, p), v3(b, p + 12), v3(b, p + 24), v3(b, p + 36)], [f_at(b, p + 48), f_at(b, p + 52), f_at(b, p + 56), f_at(b, p + 60)]));
    }
    o += MAX_QUADS * QUAD;
    for i in 0..labels {
        let p = o + i * LABEL;
        s.labels.push((v3(b, p), f_at(b, p + 12), f_at(b, p + 16), f_at(b, p + 20) > 0.5));
    }
    o += MAX_LABELS * LABEL;
    for i in 0..lead {
        s.lead.push(v3(b, o + i * 12));
    }
    Some(s)
}

struct Builder {
    v: Vec<V>,
    size: [f32; 2],
    adv: [f32; 96],
}

const NO_UV: [f32; 2] = [-1.0, -1.0];

impl Builder {
    fn tri(&mut self, a: V, b: V, c: V) {
        if self.v.len() + 3 <= MAX_VERTS {
            self.v.extend_from_slice(&[a, b, c]);
        }
    }

    fn px(&self, x: f32, y: f32) -> [f32; 2] {
        [x / self.size[0] * 2.0 - 1.0, 1.0 - y / self.size[1] * 2.0]
    }

    fn rect(&mut self, x0: f32, y0: f32, x1: f32, y1: f32, c: [f32; 4]) {
        let (a, b, d, e) = (self.px(x0, y0), self.px(x1, y0), self.px(x0, y1), self.px(x1, y1));
        let v = |p| V { p, c, uv: NO_UV, k: 0.0 };
        self.tri(v(a), v(b), v(d));
        self.tri(v(b), v(e), v(d));
    }

    fn line(&mut self, a: [f32; 2], b: [f32; 2], width: f32, c: [f32; 4]) {
        // In pixels, so a line is as thick at any distance.
        let (ax, ay) = ((a[0] + 1.0) * 0.5 * self.size[0], (1.0 - a[1]) * 0.5 * self.size[1]);
        let (bx, by) = ((b[0] + 1.0) * 0.5 * self.size[0], (1.0 - b[1]) * 0.5 * self.size[1]);
        let (dx, dy) = (bx - ax, by - ay);
        let l = (dx * dx + dy * dy).sqrt().max(0.001);
        let (nx, ny) = (-dy / l * width * 0.5, dx / l * width * 0.5);
        let pts = [self.px(ax + nx, ay + ny), self.px(bx + nx, by + ny), self.px(ax - nx, ay - ny), self.px(bx - nx, by - ny)];
        let v = |p| V { p, c, uv: NO_UV, k: 0.0 };
        self.tri(v(pts[0]), v(pts[1]), v(pts[2]));
        self.tri(v(pts[1]), v(pts[3]), v(pts[2]));
    }

    fn round_rect(&mut self, x0: f32, y0: f32, x1: f32, y1: f32, r: f32, fill: [f32; 4], border: [f32; 4]) {
        let path = |inset: f32| -> Vec<(f32, f32)> {
            let rr = (r - inset).max(0.0);
            let corners = [(x0 + r, y0 + r, 180.0f32), (x1 - r, y0 + r, 270.0), (x1 - r, y1 - r, 0.0), (x0 + r, y1 - r, 90.0)];
            let mut out = Vec::with_capacity(28);
            for (cx, cy, from) in corners {
                for k in 0..=6 {
                    let a = (from + k as f32 * 15.0).to_radians();
                    out.push((cx + rr * a.cos(), cy + rr * a.sin()));
                }
            }
            out
        };
        let (outer, inner) = (path(0.0), path(1.0));
        let n = outer.len();
        let v = |b: &Builder, q: (f32, f32), c: [f32; 4]| V { p: b.px(q.0, q.1), c, uv: NO_UV, k: 0.0 };
        let mid = ((x0 + x1) * 0.5, (y0 + y1) * 0.5);
        for i in 0..n {
            let j = (i + 1) % n;
            let (a, e, g) = (v(self, mid, fill), v(self, inner[i], fill), v(self, inner[j], fill));
            self.tri(a, e, g);
            let (o0, o1, i0, i1) = (v(self, outer[i], border), v(self, outer[j], border), v(self, inner[i], border), v(self, inner[j], border));
            self.tri(o0, o1, i0);
            self.tri(o1, i1, i0);
        }
    }

    fn text_width(&self, t: &str, scale: f32) -> f32 {
        t.bytes().map(|b| self.adv[(b.clamp(32, 127) - 32) as usize] * scale).sum()
    }

    fn text(&mut self, t: &str, mut x: f32, y: f32, scale: f32, c: [f32; 4]) {
        for b in t.bytes() {
            let i = (b.clamp(32, 127) - 32) as usize;
            let (u0, v0) = ((i % 16 * CELL.0) as f32 / ATLAS.0 as f32, (i / 16 * CELL.1) as f32 / ATLAS.1 as f32);
            let (du, dv) = (CELL.0 as f32 / ATLAS.0 as f32, CELL.1 as f32 / ATLAS.1 as f32);
            let (w, h) = (CELL.0 as f32 * scale, CELL.1 as f32 * scale);
            let (a, e, d, f) = (self.px(x, y), self.px(x + w, y), self.px(x, y + h), self.px(x + w, y + h));
            let v = |p, uv| V { p, c, uv, k: 1.0 };
            self.tri(v(a, [u0, v0]), v(e, [u0 + du, v0]), v(d, [u0, v0 + dv]));
            self.tri(v(e, [u0 + du, v0]), v(f, [u0 + du, v0 + dv]), v(d, [u0, v0 + dv]));
            x += self.adv[i] * scale;
        }
    }
}

fn b_push(b: &mut Builder, a: V, c: V, d: V, e: V) {
    b.tri(a, c, d);
    b.tri(a, d, e);
}

fn build(scene: &Scene, camera: &Camera, size: [f32; 2], adv: [f32; 96]) -> Vec<V> {
    let mut b = Builder { v: Vec::with_capacity(6000), size, adv };
    // As `ARRenderer.Draw3DLineWithGradient`, on the same points, with the same fades.
    const PRIMARY: u32 = 8960904;
    const MAX_DISTANCE: f32 = 150.0;
    let primary = rgba(PRIMARY);
    let distance = |w: [f32; 3]| camera.distance(w);
    let colour = |d: f32| -> [f32; 4] {
        let (from, to) = (scene.target - 10.0, scene.target + 10.0);
        if scene.target > 0.0 && d >= from && d <= to {
            let t = (d - from) / (to - from);
            std::array::from_fn(|i| primary[i] + (scene.second[i] - primary[i]) * t)
        } else if scene.target > 0.0 && d >= to {
            scene.second
        } else {
            primary
        }
    };
    let progress = |d: f32| -> f32 {
        if d < 15.0 {
            1.0
        } else if d < 35.0 {
            (d - 35.0) / (15.0 - 35.0)
        } else if d > 60.0 {
            (d - 60.0) / (150.0 - 60.0)
        } else {
            0.0
        }
    };
    for i in 1..scene.ribbon.len() {
        let (l1, c1, r1, start) = scene.ribbon[i];
        if start {
            continue;
        }
        let (l0, c0, r0, _) = scene.ribbon[i - 1];
        for (o0, o1) in [(l0, l1), (r0, r1)] {
            if [o0, c0, o1, c1].iter().all(|w| distance(*w) > MAX_DISTANCE) {
                continue;
            }
            let (Some(n0), Some(n1), Some(n2), Some(n3)) = (camera.ndc(o0), camera.ndc(c0), camera.ndc(c1), camera.ndc(o1)) else {
                continue;
            };
            let (d0, d1) = (distance(o0), distance(o1));
            let (c_start, c_end, p0, p1) = (colour(d0), colour(d1), progress(d0), progress(d1));
            let v = |p, c, u: f32, y: f32| V { p, c, uv: [u, y], k: 2.0 };
            let (va, vb, vc, vd) = (v(n0, c_start, -1.0, p0), v(n1, c_start, 1.0, p0), v(n2, c_end, 1.0, p1), v(n3, c_end, -1.0, p1));
            b_push(&mut b, va, vb, vc, vd);
        }
    }
    for (corners, c) in &scene.quads {
        let (Some(p0), Some(p1), Some(p2), Some(p3)) = (camera.ndc(corners[0]), camera.ndc(corners[1]), camera.ndc(corners[2]), camera.ndc(corners[3])) else {
            continue;
        };
        let v = |p| V { p, c: *c, uv: NO_UV, k: 0.0 };
        b.tri(v(p0), v(p1), v(p2));
        b.tri(v(p0), v(p2), v(p3));
    }
    if scene.lead.len() == 4 {
        let c = [0.22, 0.74, 0.97, 1.0];
        for i in 0..4 {
            if let (Some(p), Some(q)) = (camera.ndc(scene.lead[i]), camera.ndc(scene.lead[(i + 1) % 4])) {
                b.line(p, q, 2.0, c);
            }
        }
    }
    // As `Draw3DText` with DriveHud's arguments: 18 px text, padding 8 and 5, rounding 6, border 1.
    let size_of_label = scene.label;
    let scale = 18.0 * size_of_label / FONT_HEIGHT;
    let line = (18.0 * size_of_label).round();
    let (pad_x, pad_y, radius) = (8.0 * size_of_label, 5.0 * size_of_label, 6.0 * size_of_label);
    for (at, speed, distance, lead) in &scene.labels {
        let Some(p) = camera.ndc(*at) else { continue };
        let (sx, sy) = ((p[0] + 1.0) * 0.5 * size[0], (1.0 - p[1]) * 0.5 * size[1]);
        let (one, two) = (format!("{speed:.0} km/sa"), format!("{distance:.0} m"));
        let tw = b.text_width(&one, scale).max(b.text_width(&two, scale));
        let (tx, ty) = ((sx - tw * 0.5).round(), (sy - line * 2.0).round());
        let border = rgba(if *lead { 951974143 } else { 2810968831 });
        b.round_rect(tx - pad_x, ty - pad_y, tx + tw + pad_x, ty + line * 2.0 + pad_y, radius, rgba(252385996), border);
        let white = [1.0, 1.0, 1.0, 1.0];
        b.text(&one, tx, ty - 2.0 * scale, scale, white);
        b.text(&two, tx, ty + line - 2.0 * scale, scale, white);
    }
    b.v
}

struct Gpu {
    device: usize,
    state: ID3DDeviceContextState,
    vs: ID3D11VertexShader,
    ps: ID3D11PixelShader,
    layout: ID3D11InputLayout,
    vb: ID3D11Buffer,
    blend: ID3D11BlendState,
    raster: ID3D11RasterizerState,
    depth: ID3D11DepthStencilState,
    sampler: ID3D11SamplerState,
    atlas: ID3D11ShaderResourceView,
    adv: [f32; 96],
}

#[derive(Default)]
struct State {
    gpu: Option<Gpu>,
    failed: bool,
    camera: Option<Mapped>,
    hud: Option<Mapped>,
    tried: u64,
    buffer: Vec<u8>,
}
// SAFETY: its COM objects are used on the game's render thread only, through the mutex.
unsafe impl Send for State {}

static STATE: LazyLock<Mutex<State>> = LazyLock::new(|| Mutex::new(State::default()));

fn compile(entry: PCSTR, target: PCSTR) -> Result<Vec<u8>, String> {
    let (mut code, mut errors): (Option<ID3DBlob>, Option<ID3DBlob>) = (None, None);
    // SAFETY: the source is a live string of its length; blobs are read within their sizes.
    unsafe {
        let r = D3DCompile(SHADER.as_ptr() as *const c_void, SHADER.len(), s!("archud"), None, None, entry, target, 0, 0, &mut code, Some(&mut errors));
        let bytes = |b: &ID3DBlob| std::slice::from_raw_parts(b.GetBufferPointer() as *const u8, b.GetBufferSize()).to_vec();
        match (r, code) {
            (Ok(()), Some(c)) => Ok(bytes(&c)),
            (r, _) => Err(format!("shader: {:?} {}", r.err(), errors.as_ref().map(|e| String::from_utf8_lossy(&bytes(e)).into_owned()).unwrap_or_default())),
        }
    }
}

/// The font: white glyphs of ASCII on black, drawn by Windows, and each glyph's advance.
fn font_atlas() -> Result<(Vec<u8>, [f32; 96]), String> {
    let (w, h) = (ATLAS.0 as i32, ATLAS.1 as i32);
    // SAFETY: GDI objects made and released here; the DIB's memory is read within its size while selected.
    unsafe {
        let dc = CreateCompatibleDC(None);
        let mut bits: *mut c_void = std::ptr::null_mut();
        let info = BITMAPINFO {
            bmiHeader: BITMAPINFOHEADER {
                biSize: size_of::<BITMAPINFOHEADER>() as u32,
                biWidth: w,
                biHeight: -h,
                biPlanes: 1,
                biBitCount: 32,
                biCompression: BI_RGB.0,
                ..Default::default()
            },
            ..Default::default()
        };
        let bitmap = CreateDIBSection(Some(dc), &info, DIB_RGB_COLORS, &mut bits, None, 0).map_err(|e| format!("dib: {e}"))?;
        let old = SelectObject(dc, bitmap.into());
        let mut fonts = 0u32;
        const GEIST: &[u8] = include_bytes!("Geist-Regular.ttf");
        let _ = AddFontMemResourceEx(GEIST.as_ptr() as *const c_void, GEIST.len() as u32, None, &mut fonts);
        let font = CreateFontW(FONT_HEIGHT as i32, 0, 0, 0, 400, 0, 0, 0, DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, ANTIALIASED_QUALITY, 0, w!("Geist"));
        let old_font = SelectObject(dc, font.into());
        SetBkMode(dc, TRANSPARENT);
        SetTextColor(dc, windows::Win32::Foundation::COLORREF(0x00ff_ffff));
        let mut adv = [0.0f32; 96];
        for i in 0..96u16 {
            let ch = [32 + i];
            let (x, y) = ((i as usize % 16 * CELL.0) as i32, (i as usize / 16 * CELL.1) as i32);
            let _ = TextOutW(dc, x + 1, y + 2, &ch);
            let mut sz = windows::Win32::Foundation::SIZE::default();
            let _ = GetTextExtentPoint32W(dc, &ch, &mut sz);
            adv[i as usize] = sz.cx as f32;
        }
        let _ = GdiFlush();
        let source = std::slice::from_raw_parts(bits as *const u8, (w * h * 4) as usize);
        let out: Vec<u8> = source.chunks_exact(4).map(|p| p[0].max(p[1]).max(p[2])).collect();
        SelectObject(dc, old_font);
        SelectObject(dc, old);
        let _ = DeleteObject(font.into());
        let _ = DeleteObject(bitmap.into());
        let _ = DeleteDC(dc);
        Ok((out, adv))
    }
}

fn make(device: &ID3D11Device) -> Result<Gpu, String> {
    let e = |what: &'static str| move |err: windows::core::Error| format!("{what}: {err}");
    // SAFETY: the game's live device; descriptions and data are locals living through their calls.
    unsafe {
        let device1: ID3D11Device1 = device.cast().map_err(e("device1"))?;
        let mut state = None;
        device1.CreateDeviceContextState(0, &[device.GetFeatureLevel()], D3D11_SDK_VERSION, &ID3D11Device::IID, None, Some(&mut state)).map_err(e("state"))?;
        let (vs_code, ps_code) = (compile(s!("vs"), s!("vs_5_0"))?, compile(s!("ps"), s!("ps_5_0"))?);
        let (mut vs, mut ps, mut layout, mut vb, mut blend, mut raster, mut depth, mut sampler, mut atlas_tex, mut atlas) = (None, None, None, None, None, None, None, None, None, None);
        device.CreateVertexShader(&vs_code, None, Some(&mut vs)).map_err(e("vs"))?;
        device.CreatePixelShader(&ps_code, None, Some(&mut ps)).map_err(e("ps"))?;
        let element = |name: PCSTR, format, offset| D3D11_INPUT_ELEMENT_DESC {
            SemanticName: name,
            SemanticIndex: 0,
            Format: format,
            InputSlot: 0,
            AlignedByteOffset: offset,
            InputSlotClass: D3D11_INPUT_PER_VERTEX_DATA,
            InstanceDataStepRate: 0,
        };
        device
            .CreateInputLayout(
                &[element(s!("POSITION"), DXGI_FORMAT_R32G32_FLOAT, 0), element(s!("COLOR"), DXGI_FORMAT_R32G32B32A32_FLOAT, 8), element(s!("TEXCOORD"), DXGI_FORMAT_R32G32_FLOAT, 24), element(s!("KIND"), DXGI_FORMAT_R32_FLOAT, 32)],
                &vs_code,
                Some(&mut layout),
            )
            .map_err(e("layout"))?;
        device
            .CreateBuffer(
                &D3D11_BUFFER_DESC {
                    ByteWidth: (MAX_VERTS * size_of::<V>()) as u32,
                    Usage: D3D11_USAGE_DYNAMIC,
                    BindFlags: D3D11_BIND_VERTEX_BUFFER.0 as u32,
                    CPUAccessFlags: D3D11_CPU_ACCESS_WRITE.0 as u32,
                    ..Default::default()
                },
                None,
                Some(&mut vb),
            )
            .map_err(e("vb"))?;
        let mut blend_desc = D3D11_BLEND_DESC::default();
        blend_desc.RenderTarget[0] = D3D11_RENDER_TARGET_BLEND_DESC {
            BlendEnable: true.into(),
            SrcBlend: D3D11_BLEND_SRC_ALPHA,
            DestBlend: D3D11_BLEND_INV_SRC_ALPHA,
            BlendOp: D3D11_BLEND_OP_ADD,
            SrcBlendAlpha: D3D11_BLEND_ZERO,
            DestBlendAlpha: D3D11_BLEND_ONE,
            BlendOpAlpha: D3D11_BLEND_OP_ADD,
            RenderTargetWriteMask: D3D11_COLOR_WRITE_ENABLE_ALL.0 as u8,
        };
        device.CreateBlendState(&blend_desc, Some(&mut blend)).map_err(e("blend"))?;
        device.CreateRasterizerState(&D3D11_RASTERIZER_DESC { FillMode: D3D11_FILL_SOLID, CullMode: D3D11_CULL_NONE, ..Default::default() }, Some(&mut raster)).map_err(e("raster"))?;
        device
            .CreateDepthStencilState(&D3D11_DEPTH_STENCIL_DESC { DepthEnable: false.into(), DepthWriteMask: D3D11_DEPTH_WRITE_MASK_ZERO, DepthFunc: D3D11_COMPARISON_ALWAYS, ..Default::default() }, Some(&mut depth))
            .map_err(e("depth"))?;
        device
            .CreateSamplerState(
                &D3D11_SAMPLER_DESC {
                    Filter: D3D11_FILTER_MIN_MAG_MIP_LINEAR,
                    AddressU: D3D11_TEXTURE_ADDRESS_CLAMP,
                    AddressV: D3D11_TEXTURE_ADDRESS_CLAMP,
                    AddressW: D3D11_TEXTURE_ADDRESS_CLAMP,
                    MaxLOD: f32::MAX,
                    ..Default::default()
                },
                Some(&mut sampler),
            )
            .map_err(e("sampler"))?;
        let (pixels, adv) = font_atlas()?;
        device
            .CreateTexture2D(
                &D3D11_TEXTURE2D_DESC {
                    Width: ATLAS.0 as u32,
                    Height: ATLAS.1 as u32,
                    MipLevels: 1,
                    ArraySize: 1,
                    Format: DXGI_FORMAT_R8_UNORM,
                    SampleDesc: DXGI_SAMPLE_DESC { Count: 1, Quality: 0 },
                    Usage: D3D11_USAGE_IMMUTABLE,
                    BindFlags: D3D11_BIND_SHADER_RESOURCE.0 as u32,
                    ..Default::default()
                },
                Some(&D3D11_SUBRESOURCE_DATA { pSysMem: pixels.as_ptr() as *const c_void, SysMemPitch: ATLAS.0 as u32, SysMemSlicePitch: 0 }),
                Some(&mut atlas_tex),
            )
            .map_err(e("atlas"))?;
        let texture: ID3D11Texture2D = atlas_tex.ok_or("no atlas")?;
        device.CreateShaderResourceView(&texture, None, Some(&mut atlas)).map_err(e("atlas view"))?;
        Ok(Gpu {
            device: device.as_raw() as usize,
            state: state.ok_or("no state")?,
            vs: vs.ok_or("no vs")?,
            ps: ps.ok_or("no ps")?,
            layout: layout.ok_or("no layout")?,
            vb: vb.ok_or("no vb")?,
            blend: blend.ok_or("no blend")?,
            raster: raster.ok_or("no raster")?,
            depth: depth.ok_or("no depth")?,
            sampler: sampler.ok_or("no sampler")?,
            atlas: atlas.ok_or("no atlas view")?,
            adv,
        })
    }
}

/// At the game's Present: draws the HUD into the frame about to be shown.
///
/// # Safety
/// The game's live swap chain, on its render thread, from the Present hook.
pub unsafe fn draw(chain: &IDXGISwapChain, frame: u64) {
    let mut guard = STATE.lock().unwrap_or_else(|e| e.into_inner());
    let st = &mut *guard;
    if st.failed {
        return;
    }
    if (st.camera.is_none() || st.hud.is_none()) && frame.saturating_sub(st.tried) > 120 {
        st.tried = frame;
        if st.camera.is_none() {
            st.camera = open(w!("Local\\ETS2LACameraProps"));
        }
        if st.hud.is_none() {
            st.hud = open(w!("Local\\ARCHud"));
        }
    }
    let (Some(camera_map), Some(hud_map)) = (st.camera.as_ref(), st.hud.as_ref()) else { return };
    // SAFETY: both views are at least as long as read (the camera's 128 bytes, the HUD's `SIZE`).
    let scene = unsafe {
        let head = std::slice::from_raw_parts(hud_map.0, HEADER);
        let seq = u32::from_le_bytes([head[4], head[5], head[6], head[7]]);
        if seq & 1 != 0 {
            return;
        }
        st.buffer.resize(SIZE, 0);
        std::ptr::copy_nonoverlapping(hud_map.0, st.buffer.as_mut_ptr(), SIZE);
        let after = (hud_map.0.add(4) as *const u32).read_unaligned();
        if after != seq {
            return;
        }
        let now = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs_f64() * 1000.0).unwrap_or(0.0);
        let Some(scene) = parse_scene(&st.buffer, now) else { return };
        scene
    };
    // SAFETY: the camera's view is 128 bytes.
    let Some(camera) = Camera::parse(unsafe { std::slice::from_raw_parts(camera_map.0, 100) }) else { return };
    if scene.ribbon.is_empty() && scene.quads.is_empty() && scene.labels.is_empty() && scene.lead.is_empty() {
        return;
    }
    // SAFETY: the game's live chain and device on its render thread; the game's pipeline is swapped out and back.
    unsafe {
        let Ok(device) = chain.GetDevice::<ID3D11Device>() else { return };
        if st.gpu.as_ref().is_none_or(|g| g.device != device.as_raw() as usize) {
            match make(&device) {
                Ok(g) => {
                    crate::log!("hud: ready");
                    st.gpu = Some(g);
                }
                Err(e) => {
                    crate::log!("hud: cannot draw: {e}");
                    st.failed = true;
                    return;
                }
            }
        }
        let Some(gpu) = st.gpu.as_ref() else { return };
        let Ok(back) = chain.GetBuffer::<ID3D11Texture2D>(0) else { return };
        let mut desc = D3D11_TEXTURE2D_DESC::default();
        back.GetDesc(&mut desc);
        let mut target = None;
        if device.CreateRenderTargetView(&back, None, Some(&mut target)).is_err() {
            return;
        }
        let verts = build(&scene, &camera, [desc.Width as f32, desc.Height as f32], gpu.adv);
        if verts.is_empty() {
            return;
        }
        let Ok(context) = device.GetImmediateContext() else { return };
        let Ok(context1) = context.cast::<ID3D11DeviceContext1>() else { return };
        let mut games: Option<ID3DDeviceContextState> = None;
        context1.SwapDeviceContextState(&gpu.state, Some(&mut games));
        let mut mapped = D3D11_MAPPED_SUBRESOURCE::default();
        if context.Map(&gpu.vb, 0, D3D11_MAP_WRITE_DISCARD, 0, Some(&mut mapped)).is_ok() {
            std::ptr::copy_nonoverlapping(verts.as_ptr(), mapped.pData as *mut V, verts.len());
            context.Unmap(&gpu.vb, 0);
            let stride = size_of::<V>() as u32;
            let offset = 0u32;
            context.IASetInputLayout(&gpu.layout);
            context.IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
            context.IASetVertexBuffers(0, 1, Some(&Some(gpu.vb.clone())), Some(&stride), Some(&offset));
            context.VSSetShader(&gpu.vs, None);
            context.PSSetShader(&gpu.ps, None);
            context.PSSetShaderResources(0, Some(&[Some(gpu.atlas.clone())]));
            context.PSSetSamplers(0, Some(&[Some(gpu.sampler.clone())]));
            context.RSSetState(&gpu.raster);
            context.RSSetViewports(Some(&[D3D11_VIEWPORT { TopLeftX: 0.0, TopLeftY: 0.0, Width: desc.Width as f32, Height: desc.Height as f32, MinDepth: 0.0, MaxDepth: 1.0 }]));
            context.OMSetRenderTargets(Some(&[target.clone()]), None);
            context.OMSetBlendState(&gpu.blend, None, 0xffff_ffff);
            context.OMSetDepthStencilState(&gpu.depth, 0);
            context.Draw(verts.len() as u32, 0);
            context.OMSetRenderTargets(None, None);
            context.PSSetShaderResources(0, Some(&[None]));
        }
        context1.SwapDeviceContextState(games.as_ref(), None);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The numbers System.Numerics gives for the same camera (`ARRenderer.GetViewMatrix`, printed by a C# run).
    #[test]
    fn the_camera_is_the_overlays_camera() {
        let mut b = vec![0u8; 100];
        let mut put = |o: usize, v: f32| b[o..o + 4].copy_from_slice(&v.to_le_bytes());
        put(4, 100.0);
        put(8, 50.0);
        put(12, -30.0);
        let q = [0.0434f32, 0.2995, -0.0137, 0.9530];
        for (i, v) in q.iter().enumerate() {
            put(20 + i * 4, *v);
        }
        let p: [f32; 16] = [1.2, 0.0, 0.0, 0.0, 0.0, 2.1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.1, 0.0, 0.0, -1.0, 0.0];
        for (i, v) in p.iter().enumerate() {
            put(36 + i * 4, *v);
        }
        b[16..18].copy_from_slice(&2i16.to_le_bytes());
        b[18..20].copy_from_slice(&(-1i16).to_le_bytes());
        let c = Camera::parse(&b).unwrap();
        let clip = c.clip([1140.0, 52.0, -570.0]);
        let expected: Option<[f32; 4]> = option_env!("ARCHUD_EXPECT").map(|t| {
            let v: Vec<f32> = t.split(',').map(|x| x.parse().unwrap()).collect();
            [v[0], v[1], v[2], v[3]]
        });
        println!("clip {clip:?}");
        if let (Some(e), Some(c)) = (expected, clip) {
            for i in 0..4 {
                assert!((e[i] - c[i]).abs() < 1e-2 * e[i].abs().max(1.0), "{e:?} {c:?}");
            }
        }
    }

    #[test]
    fn the_shaders_compile() {
        compile(s!("vs"), s!("vs_5_0")).unwrap();
        compile(s!("ps"), s!("ps_5_0")).unwrap();
    }

    #[test]
    fn a_stale_or_foreign_scene_is_not_drawn() {
        let mut b = vec![0u8; SIZE];
        assert!(parse_scene(&b, 1000.0).is_none());
        b[0..4].copy_from_slice(&MAGIC.to_le_bytes());
        b[24..32].copy_from_slice(&1000.0f64.to_le_bytes());
        assert!(parse_scene(&b, 1500.0).is_some());
        assert!(parse_scene(&b, 9000.0).is_none());
    }

    #[test]
    fn the_font_is_made() {
        let (pixels, adv) = font_atlas().unwrap();
        assert_eq!(pixels.len(), ATLAS.0 * ATLAS.1);
        assert!(pixels.iter().any(|p| *p > 200));
        assert!(adv[('5' as usize) - 32] > 5.0);
    }

    #[test]
    fn behind_the_camera_is_nothing() {
        let b = {
            let mut b = vec![0u8; 100];
            b[32..36].copy_from_slice(&1f32.to_le_bytes());
            let p: [f32; 16] = [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.1, 0.0, 0.0, -1.0, 0.0];
            for (i, v) in p.iter().enumerate() {
                b[36 + i * 4..40 + i * 4].copy_from_slice(&v.to_le_bytes());
            }
            b
        };
        let c = Camera::parse(&b).unwrap();
        let (a, z) = (c.clip([0.0, 0.0, 50.0]), c.clip([0.0, 0.0, -50.0]));
        assert!(a.is_some() != z.is_some(), "{a:?} {z:?}");
    }
}
