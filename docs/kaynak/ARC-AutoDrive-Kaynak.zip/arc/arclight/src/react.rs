//! Brake and blinkers in the cab (`tepki 1`): while the truck's brake lights are lit both cab lights glow red, and
//! the side whose blinker lamp is lit glows amber, so it blinks with the lamp itself.

use crate::config::Light;
use crate::trucks::Cabin;

/// The truck's lamps as the SDK tells them: lit right now (a blinker's lamp goes on and off as it blinks).
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Signals {
    pub brake: bool,
    pub left: bool,
    pub right: bool,
}

pub const RED: [f32; 3] = [255.0, 24.0, 16.0];
pub const AMBER: [f32; 3] = [255.0, 130.0, 0.0];

/// The lights to add for the lamps: none, or one per side of the cab.
pub fn lights(cabin: &Cabin, s: Signals) -> Vec<Light> {
    // Above each seat, a little in front of the head, shining down and forward (as the old default cab lights).
    let side = |x: f32, blink: bool| {
        let color = if blink { AMBER } else if s.brake { RED } else { return None };
        Some(Light { x, y: 0.30, z: -0.40, pitch: 70.0, color, strength: 2.0, reach: 2.5, cone: 140.0, soft: 0.5, ..Light::default() })
    };
    [side(cabin.left + 0.45, s.left), side(cabin.right - 0.45, s.right)].into_iter().flatten().collect()
}

/// The lights to draw and their fade: the lamps' lights first (never cut by a full list) and at full strength
/// even with the cab lights faded out (Ctrl+L, `acik 0`); the player's own lights keep their fade.
pub fn merge(user: Vec<Light>, fade: f32, react: Vec<Light>) -> (Vec<Light>, f32) {
    if react.is_empty() {
        return (user, fade);
    }
    let mut all = react;
    all.extend(user.into_iter().map(|l| Light { strength: l.strength * fade, ..l }));
    all.truncate(crate::config::MAX_LIGHTS);
    // shortcut: the LED strips (off in ARC, no setting) also draw at full while a lamp is lit; scale them too if they come back.
    (all, 1.0)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::trucks::{GENERIC, find};

    fn colors(v: &[Light]) -> Vec<[f32; 3]> {
        v.iter().map(|l| l.color).collect()
    }

    #[test]
    fn shown_even_with_the_cab_lights_faded_out() {
        let mine = Light { strength: 3.0, ..Light::default() };
        let red = lights(&GENERIC, Signals { brake: true, ..Default::default() });
        let (all, fade) = merge(vec![mine], 0.0, red.clone());
        assert_eq!(fade, 1.0);
        assert_eq!(colors(&all[..2]), vec![RED, RED]);
        assert_eq!(all[2].strength, 0.0);
        let (same, f) = merge(vec![mine], 0.4, Vec::new());
        assert_eq!((same, f), (vec![mine], 0.4));
    }

    #[test]
    fn kept_when_the_list_is_full() {
        let full = vec![Light::default(); crate::config::MAX_LIGHTS];
        let (all, _) = merge(full, 1.0, lights(&GENERIC, Signals { left: true, ..Default::default() }));
        assert_eq!(all.len(), crate::config::MAX_LIGHTS);
        assert_eq!(all[0].color, AMBER);
    }

    #[test]
    fn nothing_lit_no_lights() {
        assert!(lights(&GENERIC, Signals::default()).is_empty());
    }

    #[test]
    fn brake_lights_both_sides_red() {
        let l = lights(&GENERIC, Signals { brake: true, ..Default::default() });
        assert_eq!(colors(&l), vec![RED, RED]);
        assert!(l[0].x < l[1].x);
    }

    #[test]
    fn blinker_lights_its_side_amber() {
        let left = lights(&GENERIC, Signals { left: true, ..Default::default() });
        let right = lights(&GENERIC, Signals { right: true, ..Default::default() });
        assert_eq!(colors(&left), vec![AMBER]);
        assert_eq!(colors(&right), vec![AMBER]);
        assert!(left[0].x < 0.5 && right[0].x > 0.5, "left {} right {}", left[0].x, right[0].x);
    }

    #[test]
    fn blinker_over_brake_on_its_side() {
        let l = lights(&GENERIC, Signals { brake: true, right: true, ..Default::default() });
        assert_eq!(colors(&l), vec![RED, AMBER]);
    }

    #[test]
    fn hazards_both_amber() {
        let l = lights(&GENERIC, Signals { left: true, right: true, brake: true });
        assert_eq!(colors(&l), vec![AMBER, AMBER]);
    }

    #[test]
    fn inside_the_cab_also_right_hand_drive() {
        for cabin in [GENERIC, find(Some("vehicle.scania.s_2016"), false), find(Some("vehicle.scania.s_2016"), true)] {
            let l = lights(&cabin, Signals { left: true, right: true, ..Default::default() });
            assert!(l.iter().all(|l| l.x > cabin.left && l.x < cabin.right && l.on && l.strength > 0.0));
            assert!(l[0].x < l[1].x);
        }
    }
}
