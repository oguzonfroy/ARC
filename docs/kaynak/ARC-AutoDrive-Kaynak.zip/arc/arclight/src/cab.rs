//! The camera's turn in the cab, from what the game draws the cab with, as it draws the G-buffer (before its
//! light pass).
//!
//! Each material's vertex shader takes `transform0_data` at the start of the constant buffer piece bound to
//! its slot 0 (the game's shaders, effect.scs 1.61, `transform0_cb_t`): `mv_matrix` (4 rows, the model to the
//! eye's space: column vectors, `eye = M * model`), `mvp_matrix` (4 rows), `mvp_matrix_uncorrected` (4 rows),
//! and one more vector: 13 vectors, 208 bytes. Every part of the cab is drawn with its own `mv`: most parts
//! aren't turned in the cab, so the turn most `mv`s near the eye share is the cab's turn into the eye's space.
//! Kept within 15 degrees of the head's turn (the SDK's): the world's things near the truck and the mirrors'
//! views are turned otherwise.
//!
//! A piece is taken as such a block only if its rows hold up: `mv` a rotation and a move, and `mvp`'s
//! uncorrected rows `P * mv` for a perspective `P` (which is kept: the eye's projection).

use std::collections::HashMap;
use std::ffi::c_void;
use std::sync::{LazyLock, Mutex};

use windows::Win32::Graphics::Direct3D11::{D3D11_BIND_CONSTANT_BUFFER, D3D11_BUFFER_DESC, ID3D11Buffer, ID3D11Resource};
use windows::Win32::System::Memory::{MEM_COMMIT, MEMORY_BASIC_INFORMATION, VirtualQuery};
use windows::core::Interface;

use crate::math::{Mat3, angle_between, as_rotation, euler, transpose3};

/// The block's size: 13 vectors.
const BLOCK: usize = 13 * 16;
/// Parts this near the eye may be the cab's (metres).
const NEAR: f32 = 3.0;
const NEAREST: f32 = 0.1;
/// A turn within this of the head's (degrees) may be the camera's.
const GATE: f32 = 15.0;
/// Turns within this of each other (degrees) are the same.
const SAME: f32 = 0.05;
/// Parts looked at per frame at most.
const MAX_PARTS: usize = 512;
/// A frame without the camera carries the last one on (with the head's turn since) this many frames.
const CARRY: u64 = 30;

/// The eye of a frame.
#[derive(Clone, Copy, Debug)]
pub struct Eye {
    /// The cab's turn into the eye's space (column vectors: `eye = turn * cab`).
    pub turn: Mat3,
    /// The eye's projection: P[0][0], P[1][1], P[0][2], P[1][2], P[3][2] (column vectors: `clip.x = P00 x +
    /// P02 z`, `clip.w = P32 z`).
    pub projection: [f32; 5],
    pub frame: u64,
}

#[derive(Default)]
struct State {
    /// Each constant buffer's size (0: not one) and the memory of its last mapping.
    buffers: HashMap<usize, (u32, usize)>,
    /// Memory checked readable this frame: address -> (frame, readable).
    checked: HashMap<usize, (u64, bool)>,
    frame: u64,
    /// This frame's: the turns of the parts near the eye, and the projection.
    turns: Vec<Mat3>,
    projection: Option<[f32; 5]>,
    found: Option<Eye>,
    lean: Option<Mat3>,
    stats: Stats,
}

#[derive(Default, Clone, Copy)]
struct Stats {
    frames: u64,
    found: u64,
    carried: u64,
    pieces: u64,
    blocks: u64,
    near: u64,
    gated: u64,
}

static STATE: LazyLock<Mutex<State>> = LazyLock::new(|| Mutex::new(State::default()));

fn state() -> std::sync::MutexGuard<'static, State> {
    STATE.lock().unwrap_or_else(|e| e.into_inner())
}

/// After the game maps a resource: where a constant buffer's memory is now.
///
/// # Safety
/// From the `Map` hook after it succeeded: `resource` the game's, `data` its mapping.
pub unsafe fn on_map(resource: *mut c_void, data: *mut c_void) {
    if resource.is_null() || data.is_null() {
        return;
    }
    let mut s = state();
    // SAFETY: the game's live resource.
    let size = unsafe { buffer_size(&mut s.buffers, resource) };
    if size != 0 {
        s.buffers.insert(resource as usize, (size, data as usize));
    }
}

/// The memory of a constant buffer's last mapping, if it's readable this frame, and its size.
pub fn mapped(buffer: usize) -> Option<(usize, u32)> {
    let mut s = state();
    let (size, data) = s.buffers.get(&buffer).copied()?;
    (data != 0 && readable(&mut s, data, size as usize)).then_some((data, size))
}

/// Before the game binds constant buffers to the vertex shader: the piece at slot 0 read as a transform block.
///
/// # Safety
/// The game's `VSSetConstantBuffers(1)` arguments.
pub unsafe fn on_vs_constant_buffers(start: u32, count: u32, buffers: *const *mut c_void, first: *const u32, num: *const u32) {
    if start != 0 || count == 0 || buffers.is_null() {
        return;
    }
    // SAFETY: at least one buffer, and as many offsets and lengths when given (the caller's contract).
    let (buffer, offset, length) = unsafe {
        let b = *buffers;
        if first.is_null() || num.is_null() { (b, 0usize, usize::MAX) } else { (b, *first as usize * 16, *num as usize * 16) }
    };
    if buffer.is_null() || length < BLOCK {
        return;
    }
    let mut s = state();
    let s = &mut *s;
    if s.turns.len() >= MAX_PARTS {
        return;
    }
    // SAFETY: the game's live buffer.
    let size = unsafe { buffer_size(&mut s.buffers, buffer) } as usize;
    let Some(&(_, data)) = s.buffers.get(&(buffer as usize)) else { return };
    if size == 0 || data == 0 || offset + BLOCK > size || !readable(s, data, size) {
        return;
    }
    s.stats.pieces += 1;
    // SAFETY: within the buffer's memory, found committed and readable whole this frame.
    let f: [f32; 52] = unsafe { std::ptr::read_unaligned((data + offset) as *const [f32; 52]) };
    let Some((turn, distance, projection)) = transform_block(&f) else { return };
    s.stats.blocks += 1;
    s.projection.get_or_insert(projection);
    if (NEAREST..NEAR).contains(&distance) {
        s.stats.near += 1;
        s.turns.push(turn);
    }
}

/// A transform block's model turn (column vectors), its distance from the eye, and its projection, if it is
/// one: `mv`'s rows a rotation, and the uncorrected `mvp` rows `P * mv` for a perspective `P`.
fn transform_block(f: &[f32; 52]) -> Option<(Mat3, f32, [f32; 5])> {
    if !f.iter().all(|v| v.is_finite()) {
        return None;
    }
    let row = |i: usize| [f[4 * i], f[4 * i + 1], f[4 * i + 2], f[4 * i + 3]];
    let (r0, r1, r2) = (row(0), row(1), row(2));
    let turn = as_rotation(&[[r0[0], r0[1], r0[2]], [r1[0], r1[1], r1[2]], [r2[0], r2[1], r2[2]]])?;
    let t = [r0[3], r1[3], r2[3]];
    let distance = (t[0] * t[0] + t[1] * t[1] + t[2] * t[2]).sqrt();
    // P = mvp * mv^-1, mv^-1 = [R^T, -R^T t]: P's row i is mvp's row i times it.
    let p_row = |m: [f32; 4]| -> [f32; 4] {
        let mut out = [0.0; 4];
        for c in 0..3 {
            // (m * inv)[c] = sum_k m[k] * inv[k][c], inv[k][c] = R[c][k] for k, c < 3; inv[3][c] = 0.
            out[c] = (0..3).map(|k| m[k] * turn[c][k]).sum();
        }
        // Column 3: sum_k m[k] * inv[k][3] + m[3], inv[k][3] = -(R^T t)[k].
        let rt_t: [f32; 3] = std::array::from_fn(|k| (0..3).map(|j| turn[j][k] * t[j]).sum());
        out[3] = m[3] - (0..3).map(|k| m[k] * rt_t[k]).sum::<f32>();
        out
    };
    // Uncorrected rows 8..11 (the corrected ones may hold the target's own scale).
    let p: [[f32; 4]; 4] = [p_row(row(8)), p_row(row(9)), p_row(row(10)), p_row(row(11))];
    let small = |v: f32, scale: f32| v.abs() <= 1e-3 * scale.max(1.0);
    let perspective = (p[3][2].abs() - 1.0).abs() < 1e-3
        && small(p[3][0], 1.0)
        && small(p[3][1], 1.0)
        && small(p[3][3], 1.0)
        && p[0][0].abs() > 0.1
        && p[1][1].abs() > 0.1
        && small(p[0][1], p[0][0].abs())
        && small(p[1][0], p[1][1].abs())
        && small(p[0][3], 1.0)
        && small(p[1][3], 1.0);
    perspective.then_some((turn, distance, [p[0][0], p[1][1], p[0][2], p[1][2], p[3][2].signum()]))
}

/// The cab's turn into the eye's space among the near parts' turns: the one most share, within the gate of the
/// head's (`head`: the camera's axes in the cab, column vectors; the cab's turn into the eye is its inverse).
fn cab_turn(turns: &[Mat3], head: &Mat3) -> Option<Mat3> {
    let expected = transpose3(head);
    let near: Vec<&Mat3> = turns.iter().filter(|t| angle_between(&expected, t) < GATE).collect();
    let support = |t: &Mat3| near.iter().filter(|o| angle_between(t, o) < SAME).count();
    let (best, n) = near
        .iter()
        .map(|t| (**t, support(t)))
        .max_by(|(a, na), (b, nb)| na.cmp(nb).then_with(|| angle_between(&expected, b).total_cmp(&angle_between(&expected, a))))?;
    (n >= 2).then_some(best)
}

/// At the light pass (once a frame): the eye of this frame, from what was drawn before it. `head` is the SDK's
/// head offset (x, y, z, heading, pitch, roll), none without a truck.
pub fn at_light_pass(frame: u64, head: Option<[f32; 6]>) -> Option<Eye> {
    let mut s = state();
    let s = &mut *s;
    s.stats.frames += 1;
    let turns = std::mem::take(&mut s.turns);
    let projection = s.projection.take();
    let head = head.map(|h| euler(h[3], h[4], h[5]));
    let found = match (&head, projection) {
        (Some(h), Some(p)) => {
            s.stats.gated += turns.iter().filter(|t| angle_between(&transpose3(h), t) < GATE).count() as u64;
            cab_turn(&turns, h).map(|turn| (turn, p))
        }
        _ => None,
    };
    match (found, &head) {
        (Some((turn, projection)), Some(h)) => {
            s.stats.found += 1;
            // The camera's lean beyond the head's turn, carried on when a frame shows none.
            s.lean = Some(crate::math::mul3(&turn, h));
            s.found = Some(Eye { turn, projection, frame });
        }
        (None, Some(h)) => {
            let carried = match (s.found, s.lean) {
                (Some(last), Some(lean)) if frame.saturating_sub(last.frame) <= CARRY => {
                    // turn = lean * head^T (lean = turn * head).
                    Some(Eye { turn: crate::math::mul3(&lean, &transpose3(h)), ..last })
                }
                _ => None,
            };
            s.stats.carried += carried.is_some() as u64;
            s.found = carried;
        }
        _ => s.found = None,
    }
    if s.stats.frames >= 1800 {
        let t = s.stats;
        crate::log!(
            "cab: eye found in {}/{} light passes, carried in {}; pieces read {}, transform blocks {}, near the eye {}, near the head's turn {}",
            t.found,
            t.frames,
            t.carried,
            t.pieces,
            t.blocks,
            t.near,
            t.gated
        );
        s.stats = Stats::default();
    }
    s.found.filter(|e| e.frame == frame || frame.saturating_sub(e.frame) <= CARRY)
}

/// At a frame's end: what was read after the light pass is let go.
pub fn end_frame(next_frame: u64) {
    let mut s = state();
    s.turns.clear();
    s.projection = None;
    s.frame = next_frame;
}

/// # Safety
/// `resource` is a live resource of the game's.
unsafe fn buffer_size(buffers: &mut HashMap<usize, (u32, usize)>, resource: *mut c_void) -> u32 {
    if let Some(&(size, _)) = buffers.get(&(resource as usize)) {
        return size;
    }
    // SAFETY: the game's live resource, only asked what it is.
    let size = unsafe {
        ID3D11Resource::from_raw_borrowed(&resource)
            .and_then(|r| r.cast::<ID3D11Buffer>().ok())
            .map(|b| {
                let mut d = D3D11_BUFFER_DESC::default();
                b.GetDesc(&mut d);
                if d.BindFlags & D3D11_BIND_CONSTANT_BUFFER.0 as u32 != 0 { d.ByteWidth } else { 0 }
            })
            .unwrap_or(0)
    };
    if buffers.len() > 8192 {
        buffers.clear();
    }
    buffers.insert(resource as usize, (size, 0));
    size
}

/// Whether `size` bytes at `at` are committed, readable memory (asked of Windows once a frame per address).
fn readable(s: &mut State, at: usize, size: usize) -> bool {
    let frame = s.frame;
    if let Some(&(f, ok)) = s.checked.get(&at)
        && f == frame
    {
        return ok;
    }
    let mut info = MEMORY_BASIC_INFORMATION::default();
    // SAFETY: only asks about the address, into a local of its size.
    let answered = unsafe { VirtualQuery(Some(at as *const c_void), &mut info, size_of::<MEMORY_BASIC_INFORMATION>()) };
    let protect = info.Protect.0;
    let ok = answered >= size_of::<MEMORY_BASIC_INFORMATION>()
        && info.State == MEM_COMMIT
        && protect & 0x100 == 0
        && protect & 0xee != 0
        && (info.BaseAddress as usize).saturating_add(info.RegionSize) >= at.saturating_add(size);
    if s.checked.len() > 256 {
        s.checked.retain(|_, (f, _)| *f == frame);
    }
    s.checked.insert(at, (frame, ok));
    ok
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::math::{IDENTITY3, mul3};

    /// The block the game would upload for a part turned `part` and placed `at` (cab, from the eye), the cab
    /// turned `cab` into the eye's space.
    fn block(part: &Mat3, at: [f32; 3], cab: &Mat3) -> [f32; 52] {
        let r = mul3(cab, part);
        let t: [f32; 3] = std::array::from_fn(|i| (0..3).map(|k| cab[i][k] * at[k]).sum());
        let mv = [[r[0][0], r[0][1], r[0][2], t[0]], [r[1][0], r[1][1], r[1][2], t[1]], [r[2][0], r[2][1], r[2][2], t[2]], [0.0, 0.0, 0.0, 1.0]];
        let p = [[0.89, 0.0, 0.0002, 0.0], [0.0, 1.582, -0.0003, 0.0], [0.0, 0.0, 0.0, 0.2], [0.0, 0.0, -1.0, 0.0]];
        let mvp: [[f32; 4]; 4] = std::array::from_fn(|i| std::array::from_fn(|j| (0..4).map(|k| p[i][k] * mv[k][j]).sum()));
        let mut f = [0.0f32; 52];
        for i in 0..4 {
            for j in 0..4 {
                f[4 * i + j] = mv[i][j];
                f[16 + 4 * i + j] = mvp[i][j] * 1.25; // "corrected": scaled for the target
                f[32 + 4 * i + j] = mvp[i][j];
            }
        }
        f
    }

    #[test]
    fn reads_a_parts_block_and_its_projection() {
        let cab = transpose3(&euler(0.03, -0.02, 0.001));
        let (turn, d, p) = transform_block(&block(&IDENTITY3, [0.3, -0.4, -0.6], &cab)).unwrap();
        assert!(angle_between(&turn, &cab) < 1e-3);
        assert!((d - (0.09f32 + 0.16 + 0.36).sqrt()).abs() < 1e-4);
        assert!((p[0] - 0.89).abs() < 1e-4 && (p[1] - 1.582).abs() < 1e-4 && (p[2] - 0.0002).abs() < 1e-5);
        // Not a block: a stretched mv, or garbage.
        let mut bad = block(&IDENTITY3, [0.3, -0.4, -0.6], &cab);
        bad[0] *= 1.2;
        assert!(transform_block(&bad).is_none());
        assert!(transform_block(&[1.0; 52]).is_none());
    }

    #[test]
    fn the_cab_parts_give_the_cabs_turn() {
        let head = euler(0.03, -0.02, 0.0);
        let lean = euler(0.002, 0.004, -0.003);
        let camera_in_cab = mul3(&head, &lean);
        let cab = transpose3(&camera_in_cab);
        let mut turns = Vec::new();
        for at in [[0.3, -0.4, -0.6], [-0.2, -0.5, -0.8], [0.7, 0.1, -1.0]] {
            turns.push(transform_block(&block(&IDENTITY3, at, &cab)).unwrap().0);
        }
        turns.push(transform_block(&block(&euler(0.0, 0.03, 0.0), [0.0, -0.3, -0.5], &cab)).unwrap().0);
        for at in [[1.0, 0.0, -2.0], [-1.5, 0.5, -2.5], [0.5, 1.0, -2.0]] {
            turns.push(transform_block(&block(&euler(0.4, 0.0, 0.0), at, &cab)).unwrap().0);
        }
        let found = cab_turn(&turns, &head).unwrap();
        assert!(angle_between(&found, &cab) < 0.01);
    }
}
