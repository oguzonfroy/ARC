//! Each truck's cab, measured from its interior model in the game's files (`tools/led_tablo.py`): the lines the
//! LED strips run along. Metres, in the cab's space from the driver's head's default place (x right, y up, z back).

const TABLE: &str = include_str!("trucks.txt");

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Cabin {
    pub left: f32,
    pub right: f32,
    pub front: f32,
    pub back: f32,
    pub floor: f32,
    pub roof: f32,
    pub belt: f32,
    pub panel: f32,
}

/// For a truck not in the table (a mod's): the middle of the game's own trucks.
pub const GENERIC: Cabin = Cabin { left: -0.47, right: 1.88, front: -1.08, back: 0.98, floor: -1.12, roof: 1.03, belt: -0.30, panel: -0.28 };

fn parse(line: &str) -> Option<(&str, Cabin)> {
    let mut w = line.split_whitespace();
    let id = w.next()?;
    let v: Vec<f32> = w.map_while(|x| x.parse().ok()).collect();
    (v.len() == 8).then(|| (id, Cabin { left: v[0], right: v[1], front: v[2], back: v[3], floor: v[4], roof: v[5], belt: v[6], panel: v[7] }))
}

/// The cab of the truck `id` (the SDK's), turned over for a right-hand drive one.
pub fn find(id: Option<&str>, right_hand: bool) -> Cabin {
    let found = id.and_then(|id| TABLE.lines().filter_map(parse).find(|(k, _)| *k == id).map(|(_, c)| c)).unwrap_or(GENERIC);
    if right_hand { Cabin { left: -found.right, right: -found.left, ..found } } else { found }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_line_reads_and_is_a_cab() {
        let mut n = 0;
        for line in TABLE.lines() {
            let (id, c) = parse(line).unwrap_or_else(|| panic!("{line}"));
            assert!(id.starts_with("vehicle."));
            assert!(c.right - c.left > 1.8 && c.back - c.front > 1.5 && c.roof - c.floor > 1.5, "{id}: {c:?}");
            n += 1;
        }
        assert!(n >= 15);
    }

    #[test]
    fn known_generic_and_mirrored() {
        let s = find(Some("vehicle.scania.s_2016"), false);
        assert!(s != GENERIC && s.left < 0.0 && s.right > 1.0);
        assert_eq!(find(Some("vehicle.no.such"), false), GENERIC);
        let uk = find(Some("vehicle.scania.s_2016"), true);
        assert_eq!((uk.left, uk.right), (-s.right, -s.left));
    }
}
