//! A small log, `Documents\ARC Studio\kabin_isigi.log` (started over each time the game loads the plugin).

use std::io::Write;
use std::path::PathBuf;
use std::sync::{Mutex, OnceLock};
use std::time::Instant;

use windows::Win32::System::Com::CoTaskMemFree;
use windows::Win32::UI::Shell::{FOLDERID_Documents, KF_FLAG_DEFAULT, SHGetKnownFolderPath};

static START: OnceLock<Instant> = OnceLock::new();
static FILE: Mutex<Option<std::fs::File>> = Mutex::new(None);

/// `Documents\ARC Studio`, made if missing.
pub fn dir() -> PathBuf {
    let dir = documents_dir().join("ARC Studio");
    let _ = std::fs::create_dir_all(&dir);
    dir
}

/// The player's Documents folder (Windows' own, wherever it's moved).
pub fn documents_dir() -> PathBuf {
    // SAFETY: Windows hands back a CoTaskMem string, read before it's freed here.
    unsafe {
        match SHGetKnownFolderPath(&FOLDERID_Documents, KF_FLAG_DEFAULT, None) {
            Ok(pwstr) => {
                let path = pwstr.to_string().map(PathBuf::from);
                CoTaskMemFree(Some(pwstr.0 as *const _));
                path.unwrap_or_else(|_| fallback())
            }
            Err(_) => fallback(),
        }
    }
}

fn fallback() -> PathBuf {
    std::env::var_os("USERPROFILE").map(|p| PathBuf::from(p).join("Documents")).unwrap_or_else(std::env::temp_dir)
}

pub fn init() {
    START.get_or_init(Instant::now);
    let file = std::fs::File::create(dir().join("kabin_isigi.log")).ok();
    *FILE.lock().unwrap_or_else(|e| e.into_inner()) = file;
}

pub fn write(text: &str) {
    let t = START.get_or_init(Instant::now).elapsed().as_secs_f64();
    if let Some(f) = FILE.lock().unwrap_or_else(|e| e.into_inner()).as_mut() {
        let _ = writeln!(f, "[{t:9.3}] {text}");
        let _ = f.flush();
    }
}

#[macro_export]
macro_rules! log {
    ($($arg:tt)*) => { $crate::log::write(&format!($($arg)*)) };
}
