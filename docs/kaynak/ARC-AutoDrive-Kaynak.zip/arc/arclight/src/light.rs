//! The cab's lights, drawn into the game's own light buffers right after its light pass: the same G-buffer it
//! lit the frame from (`t12`: the eye-space normal and depth, `t13`: the specular power in w, `t15`: the
//! surface's bits, the interior's among them), and the same diffuse and specular light targets, added to.
//! Composing, fog, bloom and tone mapping then treat them as the game's own light.
//!
//! The lighting follows the game's spot light (its `def.apply.light.list` shader, effect.scs 1.61): an
//! inverse-square falloff windowed to the light's reach, a cone with a soft edge, Blinn-Phong specular with
//! the surface's power.
//!
//! The lights are placed in the cab (from the driver's head's default place) and turned into the eye's space
//! with the cab's turn found as the cab was drawn (`cab`), so they stay put on the dashboard and the ceiling.
//! A pixel's place in the eye's space is found as the light pass finds it: its depth along the ray of its
//! viewport coordinate (`deferred_param_viewport_coord_to_es_ray`, read from the light pass's own constants).

use std::ffi::c_void;
use std::sync::{LazyLock, Mutex};

use windows::Win32::Graphics::Direct3D::D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST;
use windows::Win32::Graphics::Direct3D::Fxc::D3DCompile;
use windows::Win32::Graphics::Direct3D::ID3DBlob;
use windows::Win32::Graphics::Direct3D11::{
    D3D11_BIND_CONSTANT_BUFFER, D3D11_BLEND_DESC, D3D11_BLEND_ONE, D3D11_BLEND_OP_ADD, D3D11_BUFFER_DESC,
    D3D11_COLOR_WRITE_ENABLE_ALL, D3D11_COMPARISON_ALWAYS, D3D11_CPU_ACCESS_WRITE, D3D11_CULL_NONE,
    D3D11_DEPTH_STENCIL_DESC, D3D11_DEPTH_WRITE_MASK_ZERO, D3D11_FILL_SOLID, D3D11_MAP_WRITE_DISCARD,
    D3D11_MAPPED_SUBRESOURCE, D3D11_RASTERIZER_DESC, D3D11_RENDER_TARGET_BLEND_DESC, D3D11_SDK_VERSION,
    D3D11_USAGE_DYNAMIC, D3D11_VIEWPORT, ID3D11BlendState, ID3D11Buffer, ID3D11DepthStencilState, ID3D11Device,
    ID3D11Device1, ID3D11DeviceContext, ID3D11DeviceContext1, ID3D11PixelShader, ID3D11RasterizerState,
    ID3D11RenderTargetView, ID3D11ShaderResourceView, ID3D11VertexShader, ID3DDeviceContextState,
    D3D11_SHADER_RESOURCE_VIEW_DESC,
};
use windows::Win32::Graphics::Direct3D::{D3D11_SRV_DIMENSION_BUFFER, D3D11_SRV_DIMENSION_BUFFEREX, D3D11_SRV_DIMENSION_TEXTURE2D};
use windows::Win32::Graphics::Dxgi::Common::DXGI_FORMAT;
use windows::core::{Interface, PCSTR, s};

use crate::config::{LED_ZONES, Led, Light, MAX_LIGHTS};
use crate::trucks::Cabin;
use crate::math::{Mat3, mul3, rot_x, rot_y};
use crate::cab::Eye;

const SHADER: &str = concat!(crate::disco::disco_hlsl!(), r#"
cbuffer C : register(b0) { float4 ray; float4 coord; float4 misc; float4 L[128]; float4 rot[3]; float4 hd; float4 box; float4 ys; float4 fx; float4 led[6]; float4 dc; float4 dp; float4 dcol; };
Texture2D<float4> g0 : register(t0);
Texture2D<float4> g1 : register(t1);
Texture2D<uint4> g3 : register(t2);
float rectd(float2 p) {
    float2 c = float2(box.x + box.y, box.z + box.w) * 0.5, e = float2(box.y - box.x, box.w - box.z) * 0.5;
    float2 d = abs(p - c) - e;
    return length(max(d, 0.0)) + min(max(d.x, d.y), 0.0);
}
float2 rectn(float2 p) {
    float2 c = float2(box.x + box.y, box.z + box.w) * 0.5, e = float2(box.y - box.x, box.w - box.z) * 0.5;
    float2 v = p - c, a = abs(v);
    float2 d = e - a;
    if (d.x > 0.0 && d.y > 0.0) { if (d.x < d.y) v.x = (v.x < 0.0 ? -1.0 : 1.0) * e.x; else v.y = (v.y < 0.0 ? -1.0 : 1.0) * e.y; }
    else v = clamp(v, -e, e);
    return v + c;
}
float3 hue(float h) { float3 k = saturate(abs(frac(h + float3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0); return k * k; }
float strip(float d, float w, float f) { return 1.0 - smoothstep(max(w - f, 0.0), w + f, abs(d)); }
float4 vs(uint id : SV_VertexID) : SV_Position {
    float2 uv = float2((id << 1) & 2, id & 2);
    return float4(uv * float2(2.0, -2.0) + float2(-1.0, 1.0), 0.0, 1.0);
}
struct PO { float4 d : SV_Target0; float4 s : SV_Target1; };
PO ps(float4 pos : SV_Position) {
    PO o;
    o.d = float4(0, 0, 0, 0);
    o.s = float4(0, 0, 0, 0);
    int3 c = int3(int2(pos.xy), 0);
    uint mode = (uint)misc.z;
    // Diagnostics (`tani` in the settings): 1 everything magenta, 2 the interior green and the rest red,
    // 3 a band every metre from the eye, 4 the first light's place (red within a metre of it), 5 the normals.
    if (mode == 1u) { o.d = float4(2, 0, 2, 0); return o; }
    float4 a0 = g0.Load(c);
    float depth = a0.w;
    uint4 a3 = g3.Load(c);
    bool interior = ((a3.w >> 13) & 1u) != 0u;
    if (mode == 2u) { o.d = interior ? float4(0, 2, 0, 0) : float4(2, 0, 0, 0); return o; }
    if (abs(depth) < 0.01) return o;
    // As the light pass: its viewport coordinate (0-1 across the view) from the G-buffer's pixel.
    float2 vp_coord = pos.xy * coord.xy;
    float3 es = float3(vp_coord * ray.zw + ray.xy, 1.0) * depth;
    float3 n = normalize(a0.xyz);
    if (mode == 3u) { o.d = float4(frac(length(es)).xxx * 2.0, 0); return o; }
    if (mode == 4u) { o.d = float4(saturate(1.0 - length(es - L[0].xyz)) * 4.0, 0, 0, 0); return o; }
    if (mode == 5u) { o.d = float4((n * 0.5 + 0.5) * 2.0, 0); return o; }
    // The LED strips: exact, per pixel, on the cab's own surfaces (no texture, so nothing to pixelate).
    // The disco ball's spots: for this surface point, the mirror tile that would throw a light here (the half
    // vector between the point and the light), so they land in true perspective and move with the ball.
    if (dp.x > 0.5 && interior) {
        float3 pc0 = float3(dot(rot[0].xyz, es), dot(rot[1].xyz, es), dot(rot[2].xyz, es)) + hd.xyz;
        float3 nc0 = float3(dot(rot[0].xyz, n), dot(rot[1].xyz, n), dot(rot[2].xyz, n));
        float3 tp = pc0 - dc.xyz;
        float dist = length(tp);
        if (dist > dc.w * 1.1) {
            float3 dd = tp / dist;
            float sn = sin(dp.w), cs = cos(dp.w);
            uint dmode = (uint)dp.y;
            float rows = dp.x;
            float pulse = dpulse(dmode, misc.w);
            float falloff = 1.0 / (1.0 + dist * dist * 0.35);
            float face = saturate(dot(nc0, -dd));
            for (uint l = 0; l < 2; l++) {
                float3 h0 = normalize(dd + DL[l]);
                float3 q = float3(cs * h0.x - sn * h0.z, h0.y, sn * h0.x + cs * h0.z);
                float ring, col, u, v, cnt, ra, rb;
                dfacet(q, rows, ring, col, u, v, cnt, ra, rb);
                float e = clamp(length(float2(ddx(rb), ddy(rb))) + length(float2(ddx(ra), ddy(ra))), 0.03, 0.4);
                float tile = smoothstep(0.08, 0.08 + e, u) * smoothstep(0.08, 0.08 + e, 1.0 - u) * smoothstep(0.08, 0.08 + e, v) * smoothstep(0.08, 0.08 + e, 1.0 - v);
                float rnd = dhash(ring, col + (float)l * 37.0);
                if (rnd < 0.1) tile = 0.0;
                float3 c = dcolour(dcol.rgb, dmode, misc.w, rnd, ring) * pulse;
                float3 add = c * tile * (0.35 + 0.65 * rnd) * (0.08 + 0.92 * face) * falloff * dcol.a;
                o.d.rgb += add * 2.6;
                o.s.rgb += add * 0.25;
            }
        }
    }
    if (fx.x > 0.5 && interior) {
        float3 pc = float3(dot(rot[0].xyz, es), dot(rot[1].xyz, es), dot(rot[2].xyz, es)) + hd.xyz;
        float3 nc = float3(dot(rot[0].xyz, n), dot(rot[1].xyz, n), dot(rot[2].xyz, n));
        float f = abs(depth) * abs(ray.z * coord.x);
        float sd = rectd(pc.xz);
        float2 nearest = rectn(pc.xz);
        float w = fx.w;
        // The steering wheel and its column are left clean: a disc round the wheel's centre, in front of the driver.
        float keep = (length(float2(pc.x, pc.y + 0.43)) > 0.31 || pc.z < box.z + 0.22 || pc.z > -0.25) ? 1.0 : 0.0;
        float wall = (abs(nc.y) < 0.75 && sd > -0.38) ? keep : 0.0;
        float m[6];
        float h[6];
        h[0] = ys.y - 0.04; m[0] = (nc.y < -0.3 && pc.y > 0.25) ? strip(sd + 0.20, w, f) : 0.0;
        h[1] = 0.52;        m[1] = wall * strip(pc.y - h[1], w, f);
        h[2] = ys.z;        m[2] = wall * strip(pc.y - h[2], w, f);
        h[3] = ys.x + 0.26; m[3] = wall * strip(pc.y - h[3], w, f);
        h[4] = ys.x + 0.03; m[4] = (nc.y > 0.55 && pc.y < ys.x + 0.25) ? strip(sd + 0.18, w, f) : 0.0;
        h[5] = ys.w;        m[5] = (pc.z < box.z + 0.62 && abs(nc.y) < 0.85) ? keep * strip(pc.y - h[5], w, f) : 0.0;
        float around = atan2(pc.x - (box.x + box.y) * 0.5, pc.z - (box.z + box.w) * 0.5) / 6.2831853;
        for (uint i = 0; i < 6; i++) {
            if (led[i].a <= 0.0) continue;
            float3 c = led[i].rgb;
            if (fx.y > 1.5) c = hue(around + fx.z) * max(c.r, max(c.g, c.b));
            o.d.rgb += c * m[i] * 16.0;
            o.s.rgb += c * m[i] * 1.5;
            float2 q2 = nearest;
            if (i == 5u) q2.y = box.z;
            float3 to = float3(q2.x, h[i], q2.y) - pc;
            float d2 = dot(to, to);
            float window = saturate(1.0 - d2 / 2.6);
            float wrap = saturate((dot(nc, to / sqrt(max(d2, 1e-4))) + 0.25) / 1.25);
            o.d.rgb += c * led[i].a * wrap * window * window * 0.25 / (d2 + 0.25);
        }
    }
    if (misc.y > 0.5 && !interior) return o;
    float3 to_eye = normalize(-es);
    float power = clamp(g1.Load(c).w, 1.0, 500.0);
    uint count = (uint)misc.x;
    [loop] for (uint i = 0; i < count; i++) {
        float4 p = L[i * 4];
        float4 dir = L[i * 4 + 1];
        float4 col = L[i * 4 + 2];
        float3 to_light = p.xyz - es;
        float d = length(to_light);
        float3 l = to_light / max(d, 0.01);
        float ratio = d * p.w;
        float w = saturate(ratio * ratio * ratio * ratio);
        float window = 1.0 + w * (w - 2.0);
        float atten = window / (d * d + 1.0);
        float spot = saturate((dot(-l, dir.xyz) - dir.w) * col.w);
        float ndotl = saturate(dot(n, l));
        float3 light = col.rgb * atten * spot;
        o.d.rgb += light * ndotl;
        float3 h = normalize(to_eye + l);
        o.s.rgb += light * pow(saturate(dot(n, h)), power) * saturate(ndotl * 10.0);
    }
    return o;
}
"#);

#[repr(C)]
#[derive(Clone, Copy)]
struct Constants {
    /// A viewport coordinate's ray in the eye's space: `es.xy = (coord * ray.zw + ray.xy) * depth`.
    ray: [f32; 4],
    /// A G-buffer pixel's viewport coordinate: `coord = pixel * coord.xy` (the light pass's own: its texture
    /// coordinate, `pixel / scene texture size`, times `deferred_param0_data[0].zw`).
    coord: [f32; 4],
    /// Lights, interior only, unused, unused.
    misc: [f32; 4],
    lights: [[f32; 4]; MAX_LIGHTS * 4],
    /// The eye's space to the cab's (rows), and the head's offset from its default place.
    rot: [[f32; 4]; 3],
    head: [f32; 4],
    /// The cab's walls (left, right, front, back), its heights (floor, roof, shoulder, dashboard).
    cab: [f32; 4],
    heights: [f32; 4],
    /// On, mode, the colours' phase, the strip's half width (m).
    fx: [f32; 4],
    /// Each zone: linear colour, how much it lights the cab (0: off).
    led: [[f32; 4]; LED_ZONES],
    dc: [f32; 4],
    dp: [f32; 4],
    dcol: [f32; 4],
}

struct Gpu {
    device: usize,
    state: ID3DDeviceContextState,
    vs: ID3D11VertexShader,
    ps: ID3D11PixelShader,
    constants: ID3D11Buffer,
    blend: ID3D11BlendState,
    raster: ID3D11RasterizerState,
    depth: ID3D11DepthStencilState,
}

struct Shared(Option<Gpu>, bool);
// SAFETY: its COM objects are used on the game's render thread only, through the mutex.
unsafe impl Send for Shared {}

static GPU: LazyLock<Mutex<Shared>> = LazyLock::new(|| Mutex::new(Shared(None, false)));

/// A viewport coordinate's (0-1 across the view) ray from the eye's projection (when the light pass's own
/// isn't readable).
fn ray_of(projection: &[f32; 5]) -> [f32; 4] {
    let [p00, p11, p02, p12, s] = *projection;
    [(-s - p02) / p00, (s - p12) / p11, 2.0 * s / p00, -2.0 * s / p11]
}

/// The lights in the eye's space: each light's place relative to the eye (from the head's offset `head`) and
/// its aim, turned by the cab's turn into the eye's space.
fn led_constants(c: &mut Constants, led: &Led, cabin: &Cabin, eye: &Eye, head: [f32; 3], fade: f32, time: f32) {
    let t = eye.turn;
    c.rot = std::array::from_fn(|i| [t[0][i], t[1][i], t[2][i], 0.0]);
    c.head = [head[0], head[1], head[2], 0.0];
    c.cab = [cabin.left, cabin.right, cabin.front, cabin.back];
    c.heights = [cabin.floor, cabin.roof, cabin.belt, cabin.panel];
    let breathing = if led.mode == 1 { 0.55 + 0.45 * (time * led.speed * 2.0).sin() } else { 1.0 };
    c.fx = [led.on as u32 as f32, led.mode as f32, (time * led.speed * 0.15).fract(), (led.width * 0.005).max(0.001)];
    for (i, z) in led.zones.iter().enumerate() {
        let rgb = z.color.map(|v| (v / 255.0).powf(2.2) * z.strength * fade * breathing);
        c.led[i] = [rgb[0], rgb[1], rgb[2], if z.on && led.on && z.strength > 0.0 { led.spill.max(0.0001) } else { 0.0 }];
    }
}

fn constants(lights: &[Light], eye: &Eye, head: [f32; 3], fade: f32, coord: [f32; 2], ray: [f32; 4], interior: bool, mode: u32) -> Constants {
    let mut c = Constants {
        ray,
        coord: [coord[0], coord[1], 0.0, 0.0],
        misc: [lights.len().min(MAX_LIGHTS) as f32, interior as u32 as f32, mode as f32, 0.0],
        lights: [[0.0; 4]; MAX_LIGHTS * 4],
        rot: [[0.0; 4]; 3],
        head: [0.0; 4],
        cab: [0.0; 4],
        heights: [0.0; 4],
        fx: [0.0; 4],
        led: [[0.0; 4]; LED_ZONES],
        dc: [0.0; 4],
        dp: [0.0; 4],
        dcol: [0.0; 4],
    };
    let t = eye.turn;
    let to_eye = |v: [f32; 3]| -> [f32; 3] { std::array::from_fn(|i| (0..3).map(|k| t[i][k] * v[k]).sum()) };
    for (i, l) in lights.iter().take(MAX_LIGHTS).enumerate() {
        let at = to_eye([l.x - head[0], l.y - head[1], l.z - head[2]]);
        // Straight ahead is -z; turned right by `yaw`, down by `pitch` (column-vector rotations).
        let aim: Mat3 = mul3(&rot_y(-l.yaw.to_radians()), &rot_x(-l.pitch.to_radians()));
        let forward = [-aim[0][2], -aim[1][2], -aim[2][2]];
        let dir = to_eye(forward);
        let half = (l.cone * 0.5).to_radians();
        let cos_outer = half.cos();
        let cos_inner = (half * (1.0 - l.soft.clamp(0.0, 0.99))).cos();
        let falloff = 1.0 / (cos_inner - cos_outer).max(1e-3);
        let linear = l.color.map(|c| (c / 255.0).powf(2.2) * l.strength * fade);
        c.lights[i * 4] = [at[0], at[1], at[2], 1.0 / l.reach.max(0.1)];
        c.lights[i * 4 + 1] = [dir[0], dir[1], dir[2], cos_outer];
        c.lights[i * 4 + 2] = [linear[0], linear[1], linear[2], falloff];
    }
    c
}

/// The light pass's own constants (at b0): its ray (`deferred_param_viewport_coord_to_es_ray`, byte 16144) and
/// its pixel-to-viewport-coordinate scale (from `deferred_param0_data`, byte 16096: `[0].zw` and `[1]`), if its
/// buffer's memory can be read.
///
/// # Safety
/// The game's live context, on its render thread, right after the light pass drew.
unsafe fn games_ray(context: &ID3D11DeviceContext) -> Option<([f32; 4], [f32; 2], [f32; 8])> {
    // SAFETY: the game's live context, only asked what's bound; the buffer's memory read only where found
    // readable and within its size.
    unsafe {
        let context1: ID3D11DeviceContext1 = context.cast().ok()?;
        let mut buffers: [Option<windows::Win32::Graphics::Direct3D11::ID3D11Buffer>; 1] = [None];
        let (mut first, mut num) = ([0u32], [0u32]);
        context1.PSGetConstantBuffers1(0, 1, Some(buffers.as_mut_ptr()), Some(first.as_mut_ptr()), Some(num.as_mut_ptr()));
        let buffer = buffers[0].take()?;
        let (data, size) = crate::cab::mapped(buffer.as_raw() as usize)?;
        let base = first[0] as usize * 16;
        if base + 16160 > size as usize {
            return None;
        }
        let ray = std::ptr::read_unaligned((data + base + 16144) as *const [f32; 4]);
        let p: [f32; 8] = std::ptr::read_unaligned((data + base + 16096) as *const [f32; 8]);
        // scene texture size = p[1].xy / p[1].zw; coord = pixel / size * p[0].zw.
        let (sw, sh) = (p[4] / p[6], p[5] / p[7]);
        let coord = [p[2] / sw, p[3] / sh];
        let ok = ray.iter().chain(&coord).all(|v| v.is_finite()) && ray[2] != 0.0 && ray[3] != 0.0 && coord[0] > 0.0 && coord[1] > 0.0;
        ok.then_some((ray, coord, p))
    }
}

/// Right after the game's light pass drew: adds the cab's lights to the light buffers it drew into.
///
/// # Safety
/// From the draw hook, on the game's render thread, with the context the light pass drew on.
#[allow(clippy::too_many_arguments)]
pub unsafe fn after_light_pass(context: *mut c_void, lights: &[Light], led: &Led, disko: &crate::disco::Params, cabin: &Cabin, time: f32, eye: &Eye, head: [f32; 3], fade: f32, interior: bool, mode: u32) {
    // SAFETY: the game's live context (the caller's contract); what it has bound is only read, and its whole
    // pipeline state is swapped out for ours and back.
    unsafe {
        let Some(context) = ID3D11DeviceContext::from_raw_borrowed(&context) else { return };
        if (lights.is_empty() && !led.on && !disko.on) || (fade <= 0.0 && mode == 0) {
            return;
        }
        // What the light pass drew with: its two targets, the G-buffer it read, its viewport.
        let mut targets: [Option<ID3D11RenderTargetView>; 2] = [None, None];
        context.OMGetRenderTargets(Some(&mut targets), None);
        let [Some(diffuse), Some(specular)] = targets else { return };
        let mut g0 = [None];
        let mut g1 = [None];
        let mut g3 = [None];
        context.PSGetShaderResources(12, Some(&mut g0));
        context.PSGetShaderResources(13, Some(&mut g1));
        context.PSGetShaderResources(15, Some(&mut g3));
        let (Some(g0), Some(g1), Some(g3)) = (g0[0].take(), g1[0].take(), g3[0].take()) else { return };
        let mut count = 1u32;
        let mut viewport = [D3D11_VIEWPORT::default()];
        context.RSGetViewports(&mut count, Some(viewport.as_mut_ptr()));
        if count == 0 || viewport[0].Width <= 0.0 {
            return;
        }
        let viewport = viewport[0];

        let Ok(device) = context.GetDevice() else { return };
        let mut gpu = GPU.lock().unwrap_or_else(|e| e.into_inner());
        if gpu.0.as_ref().is_none_or(|g| g.device != device.as_raw() as usize) {
            if gpu.1 && gpu.0.is_none() {
                return;
            }
            gpu.1 = true;
            gpu.0 = match make(&device) {
                Ok(g) => {
                    log!("light: ready");
                    Some(g)
                }
                Err(e) => {
                    log!("light: cannot draw: {e}");
                    None
                }
            };
        }
        let Some(gpu) = gpu.0.as_ref() else { return };
        let (ray, coord, param0) = match games_ray(context) {
            Some(found) => found,
            None => {
                static TOLD: std::sync::Once = std::sync::Once::new();
                TOLD.call_once(|| log!("light: the light pass's constants aren't readable; made from the projection"));
                // The view as wide as the viewport, as high as its shape says (P11 / P00 = width / height).
                let height = viewport.Width * eye.projection[0] / eye.projection[1];
                (ray_of(&eye.projection), [1.0 / viewport.Width, 1.0 / height], [0.0; 8])
            }
        };
        let mut constants = constants(lights, eye, head, fade, coord, ray, interior, mode);
        led_constants(&mut constants, led, cabin, eye, head, fade, time);
        if disko.on {
            constants.dc = [disko.center[0], disko.center[1], disko.center[2], disko.radius];
            constants.dp = [disko.rows, disko.mode as f32, disko.time, disko.spin];
            constants.dcol = [disko.colour[0], disko.colour[1], disko.colour[2], disko.strength];
            constants.misc[3] = disko.time;
            // This frame's depth, for the ball drawn at Present.
            crate::disco::capture(context, &g0, *disko, eye, head, ray, coord);
        }
        static DRAWS: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        if DRAWS.fetch_add(1, std::sync::atomic::Ordering::Relaxed).is_multiple_of(600) {
            let mut fmt = [0u32];
            let mut desc = windows::Win32::Graphics::Direct3D11::D3D11_RENDER_TARGET_VIEW_DESC::default();
            diffuse.GetDesc(&mut desc);
            fmt[0] = desc.Format.0 as u32;
            log!(
                "light: viewport {:?}, ray {:?}, coord {:?}, param0 {:?}, light 1 at {:?} aimed {:?}, colour {:?}, target format {}, mode {mode}",
                [viewport.TopLeftX, viewport.TopLeftY, viewport.Width, viewport.Height],
                ray,
                coord,
                param0,
                constants.lights[0],
                constants.lights[1],
                constants.lights[2],
                fmt[0]
            );
        }
        let Ok(context1) = context.cast::<ID3D11DeviceContext1>() else { return };
        let mut games: Option<ID3DDeviceContextState> = None;
        context1.SwapDeviceContextState(&gpu.state, Some(&mut games));
        let mut mapped = D3D11_MAPPED_SUBRESOURCE::default();
        if context.Map(&gpu.constants, 0, D3D11_MAP_WRITE_DISCARD, 0, Some(&mut mapped)).is_ok() {
            std::ptr::write_unaligned(mapped.pData as *mut Constants, constants);
            context.Unmap(&gpu.constants, 0);
            context.IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
            context.VSSetShader(&gpu.vs, None);
            context.PSSetShader(&gpu.ps, None);
            context.PSSetConstantBuffers(0, Some(&[Some(gpu.constants.clone())]));
            context.PSSetShaderResources(0, Some(&[Some(g0), Some(g1), Some(g3)]));
            context.RSSetState(&gpu.raster);
            context.RSSetViewports(Some(&[viewport]));
            context.OMSetRenderTargets(Some(&[Some(diffuse), Some(specular)]), None);
            context.OMSetBlendState(&gpu.blend, None, 0xffff_ffff);
            context.OMSetDepthStencilState(&gpu.depth, 0);
            context.Draw(3, 0);
            // Nothing of the game's left bound in our state.
            context.PSSetShaderResources(0, Some(&[None, None, None]));
            context.OMSetRenderTargets(None, None);
        }
        context1.SwapDeviceContextState(games.as_ref(), None);
    }
}

/// Whether what's bound on `context` now is what the light pass draws with (its pixel shader made before the
/// plugin was loaded, so its bytecode wasn't seen): a buffer at t9, float textures at t12 and t13, an integer
/// texture at t15, and two targets.
///
/// # Safety
/// The game's live context, on its render thread.
pub unsafe fn bound_like_light_pass(context: *mut c_void) -> bool {
    // SAFETY: the game's live context (the caller's contract), only asked what's bound.
    unsafe {
        let Some(context) = ID3D11DeviceContext::from_raw_borrowed(&context) else { return false };
        let view = |slot: u32| {
            let mut v = [None];
            context.PSGetShaderResources(slot, Some(&mut v));
            v[0].take().map(|v: ID3D11ShaderResourceView| {
                let mut d = D3D11_SHADER_RESOURCE_VIEW_DESC::default();
                v.GetDesc(&mut d);
                (d.ViewDimension, d.Format)
            })
        };
        let uint = |f: DXGI_FORMAT| [3, 12, 17, 25, 30, 36, 42, 50, 57, 62].contains(&f.0);
        let buffer = view(9).is_some_and(|(d, _)| d == D3D11_SRV_DIMENSION_BUFFER || d == D3D11_SRV_DIMENSION_BUFFEREX);
        let g0 = view(12).is_some_and(|(d, f)| d == D3D11_SRV_DIMENSION_TEXTURE2D && !uint(f));
        let g1 = view(13).is_some_and(|(d, f)| d == D3D11_SRV_DIMENSION_TEXTURE2D && !uint(f));
        let g3 = view(15).is_some_and(|(d, f)| d == D3D11_SRV_DIMENSION_TEXTURE2D && uint(f));
        if !(buffer && g0 && g1 && g3) {
            return false;
        }
        let mut targets: [Option<ID3D11RenderTargetView>; 2] = [None, None];
        context.OMGetRenderTargets(Some(&mut targets), None);
        targets.iter().all(Option::is_some)
    }
}

/// The width of the viewport bound on `context` now (0 for none).
///
/// # Safety
/// The game's live context, on its render thread.
pub unsafe fn viewport_width(context: *mut c_void) -> f32 {
    // SAFETY: the game's live context (the caller's contract), only asked its viewport.
    unsafe {
        let Some(context) = ID3D11DeviceContext::from_raw_borrowed(&context) else { return 0.0 };
        let mut count = 1u32;
        let mut viewport = [D3D11_VIEWPORT::default()];
        context.RSGetViewports(&mut count, Some(viewport.as_mut_ptr()));
        if count == 0 { 0.0 } else { viewport[0].Width }
    }
}

/// # Safety
/// The game's live device.
unsafe fn make(device: &ID3D11Device) -> Result<Gpu, String> {
    // SAFETY: the game's live device; descriptions are locals living through their calls.
    unsafe {
        let e = |what: &'static str| move |err: windows::core::Error| format!("{what}: {err}");
        let device1: ID3D11Device1 = device.cast().map_err(e("ID3D11Device1"))?;
        let mut state = None;
        device1
            .CreateDeviceContextState(0, &[device.GetFeatureLevel()], D3D11_SDK_VERSION, &ID3D11Device::IID, None, Some(&mut state))
            .map_err(e("context state"))?;
        let vs_code = compile(s!("vs"), s!("vs_5_0"))?;
        let ps_code = compile(s!("ps"), s!("ps_5_0"))?;
        let mut vs = None;
        device.CreateVertexShader(&vs_code, None, Some(&mut vs)).map_err(e("vertex shader"))?;
        let mut ps = None;
        device.CreatePixelShader(&ps_code, None, Some(&mut ps)).map_err(e("pixel shader"))?;
        let mut constants = None;
        device
            .CreateBuffer(
                &D3D11_BUFFER_DESC {
                    ByteWidth: size_of::<Constants>().next_multiple_of(16) as u32,
                    Usage: D3D11_USAGE_DYNAMIC,
                    BindFlags: D3D11_BIND_CONSTANT_BUFFER.0 as u32,
                    CPUAccessFlags: D3D11_CPU_ACCESS_WRITE.0 as u32,
                    ..Default::default()
                },
                None,
                Some(&mut constants),
            )
            .map_err(e("constants"))?;
        // Added to the light already there, as the game's lights are (its apply_light.rs: one + one).
        let mut blend_desc = D3D11_BLEND_DESC::default();
        let add = D3D11_RENDER_TARGET_BLEND_DESC {
            BlendEnable: true.into(),
            SrcBlend: D3D11_BLEND_ONE,
            DestBlend: D3D11_BLEND_ONE,
            BlendOp: D3D11_BLEND_OP_ADD,
            SrcBlendAlpha: D3D11_BLEND_ONE,
            DestBlendAlpha: D3D11_BLEND_ONE,
            BlendOpAlpha: D3D11_BLEND_OP_ADD,
            RenderTargetWriteMask: D3D11_COLOR_WRITE_ENABLE_ALL.0 as u8,
        };
        blend_desc.RenderTarget[0] = add;
        blend_desc.RenderTarget[1] = add;
        blend_desc.IndependentBlendEnable = true.into();
        let mut blend = None;
        device.CreateBlendState(&blend_desc, Some(&mut blend)).map_err(e("blend"))?;
        let mut raster = None;
        device
            .CreateRasterizerState(
                &D3D11_RASTERIZER_DESC { FillMode: D3D11_FILL_SOLID, CullMode: D3D11_CULL_NONE, ..Default::default() },
                Some(&mut raster),
            )
            .map_err(e("rasterizer"))?;
        let mut depth = None;
        device
            .CreateDepthStencilState(
                &D3D11_DEPTH_STENCIL_DESC {
                    DepthEnable: false.into(),
                    DepthWriteMask: D3D11_DEPTH_WRITE_MASK_ZERO,
                    DepthFunc: D3D11_COMPARISON_ALWAYS,
                    ..Default::default()
                },
                Some(&mut depth),
            )
            .map_err(e("depth"))?;
        Ok(Gpu {
            device: device.as_raw() as usize,
            state: state.ok_or("no context state")?,
            vs: vs.ok_or("no vertex shader")?,
            ps: ps.ok_or("no pixel shader")?,
            constants: constants.ok_or("no constants")?,
            blend: blend.ok_or("no blend")?,
            raster: raster.ok_or("no rasterizer")?,
            depth: depth.ok_or("no depth state")?,
        })
    }
}

fn compile(entry: PCSTR, target: PCSTR) -> Result<Vec<u8>, String> {
    let mut code: Option<ID3DBlob> = None;
    let mut errors: Option<ID3DBlob> = None;
    // SAFETY: the source is a live string of its length; blobs are read within their sizes.
    unsafe {
        let result = D3DCompile(
            SHADER.as_ptr() as *const c_void,
            SHADER.len(),
            s!("arclight"),
            None,
            None,
            entry,
            target,
            0,
            0,
            &mut code,
            Some(&mut errors),
        );
        let text = |b: &ID3DBlob| {
            String::from_utf8_lossy(std::slice::from_raw_parts(b.GetBufferPointer() as *const u8, b.GetBufferSize())).into_owned()
        };
        match (result, code) {
            (Ok(()), Some(code)) => Ok(std::slice::from_raw_parts(code.GetBufferPointer() as *const u8, code.GetBufferSize()).to_vec()),
            (r, _) => Err(format!("shader: {:?} {}", r.err(), errors.as_ref().map(text).unwrap_or_default())),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::math::IDENTITY3;

    const P: [f32; 5] = [0.89, 1.582, 0.0, 0.0, -1.0];

    fn eye(turn: Mat3) -> Eye {
        Eye { turn, projection: P, frame: 0 }
    }

    #[test]
    fn the_ray_puts_a_pixel_where_the_projection_does() {
        // A point 2 m ahead, 0.5 right, 0.3 up, through the projection to its pixel, and back by the ray.
        let (w, h) = (1920.0f32, 1080.0f32);
        let (x, y, z) = (0.5f32, 0.3f32, -2.0f32);
        let ndc = [(0.89 * x) / -z, (1.582 * y) / -z];
        let px = [(ndc[0] + 1.0) / 2.0 * w, (1.0 - ndc[1]) / 2.0 * h];
        let r = ray_of(&P);
        let uv = [px[0] / w, px[1] / h];
        let back = [(uv[0] * r[2] + r[0]) * z, (uv[1] * r[3] + r[1]) * z];
        assert!((back[0] - x).abs() < 1e-4 && (back[1] - y).abs() < 1e-4, "{back:?}");
    }

    #[test]
    fn a_light_above_the_head_aimed_down_stays_above_in_the_eyes_space() {
        let l = Light { x: 0.0, y: 0.4, z: 0.0, pitch: 90.0, ..Light::default() };
        let c = constants(&[l], &eye(IDENTITY3), [0.0; 3], 1.0, [1.0 / 1920.0, 1.0 / 1080.0], [0.0; 4], true, 0);
        let at = c.lights[0];
        assert!((at[1] - 0.4).abs() < 1e-5 && at[0].abs() < 1e-5);
        assert!((c.lights[1][1] + 1.0).abs() < 1e-4, "aimed down: {:?}", c.lights[1]);
        // The head turned right: the cab's forward is to the eye's left (the cab's turn into the eye: its inverse).
        let head = crate::math::euler(-0.25, 0.0, 0.0);
        let l2 = Light { x: 0.0, y: 0.0, z: -1.0, pitch: 0.0, ..Light::default() };
        let c2 = constants(&[l2], &eye(crate::math::transpose3(&head)), [0.0; 3], 1.0, [1.0 / 1920.0, 1.0 / 1080.0], [0.0; 4], true, 0);
        assert!(c2.lights[0][0] < -0.9, "{:?}", c2.lights[0]);
    }

    #[test]
    fn the_shaders_compile() {
        compile(s!("vs"), s!("vs_5_0")).unwrap();
        compile(s!("ps"), s!("ps_5_0")).unwrap();
    }

    #[test]
    fn the_led_constants_put_the_cab_where_it_is() {
        let (cabin, led) = (crate::trucks::GENERIC, Led { on: true, ..Led::default() });
        let mut c = constants(&[], &eye(IDENTITY3), [0.1, 0.0, 0.0], 1.0, [1.0, 1.0], [0.0; 4], true, 0);
        led_constants(&mut c, &led, &cabin, &eye(IDENTITY3), [0.1, 0.0, 0.0], 1.0, 0.0);
        assert_eq!(c.cab[0], cabin.left);
        assert_eq!(c.rot[0], [1.0, 0.0, 0.0, 0.0]);
        assert_eq!(c.head[0], 0.1);
        assert_eq!(size_of::<Constants>() % 16, 0);
        assert!(c.led[0][3] > 0.0 && c.fx[0] == 1.0);
        let off = Led { on: false, ..Led::default() };
        led_constants(&mut c, &off, &cabin, &eye(IDENTITY3), [0.0; 3], 1.0, 0.0);
        assert_eq!(c.led[0][3], 0.0);
    }

    #[test]
    fn a_light_aimed_right_points_right() {
        let l = Light { pitch: 0.0, yaw: 90.0, ..Light::default() };
        let c = constants(&[l], &eye(IDENTITY3), [0.0; 3], 1.0, [1.0 / 1920.0, 1.0 / 1080.0], [0.0; 4], true, 0);
        assert!((c.lights[1][0] - 1.0).abs() < 1e-4, "{:?}", c.lights[1]);
    }
}
