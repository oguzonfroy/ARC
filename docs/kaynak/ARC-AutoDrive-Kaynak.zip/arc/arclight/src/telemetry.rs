//! What the SDK tells of the truck: its model, the head's default place in the cab and its offset from it.

use std::ffi::{CStr, CString, c_char, c_void};
use std::sync::Mutex;

use crate::scs::{
    ChannelCallback, ConfigurationEvent, EventCallback, SCS_TELEMETRY_EVENT_CONFIGURATION, SCS_U32_NIL,
    SCS_VALUE_TYPE_BOOL, SCS_VALUE_TYPE_FPLACEMENT, ScsValue, TelemetryInitParamsV100,
};

/// The lamps (`react`), as the SDK's channels: lit right now.
const LAMP_CHANNELS: [&str; 3] = ["truck.light.brake", "truck.light.lblinker", "truck.light.rblinker"];
static LAMPS: [std::sync::atomic::AtomicBool; 3] =
    [const { std::sync::atomic::AtomicBool::new(false) }; 3];

pub fn signals() -> crate::react::Signals {
    let lit = |i: usize| LAMPS[i].load(std::sync::atomic::Ordering::Relaxed);
    crate::react::Signals { brake: lit(0), left: lit(1), right: lit(2) }
}

/// The head's offset from its default place in the cab: x, y, z (metres), heading, pitch, roll (turns).
static HEAD_OFFSET: Mutex<[f32; 6]> = Mutex::new([0.0; 6]);
/// The truck's model (SDK id, e.g. `vehicle.scania.s_2016`), empty for none.
static TRUCK: Mutex<String> = Mutex::new(String::new());
/// Whether the driver sits on the right (the head's default place in the cab is right of its middle).
static RIGHT_HAND: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

pub fn right_hand() -> bool {
    RIGHT_HAND.load(std::sync::atomic::Ordering::Relaxed)
}

pub fn head_offset() -> [f32; 6] {
    *HEAD_OFFSET.lock().unwrap_or_else(|e| e.into_inner())
}

pub fn truck() -> Option<String> {
    let t = TRUCK.lock().unwrap_or_else(|e| e.into_inner()).clone();
    (!t.is_empty()).then_some(t)
}

type EventRegisterFn = unsafe extern "system" fn(u32, EventCallback, *mut c_void) -> i32;
type ChannelRegisterFn = unsafe extern "system" fn(*const c_char, u32, u32, u32, ChannelCallback, *mut c_void) -> i32;

/// # Safety
/// During `scs_telemetry_init`, with the game's parameters.
pub unsafe fn register(params: &TelemetryInitParamsV100) {
    // SAFETY: the game's registration functions with the SDK's signatures; names are copied by the SDK.
    unsafe {
        let register_event: EventRegisterFn = std::mem::transmute(params.register_for_event);
        register_event(SCS_TELEMETRY_EVENT_CONFIGURATION, on_event, std::ptr::null_mut());
        let register_channel: ChannelRegisterFn = std::mem::transmute(params.register_for_channel);
        let name = CString::new("truck.head.offset").unwrap_or_default();
        register_channel(name.as_ptr(), SCS_U32_NIL, SCS_VALUE_TYPE_FPLACEMENT, 0, on_channel, std::ptr::null_mut());
        for (i, lamp) in LAMP_CHANNELS.iter().enumerate() {
            let name = CString::new(*lamp).unwrap_or_default();
            // The context is the lamp's index.
            // SCS_TELEMETRY_CHANNEL_FLAG_no_value: told "no value" (off) when the SDK stops having one (menu, truck change).
            register_channel(name.as_ptr(), SCS_U32_NIL, SCS_VALUE_TYPE_BOOL, 0x2, on_lamp, i as *mut c_void);
        }
    }
}

unsafe extern "system" fn on_lamp(_name: *const c_char, _index: u32, value: *const ScsValue, context: *mut c_void) {
    // SAFETY: the SDK's value of the registered type, or null (none: not lit).
    let _ = std::panic::catch_unwind(|| unsafe {
        let lit = value.as_ref().is_some_and(|v| v.bool());
        if let Some(lamp) = LAMPS.get(context as usize) {
            lamp.store(lit, std::sync::atomic::Ordering::Relaxed);
        }
    });
}

unsafe extern "system" fn on_event(_event: u32, info: *const c_void, _context: *mut c_void) {
    // SAFETY: a configuration event's info, its strings alive through the call.
    let _ = std::panic::catch_unwind(|| unsafe {
        let Some(c) = (info as *const ConfigurationEvent).as_ref() else { return };
        if c.id.is_null() || CStr::from_ptr(c.id).to_bytes() != b"truck" {
            return;
        }
        let mut id = String::new();
        for a in c.attributes() {
            if CStr::from_ptr(a.name).to_bytes() == b"id"
                && let Some(v) = a.value.string()
            {
                id = v;
            }
            if CStr::from_ptr(a.name).to_bytes() == b"head_position"
                && let Some(v) = a.value.fvector()
            {
                RIGHT_HAND.store(v[0] > 0.05, std::sync::atomic::Ordering::Relaxed);
            }
        }
        crate::log!("truck: {id}");
        *TRUCK.lock().unwrap_or_else(|e| e.into_inner()) = id;
    });
}

unsafe extern "system" fn on_channel(_name: *const c_char, _index: u32, value: *const ScsValue, _context: *mut c_void) {
    // SAFETY: the SDK's value of the registered type, or null.
    let _ = std::panic::catch_unwind(|| unsafe {
        let v = match value.as_ref() {
            Some(v) => {
                let p = v.fplacement();
                [p.x, p.y, p.z, p.heading, p.pitch, p.roll]
            }
            None => [0.0; 6],
        };
        *HEAD_OFFSET.lock().unwrap_or_else(|e| e.into_inner()) = v;
    });
}
