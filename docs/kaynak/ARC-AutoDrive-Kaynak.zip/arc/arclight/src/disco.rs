//! The disco ball: a mirror ball hanging from the cab's ceiling. Its spots are found in the light pass (`light`),
//! from each surface point: the half vector between the point and the light picks the mirror tile that would
//! reflect the light there, so the spots fall on the cab's real surfaces in true perspective and move as the ball
//! turns. The ball itself is ray traced into the frame at Present, hidden by what's in front of it through a copy
//! of the G-buffer's depth.

use std::ffi::c_void;
use std::sync::{LazyLock, Mutex};

use windows::Win32::Graphics::Direct3D::Fxc::D3DCompile;
use windows::Win32::Graphics::Direct3D::{D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST, ID3DBlob};
use windows::Win32::Graphics::Direct3D11::*;
use windows::Win32::Graphics::Dxgi::IDXGISwapChain;
use windows::core::{Interface, PCSTR, s};

use crate::cab::Eye;
use crate::config::Disko;
use crate::math::Mat3;
use crate::trucks::Cabin;

/// HLSL both passes share: the colours, the pulse and the mirror tiles.
macro_rules! disco_hlsl {
    () => {
        r#"
static const float3 DL[2] = { float3(-0.336, -0.528, -0.780), float3(0.550, -0.250, 0.797) };
float3 dhue(float h) { float3 k = saturate(abs(frac(h + float3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0); return k * k; }
float dhash(float a, float b) { float2 p = frac(float2(a, b) * float2(0.3183, 0.3678) + 0.1) * 17.0; return frac(p.x * p.y * (p.x + p.y)); }
float3 dcolour(float3 base, uint mode, float t, float rnd, float ring) {
    float m = max(base.r, max(base.g, base.b));
    if (mode == 1u) return dhue(rnd * 0.2 + t * 0.1) * m;
    if (mode == 2u) return dhue(rnd) * m;
    if (mode == 5u) return dhue(ring * 0.07 + t * 0.18) * m;
    return base;
}
float dpulse(uint mode, float t) {
    if (mode == 3u) return 0.3 + 0.7 * (0.5 + 0.5 * sin(t * 1.7));
    if (mode == 4u) return frac(t * 2.8) < 0.4 ? 1.0 : 0.0;
    if (mode == 5u) return 0.7 + 0.3 * sin(t * 3.0);
    return 1.0;
}
void dfacet(float3 q, float rows, out float ring, out float col, out float u, out float v, out float cnt, out float a, out float b) {
    a = (asin(clamp(q.y, -1.0, 1.0)) / 3.14159265 + 0.5) * rows;
    ring = min(floor(a), rows - 1.0);
    v = a - ring;
    float rl = ((ring + 0.5) / rows - 0.5) * 3.14159265;
    cnt = max(4.0, floor(2.0 * rows * cos(rl)));
    b = (atan2(q.z, q.x) / 6.2831853 + 0.5) * cnt;
    col = floor(b);
    u = b - col;
    if (col >= cnt) col = 0.0;
}
float3 dcentre(float ring, float col, float cnt, float rows) {
    float lat = ((ring + 0.5) / rows - 0.5) * 3.14159265;
    float lon = ((col + 0.5) / cnt - 0.5) * 6.2831853;
    return float3(cos(lat) * cos(lon), sin(lat), cos(lat) * sin(lon));
}
"#
    };
}
pub(crate) use disco_hlsl;

const SHADER: &str = concat!(
    disco_hlsl!(),
    r#"
Texture2D<float4> g0 : register(t0);
cbuffer C : register(b0) { float4 ray; float4 gray; float4 coord; float4 size; float4 ctr; float4 top; float4 rot[3]; float4 dp; float4 dcol; };
float4 vs(uint id : SV_VertexID) : SV_Position {
    float2 uv = float2((id << 1) & 2, id & 2);
    return float4(uv * float2(2.0, -2.0) + float2(-1.0, 1.0), 0.0, 1.0);
}
float3 tocab(float3 v) { return float3(dot(rot[0].xyz, v), dot(rot[1].xyz, v), dot(rot[2].xyz, v)); }
float sceneAt(float2 rxy) {
    float2 pix = (rxy - gray.xy) / gray.zw / coord.xy;
    return abs(g0.Load(int3(int2(pix), 0)).w);
}
float4 ps(float4 pos : SV_Position) : SV_Target {
    float2 uv = pos.xy / size.xy;
    float2 rxy = uv * ray.zw + ray.xy;
    float3 dir = -normalize(float3(rxy, 1.0));
    float scene = sceneAt(rxy);
    float3 C = ctr.xyz;
    float r = ctr.w;
    float b = dot(dir, C);
    float perp2 = max(dot(C, C) - b * b, 0.0);
    float perp = sqrt(perp2);
    float pixel = max(b, 0.05) * abs(ray.z) / size.x;
    uint mode = (uint)dp.y;
    float t = dp.z;
    float4 result = float4(0, 0, 0, 0);

    // The rod it hangs from.
    float3 a0 = C + float3(rot[1].xyz) * r;
    float3 u0 = top.xyz - a0;
    float uu = dot(u0, u0), ud = dot(u0, dir), ad = dot(a0, dir), au = dot(a0, u0);
    float s0 = saturate((ud * ad - au) / max(uu - ud * ud, 1e-5));
    float t0 = ad + s0 * ud;
    float dist = length(dir * t0 - (a0 + u0 * s0));
    float rodpix = max(t0, 0.05) * abs(ray.z) / size.x;
    float rodA = saturate((0.0045 - dist) / rodpix + 0.5);
    if (rodA > 0.0 && t0 > 0.0 && !(scene > 0.01 && scene < (-(dir * t0).z) - 0.01)) result = float4(float3(0.34, 0.35, 0.38), rodA);

    float ballA = saturate((r - perp) / pixel + 0.5);
    if (ballA > 0.0 && b > 0.0) {
        float th = sqrt(max(r * r - perp2, 0.0));
        float3 hit = dir * (b - th);
        if (!(scene > 0.01 && scene < (-hit.z) - 0.01)) {
            float3 nc = tocab(normalize(hit - C));
            float3 vc = tocab(dir);
            float sn = sin(dp.w), cs = cos(dp.w);
            float3 q = float3(cs * nc.x - sn * nc.z, nc.y, sn * nc.x + cs * nc.z);
            float ring, col, u, v, cnt, ra, rb;
            float rows = dp.x;
            dfacet(q, rows, ring, col, u, v, cnt, ra, rb);
            float e = clamp(length(float2(ddx(rb), ddy(rb))) + length(float2(ddx(ra), ddy(ra))), 0.04, 0.45);
            float tile = smoothstep(0.03, 0.03 + e, u) * smoothstep(0.03, 0.03 + e, 1.0 - u) * smoothstep(0.03, 0.03 + e, v) * smoothstep(0.03, 0.03 + e, 1.0 - v);
            float3 c0 = dcentre(ring, col, cnt, rows);
            float3 fc = float3(cs * c0.x + sn * c0.z, c0.y, -sn * c0.x + cs * c0.z);
            float3 R = reflect(vc, fc);
            float rnd = dhash(ring, col);
            float up = saturate(R.y * 0.5 + 0.5);
            float windows = smoothstep(0.2, 0.9, saturate(-R.z)) * smoothstep(0.75, 0.2, abs(R.y));
            float3 env = lerp(float3(0.07, 0.07, 0.09), float3(0.34, 0.35, 0.40), up) + float3(0.85, 0.88, 0.95) * windows;
            env *= 0.55 + 0.6 * rnd;
            float3 tint = dcolour(dcol.rgb, mode, t, rnd, ring) * dpulse(mode, t);
            float3 glint = float3(0, 0, 0);
            for (uint l = 0; l < 2; l++) glint += tint * pow(saturate(dot(R, -DL[l])), 90.0) * 2.4;
            float3 rgb = env + tint * 0.22 * (0.4 + rnd) + glint;
            rgb *= 0.18 + 0.82 * tile;
            result = float4(lerp(result.rgb, saturate(rgb), ballA), max(result.a, ballA));
        }
    }
    if (result.a <= 0.0) discard;
    return result;
}
"#
);

#[repr(C)]
#[derive(Clone, Copy)]
struct Constants {
    ray: [f32; 4],
    game_ray: [f32; 4],
    coord: [f32; 4],
    size: [f32; 4],
    center: [f32; 4],
    top: [f32; 4],
    rot: [[f32; 4]; 3],
    params: [f32; 4],
    colour: [f32; 4],
}

/// What the light-pass shader needs of the ball, and where it hangs.
#[derive(Clone, Copy, Debug)]
pub struct Params {
    pub on: bool,
    /// In the cab's space, from the head's default place.
    pub center: [f32; 3],
    pub roof: f32,
    pub radius: f32,
    pub rows: f32,
    pub mode: u32,
    pub time: f32,
    pub spin: f32,
    pub colour: [f32; 3],
    pub strength: f32,
}

pub fn params(d: &Disko, cabin: &Cabin, time: f32, fade: f32) -> Params {
    let x = (cabin.left + cabin.right) * 0.5 + d.x;
    let z = (cabin.front + cabin.back) * 0.5 + d.z;
    let y = cabin.roof - d.drop - d.radius;
    Params {
        on: d.on,
        center: [x, y, z],
        roof: cabin.roof,
        radius: d.radius,
        rows: d.rows,
        mode: d.mode,
        time,
        spin: (time * d.speed * 0.8).rem_euclid(std::f32::consts::TAU),
        colour: d.color.map(|c| (c / 255.0).powf(2.2)),
        strength: d.strength * fade,
    }
}

#[derive(Default)]
struct Slot {
    texture: Option<ID3D11Texture2D>,
    view: Option<ID3D11ShaderResourceView>,
    size: (u32, u32, i32),
    data: Option<(Params, Mat3, [f32; 3], [f32; 5], [f32; 4], [f32; 2], u64)>,
    gpu: Option<Gpu>,
    failed: bool,
}
// SAFETY: its COM objects are used on the game's render thread only, through the mutex.
unsafe impl Send for Slot {}

static SLOT: LazyLock<Mutex<Slot>> = LazyLock::new(|| Mutex::new(Slot::default()));

struct Gpu {
    device: usize,
    state: ID3DDeviceContextState,
    vs: ID3D11VertexShader,
    ps: ID3D11PixelShader,
    constants: ID3D11Buffer,
    blend: ID3D11BlendState,
    raster: ID3D11RasterizerState,
    depth: ID3D11DepthStencilState,
}

/// At the light pass: keeps this frame's depth for the ball's drawing at Present.
///
/// # Safety
/// The game's live context, on its render thread, with `g0` its G-buffer view.
pub unsafe fn capture(context: &ID3D11DeviceContext, g0: &ID3D11ShaderResourceView, p: Params, eye: &Eye, head: [f32; 3], game_ray: [f32; 4], coord: [f32; 2]) {
    let mut guard = SLOT.lock().unwrap_or_else(|e| e.into_inner());
    let slot = &mut *guard;
    if slot.failed {
        return;
    }
    // SAFETY: the game's live objects; our texture is made to the source's description.
    unsafe {
        let Ok(resource) = g0.GetResource() else { return };
        let Ok(source) = resource.cast::<ID3D11Texture2D>() else { return };
        let mut desc = D3D11_TEXTURE2D_DESC::default();
        source.GetDesc(&mut desc);
        if desc.SampleDesc.Count != 1 {
            return;
        }
        let want = (desc.Width, desc.Height, desc.Format.0);
        if slot.texture.is_none() || slot.size != want {
            let Ok(device) = context.GetDevice() else { return };
            let mut own = desc;
            own.BindFlags = D3D11_BIND_SHADER_RESOURCE.0 as u32;
            own.MiscFlags = 0;
            own.CPUAccessFlags = 0;
            own.Usage = D3D11_USAGE_DEFAULT;
            own.MipLevels = 1;
            own.ArraySize = 1;
            let mut texture = None;
            if device.CreateTexture2D(&own, None, Some(&mut texture)).is_err() {
                slot.failed = true;
                crate::log!("disco: cannot keep the depth");
                return;
            }
            let Some(texture) = texture else { return };
            let mut view = None;
            if device.CreateShaderResourceView(&texture, None, Some(&mut view)).is_err() {
                slot.failed = true;
                return;
            }
            slot.texture = Some(texture);
            slot.view = view;
            slot.size = want;
        }
        let Some(texture) = slot.texture.as_ref() else { return };
        context.CopyResource(texture, &source);
    }
    slot.data = Some((p, eye.turn, head, eye.projection, game_ray, coord, eye.frame));
}

fn compile(entry: PCSTR, target: PCSTR) -> Result<Vec<u8>, String> {
    let (mut code, mut errors): (Option<ID3DBlob>, Option<ID3DBlob>) = (None, None);
    // SAFETY: the source is a live string of its length; blobs are read within their sizes.
    unsafe {
        let r = D3DCompile(SHADER.as_ptr() as *const c_void, SHADER.len(), s!("disco"), None, None, entry, target, 0, 0, &mut code, Some(&mut errors));
        let bytes = |b: &ID3DBlob| std::slice::from_raw_parts(b.GetBufferPointer() as *const u8, b.GetBufferSize()).to_vec();
        match (r, code) {
            (Ok(()), Some(c)) => Ok(bytes(&c)),
            (r, _) => Err(format!("shader: {:?} {}", r.err(), errors.as_ref().map(|e| String::from_utf8_lossy(&bytes(e)).into_owned()).unwrap_or_default())),
        }
    }
}

fn make(device: &ID3D11Device) -> Result<Gpu, String> {
    let e = |what: &'static str| move |err: windows::core::Error| format!("{what}: {err}");
    // SAFETY: the game's live device; descriptions are locals living through their calls.
    unsafe {
        let device1: ID3D11Device1 = device.cast().map_err(e("device1"))?;
        let (mut state, mut vs, mut ps, mut constants, mut blend, mut raster, mut depth) = (None, None, None, None, None, None, None);
        device1.CreateDeviceContextState(0, &[device.GetFeatureLevel()], D3D11_SDK_VERSION, &ID3D11Device::IID, None, Some(&mut state)).map_err(e("state"))?;
        let (vs_code, ps_code) = (compile(s!("vs"), s!("vs_5_0"))?, compile(s!("ps"), s!("ps_5_0"))?);
        device.CreateVertexShader(&vs_code, None, Some(&mut vs)).map_err(e("vs"))?;
        device.CreatePixelShader(&ps_code, None, Some(&mut ps)).map_err(e("ps"))?;
        device
            .CreateBuffer(
                &D3D11_BUFFER_DESC {
                    ByteWidth: size_of::<Constants>().next_multiple_of(16) as u32,
                    Usage: D3D11_USAGE_DYNAMIC,
                    BindFlags: D3D11_BIND_CONSTANT_BUFFER.0 as u32,
                    CPUAccessFlags: D3D11_CPU_ACCESS_WRITE.0 as u32,
                    ..Default::default()
                },
                None,
                Some(&mut constants),
            )
            .map_err(e("constants"))?;
        let mut blend_desc = D3D11_BLEND_DESC::default();
        blend_desc.RenderTarget[0] = D3D11_RENDER_TARGET_BLEND_DESC {
            BlendEnable: true.into(),
            SrcBlend: D3D11_BLEND_SRC_ALPHA,
            DestBlend: D3D11_BLEND_INV_SRC_ALPHA,
            BlendOp: D3D11_BLEND_OP_ADD,
            SrcBlendAlpha: D3D11_BLEND_ZERO,
            DestBlendAlpha: D3D11_BLEND_ONE,
            BlendOpAlpha: D3D11_BLEND_OP_ADD,
            RenderTargetWriteMask: D3D11_COLOR_WRITE_ENABLE_ALL.0 as u8,
        };
        device.CreateBlendState(&blend_desc, Some(&mut blend)).map_err(e("blend"))?;
        device.CreateRasterizerState(&D3D11_RASTERIZER_DESC { FillMode: D3D11_FILL_SOLID, CullMode: D3D11_CULL_NONE, ..Default::default() }, Some(&mut raster)).map_err(e("raster"))?;
        device
            .CreateDepthStencilState(&D3D11_DEPTH_STENCIL_DESC { DepthEnable: false.into(), DepthWriteMask: D3D11_DEPTH_WRITE_MASK_ZERO, DepthFunc: D3D11_COMPARISON_ALWAYS, ..Default::default() }, Some(&mut depth))
            .map_err(e("depth"))?;
        Ok(Gpu {
            device: device.as_raw() as usize,
            state: state.ok_or("no state")?,
            vs: vs.ok_or("no vs")?,
            ps: ps.ok_or("no ps")?,
            constants: constants.ok_or("no constants")?,
            blend: blend.ok_or("no blend")?,
            raster: raster.ok_or("no raster")?,
            depth: depth.ok_or("no depth")?,
        })
    }
}

fn to_eye(t: &Mat3, v: [f32; 3]) -> [f32; 3] {
    std::array::from_fn(|i| (0..3).map(|k| t[i][k] * v[k]).sum())
}

fn ray_of(projection: &[f32; 5]) -> [f32; 4] {
    let [p00, p11, p02, p12, s] = *projection;
    [(-s - p02) / p00, (s - p12) / p11, 2.0 * s / p00, -2.0 * s / p11]
}

/// At the game's Present: draws the ball into the frame about to be shown.
///
/// # Safety
/// The game's live swap chain, on its render thread, from the Present hook.
pub unsafe fn draw(chain: &IDXGISwapChain, frame: u64) {
    let mut guard = SLOT.lock().unwrap_or_else(|e| e.into_inner());
    let slot = &mut *guard;
    if slot.failed {
        return;
    }
    let Some((p, turn, head, projection, game_ray, coord, seen)) = slot.data else { return };
    if !p.on || frame.saturating_sub(seen) > 3 {
        return;
    }
    let Some(depth_view) = slot.view.clone() else { return };
    // SAFETY: the game's live chain and device on its render thread; the game's pipeline is swapped out and back.
    unsafe {
        let Ok(device) = chain.GetDevice::<ID3D11Device>() else { return };
        if slot.gpu.as_ref().is_none_or(|g| g.device != device.as_raw() as usize) {
            match make(&device) {
                Ok(g) => {
                    crate::log!("disco: ready");
                    slot.gpu = Some(g);
                }
                Err(e) => {
                    crate::log!("disco: cannot draw: {e}");
                    slot.failed = true;
                    return;
                }
            }
        }
        let Some(gpu) = slot.gpu.as_ref() else { return };
        let Ok(back) = chain.GetBuffer::<ID3D11Texture2D>(0) else { return };
        let mut desc = D3D11_TEXTURE2D_DESC::default();
        back.GetDesc(&mut desc);
        let mut target = None;
        if device.CreateRenderTargetView(&back, None, Some(&mut target)).is_err() {
            return;
        }
        let rel = |v: [f32; 3]| to_eye(&turn, [v[0] - head[0], v[1] - head[1], v[2] - head[2]]);
        let c = rel(p.center);
        let top = rel([p.center[0], p.roof + 0.03, p.center[2]]);
        let constants = Constants {
            ray: ray_of(&projection),
            game_ray,
            coord: [coord[0], coord[1], 0.0, 0.0],
            size: [desc.Width as f32, desc.Height as f32, 0.0, 0.0],
            center: [c[0], c[1], c[2], p.radius],
            top: [top[0], top[1], top[2], 0.0],
            rot: std::array::from_fn(|i| [turn[0][i], turn[1][i], turn[2][i], 0.0]),
            params: [p.rows, p.mode as f32, p.time, p.spin],
            colour: [p.colour[0], p.colour[1], p.colour[2], p.strength],
        };
        let Ok(context) = device.GetImmediateContext() else { return };
        let Ok(context1) = context.cast::<ID3D11DeviceContext1>() else { return };
        let mut games: Option<ID3DDeviceContextState> = None;
        context1.SwapDeviceContextState(&gpu.state, Some(&mut games));
        let mut mapped = D3D11_MAPPED_SUBRESOURCE::default();
        if context.Map(&gpu.constants, 0, D3D11_MAP_WRITE_DISCARD, 0, Some(&mut mapped)).is_ok() {
            std::ptr::write_unaligned(mapped.pData as *mut Constants, constants);
            context.Unmap(&gpu.constants, 0);
            context.IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
            context.VSSetShader(&gpu.vs, None);
            context.PSSetShader(&gpu.ps, None);
            context.PSSetConstantBuffers(0, Some(&[Some(gpu.constants.clone())]));
            context.PSSetShaderResources(0, Some(&[Some(depth_view)]));
            context.RSSetState(&gpu.raster);
            context.RSSetViewports(Some(&[D3D11_VIEWPORT { TopLeftX: 0.0, TopLeftY: 0.0, Width: desc.Width as f32, Height: desc.Height as f32, MinDepth: 0.0, MaxDepth: 1.0 }]));
            context.OMSetRenderTargets(Some(&[target.clone()]), None);
            context.OMSetBlendState(&gpu.blend, None, 0xffff_ffff);
            context.OMSetDepthStencilState(&gpu.depth, 0);
            context.Draw(3, 0);
            context.OMSetRenderTargets(None, None);
            context.PSSetShaderResources(0, Some(&[None]));
        }
        context1.SwapDeviceContextState(games.as_ref(), None);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_shaders_compile() {
        compile(s!("vs"), s!("vs_5_0")).unwrap();
        compile(s!("ps"), s!("ps_5_0")).unwrap();
    }

    #[test]
    fn it_hangs_from_the_cabs_roof_in_its_middle() {
        let cabin = crate::trucks::GENERIC;
        let d = Disko { on: true, ..Disko::default() };
        let p = params(&d, &cabin, 2.0, 1.0);
        assert!((p.center[0] - (cabin.left + cabin.right) * 0.5).abs() < 1e-4);
        assert!(p.center[1] < cabin.roof && p.center[1] + p.radius <= cabin.roof);
        assert!(p.spin >= 0.0 && p.spin < std::f32::consts::TAU);
    }
}
