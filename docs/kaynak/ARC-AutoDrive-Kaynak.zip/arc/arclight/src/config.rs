//! The lights, as the player (or ETS2 Auto Drive) sets them: `Documents\ARC Studio\kabin_isigi.cfg`, read
//! again whenever it changes, so a change shows in the game at once.
//!
//! ```text
//! acik 1            # the lights on (the key toggles them too)
//! tus 76            # the key that toggles them (a virtual-key code: 76 = L), with Ctrl
//! ctrl 1
//! gecis 1.5         # seconds to fade in or out
//! sadece_ic 1       # light only the cab's interior (not the road through the windows)
//! [isik]            # one light; up to 32
//! acik 1
//! x 0.30            # from the driver's head (its default place): metres right
//! y 0.40            #   up
//! z 0.10            #   back
//! egim 90           # aimed this many degrees down from straight ahead
//! yan 0             # and this many degrees to the right
//! renk 255 214 170  # colour (sRGB)
//! guc 3.0           # strength
//! menzil 2.0        # reach (metres)
//! aci 120           # cone (degrees, its full width)
//! yumusak 0.4       # how soft the cone's edge is (0-1)
//! ayna 0            # also a mirror of it on the other side (x and yan turned over)
//! ```

use std::path::PathBuf;
use std::time::{Duration, Instant, SystemTime};

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Light {
    pub on: bool,
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub pitch: f32,
    pub yaw: f32,
    pub color: [f32; 3],
    pub strength: f32,
    pub reach: f32,
    pub cone: f32,
    pub soft: f32,
    pub mirror: bool,
}

impl Default for Light {
    fn default() -> Self {
        Self {
            on: true,
            x: 0.3,
            y: 0.4,
            z: 0.1,
            pitch: 90.0,
            yaw: 0.0,
            color: [255.0, 214.0, 170.0],
            strength: 3.0,
            reach: 2.0,
            cone: 120.0,
            soft: 0.4,
            mirror: false,
        }
    }
}

/// One zone of the LED strips.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct LedZone {
    pub on: bool,
    pub color: [f32; 3],
    pub strength: f32,
}

pub const LED_ZONES: usize = 6;

/// The LED strips: `led_acik 1`, `led_mod 0` (0 steady, 1 breathing, 2 colours running round the cab), `led_hiz`,
/// `led_kalinlik` (the strip's width, cm), `led_isik` (how much it lights the cab), `led N on r g b strength`
/// (0 ceiling, 1 upper wall, 2 shoulder line, 3 lower wall, 4 floor, 5 dashboard).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Led {
    pub on: bool,
    pub mode: u32,
    pub speed: f32,
    pub width: f32,
    pub spill: f32,
    pub zones: [LedZone; LED_ZONES],
}

impl Default for Led {
    fn default() -> Self {
        let z = |r: f32, g: f32, b: f32| LedZone { on: true, color: [r, g, b], strength: 1.0 };
        Self {
            on: false,
            mode: 0,
            speed: 1.0,
            width: 1.2,
            spill: 1.0,
            zones: [z(120.0, 70.0, 255.0), z(120.0, 70.0, 255.0), z(60.0, 170.0, 255.0), z(60.0, 170.0, 255.0), z(120.0, 70.0, 255.0), z(60.0, 170.0, 255.0)],
        }
    }
}

/// The disco ball: `disko_acik`, `disko_mod` (0 steady, 1 RGB flow, 2 mixed, 3 breathing, 4 strobe, 5 wave),
/// `disko_renk r g b`, `disko_hiz`, `disko_guc`, `disko_boyut` (radius, m), `disko_sarkma` (m below the roof),
/// `disko_sik` (rows of mirrors), `disko_x` and `disko_z` (m from the cab's middle).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Disko {
    pub on: bool,
    pub mode: u32,
    pub color: [f32; 3],
    pub speed: f32,
    pub strength: f32,
    pub radius: f32,
    pub drop: f32,
    pub rows: f32,
    pub x: f32,
    pub z: f32,
}

impl Default for Disko {
    fn default() -> Self {
        Self { on: false, mode: 1, color: [200.0, 120.0, 255.0], speed: 1.0, strength: 1.0, radius: 0.1, drop: 0.2, rows: 14.0, x: 0.0, z: 0.0 }
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct Config {
    pub on: bool,
    pub key: u32,
    pub ctrl: bool,
    pub fade: f32,
    pub interior_only: bool,
    /// A diagnostic view instead of the lights (0: none).
    pub diagnostic: u32,
    /// Brake and blinkers light the cab (`tepki 1`, see `react`).
    pub react: bool,
    pub lights: Vec<Light>,
    pub led: Led,
    pub disko: Disko,
}

pub const MAX_LIGHTS: usize = 32;

impl Default for Config {
    fn default() -> Self {
        Self {
            on: true,
            key: 0x4c,
            ctrl: true,
            fade: 1.5,
            interior_only: true,
            diagnostic: 0,
            react: false,
            lights: vec![
                Light { x: 0.0, y: 0.30, z: -0.40, pitch: 70.0, strength: 3.0, reach: 2.5, cone: 140.0, ..Light::default() },
                Light { x: 0.90, y: 0.30, z: -0.30, pitch: 70.0, strength: 2.5, reach: 2.5, cone: 140.0, ..Light::default() },
            ],
            led: Led::default(),
            disko: Disko::default(),
        }
    }
}

impl Config {
    pub fn parse(text: &str) -> Self {
        let mut c = Config { lights: Vec::new(), ..Config::default() };
        let mut light: Option<Light> = None;
        for line in text.lines() {
            let line = line.split('#').next().unwrap_or("").trim();
            if line.is_empty() {
                continue;
            }
            if line.eq_ignore_ascii_case("[isik]") || line.eq_ignore_ascii_case("[ışık]") {
                if let Some(l) = light.take() {
                    c.lights.push(l);
                }
                light = Some(Light::default());
                continue;
            }
            let mut words = line.split_whitespace();
            let Some(key) = words.next() else { continue };
            let nums: Vec<f32> = words.filter_map(|w| w.replace(',', ".").parse::<f32>().ok()).filter(|v| v.is_finite()).collect();
            let Some(&v) = nums.first() else { continue };
            match light.as_mut() {
                None => match key {
                    "acik" => c.on = v != 0.0,
                    "tus" => c.key = v.clamp(1.0, 254.0) as u32,
                    "ctrl" => c.ctrl = v != 0.0,
                    "gecis" => c.fade = v.clamp(0.0, 10.0),
                    "sadece_ic" => c.interior_only = v != 0.0,
                    "tani" => c.diagnostic = v.clamp(0.0, 9.0) as u32,
                    "tepki" => c.react = v != 0.0,
                    "disko_acik" => c.disko.on = v != 0.0,
                    "disko_mod" => c.disko.mode = v.clamp(0.0, 5.0) as u32,
                    "disko_renk" if nums.len() >= 3 => c.disko.color = [nums[0], nums[1], nums[2]].map(|x| x.clamp(0.0, 255.0)),
                    "disko_hiz" => c.disko.speed = v.clamp(0.0, 5.0),
                    "disko_guc" => c.disko.strength = v.clamp(0.0, 5.0),
                    "disko_boyut" => c.disko.radius = v.clamp(0.03, 0.3),
                    "disko_sarkma" => c.disko.drop = v.clamp(0.0, 0.8),
                    "disko_sik" => c.disko.rows = v.clamp(6.0, 32.0).round(),
                    "disko_x" => c.disko.x = v.clamp(-1.5, 1.5),
                    "disko_z" => c.disko.z = v.clamp(-1.5, 1.5),
                    "led_acik" => c.led.on = v != 0.0,
                    "led_mod" => c.led.mode = v.clamp(0.0, 2.0) as u32,
                    "led_hiz" => c.led.speed = v.clamp(0.0, 10.0),
                    "led_kalinlik" => c.led.width = v.clamp(0.2, 8.0),
                    "led_isik" => c.led.spill = v.clamp(0.0, 5.0),
                    "led" if nums.len() >= 6 && (v as usize) < LED_ZONES => {
                        c.led.zones[v as usize] = LedZone {
                            on: nums[1] != 0.0,
                            color: [nums[2], nums[3], nums[4]].map(|x| x.clamp(0.0, 255.0)),
                            strength: nums[5].clamp(0.0, 10.0),
                        };
                    }
                    _ => {}
                },
                Some(l) => match key {
                    "acik" => l.on = v != 0.0,
                    "x" => l.x = v.clamp(-3.0, 3.0),
                    "y" => l.y = v.clamp(-3.0, 3.0),
                    "z" => l.z = v.clamp(-3.0, 3.0),
                    "egim" => l.pitch = v.clamp(-180.0, 180.0),
                    "yan" => l.yaw = v.clamp(-180.0, 180.0),
                    "renk" if nums.len() >= 3 => l.color = [nums[0], nums[1], nums[2]].map(|c| c.clamp(0.0, 255.0)),
                    "guc" => l.strength = v.clamp(0.0, 100.0),
                    "menzil" => l.reach = v.clamp(0.1, 10.0),
                    "aci" => l.cone = v.clamp(1.0, 179.0),
                    "yumusak" => l.soft = v.clamp(0.0, 1.0),
                    "ayna" => l.mirror = v != 0.0,
                    _ => {}
                },
            }
        }
        if let Some(l) = light {
            c.lights.push(l);
        }
        c
    }

    pub fn text(&self) -> String {
        let mut s = String::from("# ARC Kabin Işığı: değiştirip kaydedince oyunda hemen görünür.\n");
        s += &format!(
            "acik {}\ntus {}\nctrl {}\ngecis {}\nsadece_ic {}\ntepki {}\n",
            self.on as u8, self.key, self.ctrl as u8, self.fade, self.interior_only as u8, self.react as u8
        );
        let d = &self.disko;
        s += &format!(
            "disko_acik {}\ndisko_mod {}\ndisko_renk {} {} {}\ndisko_hiz {}\ndisko_guc {}\ndisko_boyut {}\ndisko_sarkma {}\ndisko_sik {}\ndisko_x {}\ndisko_z {}\n",
            d.on as u8, d.mode, d.color[0], d.color[1], d.color[2], d.speed, d.strength, d.radius, d.drop, d.rows, d.x, d.z
        );
        s += &format!("led_acik {}\nled_mod {}\nled_hiz {}\nled_kalinlik {}\nled_isik {}\n", self.led.on as u8, self.led.mode, self.led.speed, self.led.width, self.led.spill);
        for (i, z) in self.led.zones.iter().enumerate() {
            s += &format!("led {} {} {} {} {} {}\n", i, z.on as u8, z.color[0], z.color[1], z.color[2], z.strength);
        }
        for l in &self.lights {
            s += &format!(
                "\n[isik]\nacik {}\nx {}\ny {}\nz {}\negim {}\nyan {}\nrenk {} {} {}\nguc {}\nmenzil {}\naci {}\nyumusak {}\nayna {}\n",
                l.on as u8, l.x, l.y, l.z, l.pitch, l.yaw, l.color[0], l.color[1], l.color[2], l.strength, l.reach,
                l.cone, l.soft, l.mirror as u8
            );
        }
        s
    }

    /// The lights to draw: each that's on, and its mirror where asked, at most [`MAX_LIGHTS`].
    pub fn active(&self) -> Vec<Light> {
        let mut out = Vec::new();
        for l in self.lights.iter().filter(|l| l.on) {
            out.push(*l);
            if l.mirror {
                out.push(Light { x: -l.x, yaw: -l.yaw, mirror: false, ..*l });
            }
        }
        out.truncate(MAX_LIGHTS);
        out
    }
}

pub fn path() -> PathBuf {
    crate::log::dir().join("kabin_isigi.cfg")
}

/// The settings, read again when the file changes (looked at a few times a second).
pub struct Watched {
    pub config: Config,
    written: Option<SystemTime>,
    looked: Option<Instant>,
}

impl Watched {
    pub fn new() -> Self {
        Self { config: Config::default(), written: None, looked: None }
    }

    /// Looks at the file now and then; returns whether the settings changed.
    pub fn refresh(&mut self) -> bool {
        if self.looked.is_some_and(|at| at.elapsed() < Duration::from_millis(200)) {
            return false;
        }
        self.looked = Some(Instant::now());
        let path = path();
        let written = std::fs::metadata(&path).and_then(|m| m.modified()).ok();
        if written.is_none() {
            // None yet: the defaults, written out for the player to change.
            let _ = std::fs::write(&path, Config::default().text());
            self.written = std::fs::metadata(&path).and_then(|m| m.modified()).ok();
            self.config = Config::default();
            return true;
        }
        if written == self.written {
            return false;
        }
        self.written = written;
        match std::fs::read_to_string(&path) {
            Ok(text) => {
                let config = Config::parse(&text);
                let changed = config != self.config;
                self.config = config;
                changed
            }
            Err(_) => false,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_back_what_it_writes_and_mirrors() {
        let mut c = Config::default();
        c.lights[1].mirror = true;
        let back = Config::parse(&c.text());
        assert_eq!(back, c);
        let active = back.active();
        assert_eq!(active.len(), 3);
        assert_eq!(active[2].x, -c.lights[1].x);
    }

    #[test]
    fn brake_and_blinker_reaction_off_unless_asked() {
        assert!(!Config::default().react && !Config::parse("acik 1\n").react);
        let c = Config::parse("tepki 1\n");
        assert!(c.react);
        assert_eq!(Config::parse(&c.text()), c);
    }

    #[test]
    fn wild_values_are_kept_in_range() {
        let c = Config::parse("acik 1\n[isik]\nx 99\nrenk 300 -5 10\nmenzil 0\naci 999\nguc nan\n");
        let l = c.lights[0];
        assert_eq!(l.x, 3.0);
        assert_eq!(l.color, [255.0, 0.0, 10.0]);
        assert_eq!(l.reach, 0.1);
        assert_eq!(l.cone, 179.0);
        assert_eq!(l.strength, Light::default().strength);
    }
}
