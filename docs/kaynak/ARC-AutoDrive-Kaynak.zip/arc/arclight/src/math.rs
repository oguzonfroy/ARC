//! The little linear algebra the tablet needs, in the game's conventions.
//!
//! Matrices are row-major and used with row vectors, as the game uploads its own (`clip = [x, y, z, 1] * M`).
//! Rotations follow the SCS SDK: x right, y up, z backward; heading turns counterclockwise seen from above
//! (around y), pitch raises the nose (around x), roll turns counterclockwise looking along the roll axis
//! (around z), applied heading, then pitch, then roll. Angles from the SDK are in turns (1 = 360 degrees).

pub type Mat3 = [[f32; 3]; 3];
pub type Mat4 = [[f32; 4]; 4];

#[cfg_attr(not(test), allow(dead_code))]
pub const IDENTITY3: Mat3 = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]];

pub fn mul3(a: &Mat3, b: &Mat3) -> Mat3 {
    std::array::from_fn(|r| std::array::from_fn(|c| (0..3).map(|k| a[r][k] * b[k][c]).sum()))
}

pub fn mul4(a: &Mat4, b: &Mat4) -> Mat4 {
    std::array::from_fn(|r| std::array::from_fn(|c| (0..4).map(|k| a[r][k] * b[k][c]).sum()))
}

pub fn transpose3(a: &Mat3) -> Mat3 {
    std::array::from_fn(|r| std::array::from_fn(|c| a[c][r]))
}

/// `v * a` (a row vector times a matrix).
#[cfg_attr(not(test), allow(dead_code))]
pub fn row_times3(v: [f32; 3], a: &Mat3) -> [f32; 3] {
    std::array::from_fn(|c| (0..3).map(|k| v[k] * a[k][c]).sum())
}

/// The rotation about y by `a` radians (column-vector form: `R * v` turns `v`).
pub fn rot_y(a: f32) -> Mat3 {
    let (s, c) = a.sin_cos();
    [[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]]
}

pub fn rot_x(a: f32) -> Mat3 {
    let (s, c) = a.sin_cos();
    [[1.0, 0.0, 0.0], [0.0, c, -s], [0.0, s, c]]
}

pub fn rot_z(a: f32) -> Mat3 {
    let (s, c) = a.sin_cos();
    [[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]]
}

/// An SDK orientation (heading, pitch, roll in turns) as a rotation matrix (column-vector form).
pub fn euler(heading: f32, pitch: f32, roll: f32) -> Mat3 {
    let turn = std::f32::consts::TAU;
    mul3(&mul3(&rot_y(heading * turn), &rot_x(pitch * turn)), &rot_z(roll * turn))
}

/// The angle (degrees) of the rotation that takes `a` to `b`.
pub fn angle_between(a: &Mat3, b: &Mat3) -> f32 {
    let r = mul3(&transpose3(a), b);
    let cos = ((r[0][0] + r[1][1] + r[2][2] - 1.0) / 2.0).clamp(-1.0, 1.0);
    cos.acos().to_degrees()
}

fn dot(a: [f32; 3], b: [f32; 3]) -> f32 {
    a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
}

fn cross(a: [f32; 3], b: [f32; 3]) -> [f32; 3] {
    [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
}

fn scaled(a: [f32; 3], s: f32) -> [f32; 3] {
    [a[0] * s, a[1] * s, a[2] * s]
}

fn minus(a: [f32; 3], b: [f32; 3]) -> [f32; 3] {
    [a[0] - b[0], a[1] - b[1], a[2] - b[2]]
}

fn length(a: [f32; 3]) -> f32 {
    dot(a, a).sqrt()
}

/// The nearest rotation to `m` (its rows made orthonormal, the first kept as it points), if `m` is nearly one
/// already: each row within 2% of unit length and within about 1 degree of square with the others.
pub fn as_rotation(m: &Mat3) -> Option<Mat3> {
    for r in m {
        if !(0.98..=1.02).contains(&length(*r)) {
            return None;
        }
    }
    if dot(m[0], m[1]).abs() > 0.02 || dot(m[0], m[2]).abs() > 0.02 || dot(m[1], m[2]).abs() > 0.02 {
        return None;
    }
    let x = scaled(m[0], 1.0 / length(m[0]));
    let y = minus(m[1], scaled(x, dot(m[1], x)));
    let y = scaled(y, 1.0 / length(y));
    let z = cross(x, y);
    // A mirror isn't a rotation.
    (dot(z, m[2]) > 0.0).then_some([x, y, z])
}

/// The inverse of `m`, if it has one.
pub fn inverse4(m: &Mat4) -> Option<Mat4> {
    // Gauss-Jordan with partial pivoting, in f64.
    let mut a: [[f64; 8]; 4] = std::array::from_fn(|r| {
        std::array::from_fn(|c| if c < 4 { m[r][c] as f64 } else if c - 4 == r { 1.0 } else { 0.0 })
    });
    for col in 0..4 {
        let pivot = (col..4).max_by(|&i, &j| a[i][col].abs().total_cmp(&a[j][col].abs()))?;
        if a[pivot][col].abs() < 1e-12 {
            return None;
        }
        a.swap(col, pivot);
        let p = a[col][col];
        for v in &mut a[col] {
            *v /= p;
        }
        for r in 0..4 {
            if r != col {
                let f = a[r][col];
                if f != 0.0 {
                    let pivot_row = a[col];
                    for (v, p) in a[r].iter_mut().zip(pivot_row) {
                        *v -= f * p;
                    }
                }
            }
        }
    }
    Some(std::array::from_fn(|r| std::array::from_fn(|c| a[r][c + 4] as f32)))
}

/// Where the camera sits in a view-projection's own space (row-vector form): the point it maps to x = y = w = 0.
pub fn camera_of(m: &Mat4) -> Option<[f32; 3]> {
    // [c, 1] * M has columns 0, 1 and 3 zero: three equations in c, by Cramer's rule.
    let rows = [[m[0][0], m[1][0], m[2][0]], [m[0][1], m[1][1], m[2][1]], [m[0][3], m[1][3], m[2][3]]];
    let rhs = [-m[3][0], -m[3][1], -m[3][3]];
    let det = |a: [[f32; 3]; 3]| {
        a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1]) - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0])
            + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0])
    };
    let d = det(rows);
    if d.abs() < 1e-9 {
        return None;
    }
    let mut c = [0.0f32; 3];
    for (k, out) in c.iter_mut().enumerate() {
        let mut a = rows;
        for row in 0..3 {
            a[row][k] = rhs[row];
        }
        *out = det(a) / d;
    }
    c.iter().all(|v| v.is_finite()).then_some(c)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn close(a: &Mat4, b: &Mat4) -> bool {
        a.iter().flatten().zip(b.iter().flatten()).all(|(x, y)| (x - y).abs() < 1e-4)
    }

    #[test]
    fn inverts_a_projection() {
        let p: Mat4 = [[0.89, 0.0, 0.0, 0.0], [0.0, 1.582, 0.0, 0.0], [0.0002, -0.0001, 0.0, -1.0], [0.0, 0.0, 0.2, 0.0]];
        let inv = inverse4(&p).unwrap();
        let id: Mat4 = std::array::from_fn(|r| std::array::from_fn(|c| if r == c { 1.0 } else { 0.0 }));
        assert!(close(&mul4(&p, &inv), &id));
    }

    #[test]
    fn heading_turns_forward_to_the_left() {
        // Forward is -z; a quarter turn of heading points it left (-x), as the SDK says.
        let r = euler(0.25, 0.0, 0.0);
        let forward = [-r[0][2], -r[1][2], -r[2][2]];
        assert!((forward[0] + 1.0).abs() < 1e-5 && forward[2].abs() < 1e-5);
        // Positive pitch raises it.
        let r = euler(0.0, 0.05, 0.0);
        assert!(-r[1][2] > 0.3);
    }

    #[test]
    fn finds_the_camera_of_a_view_projection() {
        // A projection moved so the camera sits at (1, 2, 3).
        let p: Mat4 = [[0.89, 0.0, 0.0, 0.0], [0.0, 1.582, 0.0, 0.0], [0.0, 0.0, 0.0, -1.0], [0.0, 0.0, 0.2, 0.0]];
        let t: Mat4 = [[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0], [-1.0, -2.0, -3.0, 1.0]];
        let c = camera_of(&mul4(&t, &p)).unwrap();
        assert!((c[0] - 1.0).abs() < 1e-4 && (c[1] - 2.0).abs() < 1e-4 && (c[2] - 3.0).abs() < 1e-4);
    }

    #[test]
    fn a_rotation_stays_and_a_stretch_or_mirror_does_not() {
        let r = euler(0.1, -0.02, 0.01);
        let back = as_rotation(&r).unwrap();
        assert!(angle_between(&r, &back) < 1e-3);
        let mut stretched = r;
        stretched[0] = scaled(r[0], 1.1);
        assert!(as_rotation(&stretched).is_none());
        let mut mirrored = r;
        mirrored[2] = scaled(r[2], -1.0);
        assert!(as_rotation(&mirrored).is_none());
    }
}
