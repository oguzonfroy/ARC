//! The game's Direct3D 11 functions this plugin listens in on, and its frame.
//!
//! - `CreatePixelShader`: tells the light pass's shader (`dxbc`).
//! - `PSSetShader` and the draws: right after the light pass draws, the cab's lights are added (`light`).
//! - `Map`, `VSSetConstantBuffers(1)`: the matrices the game draws with, for the camera in the cab (`view`).
//! - `Present`: the frame's end: the settings, the key, the fade.
//!
//! MinHook patches the functions inside d3d11.dll/dxgi.dll, so the game's own device and contexts go through
//! them. A panic in here never reaches the game (`guarded`), and our own calls inside are let through.

use windows::Win32::Foundation::{HANDLE, WAIT_OBJECT_0};
use windows::Win32::System::LibraryLoader::{GetModuleHandleW, GetProcAddress};
use windows::Win32::System::Threading::{OpenEventW, SYNCHRONIZATION_SYNCHRONIZE, WaitForSingleObject};
use windows::core::{s as cs, w};
use std::cell::Cell;
use std::collections::HashSet;
use std::ffi::c_void;
use std::panic::AssertUnwindSafe;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::{LazyLock, Mutex};
use std::time::Instant;

use minhook::MinHook;
use windows::Win32::Foundation::HMODULE;
use windows::Win32::Graphics::Direct3D::D3D_DRIVER_TYPE_HARDWARE;
use windows::Win32::Graphics::Direct3D11::{
    D3D11_CREATE_DEVICE_FLAG, D3D11_MAPPED_SUBRESOURCE, D3D11_SDK_VERSION, D3D11CreateDeviceAndSwapChain,
    ID3D11Device, ID3D11DeviceContext, ID3D11DeviceContext1,
};
use windows::Win32::Graphics::Dxgi::Common::{DXGI_FORMAT_R8G8B8A8_UNORM, DXGI_MODE_DESC, DXGI_SAMPLE_DESC};
use windows::Win32::Graphics::Dxgi::{
    DXGI_PRESENT_PARAMETERS, DXGI_SWAP_CHAIN_DESC, DXGI_SWAP_EFFECT_DISCARD, DXGI_USAGE_RENDER_TARGET_OUTPUT,
    IDXGISwapChain,
};
use windows::Win32::UI::Input::KeyboardAndMouse::{GetAsyncKeyState, VK_CONTROL};
use windows::Win32::UI::WindowsAndMessaging::{CreateWindowExW, DestroyWindow, WINDOW_EX_STYLE, WS_OVERLAPPEDWINDOW};
use windows::core::{BOOL, HRESULT, Interface};

use crate::config::Watched;
use crate::{cab, light, telemetry};

thread_local! {
    static INSIDE: Cell<bool> = const { Cell::new(false) };
    /// The pixel shader bound last on this thread's context.
    static CURRENT_PS: Cell<usize> = const { Cell::new(0) };
}

/// Runs plugin code from a hook: never re-entered (our own calls land in the hooks too), never unwinding into
/// the game.
fn guarded(f: impl FnOnce()) {
    if INSIDE.with(|i| i.replace(true)) {
        return;
    }
    if std::panic::catch_unwind(AssertUnwindSafe(f)).is_err() {
        log!("a panic in a hook was contained");
    }
    INSIDE.with(|i| i.set(false));
}

static TARGETS: Mutex<Vec<usize>> = Mutex::new(Vec::new());

macro_rules! originals {
    ($($name:ident),*) => { $(static $name: AtomicUsize = AtomicUsize::new(0);)* };
}
originals!(
    O_CREATE_PS, O_PS_SET_SHADER, O_DRAW, O_DRAW_INDEXED, O_DRAW_INSTANCED, O_DRAW_INDEXED_INSTANCED, O_MAP,
    O_VS_CB, O_VS_CB1, O_PRESENT, O_PRESENT1, O_SET_CURSOR, O_CLIP_CURSOR
);

/// The light pass's pixel shaders (their addresses).
static LIGHT_SHADERS: LazyLock<Mutex<HashSet<usize>>> = LazyLock::new(|| Mutex::new(HashSet::new()));
/// Every pixel shader drawn with, told once: whether it's the light pass's.
static KINDS: LazyLock<Mutex<std::collections::HashMap<usize, bool>>> = LazyLock::new(|| Mutex::new(std::collections::HashMap::new()));
/// Presented frames.
static FRAME: AtomicU64 = AtomicU64::new(0);
/// The frame the lights were last added in (once a frame, whatever the light pass's draws).
static LIT_FRAME: AtomicU64 = AtomicU64::new(u64::MAX);
static IN_PRESENT: AtomicBool = AtomicBool::new(false);
/// The back buffer's width.
static SCREEN_WIDTH: AtomicU64 = AtomicU64::new(0);

struct Frame {
    settings: Watched,
    /// The lights on (the key toggles it), and how far faded in (0-1).
    on: bool,
    fade: f32,
    key_was_down: bool,
    last: Option<Instant>,
    light_passes: u64,
    lit: u64,
    no_camera: u64,
}

static STATE: LazyLock<Mutex<Frame>> = LazyLock::new(|| {
    Mutex::new(Frame {
        settings: Watched::new(),
        on: true,
        fade: 0.0,
        key_was_down: false,
        last: None,
        light_passes: 0,
        lit: 0,
        no_camera: 0,
    })
});

/// # Safety
/// In the game's process, at init on its main thread.
pub unsafe fn install() -> Result<(), String> {
    // SAFETY: d3d11's and dxgi's own vtables (from throwaway objects), each function by its field in the
    // interface's vtable type, hooked with detours of the same signatures.
    unsafe {
        let (device, context, context1, chain) = dummy()?;
        let hook = |target: usize, detour: *mut c_void, original: &AtomicUsize| -> Result<(), String> {
            let trampoline = MinHook::create_hook(target as *mut c_void, detour).map_err(|e| format!("{e:?}"))?;
            original.store(trampoline as usize, Ordering::Release);
            TARGETS.lock().unwrap_or_else(|e| e.into_inner()).push(target);
            Ok(())
        };
        let user32 = GetModuleHandleW(w!("user32.dll")).map_err(|e| format!("{e:?}"))?;
        for (name, detour, original) in [
            (cs!("SetCursorPos"), set_cursor_pos as *mut c_void, &O_SET_CURSOR),
            (cs!("ClipCursor"), clip_cursor as *mut c_void, &O_CLIP_CURSOR),
        ] {
            let target = GetProcAddress(user32, name).ok_or("no cursor function")?;
            hook(target as usize, detour, original)?;
        }
        let d = Interface::vtable(&device);
        let c = Interface::vtable(&context);
        let c1 = Interface::vtable(&context1);
        let s = Interface::vtable(&chain);
        hook(d.CreatePixelShader as usize, create_ps as *mut c_void, &O_CREATE_PS)?;
        hook(c.PSSetShader as usize, ps_set_shader as *mut c_void, &O_PS_SET_SHADER)?;
        hook(c.Draw as usize, draw as *mut c_void, &O_DRAW)?;
        hook(c.DrawIndexed as usize, draw_indexed as *mut c_void, &O_DRAW_INDEXED)?;
        hook(c.DrawInstanced as usize, draw_instanced as *mut c_void, &O_DRAW_INSTANCED)?;
        hook(c.DrawIndexedInstanced as usize, draw_indexed_instanced as *mut c_void, &O_DRAW_INDEXED_INSTANCED)?;
        hook(c.Map as usize, map as *mut c_void, &O_MAP)?;
        hook(c.VSSetConstantBuffers as usize, vs_cb as *mut c_void, &O_VS_CB)?;
        hook(c1.VSSetConstantBuffers1 as usize, vs_cb1 as *mut c_void, &O_VS_CB1)?;
        hook(s.Present as usize, present as *mut c_void, &O_PRESENT)?;
        // IDXGISwapChain1::Present1 shares the vtable (slot 22) on DXGI 1.2+.
        let present1 = *(*(chain.as_raw() as *const *const usize)).add(22);
        hook(present1, present1_hook as *mut c_void, &O_PRESENT1)?;
        MinHook::enable_all_hooks().map_err(|e| format!("{e:?}"))?;
        log!("hooks installed");
        Ok(())
    }
}

/// Switches the hooks off and removes them (the plugin unloading).
///
/// # Safety
/// No detour may run meanwhile or after (the game calls this on its main thread; the caller waits).
pub unsafe fn remove() {
    for target in TARGETS.lock().unwrap_or_else(|e| e.into_inner()).drain(..) {
        // SAFETY: a hook this plugin made, removed once.
        unsafe {
            let _ = MinHook::disable_hook(target as *mut c_void);
            let _ = MinHook::remove_hook(target as *mut c_void);
        }
    }
}

/// # Safety
/// On a thread that may own a window (the game's main thread, at init).
unsafe fn dummy() -> Result<(ID3D11Device, ID3D11DeviceContext, ID3D11DeviceContext1, IDXGISwapChain), String> {
    // SAFETY: a hidden window, device and swap chain made here; the window is let go before returning.
    unsafe {
        let hinstance = GetModuleHandleW(None).map_err(|e| e.to_string())?;
        let hwnd = CreateWindowExW(
            WINDOW_EX_STYLE(0),
            w!("STATIC"),
            w!("arclight-dummy"),
            WS_OVERLAPPEDWINDOW,
            0,
            0,
            64,
            64,
            None,
            None,
            Some(hinstance.into()),
            None,
        )
        .map_err(|e| e.to_string())?;
        let result = (|| {
            let desc = DXGI_SWAP_CHAIN_DESC {
                BufferDesc: DXGI_MODE_DESC { Width: 64, Height: 64, Format: DXGI_FORMAT_R8G8B8A8_UNORM, ..Default::default() },
                SampleDesc: DXGI_SAMPLE_DESC { Count: 1, Quality: 0 },
                BufferUsage: DXGI_USAGE_RENDER_TARGET_OUTPUT,
                BufferCount: 1,
                OutputWindow: hwnd,
                Windowed: BOOL::from(true),
                SwapEffect: DXGI_SWAP_EFFECT_DISCARD,
                Flags: 0,
            };
            let (mut chain, mut device, mut context) = (None, None, None);
            D3D11CreateDeviceAndSwapChain(
                None,
                D3D_DRIVER_TYPE_HARDWARE,
                HMODULE::default(),
                D3D11_CREATE_DEVICE_FLAG(0),
                None,
                D3D11_SDK_VERSION,
                Some(&desc),
                Some(&mut chain),
                Some(&mut device),
                None,
                Some(&mut context),
            )
            .map_err(|e| e.to_string())?;
            let context: ID3D11DeviceContext = context.ok_or("no context")?;
            let context1 = context.cast::<ID3D11DeviceContext1>().map_err(|e| e.to_string())?;
            Ok((device.ok_or("no device")?, context, context1, chain.ok_or("no swap chain")?))
        })();
        let _ = DestroyWindow(hwnd);
        result
    }
}

// --------------------------------------------------------------------------------------------------------------
// Detours

unsafe extern "system" fn create_ps(this: *mut c_void, code: *const c_void, len: usize, linkage: *mut c_void, out: *mut *mut c_void) -> HRESULT {
    // SAFETY: the original with the game's arguments; its bytecode read within its length, the shader once made.
    unsafe {
        let f: unsafe extern "system" fn(*mut c_void, *const c_void, usize, *mut c_void, *mut *mut c_void) -> HRESULT =
            std::mem::transmute(O_CREATE_PS.load(Ordering::Acquire));
        let result = f(this, code, len, linkage, out);
        if result.is_ok() && !code.is_null() && !out.is_null() && len < 16 << 20 {
            guarded(|| {
                let bytes = std::slice::from_raw_parts(code as *const u8, len);
                if crate::dxbc::is_light_pass(bytes) {
                    let shader = *out as usize;
                    log!("the game's light pass shader found ({len} bytes) at {shader:#x}");
                    LIGHT_SHADERS.lock().unwrap_or_else(|e| e.into_inner()).insert(shader);
                }
            });
        }
        result
    }
}

unsafe extern "system" fn ps_set_shader(this: *mut c_void, shader: *mut c_void, instances: *const *mut c_void, count: u32) {
    // SAFETY: the original with the game's arguments.
    unsafe {
        if !INSIDE.with(|i| i.get()) {
            CURRENT_PS.with(|c| c.set(shader as usize));
        }
        let f: unsafe extern "system" fn(*mut c_void, *mut c_void, *const *mut c_void, u32) =
            std::mem::transmute(O_PS_SET_SHADER.load(Ordering::Acquire));
        f(this, shader, instances, count)
    }
}

/// After a draw: if the light pass drew it, the cab's lights are added (once a frame).
fn after_draw(context: *mut c_void) {
    let ps = CURRENT_PS.with(|c| c.get());
    if ps == 0 || INSIDE.with(|i| i.get()) {
        return;
    }
    let frame = FRAME.load(Ordering::Acquire);
    if LIT_FRAME.load(Ordering::Acquire) == frame {
        return;
    }
    // Each pixel shader is told once: by its bytecode if the plugin saw it made, else by what it's drawn with.
    let known = KINDS.lock().unwrap_or_else(|e| e.into_inner()).get(&ps).copied();
    let is_light_pass = match known {
        Some(kind) => kind,
        None => {
            let mut kind = LIGHT_SHADERS.lock().unwrap_or_else(|e| e.into_inner()).contains(&ps);
            if !kind {
                // SAFETY: the game's context the shader just drew on, on its render thread; only asked what's bound.
                guarded(|| kind = unsafe { light::bound_like_light_pass(context) });
            }
            if kind {
                log!("the game's light pass shader recognised by its bindings at {ps:#x}");
            }
            KINDS.lock().unwrap_or_else(|e| e.into_inner()).insert(ps, kind);
            kind
        }
    };
    if !is_light_pass {
        return;
    }
    // The main view's light pass only (the mirrors' views, if lit the same way, are smaller).
    let screen = SCREEN_WIDTH.load(Ordering::Acquire) as f32;
    let mut width = 0.0;
    // SAFETY: the game's context, only asked its viewport.
    guarded(|| width = unsafe { light::viewport_width(context) });
    if screen > 0.0 && width < screen * 0.6 {
        return;
    }
    LIT_FRAME.store(frame, Ordering::Release);
    guarded(|| {
        let head = telemetry::head_offset();
        let truck_id = telemetry::truck();
        let truck = truck_id.is_some();
        let eye = cab::at_light_pass(frame, truck.then_some(head));
        let mut state = STATE.lock().unwrap_or_else(|e| e.into_inner());
        state.light_passes += 1;
        let Some(camera) = eye else {
            state.no_camera += 1;
            return;
        };
        let lights = state.settings.config.active();
        let react = state.settings.config.react;
        let interior = state.settings.config.interior_only;
        let mode = state.settings.config.diagnostic;
        let cab_fade = state.fade;
        let led = state.settings.config.led;
        let disko_settings = state.settings.config.disko;
        drop(state);
        let cabin = crate::trucks::find(truck_id.as_deref(), telemetry::right_hand());
        let lamps = if react { crate::react::lights(&cabin, telemetry::signals()) } else { Vec::new() };
        let (lights, fade) = crate::react::merge(lights, cab_fade, lamps);
        static STARTED: std::sync::LazyLock<Instant> = std::sync::LazyLock::new(Instant::now);
        let time = STARTED.elapsed().as_secs_f32();
        let disko = crate::disco::params(&disko_settings, &cabin, time, cab_fade);
        if (fade > 0.0 || mode > 0) && (!lights.is_empty() || led.on || disko.on) {
            // SAFETY: the game's context the light pass just drew on, on its render thread.
            unsafe { light::after_light_pass(context, &lights, &led, &disko, &cabin, time, &camera, [head[0], head[1], head[2]], fade.max((mode > 0) as u32 as f32), interior, mode) };
            STATE.lock().unwrap_or_else(|e| e.into_inner()).lit += 1;
        }
    });
}

unsafe extern "system" fn draw(this: *mut c_void, a: u32, b: u32) {
    // SAFETY: the original with the game's arguments.
    unsafe {
        let f: unsafe extern "system" fn(*mut c_void, u32, u32) = std::mem::transmute(O_DRAW.load(Ordering::Acquire));
        f(this, a, b);
    }
    after_draw(this);
}

unsafe extern "system" fn draw_indexed(this: *mut c_void, a: u32, b: u32, c: i32) {
    // SAFETY: the original with the game's arguments.
    unsafe {
        let f: unsafe extern "system" fn(*mut c_void, u32, u32, i32) = std::mem::transmute(O_DRAW_INDEXED.load(Ordering::Acquire));
        f(this, a, b, c);
    }
    after_draw(this);
}

unsafe extern "system" fn draw_instanced(this: *mut c_void, a: u32, b: u32, c: u32, d: u32) {
    // SAFETY: the original with the game's arguments.
    unsafe {
        let f: unsafe extern "system" fn(*mut c_void, u32, u32, u32, u32) =
            std::mem::transmute(O_DRAW_INSTANCED.load(Ordering::Acquire));
        f(this, a, b, c, d);
    }
    after_draw(this);
}

unsafe extern "system" fn draw_indexed_instanced(this: *mut c_void, a: u32, b: u32, c: u32, d: i32, e: u32) {
    // SAFETY: the original with the game's arguments.
    unsafe {
        let f: unsafe extern "system" fn(*mut c_void, u32, u32, u32, i32, u32) =
            std::mem::transmute(O_DRAW_INDEXED_INSTANCED.load(Ordering::Acquire));
        f(this, a, b, c, d, e);
    }
    after_draw(this);
}

unsafe extern "system" fn map(
    this: *mut c_void,
    resource: *mut c_void,
    sub: u32,
    kind: i32,
    flags: u32,
    mapped: *mut D3D11_MAPPED_SUBRESOURCE,
) -> HRESULT {
    // SAFETY: the original with the game's arguments; its mapping read only once it succeeded, still mapped.
    unsafe {
        let f: unsafe extern "system" fn(*mut c_void, *mut c_void, u32, i32, u32, *mut D3D11_MAPPED_SUBRESOURCE) -> HRESULT =
            std::mem::transmute(O_MAP.load(Ordering::Acquire));
        let result = f(this, resource, sub, kind, flags, mapped);
        if result.is_ok() && sub == 0 && !mapped.is_null() {
            let data = (*mapped).pData;
            guarded(|| cab::on_map(resource, data));
        }
        result
    }
}

unsafe extern "system" fn vs_cb(this: *mut c_void, start: u32, count: u32, buffers: *const *mut c_void) {
    // SAFETY: the game's arguments looked at, then the original with them.
    unsafe {
        guarded(|| cab::on_vs_constant_buffers(start, count, buffers, std::ptr::null(), std::ptr::null()));
        let f: unsafe extern "system" fn(*mut c_void, u32, u32, *const *mut c_void) = std::mem::transmute(O_VS_CB.load(Ordering::Acquire));
        f(this, start, count, buffers)
    }
}

unsafe extern "system" fn vs_cb1(this: *mut c_void, start: u32, count: u32, buffers: *const *mut c_void, first: *const u32, num: *const u32) {
    // SAFETY: as `vs_cb`.
    unsafe {
        guarded(|| cab::on_vs_constant_buffers(start, count, buffers, first, num));
        let f: unsafe extern "system" fn(*mut c_void, u32, u32, *const *mut c_void, *const u32, *const u32) =
            std::mem::transmute(O_VS_CB1.load(Ordering::Acquire));
        f(this, start, count, buffers, first, num)
    }
}

/// Whether the phone has the mouse: the game then may not pull the cursor back to its middle.
fn phone_has_mouse() -> bool {
    static EVENT: AtomicUsize = AtomicUsize::new(0);
    static TRIED: AtomicU64 = AtomicU64::new(0);
    let mut h = EVENT.load(Ordering::Relaxed);
    if h == 0 {
        if TRIED.fetch_add(1, Ordering::Relaxed) % 240 != 0 {
            return false;
        }
        // SAFETY: opening a named event by a constant name; the handle is kept for the process's life.
        match unsafe { OpenEventW(SYNCHRONIZATION_SYNCHRONIZE, false, w!("Local\\ARCTelefonModu")) } {
            Ok(e) => {
                h = e.0 as usize;
                EVENT.store(h, Ordering::Relaxed);
            }
            Err(_) => return false,
        }
    }
    // SAFETY: our own event handle, polled without waiting.
    unsafe { WaitForSingleObject(HANDLE(h as *mut c_void), 0) == WAIT_OBJECT_0 }
}

unsafe extern "system" fn set_cursor_pos(x: i32, y: i32) -> i32 {
    if phone_has_mouse() {
        return 1;
    }
    // SAFETY: the original with the game's arguments.
    unsafe {
        let f: unsafe extern "system" fn(i32, i32) -> i32 = std::mem::transmute(O_SET_CURSOR.load(Ordering::Acquire));
        f(x, y)
    }
}

unsafe extern "system" fn clip_cursor(rect: *const c_void) -> i32 {
    // SAFETY: the original, with the game's rectangle or, while the phone has the mouse, none.
    unsafe {
        let f: unsafe extern "system" fn(*const c_void) -> i32 = std::mem::transmute(O_CLIP_CURSOR.load(Ordering::Acquire));
        f(if phone_has_mouse() { std::ptr::null() } else { rect })
    }
}

unsafe extern "system" fn present(this: *mut c_void, sync: u32, flags: u32) -> HRESULT {
    // SAFETY: the original with the game's arguments.
    unsafe {
        let outer = !IN_PRESENT.swap(true, Ordering::AcqRel);
        if outer {
            guarded(|| on_present(this));
        }
        let f: unsafe extern "system" fn(*mut c_void, u32, u32) -> HRESULT = std::mem::transmute(O_PRESENT.load(Ordering::Acquire));
        let result = f(this, sync, flags);
        if outer {
            IN_PRESENT.store(false, Ordering::Release);
        }
        result
    }
}

unsafe extern "system" fn present1_hook(this: *mut c_void, sync: u32, flags: u32, params: *const DXGI_PRESENT_PARAMETERS) -> HRESULT {
    // SAFETY: the original with the game's arguments.
    unsafe {
        let outer = !IN_PRESENT.swap(true, Ordering::AcqRel);
        if outer {
            guarded(|| on_present(this));
        }
        let f: unsafe extern "system" fn(*mut c_void, u32, u32, *const DXGI_PRESENT_PARAMETERS) -> HRESULT =
            std::mem::transmute(O_PRESENT1.load(Ordering::Acquire));
        let result = f(this, sync, flags, params);
        if outer {
            IN_PRESENT.store(false, Ordering::Release);
        }
        result
    }
}

/// A frame's end: the screen's shape for `view`, the settings, the key and the fade.
fn on_present(chain: *mut c_void) {
    let frame = FRAME.fetch_add(1, Ordering::AcqRel) + 1;
    cab::end_frame(frame);
    // SAFETY: the game's swap chain, alive through its Present.
    unsafe {
        if let Some(chain) = IDXGISwapChain::from_raw_borrowed(&chain)
            && let Ok(desc) = chain.GetDesc()
        {
            SCREEN_WIDTH.store(desc.BufferDesc.Width as u64, Ordering::Release);
            crate::disco::draw(chain, frame);
            crate::hud::draw(chain, frame);
        }
    }
    let mut state = STATE.lock().unwrap_or_else(|e| e.into_inner());
    let state = &mut *state;
    if state.settings.refresh() {
        state.on = state.settings.config.on;
        log!("settings: {} lights, {}", state.settings.config.lights.len(), if state.on { "on" } else { "off" });
    }
    let config = &state.settings.config;
    // SAFETY: plain key queries.
    let (down, ctrl) = unsafe {
        (GetAsyncKeyState(config.key as i32) as u16 & 0x8000 != 0, GetAsyncKeyState(VK_CONTROL.0 as i32) as u16 & 0x8000 != 0)
    };
    if down && !state.key_was_down && (ctrl || !config.ctrl) && crate::foreground() {
        state.on = !state.on;
        log!("lights {}", if state.on { "on" } else { "off" });
    }
    state.key_was_down = down;
    let now = Instant::now();
    let dt = state.last.map_or(0.0, |t| (now - t).as_secs_f32()).min(0.25);
    state.last = Some(now);
    let target = if state.on { 1.0 } else { 0.0 };
    let step = if config.fade > 0.0 { dt / config.fade } else { 1.0 };
    state.fade = if state.fade < target { (state.fade + step).min(target) } else { (state.fade - step).max(target) };
    if frame.is_multiple_of(1800) {
        log!(
            "frames {frame}: light passes {}, lit {}, without the camera {}, fade {:.2}",
            state.light_passes,
            state.lit,
            state.no_camera,
            state.fade
        );
        state.light_passes = 0;
        state.lit = 0;
        state.no_camera = 0;
    }
}
