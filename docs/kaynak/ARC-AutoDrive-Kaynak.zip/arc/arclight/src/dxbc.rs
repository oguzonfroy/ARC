//! Tells the game's light pass shader (`def.apply.light.list*`) by what its bytecode declares, so it's found
//! whatever the game's version: a constant buffer of a thousand and more vectors at b0 (the light list), the
//! light list buffer at t9, the G-buffer's float attributes at t12 and t13 and its integer ones at t15, and two
//! outputs (the diffuse and specular light). Read from the game's own shaders (effect.scs, 1.61):
//! `cb0[1013]`/`cb0[1014]`, `t9` buffer, `t12`/`t13` float 2D, `t15` uint 2D, `o0`, `o1`.

/// Whether `bytecode` (a DXBC blob) is the light pass's pixel shader.
pub fn is_light_pass(bytecode: &[u8]) -> bool {
    let Some(tokens) = shader_tokens(bytecode) else { return false };
    let mut big_cb0 = false;
    let (mut t9_buffer, mut t12, mut t13, mut t15_uint) = (false, false, false, false);
    let mut outputs = 0;
    let mut p = 2;
    while p < tokens.len() {
        let t = tokens[p];
        let op = t & 0x7ff;
        let mut len = ((t >> 24) & 0x7f) as usize;
        if op == 0x35 {
            // customdata: its length is the next token.
            len = tokens.get(p + 1).copied().unwrap_or(0) as usize;
        }
        if len == 0 || p + len > tokens.len() {
            break;
        }
        let args = &tokens[p + 1..p + len];
        match op {
            // dcl_constantbuffer: operand token, register, size in vectors.
            0x59 if args.len() >= 3 => {
                if args[1] == 0 && args[2] >= 1000 {
                    big_cb0 = true;
                }
            }
            // dcl_resource: operand token, register, return type (4 bits per component).
            0x58 if args.len() >= 3 => {
                let dim = (t >> 11) & 0x1f;
                let (reg, ret) = (args[1], args[2]);
                match (reg, dim) {
                    (9, 1) => t9_buffer = true,
                    (12, 3) => t12 = true,
                    (13, 3) => t13 = true,
                    // 4: uint return type in every component.
                    (15, 3) if ret == 0x4444 => t15_uint = true,
                    _ => {}
                }
            }
            0x65 => outputs += 1,
            // Declarations end where the code starts (anything not a declaration).
            0x59 | 0x58 | 0x5a | 0x6a | 0x68 | 0x62 | 0x64 | 0x5f | 0x35 | 0x61 | 0x63 | 0x67 | 0x69 => {}
            _ => break,
        }
        p += len;
    }
    big_cb0 && t9_buffer && t12 && t13 && t15_uint && outputs >= 2
}

/// The shader program's tokens (the SHEX or SHDR chunk of a DXBC blob).
fn shader_tokens(dxbc: &[u8]) -> Option<Vec<u32>> {
    let u32_at = |at: usize| dxbc.get(at..at + 4).map(|b| u32::from_le_bytes([b[0], b[1], b[2], b[3]]));
    if dxbc.get(0..4)? != b"DXBC" {
        return None;
    }
    let chunks = u32_at(28)? as usize;
    for i in 0..chunks.min(64) {
        let at = u32_at(32 + 4 * i)? as usize;
        let tag = dxbc.get(at..at + 4)?;
        if tag == b"SHEX" || tag == b"SHDR" {
            let size = u32_at(at + 4)? as usize;
            let body = dxbc.get(at + 8..at + 8 + size)?;
            return Some(body.chunks_exact(4).map(|c| u32::from_le_bytes([c[0], c[1], c[2], c[3]])).collect());
        }
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The game's own shaders (from its effect.scs): `ARCLIGHT_SHADERS` = the folder of `effect/deferred/_shd`.
    #[test]
    #[ignore = "needs the game's shaders: ARCLIGHT_SHADERS"]
    fn tells_the_light_pass_among_the_games_shaders() {
        let dir = std::env::var("ARCLIGHT_SHADERS").unwrap();
        let read = |name: &str| {
            let b = std::fs::read(format!("{dir}/{name}")).unwrap();
            let at = b.windows(4).position(|w| w == b"DXBC").unwrap();
            b[at..].to_vec()
        };
        assert!(is_light_pass(&read("8af384d7cc4df20b5bb49ac0be0c2e79.sm5x.fso")));
        assert!(is_light_pass(&read("11181c3bb7263cef0f333520fafabad9.sm5x.fso")));
        // The coverage pass (a small constant buffer) is not.
        assert!(!is_light_pass(&read("ef2abef8a6cb63fc16fdbbc9b37c4120.sm5x.fso")));
        // Nor is any other pixel shader of the deferred passes.
        let mut others = 0;
        for entry in std::fs::read_dir(&dir).unwrap().flatten() {
            let name = entry.file_name().to_string_lossy().into_owned();
            if !name.ends_with(".sm5x.fso") {
                continue;
            }
            let b = std::fs::read(entry.path()).unwrap();
            let Some(at) = b.windows(4).position(|w| w == b"DXBC") else { continue };
            if is_light_pass(&b[at..]) {
                others += 1;
            }
        }
        assert_eq!(others, 2, "exactly the two light pass shaders");
    }
}
