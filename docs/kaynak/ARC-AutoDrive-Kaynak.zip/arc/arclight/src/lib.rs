//! ARC Kabin Işığı (`arclight.dll`): lights in the truck's cab, drawn into the game's own light pass, set live
//! from a settings file (`Documents\ARC Studio\kabin_isigi.cfg`, which ETS2 Auto Drive writes).
//!
//! Loaded by ETS2/ATS from `bin/win_x64/plugins` as an SDK plugin. Nothing in the game's files changes, and no
//! accessory is needed.

#[macro_use]
pub mod log;
mod cab;
mod config;
mod disco;
mod dxbc;
mod hooks;
mod hud;
mod light;
#[allow(dead_code)]
mod math;
mod react;
#[allow(dead_code)]
mod scs;
mod telemetry;
mod trucks;

use std::ffi::CString;
use std::panic::AssertUnwindSafe;

use scs::{SCS_RESULT_OK, SCS_RESULT_UNSUPPORTED, TelemetryInitParamsV100};
use windows::Win32::System::Threading::GetCurrentProcessId;
use windows::Win32::UI::WindowsAndMessaging::{GetForegroundWindow, GetWindowThreadProcessId};

/// Whether the game's window is in front (a key pressed is for it).
pub(crate) fn foreground() -> bool {
    // SAFETY: plain queries into a local.
    unsafe {
        let mut pid = 0u32;
        GetWindowThreadProcessId(GetForegroundWindow(), Some(&mut pid));
        pid == GetCurrentProcessId()
    }
}

/// # Safety
/// Called by the game with a valid `params` pointer for the negotiated `version`, on its main thread.
#[unsafe(no_mangle)]
pub unsafe extern "system" fn scs_telemetry_init(version: u32, params: *const TelemetryInitParamsV100) -> i32 {
    // SAFETY: as the game calls it (the contract above).
    std::panic::catch_unwind(AssertUnwindSafe(|| unsafe { init(version, params) })).unwrap_or(SCS_RESULT_UNSUPPORTED)
}

/// # Safety
/// As [`scs_telemetry_init`].
unsafe fn init(version: u32, params: *const TelemetryInitParamsV100) -> i32 {
    // SAFETY: the game's parameters for the version (checked), on its main thread.
    unsafe {
        if version != scs::SCS_TELEMETRY_VERSION_1_01 && version != scs::SCS_TELEMETRY_VERSION_1_00 {
            return SCS_RESULT_UNSUPPORTED;
        }
        let Some(params) = params.as_ref() else { return SCS_RESULT_UNSUPPORTED };
        log::init();
        log!("arclight {} loaded", env!("CARGO_PKG_VERSION"));
        telemetry::register(params);
        let status = match hooks::install() {
            Ok(()) => "hazir".to_string(),
            Err(e) => {
                log!("hooks: {e}");
                format!("kurulamadi: {e}")
            }
        };
        if let Some(game_log) = params.common.log
            && let Ok(message) = CString::new(format!("[arclight] ARC Kabin Isigi {status}; ayarlar: {}", config::path().display()))
        {
            game_log(scs::SCS_LOG_TYPE_MESSAGE, message.as_ptr());
        }
        SCS_RESULT_OK
    }
}

/// # Safety
/// Called by the game on its main thread, after a successful init.
#[unsafe(no_mangle)]
pub unsafe extern "system" fn scs_telemetry_shutdown() {
    let _ = std::panic::catch_unwind(|| {
        // SAFETY: the game's main thread; detours still running are given time to return below.
        unsafe { hooks::remove() };
        std::thread::sleep(std::time::Duration::from_millis(100));
        log!("unloaded");
    });
}
