using ETS2LA.Game.Data;
using ETS2LA.Logging;
using TruckLib.ScsMap;

namespace ARC.HaritaBudama;

/// <summary>
///  Harita belleğini küçültür. "Düşük" veri seviyesinde ETS2LA yalnız yolları ve kavşakları tutar, ama atılan öğelerin
///  düğümleri (ETS2 haritasında ~1,7 milyon) <c>Map.Nodes</c>'ta kalır ve onlara bağlı öğeleri de bellekte tutar.
///  Burada hiçbir yola ya da kavşağa bağlı olmayan düğümler silinir: ölçümde harita belleği 853 MB'tan 258 MB'a indi
///  (Orta seviye 988 MB). Yalnız Düşük seviyede çalışır; orada haritada yol ve kavşaktan başka öğe kalmadığı için
///  silinen düğümü kullanan bir şey yoktur.
///  ETS2LA.Game.dll'deki <c>Installation.ParseActual</c>, haritayı okuduktan hemen sonra, harita "hazır" sayılıp
///  eklentilere açılmadan önce bunu çağırır (yedek\il_yama "budama" yaması). Hata verirse haritaya dokunmaz.
/// </summary>
public static class HaritaBudama
{
    public static void Buda(Map? harita)
    {
        if (harita == null || DataSettings.Current.DataFidelity != DataFidelity.Low) return;
        try
        {
            int once = harita.Nodes.Count;
            int silinen = Uygula(harita);
            GC.Collect(GC.MaxGeneration, GCCollectionMode.Aggressive, true, true);
            Logger.Info($"ARC harita budama: {silinen} bağsız düğüm silindi ({once} -> {harita.Nodes.Count}).");
        }
        catch (Exception e)
        {
            Logger.Warn("ARC harita budama yapılamadı, harita olduğu gibi kullanılıyor: " + e.Message);
        }
    }

    /// <summary>Yol ve kavşaklara bağlı olmayan düğümleri siler; silinen sayıyı döner.</summary>
    public static int Uygula(Map harita)
    {
        var tut = new HashSet<ulong>();
        foreach (var oge in harita.MapItems.Values)
        {
            if (oge is Road r)
            {
                if (r.Node != null) tut.Add(r.Node.Uid);
                if (r.ForwardNode != null) tut.Add(r.ForwardNode.Uid);
            }
            else if (oge is Prefab p)
            {
                foreach (var n in p.Nodes) if (n != null) tut.Add(n.Uid);
            }
            else
            {
                return 0;  // Düşük seviyede olmaması gereken bir öğe var: o öğenin düğümünü silmemek için hiç budanmaz
            }
        }
        // NodeDictionary her düğümü bir de uzaysal ağaçta (RBush) tutar; 1,7 milyon tek tek Remove ayrıştırmayı ~50 sn
        // uzatıyordu. Kalacak ~65 bin düğüm ayrılıp sözlük ve ağaç baştan kurulur (ikisini de Add günceller).
        var kalan = harita.Nodes.Where(kv => tut.Contains(kv.Key)).ToList();
        int silinen = harita.Nodes.Count - kalan.Count;
        if (silinen == 0) return 0;
        harita.Nodes.Clear();
        foreach (var kv in kalan) harita.Nodes.Add(kv.Key, kv.Value);
        return silinen;
    }
}
