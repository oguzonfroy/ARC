using System.Globalization;
using System.Text;

namespace ARC.CabinLight;

/// <summary>Bir kabin ışığı (oyundaki eklentinin ayar dosyasındaki <c>[isik]</c> bölümü).</summary>
public class Light
{
    public bool On { get; set; } = true;
    /// <summary>Sürücünün başının varsayılan yerinden: sağa, yukarı, geriye (metre).</summary>
    public float X { get; set; } = 0.3f;
    public float Y { get; set; } = 0.4f;
    public float Z { get; set; } = 0.1f;
    /// <summary>Düz ileriden aşağı (derece) ve sağa (derece).</summary>
    public float Pitch { get; set; } = 90f;
    public float Yaw { get; set; } = 0f;
    public int R { get; set; } = 255;
    public int G { get; set; } = 214;
    public int B { get; set; } = 170;
    public float Strength { get; set; } = 3f;
    public float Reach { get; set; } = 2f;
    public float Cone { get; set; } = 120f;
    public float Soft { get; set; } = 0.4f;
    public bool Mirror { get; set; }

    public string Hex
    {
        get => $"#{R:x2}{G:x2}{B:x2}";
        set
        {
            var v = value.TrimStart('#');
            if (v.Length == 6 && int.TryParse(v, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var rgb))
            {
                R = (rgb >> 16) & 255;
                G = (rgb >> 8) & 255;
                B = rgb & 255;
            }
        }
    }

    public Light Copy() => (Light)MemberwiseClone();
}

/// <summary>Kabin LED şeridinin bir bölgesi.</summary>
public class LedZone
{
    public bool On { get; set; } = true;
    public int R { get; set; } = 120;
    public int G { get; set; } = 70;
    public int B { get; set; } = 255;
    public float Strength { get; set; } = 1f;
}

/// <summary>
///  Işıkların ayarları: <c>Belgeler\ARC Studio\kabin_isigi.cfg</c>. Oyundaki eklenti (arclight.dll) bu dosyayı
///  saniyede beş kez kontrol eder; kaydedilen her değişiklik oyunda hemen görünür.
/// </summary>
public class Settings
{
    public bool On { get; set; } = true;
    /// <summary>Işıkları açıp kapatan tuş (Windows sanal tuş kodu) ve Ctrl ile mi.</summary>
    public int Key { get; set; } = 0x4C;
    public bool Ctrl { get; set; } = true;
    public float Fade { get; set; } = 1.5f;
    public bool InteriorOnly { get; set; } = true;
    /// <summary>Tanı görünümü (0: yok); oyundaki eklentinin sorun ayıklaması için, korunur.</summary>
    public int Diagnostic { get; set; }
    public List<Light> Lights { get; set; } = new();

    public static readonly string[] LedZoneNames = { "Tavan", "Üst duvar", "Omuz hattı", "Alt duvar", "Zemin", "Ön panel" };
    public static readonly string[] LedModeNames = { "Sabit", "Nefes", "Renk akışı" };
    public bool LedOn { get; set; } = true;
    public int LedMode { get; set; }
    public float LedSpeed { get; set; } = 1f;
    public float LedWidth { get; set; } = 1.2f;
    public float LedSpill { get; set; } = 1f;
    public LedZone[] LedZones { get; set; } =
    {
        new(), new(), new() { R = 60, G = 170, B = 255 }, new() { R = 60, G = 170, B = 255 }, new(), new() { R = 60, G = 170, B = 255 },
    };

    public const int MaxLights = 32;

    public static Settings Default() => new()
    {
        Lights = new()
        {
            new Light { X = 0f, Y = 0.30f, Z = -0.40f, Pitch = 70f, Strength = 3f, Reach = 2.5f, Cone = 140f },
            new Light { X = 0.90f, Y = 0.30f, Z = -0.30f, Pitch = 70f, Strength = 2.5f, Reach = 2.5f, Cone = 140f },
        },
    };

    public static string FilePath
    {
        get
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "ARC Studio");
            Directory.CreateDirectory(dir);
            return Path.Combine(dir, "kabin_isigi.cfg");
        }
    }

    static string F(float v) => v.ToString("0.###", CultureInfo.InvariantCulture);

    public string Text()
    {
        var s = new StringBuilder("# ARC Kabin Işığı: ETS2 Auto Drive'dan ayarlanır; değişince oyunda hemen görünür.\n");
        s.Append($"acik {(On ? 1 : 0)}\ntus {Key}\nctrl {(Ctrl ? 1 : 0)}\ngecis {F(Fade)}\nsadece_ic {(InteriorOnly ? 1 : 0)}\n");
        if (Diagnostic > 0) s.Append($"tani {Diagnostic}\n");
        s.Append($"led_acik {(LedOn ? 1 : 0)}\nled_mod {LedMode}\nled_hiz {F(LedSpeed)}\nled_kalinlik {F(LedWidth)}\nled_isik {F(LedSpill)}\n");
        for (var i = 0; i < LedZones.Length; i++)
        {
            var z = LedZones[i];
            s.Append($"led {i} {(z.On ? 1 : 0)} {z.R} {z.G} {z.B} {F(z.Strength)}\n");
        }
        foreach (var l in Lights)
        {
            s.Append($"\n[isik]\nacik {(l.On ? 1 : 0)}\nx {F(l.X)}\ny {F(l.Y)}\nz {F(l.Z)}\negim {F(l.Pitch)}\nyan {F(l.Yaw)}\n");
            s.Append($"renk {l.R} {l.G} {l.B}\nguc {F(l.Strength)}\nmenzil {F(l.Reach)}\naci {F(l.Cone)}\nyumusak {F(l.Soft)}\nayna {(l.Mirror ? 1 : 0)}\n");
        }
        return s.ToString();
    }

    public static Settings Parse(string text)
    {
        var c = new Settings();
        Light? light = null;
        foreach (var raw in text.Split('\n'))
        {
            var line = raw.Split('#')[0].Trim();
            if (line.Length == 0) continue;
            if (line.Equals("[isik]", StringComparison.OrdinalIgnoreCase))
            {
                if (light != null) c.Lights.Add(light);
                light = new Light();
                continue;
            }
            var words = line.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
            var nums = words.Skip(1)
                .Select(w => float.TryParse(w.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out var v) ? v : float.NaN)
                .Where(v => !float.IsNaN(v) && !float.IsInfinity(v)).ToList();
            if (nums.Count == 0) continue;
            var v0 = nums[0];
            if (light == null)
            {
                switch (words[0])
                {
                    case "acik": c.On = v0 != 0; break;
                    case "tus": c.Key = (int)Math.Clamp(v0, 1, 254); break;
                    case "ctrl": c.Ctrl = v0 != 0; break;
                    case "gecis": c.Fade = Math.Clamp(v0, 0, 10); break;
                    case "sadece_ic": c.InteriorOnly = v0 != 0; break;
                    case "tani": c.Diagnostic = (int)Math.Clamp(v0, 0, 9); break;
                    case "led_acik": c.LedOn = v0 != 0; break;
                    case "led_mod": c.LedMode = (int)Math.Clamp(v0, 0, 2); break;
                    case "led_hiz": c.LedSpeed = Math.Clamp(v0, 0, 10); break;
                    case "led_kalinlik": c.LedWidth = Math.Clamp(v0, 0.2f, 8); break;
                    case "led_isik": c.LedSpill = Math.Clamp(v0, 0, 5); break;
                    case "led" when nums.Count >= 6 && v0 >= 0 && v0 < c.LedZones.Length:
                        var zone = c.LedZones[(int)v0];
                        zone.On = nums[1] != 0;
                        zone.R = (int)Math.Clamp(nums[2], 0, 255);
                        zone.G = (int)Math.Clamp(nums[3], 0, 255);
                        zone.B = (int)Math.Clamp(nums[4], 0, 255);
                        zone.Strength = Math.Clamp(nums[5], 0, 10);
                        break;
                }
            }
            else
            {
                switch (words[0])
                {
                    case "acik": light.On = v0 != 0; break;
                    case "x": light.X = Math.Clamp(v0, -3, 3); break;
                    case "y": light.Y = Math.Clamp(v0, -3, 3); break;
                    case "z": light.Z = Math.Clamp(v0, -3, 3); break;
                    case "egim": light.Pitch = Math.Clamp(v0, -180, 180); break;
                    case "yan": light.Yaw = Math.Clamp(v0, -180, 180); break;
                    case "renk" when nums.Count >= 3:
                        light.R = (int)Math.Clamp(nums[0], 0, 255);
                        light.G = (int)Math.Clamp(nums[1], 0, 255);
                        light.B = (int)Math.Clamp(nums[2], 0, 255);
                        break;
                    case "guc": light.Strength = Math.Clamp(v0, 0, 100); break;
                    case "menzil": light.Reach = Math.Clamp(v0, 0.1f, 10); break;
                    case "aci": light.Cone = Math.Clamp(v0, 1, 179); break;
                    case "yumusak": light.Soft = Math.Clamp(v0, 0, 1); break;
                    case "ayna": light.Mirror = v0 != 0; break;
                }
            }
        }
        if (light != null) c.Lights.Add(light);
        return c;
    }

    public static Settings Load()
    {
        try
        {
            if (File.Exists(FilePath)) return Parse(File.ReadAllText(FilePath));
        }
        catch { }
        return Default();
    }

    private static readonly object WriteLock = new();

    /// <summary>Dosyaya yazar (önce yanına, sonra üzerine: oyundaki eklenti yarım dosya görmez).</summary>
    public void Save()
    {
        lock (WriteLock)
        {
            try
            {
                var path = FilePath;
                var temp = path + ".yeni";
                File.WriteAllText(temp, Text(), new UTF8Encoding(false));
                File.Move(temp, path, true);
            }
            catch { }
        }
    }
}
