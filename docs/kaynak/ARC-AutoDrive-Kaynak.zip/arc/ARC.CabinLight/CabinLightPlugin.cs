using System.Diagnostics;
using System.Security.Cryptography;

using ETS2LA.Game;
using ETS2LA.Logging;
using ETS2LA.Notifications;
using ETS2LA.Shared;

namespace ARC.CabinLight;

/// <summary>
///  ARC Kabin Işığı: kabine, oyunun kendi ışık aşamasında çizilen ışıklar. Bu eklenti oyuna ışıkları çizen
///  eklentiyi (arclight.dll) kurar ve ayar sayfasıyla ışıkları canlı ayarlar.
/// </summary>
public class CabinLightPlugin : Plugin
{
    public const string PluginId = "arc.cabinlight";

    public override PluginInformation Info => new PluginInformation
    {
        Id = PluginId,
        Name = "ARC Oyun Çizimi",
        Description = "Sürüş göstergesini oyunun kendi görüntüsüne çizen eklentiyi oyuna kurar.",
        Version = "1.0.0",
        AuthorName = "ARC Studio",
        PluginPageButtonName = "Ayarlar",
    };

    public override float TickRate => 0.1f;

    /// <summary>Kurulumun durumu, ayar sayfasında gösterilir.</summary>
    public static string Status { get; private set; } = "";
    public static bool Installed { get; private set; }
    static bool _waitingNotified;

    public static CabinLightPlugin? Current { get; private set; }

    /// <summary>
    ///  Yüklenir yüklenmez (etkinleştirilmesini beklemeden: ARC'ta eklenti yöneticisi yok) oyuna kurar ve oyun
    ///  içi pencereyi ekler; kurulamadıysa (oyun açıktı) oyun kapanınca yeniden dener.
    /// </summary>
    public override void Init()
    {
        base.Init();
        Current = this;
        // Kabin ışıkları ve LED'ler kalktı: ayar dosyası disko topu ayarlarıyla başlar, kayıtlı disko ayarı korunur.
        if (!File.Exists(Settings.FilePath) || !File.ReadAllText(Settings.FilePath).Contains("disko_acik"))
            File.WriteAllText(Settings.FilePath, "acik 1\ntus 76\nctrl 1\ngecis 1.5\nsadece_ic 1\nled_acik 0\ndisko_acik 0\ndisko_mod 1\ndisko_renk 200 120 255\ndisko_hiz 1\ndisko_guc 1\ndisko_boyut 0.1\ndisko_sarkma 0.2\ndisko_sik 14\ndisko_x 0\ndisko_z 0\n", new System.Text.UTF8Encoding(false));
        Task.Run(async () =>
        {
            // Auto Drive'ın oyun ve pencere sistemleri hazır olsun.
            await Task.Delay(TimeSpan.FromSeconds(3));
            while (true)
            {
                if (!Installed) InstallIntoGames();
                await Task.Delay(TimeSpan.FromSeconds(10));
            }
        });
    }

    static byte[]? Bundled()
    {
        using var stream = typeof(CabinLightPlugin).Assembly.GetManifestResourceStream("arclight.dll");
        if (stream == null) return null;
        using var memory = new MemoryStream();
        stream.CopyTo(memory);
        return memory.ToArray();
    }

    static bool GameRunning() =>
        Process.GetProcessesByName("eurotrucks2").Length > 0 || Process.GetProcessesByName("amtrucks").Length > 0;

    /// <summary>arclight.dll'yi her oyunun eklenti klasörüne koyar (aynısı zaten oradaysa dokunmaz).</summary>
    public static void InstallIntoGames()
    {
        try
        {
            var dll = Bundled();
            if (dll == null)
            {
                Status = "Eklenti dosyası bulunamadı.";
                return;
            }
            var hash = SHA256.HashData(dll);
            var games = GameHandler.Current.Installations.ToList();
            if (games.Count == 0)
            {
                Status = "Oyun bulunamadı. Auto Drive'ın Ayarlar > SDK bölümünden oyunu ekle.";
                return;
            }
            var installed = 0;
            var waiting = false;
            foreach (var game in games)
            {
                var folder = Path.Combine(game.Path, "bin", "win_x64", "plugins");
                var target = Path.Combine(folder, "arclight.dll");
                if (File.Exists(target) && SHA256.HashData(File.ReadAllBytes(target)).SequenceEqual(hash))
                {
                    installed++;
                    continue;
                }
                if (GameRunning())
                {
                    waiting = true;
                    continue;
                }
                Directory.CreateDirectory(folder);
                var temp = target + ".yeni";
                File.WriteAllBytes(temp, dll);
                File.Move(temp, target, true);
                installed++;
                Logger.Info($"ARC Kabin Işığı kuruldu: {target}");
            }
            Installed = installed == games.Count;
            Status = Installed
                ? "Oyuna kurulu. Ayarlar oyunda anında değişir."
                : waiting
                    ? "Oyun açık: kapattığında kurulacak (oyunu yeniden açınca ışıklar gelir)."
                    : "Kurulamadı.";
            if (waiting && !_waitingNotified)
            {
                _waitingNotified = true;
                NotificationHandler.Current.SendNotification(new Notification
                {
                    Id = "ARC.CabinLight.Waiting",
                    Title = "Yol çizgileri için oyunu yeniden başlat",
                    Content = "Gerekli parça oyun açıkken kurulamaz. Oyunu kapat, ETS2 Auto Drive açıkken birkaç saniye bekle, sonra oyunu yeniden aç.",
                    Level = NotificationLevel.Warning,
                    CloseAfter = 20
                });
            }
        }
        catch (Exception e)
        {
            Status = $"Kurulamadı: {e.Message}";
            Logger.Warn($"ARC Kabin Işığı kurulamadı: {e.Message}");
        }
    }
}
