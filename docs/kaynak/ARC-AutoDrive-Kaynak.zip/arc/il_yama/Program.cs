// Auto Drive çekirdek DLL'lerine küçük, hedefli IL yamaları (kaynak eski olduğu için yeniden derlenmez).
//
//  kontrol : ETS2LA.Controls.dll, SharpDXControlsBackend.ControlListener: joystick listesini yenileme aralığı 2 sn -> 30 sn.
//            DirectInput EnumDevices bu bilgisayarda ~100 ms sürüyor; 2 sn'de bir çalışınca oyunun DirectInput
//            okumasıyla çakışıp takılmaya yol açabiliyor.
//  spin    : verilen Tip::Metot içinde zamanlama döngüsünün sonundaki Thread.SpinWait(10) -> Thread.Sleep(0).
//            Döngü ve tick zamanlaması aynı kalır; bekleme sırasında çekirdek boşa dönmek yerine hazır bekleyen
//            başka iş parçacığına (oyun) bırakılır.
//
// Kullanım: il_yama <girdi.dll> <cikti.dll> kontrol
//           il_yama <girdi.dll> <cikti.dll> spin <Tam.Tip.Adi> <Metot>
//           il_yama <girdi.dll> - listele <Tam.Tip.Adi> <Metot>
using Mono.Cecil;
using Mono.Cecil.Cil;

var (girdi, cikti, mod) = (args[0], args[1], args[2]);
var cozucu = new DefaultAssemblyResolver();
cozucu.AddSearchDirectory(Path.GetDirectoryName(Path.GetFullPath(girdi)));
if (cikti != "-") cozucu.AddSearchDirectory(Path.GetDirectoryName(Path.GetFullPath(cikti)));  // bağımlılıklar paket klasöründe
using var asm = AssemblyDefinition.ReadAssembly(girdi, new ReaderParameters { AssemblyResolver = cozucu, InMemory = true });

MethodDefinition Bul(string tip, string metot) =>
    (asm.MainModule.GetTypes().FirstOrDefault(t => t.FullName == tip) ?? throw new Exception($"{tip} bulunamadı"))
    .Methods.FirstOrDefault(m => m.Name == metot) ?? throw new Exception($"{tip}::{metot} bulunamadı");

switch (mod)
{
    case "listele":
        foreach (var i in Bul(args[3], args[4]).Body.Instructions) Console.WriteLine(i);
        return 0;

    case "kontrol":
    {
        var m = Bul("ETS2LA.Controls.Windows.SharpDXControlsBackend", "ControlListener");
        var adaylar = m.Body.Instructions.Where(i => i.OpCode == OpCodes.Ldc_R8 && (double)i.Operand == 2.0
            && i.Previous is { OpCode.Code: Code.Call } p && p.Operand is MethodReference mr && mr.Name == "get_TotalSeconds").ToList();
        if (adaylar.Count != 1) throw new Exception($"Beklenen 1 sabit, bulunan {adaylar.Count}: DLL sürümü farklı, yama uygulanmadı");
        adaylar[0].Operand = 30.0;
        Console.WriteLine("yamalandı: joystick yenileme 2 sn -> 30 sn");
        break;
    }

    case "tuslar":
    {
        // ETS2LA.Controls.dll: hazır kısayollar oyunun sürüş tuşlarıyla (ok tuşları) çakışıyordu; ok tuşuyla sürenlerde
        // gaz (Yukarı) otopilotu açıyor, sola dönüş (Sol) kapatıyordu. ETS2'nin yalnız menüde kullandığı tuşlara taşınır.
        var yeni = new Dictionary<string, string> { ["Up"] = "PageUp", ["Down"] = "PageDown", ["Left"] = "End", ["Right"] = "Home" };
        var m = Bul("ETS2LA.Controls.Defaults.DefaultControls", ".cctor");
        var adaylar = m.Body.Instructions.Where(i => i.OpCode == OpCodes.Ldstr && yeni.ContainsKey((string)i.Operand)
            && i.Next is { OpCode.Code: Code.Stfld } n && n.Operand is FieldReference f && f.Name == "DefaultKeybind").ToList();
        if (adaylar.Count != 4) throw new Exception($"Beklenen 4 hazır tuş, bulunan {adaylar.Count}: yama uygulanmadı");
        foreach (var i in adaylar) i.Operand = yeni[(string)i.Operand];
        Console.WriteLine("yamalandı: hazır tuşlar Up/Down/Left/Right -> PageUp/PageDown/End/Home");
        break;
    }

    case "budama":
    {
        // ETS2LA.Game.dll: Installation.ParseActual'da harita okunduktan hemen sonra (aynı try içinde, harita "hazır"
        // sayılmadan önce) ARC.HaritaBudama.HaritaBudama.Buda(map) çağrılır. args[3]: ARC.HaritaBudama.dll yolu.
        var m = Bul("ETS2LA.Game.Installation", "ParseActual");
        if (m.Body.Instructions.Any(i => i.Operand is MethodReference r && r.DeclaringType.FullName == "ARC.HaritaBudama.HaritaBudama"))
            throw new Exception("Budama yaması zaten uygulanmış");
        var oku = m.Body.Instructions.Where(i => i.OpCode == OpCodes.Callvirt && i.Operand is MethodReference r
            && r.Name == "Read" && r.DeclaringType.FullName == "TruckLib.ScsMap.Map").ToList();
        if (oku.Count != 1) throw new Exception($"Beklenen 1 Map.Read, bulunan {oku.Count}: yama uygulanmadı");
        var alan = m.DeclaringType.Fields.Single(f => f.Name == "map");
        using var budama = AssemblyDefinition.ReadAssembly(args[3]);
        var buda = budama.MainModule.GetType("ARC.HaritaBudama.HaritaBudama").Methods.Single(x => x.Name == "Buda");
        var il = m.Body.GetILProcessor();
        var cagri = il.Create(OpCodes.Call, asm.MainModule.ImportReference(buda));
        il.InsertAfter(oku[0], cagri);
        il.InsertBefore(cagri, il.Create(OpCodes.Ldfld, alan));
        il.InsertBefore(il.Body.Instructions[il.Body.Instructions.IndexOf(cagri) - 1], il.Create(OpCodes.Ldarg_0));
        Console.WriteLine("yamalandı: harita okunduktan sonra ARC.HaritaBudama.Buda(map) çağrılır");
        break;
    }

    case "spin":
    {
        var m = Bul(args[3], args[4]);
        var cagrilar = m.Body.Instructions.Where(i => i.OpCode == OpCodes.Call && i.Operand is MethodReference r
            && r.Name == "SpinWait" && r.DeclaringType.FullName == "System.Threading.Thread").ToList();
        if (cagrilar.Count != 1) throw new Exception($"Beklenen 1 SpinWait, bulunan {cagrilar.Count}: yama uygulanmadı");
        var arg = cagrilar[0].Previous;
        if (!(arg.OpCode == OpCodes.Ldc_I4_S && (sbyte)arg.Operand == 10))
            throw new Exception($"SpinWait argümanı beklenen 10 değil ({arg}): yama uygulanmadı");
        // Sleep(int) başvurusu, DLL'in SpinWait için zaten kullandığı Thread tip başvurusundan kurulur (aynı derleme kapsamı)
        var spin = (MethodReference)cagrilar[0].Operand;
        var sleep = new MethodReference("Sleep", spin.ReturnType, spin.DeclaringType) { HasThis = false };
        sleep.Parameters.Add(new ParameterDefinition(spin.Parameters[0].ParameterType));
        arg.OpCode = OpCodes.Ldc_I4_0;
        arg.Operand = null;
        cagrilar[0].Operand = sleep;
        Console.WriteLine($"yamalandı: {args[3]}::{args[4]} SpinWait(10) -> Sleep(0)");
        break;
    }

    default:
        throw new Exception("mod: kontrol | spin | listele");
}
// Önce geçici dosyaya yaz: yazım yarıda kalırsa hedef DLL bozulmasın
var gecici = cikti + ".yama_tmp";
asm.Write(gecici);
File.Move(gecici, cikti, overwrite: true);
return 0;
