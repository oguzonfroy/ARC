namespace ARC.DriveAssist;

/// <summary>Ekranda bir dikdörtgen: sol, üst, genişlik, yükseklik.</summary>
public readonly record struct ScreenArea(float X, float Y, float W, float H);

/// <summary>Oyun penceresinin Windows'tan okunan durumu. Yalnız pencere bilgisi; oyunun belleğine dokunulmaz.</summary>
public readonly record struct GameScreen(bool Found, bool Minimized, bool ExclusiveFullscreen, ScreenArea? Area);

/// <summary>
///  Oyun penceresini overlay koordinatlarına çevirir. ETS2LA overlay'i birincil monitörü kaplar; Windows API'den
///  gelen koordinatlar DPI sanallaştırması yüzünden overlay'in piksellerinden farklı ölçekte olabilir.
/// </summary>
public static class GameArea
{
    /// <param name="game">Oyunun istemci alanı, Windows ekran koordinatlarında.</param>
    /// <param name="primary">Birincil monitör, aynı koordinat sisteminde.</param>
    /// <param name="overlayW">Overlay'in çizim genişliği (piksel).</param>
    /// <param name="overlayH">Overlay'in çizim yüksekliği (piksel).</param>
    /// <returns>Overlay'deki alan; oyunun yarısından azı birincil monitördeyse null (çizilecek yer yok).</returns>
    public static ScreenArea? Map(ScreenArea game, ScreenArea primary, float overlayW, float overlayH)
    {
        if (game.W <= 0 || game.H <= 0 || primary.W <= 0 || primary.H <= 0) return null;
        float x0 = MathF.Max(game.X, primary.X), y0 = MathF.Max(game.Y, primary.Y);
        float x1 = MathF.Min(game.X + game.W, primary.X + primary.W), y1 = MathF.Min(game.Y + game.H, primary.Y + primary.H);
        if (x1 <= x0 || y1 <= y0 || (x1 - x0) * (y1 - y0) < 0.5f * game.W * game.H) return null;
        float sx = overlayW / primary.W, sy = overlayH / primary.H;
        return new ScreenArea((x0 - primary.X) * sx, (y0 - primary.Y) * sy, (x1 - x0) * sx, (y1 - y0) * sy);
    }

    /// <summary>Panelin gösterilemediği ekran durumu için kullanıcı yazısı; sorun yoksa null.</summary>
    public static string? ProblemText(GameScreen s)
    {
        if (!s.Found) return null; // oyun yoksa telemetri durumu konuşur
        if (s.ExclusiveFullscreen)
            return "Oyun özel (exclusive) tam ekranda; Windows üstteki pencereleri göstermez, panel görünmez. Oyunu pencere ya da kenarlıksız moda alın.";
        if (s.Minimized) return "Oyun simge durumunda, panel gösterilmez.";
        if (s.Area == null)
            return "Oyun birincil monitörde değil. Overlay yalnız birincil monitörde çizilir: oyunu oraya taşıyın ya da Windows'ta oyunun monitörünü birincil yapın.";
        return null;
    }
}
