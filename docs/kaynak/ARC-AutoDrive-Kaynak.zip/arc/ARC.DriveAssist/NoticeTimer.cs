namespace ARC.DriveAssist;

/// <summary>Ekran uyarısının süresi: birkaç saniye görünür, peş peşe gelen uyarılar ekranı meşgul etmez. Zamanlar milisaniye.</summary>
public sealed class NoticeTimer
{
    public const long VisibleMs = 4000;
    public const long CooldownMs = 8000;

    long _shownAt = long.MinValue;

    /// <returns>Uyarı yeni gösterildiyse true.</returns>
    public bool Show(long now)
    {
        if (_shownAt != long.MinValue && now - _shownAt < CooldownMs) return false;
        _shownAt = now;
        return true;
    }

    public bool IsVisible(long now) => _shownAt != long.MinValue && now - _shownAt < VisibleMs;

    /// <summary>Girip çıkış için 0..1 görünürlük.</summary>
    public float Alpha(long now)
    {
        if (!IsVisible(now)) return 0f;
        var elapsed = now - _shownAt;
        var fade = MathF.Min(MathF.Min(elapsed, VisibleMs - elapsed) / 250f, 1f);
        return Math.Clamp(fade, 0f, 1f);
    }
}
