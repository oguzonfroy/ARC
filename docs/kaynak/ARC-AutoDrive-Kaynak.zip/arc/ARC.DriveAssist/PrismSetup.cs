using System.Security.Cryptography;

namespace ARC.DriveAssist;

/// <summary>
///  Ekran yansıtma (Prism Texture Streamer) ARC'tan kaldırıldı (2026-11-13). Eski sürümlerin oyuna kurduğu eklenti
///  burada bir kez temizlenir: yalnız ARC'ın kurduğu dosyayla bayt bayt aynı olan DLL silinir (kullanıcının kendi kurduğu
///  başka sürüme dokunulmaz); ARC kurarken kullanıcının sürümünü <c>.arc_eski</c> olarak yedeklediyse o geri konur.
///  Oyun açıkken DLL kilitli olduğu için yalnız oyun kapalıyken çağrılmalıdır. Belgeler'deki doku klasörü kullanıcı
///  verisidir, silinmez.
/// </summary>
public static class PrismKaldirma
{
    public const string DllName = "PrismTextureStreamerFB.dll";
    const string DisabledSuffix = ".arc_kapali", BackupSuffix = ".arc_eski";

    /// <summary>ARC'ın taşıdığı PrismTextureStreamerFB.dll'in SHA-256'sı (dosya artık ARC'ta yok).</summary>
    public const string ArcHash = "D00F832BF8102C38FBBFDDE32238D1A6F3B465D4C342554FE324A736F1D2E56E";

    /// <summary>Bir oyunun eklenti klasöründen ARC'ın Prism'ini kaldırır. Bir şey değiştiyse true.</summary>
    public static bool Kaldir(string pluginsDir)
    {
        var dll = Path.Combine(pluginsDir, DllName);
        bool degisti = false;
        foreach (var yol in new[] { dll, dll + DisabledSuffix })
        {
            if (File.Exists(yol) && ArcinMi(yol))
            {
                File.Delete(yol);
                degisti = true;
            }
        }
        var yedek = dll + BackupSuffix;
        if (!File.Exists(dll) && File.Exists(yedek))
        {
            File.Move(yedek, dll);  // ARC'tan önce kullanıcının kurduğu sürüm geri gelir
            degisti = true;
        }
        return degisti;
    }

    static bool ArcinMi(string yol) =>
        Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(yol))).Equals(ArcHash, StringComparison.OrdinalIgnoreCase);
}
