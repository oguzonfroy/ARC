# ARC Sürüş Ayarları: Geri manevra paneli

Geri vitese geçince ekranda küçük bir **manevra yardımı** paneli açılır: direksiyonun yönü ve (dorse bağlıysa)
dorsenin çekiciye göre açısı. Normal sürüşte hiçbir şey görünmez.

> **Kamera görüntüsü yoktur.** Oyunun ayna ya da kamera görüntüsüne erişmek oyuna DLL sokmayı veya belleğine
> girmeyi gerektirir; bu panel bunları yapmaz. Bu yüzden panel "kamera" ya da "canlı" diye anılmaz, başlığında
> "kamera yok" yazar ve mesafe bilgisi göstermez.

## Nasıl çalışır

- Panel, **ETS2 Auto Drive** içindeki `ARC.DriveAssist` eklentisinin parçasıdır. Auto Drive açık değilse panel de yoktur.
- Telemetriyi ETS2LA'nın okuduğu `Local\SCSTelemetry` paylaşımından alır. Bunu oyunun yüklediği SCS Telemetry SDK
  eklentisi yayımlar ([RenCloud scs-sdk-plugin](https://github.com/RenCloud/scs-sdk-plugin): `truck.engine.gear`
  kanalı `truck_i.gear` alanına yazılır). Panel bu paylaşımı **yalnız okur**. Oyun işleminin belleğine dokunmaz,
  oyuna girdi göndermez, oyun ya da TruckersMP dosyalarını değiştirmez.
- **Bağımlılık:** bu SDK eklentisini panel kurmaz. ETS2 Auto Drive, SDK sayfasında oyunun `bin\win_x64\plugins`
  klasörüne kopyalar ve oradan kaldırabilir (`ETS2LA.Game/Installation.cs`). Eklenti yoksa panel "Oyun bekleniyor"
  der ve hiç açılmaz.
- Çizim, ETS2LA'nın overlay penceresinde yapılır. Bu pencere oyunun üstünde duran, saydam, fareyi geçiren ayrı bir
  penceredir. Oyunun içine çizilmez.

Kullanılan SDK alanları (SCS SDK 1.15 başlıkları, `arc-play/tools/scs_sdk_1_15/include`):

| Alan | Kanal | Belgedeki anlam |
|---|---|---|
| Geri vites | `truck.engine.gear` | `>0` ileri, `0` boş, `<0` geri (`common/scssdk_telemetry_truck_common_channels.h`) |
| Direksiyon | `truck.effective.steering` | −1..1, saat yönünün tersine: artı sol (aynı dosya) |
| Dorse açısı | `truck.world.placement`, `trailer.world.placement` heading | `[0,1)` = `[0°,360°)`, üstten saat yönünün tersine (`scssdk_value.h`) |

## Kurulum (ARC Studio için)

Önce iki projeyi derle:

```powershell
cd $env:USERPROFILE\arc-harita\arc_driveassist; dotnet build -c Release
cd $env:USERPROFILE\arc-harita\yeni\ui_kaynak;  dotnet build -c Release
```

Sonra yayın paketine koy. Betikler eskisini `arc-harita\yedek` altına alır:

```powershell
cd $env:USERPROFILE\arc-harita\yedek
python ffb_anahtar_uygula.py   # ARC.DriveAssist.dll (+ Pathfinding)
python gosterge_uygula.py      # ETS2LA.UI.dll (+ ARC.CabinLight)
```

Bu bilgisayarda denemek için Auto Drive'ı kapat, `kuruluma_koy.ps1`'i yönetici olarak çalıştır, ARC'ı yeniden aç.
Kullanıcılara ARC APP'in bir sonraki sürümüyle (`build.ps1`, `yayinla.ps1`) ulaşır.

## Kullanım

1. ETS2'yi **birincil monitörde**, **pencereli** ya da **kenarlıksız** modda aç (aşağıya bak).
2. ARC'tan ETS2 Auto Drive'ı başlat.
3. **Gösterge** sayfasında "Geri manevra paneli" bölümünün altındaki durum yazısı "Bağlı. Geri vitese geçince panel
   açılır." olmalı.
4. Geri vitese geç: panel açılma gecikmesinden sonra belirir. Geri vitesten çıkınca kapanma gecikmesinden sonra söner.

## Ayarlar

Gösterge sayfasında, "Geri manevra paneli" bölümünde. Hepsi `%APPDATA%\ETS2LA\arc.driveassist.json` dosyasında
kalıcıdır ve eklenti dosya değişince yeniden başlatmaya gerek kalmadan uygular.

| Ayar | json | Varsayılan | Aralık |
|---|---|---|---|
| Geri viteste paneli göster | `ReverseOn` | açık | |
| Konum | `ReverseAnchor` | 0 üst orta | 0 üst orta, 1 üst sol, 2 üst sağ, 3 alt sol, 4 alt sağ |
| Boyut | `ReverseScale` | 1 (%100) | 0,75–1,5 |
| Açılma gecikmesi | `ReverseEnterMs` | 250 ms | 0–2000 |
| Kapanma gecikmesi | `ReverseExitMs` | 600 ms | 0–3000 |
| Dorse açısı (deneysel) | `ReverseHitch` | **kapalı** | Açıkken dorsenin açısını çizer ve yazar |
| İnce kaydırma | `ReverseOffsetX`, `ReverseOffsetY` | 0 | −0,2–0,2 (ekranın oranı), yalnız dosyadan |

Açılma gecikmesi, vites geçişinde anlık "geri" okumasında panelin açılmasını önler. Kapanma gecikmesi ise R, N ve 1
arasında gidip gelirken panelin yanıp sönmesini önler.

## Durumlar ve mesajlar

Durum yazısı Gösterge sayfasında görünür. Panel yalnız **Bağlı + geri vites** durumunda ekrandadır.

| Durum | Yazı | Panel |
|---|---|---|
| Telemetri hiç gelmedi | Oyun bekleniyor: telemetri gelmiyor… | gizli |
| SDK kapandı | Oyun kapandı ya da telemetri eklentisi çalışmıyor… | gizli |
| Bağlı | Bağlı. Geri vitese geçince panel açılır. | gizli |
| Geri vites | Geri vites: panel açık. | açık |
| Duraklatıldı / menü | Oyun duraklatıldı ya da menüde… | anında gizli |
| Eklenti çalışmıyor | ARC Sürüş Ayarları eklentisinden durum gelmiyor… (6 sn sessizlik) | gösterilmez |
| Bağlantı koptu | Telemetri bağlantısı kesildi, panel kapatıldı… | anında gizli |
| Ayar kapalı | Panel kapalı. Açmak için… | gizli |
| Overlay kapalı | ETS2LA overlay ayarlardan kapalı… | gösterilemez |
| Özel tam ekran | Oyun özel (exclusive) tam ekranda… | görünmez |
| Başka monitör | Oyun birincil monitörde değil… | çizilmez |
| Simge durumu | Oyun simge durumunda… | çizilmez |
| Çizim hatası | Panel çizilemedi: … | gösterilmez, hata loga yazılır |

Güvenlik kuralları:
- Oyun karesi 1,5 sn ilerlemezse bağlantı koptu sayılır.
- Eklentinin döngüsü 0,5 sn güncelleme yapmazsa panel kendiliğinden söner.
- Bu kurallar sayesinde panel son değerle ekranda açık kalamaz.

## Ekran modları ve monitörler

Overlay, ETS2LA'nın birincil monitörü kaplayan ayrı penceresidir (`ETS2LA.Overlay/Overlay.cs`). Panel bu pencerede,
**oyun penceresinin kendi alanına göre** konumlanır: pencereli modda pencerenin içinde kalır, dar pencerede küçülür.
Oyun penceresi Windows API'siyle salt okunur bulunur (`eurotrucks2` süreci, istemci alanı, birincil monitör). Windows'un
bildirdiği koordinatlar DPI ölçeği yüzünden overlay piksellerinden farklıysa oranlanır.

| Durum | Destek | Algılama |
|---|---|---|
| Pencere | Var | |
| Kenarlıksız / pencereli tam ekran | Var | |
| Özel (exclusive) tam ekran | **Yok:** Windows üstteki pencereleri göstermez | `SHQueryUserNotificationState` = `QUNS_RUNNING_D3D_FULL_SCREEN` ([Microsoft](https://learn.microsoft.com/en-us/windows/win32/api/shellapi/ne-shellapi-query_user_notification_state)), oyun öndeyken. Gösterge'de uyarı çıkar. |
| Oyun ikinci monitörde | **Yok:** overlay yalnız birincil monitörde; ETS2LA overlay'inin monitör seçimi yok | Oyun alanının yarısından azı birincil monitördeyse panel çizilmez, Gösterge'de uyarı çıkar |
| Oyun simge durumunda | Panel gösterilmez | `IsIconic` |

ETS2'nin hangi modu kullandığı resmî olarak belgelenmemiştir. `config.cfg`'de `r_fullscreen`,
`r_fullscreen_borderless` ve `r_windowed_borderless` anahtarları vardır, ama SCS anlamlarını belgelemez. Topluluk
raporlarına göre 1.50'den beri oyun özel tam ekrana geçmiyor. Bu yüzden panel modu dosyadan tahmin etmez,
Windows'un o anki durumuna bakar. Oyun dosyalarına ya da `config.cfg`'ye yazılmaz.

Uyarı çıkarsa:
1. Oyunun grafik ayarlarındaki tam ekran seçeneğini kapatıp pencere moduna geçin (topluluk önerisi; SCS belgesi yok).
2. Pencere moduna geçtiyseniz oyunu birincil monitöre taşıyın.

## TruckersMP

- **Kurallar:** [TruckersMP kuralları](https://truckersmp.com/rules) telemetri okuyan ya da ayrı pencerede bilgi
  gösteren araçlardan açıkça söz etmez. §2.1 oyunu değiştiren araçları yasaklar; belirsiz durumları yetkililer yorumlar.
- **Panel:** yalnız okur ve oyunu değiştirmez. Ama TruckersMP'nin bunu onayladığına dair bir belge yok; "uyumlu"
  diye bir garanti verilmez.
- **Auto Drive ile birlikte çalışır:** panel tek başına çalışmaz, ETS2 Auto Drive'ın içindedir. Auto Drive bir
  otomatik sürüş aracıdır; oyuna girdi gönderir ve oyun klasörüne SDK eklentisi kurar. TruckersMP'deki risk
  panelden değil, Auto Drive'ın kendisinden gelir.
- **Veri kalitesi:** TruckersMP'de telemetri gecikebilir ya da kesilebilir. Bu durumda panel kapanır.

## Dorse açısı (deneysel) ve mesafe

- **Dorse açısının kaynağı:** `truck.world.placement` ve `trailer.world.placement` başlıkları (SDK, `[0,1)`, üstten
  saat yönünün tersine). RenCloud eklentisi başlığı her iki yerleşimin dördüncü alanına yazar; ETS2LA bunu
  `rotation.X` / `worldRotation.X` olarak okur.
- **Açı nasıl hesaplanır:** fark (dorse − çekici) sarılır, 90°'yi aşan değer gösterilmez. Artı değer, dorsenin
  burnunun sola baktığı, arkasının sağa kaçtığı anlamına gelir.
- **Neden deneysel:** bu yorum belgeden türetildi; oyunda doğrulanmadı. Bu yüzden varsayılan kapalı. Kapalıyken
  dorse çizilmez ve "kapalı (deneysel ayar)" yazar.
- **Mesafe:** SDK'da engel, araç ya da mesafe verisi yoktur. Kanallarda yalnız rota mesafesi var
  (`truck.navigation.distance`). Panel metre, çarpışma uyarısı ya da engel üretmez ve "mesafe ölçümü mevcut değil"
  yazar. ETS2LA'nın kendi trafik paylaşımı (`Local\ETS2LATraffic`) resmî SDK'nın parçası değildir, bu yüzden
  kullanılmaz.
- **Kamera:** SDK telemetri ve girdi sağlar, görüntü sağlamaz. Görüntü yalnız oyunun çizimine girerek alınabilir
  (DLL enjeksiyonu ya da çizim kancası). Resmî bir arayüz olmadığı için panelde kamera yoktur.

## Manuel test listesi (oyunda)

1. ETS2'yi birincil monitörde, pencereli modda aç. ARC'tan Auto Drive'ı başlat. Gösterge sayfasında "Bağlı. Geri
   vitese geçince panel açılır." yazısını gör.
2. İleri viteste ve boşta 10 sn bekle. Panel **çıkmamalı**.
3. R'ye geç. Yaklaşık 0,25 sn sonra panel **oyun penceresinin** üst ortasında çıkmalı. R'den 1'e geç: yaklaşık 0,6 sn
   sonra sönmeli.
4. R'deyken direksiyonu sola çevir. "Direksiyon sol %…" yazmalı ve çizgiler sola kıvrılmalı. Gerçekte tırın arkası
   da sola gitmeli.
5. R'deyken Esc ile duraklat. Panel hemen kapanmalı ve "Oyun duraklatıldı ya da menüde" yazmalı.
6. R'deyken oyunu kapat (ya da Görev Yöneticisi'nden sonlandır). Panel en geç 1,5 sn içinde kapanmalı.
7. Pencereyi küçült ve köşeye taşı. Panel pencerenin içinde kalmalı, simge durumundayken çıkmamalı.
8. Pencereyi ikinci monitöre taşı. Panel çıkmamalı ve Gösterge'de "Oyun birincil monitörde değil" yazmalı.
9. Oyunu tam ekrana al. Panel görünüyorsa sorun yok. Görünmüyorsa Gösterge'de "özel tam ekran" uyarısı çıkmalı.
10. Windows ekran ölçeğini %125 yap. Panel yine oyun alanında, doğru yerde olmalı.
11. (Deneysel) Dorse bağlıyken "Dorse açısı (deneysel)" ayarını aç. Geri giderken dorsenin gerçekte kaçtığı tarafı
    not et ve panelin yazdığı tarafla karşılaştır. Ters çıkarsa bildir, ayarı kapalı bırak.
12. `ets2la.log`'da `ARC geri paneli:` satırlarını kontrol et.

## Kaldırma

- **Yalnız paneli kapatmak:** Gösterge'de "Geri viteste paneli göster" anahtarını kapat. Ayarlar dosyada kalır.
- **Ayarları silmek:** Auto Drive kapalıyken `%APPDATA%\ETS2LA\arc.driveassist.json` içindeki `Reverse*` satırlarını
  sil. Dosyanın tamamını silersen diğer sürüş ayarları da sıfırlanır.
- **Özelliği yayın paketinden çıkarmak (ARC Studio):** paketteki `Plugins\ARC.DriveAssist.dll` ve `ETS2LA.UI.dll`
  dosyalarını, `ffb_anahtar_uygula.py` ile `gosterge_uygula.py`'nin `arc-harita\yedek` altına aldığı önceki
  kopyalarla değiştir. Kaynakların eski hali `yedek\geri_panel_oncesi` klasöründedir.
- **Tamamen kaldırmak:** ARC APP'i Windows'un "Uygulamalar" bölümünden kaldır; ETS2 Auto Drive da onunla gider.
  Oyun klasörüne kurulan SDK eklentisi bununla birlikte silinmez. Silmek için ARC'ı kaldırmadan **önce** Auto
  Drive'ın SDK sayfasındaki kaldırma düğmesini kullan; bu, kopyaladığı dosyaları `bin\win_x64\plugins`'ten siler.

## Sorun giderme

Kurulu klasördeki `ets2la.log`'da `ARC geri paneli:` satırlarına bak:
- **Durum değişimleri:** `GameClosed`, `Waiting`, `Hidden`, `Visible`, `Lost`, `Paused`.
- **Overlay kaydı:** `overlay'e kaydedildi`.
- **Kapanış:** `kapatıldı`.
- **Çizim hataları.**

Testler: `dotnet run -c Release --project %USERPROFILE%\arc-harita\arc_driveassist_test`.

## Dosyalar

| Dosya | Görevi |
|---|---|
| `ReverseGate.cs` | Saf karar: durum, gecikmeler, tazelik, saydamlık, dorse açısı, durum yazıları. Testlidir. |
| `ReverseMonitor.cs` | Telemetri bağlantısı ve geri vites algılaması. Arayüze yalnız `ReverseView` ve durum yazısını verir. |
| `ReversePanel.cs` | Overlay'e kayıt, oyun alanında çizim, hata yakalama, kapanışta kaydı silme. |
| `GameArea.cs` | Saf: oyun penceresini overlay koordinatlarına çevirme (monitör, DPI) ve ekran sorunu yazıları. Testlidir. |
| `GameWindow.cs` | Oyun penceresini, birincil monitörü ve özel tam ekranı Windows API'siyle salt okur. |
| `DriveConfig.cs` | `Reverse*` ayarları ve sınırları. |
| `DriveAssistPlugin.cs` | Döngüde monitörü günceller, kapanışta (`Shutdown`) döngüyü durdurup paneli temizler. |
| `yeni/ui_kaynak/.../ArcSurusAyar.cs`, `Home.cs` | Gösterge'deki ayarlar ve durum yazısı. |

## Ekran yansıtma (Gösterge → Ekran yansıtma)

Prism Texture Streamer (yazar: Baldy09, github.com/Baldywaldy09/PrismTextureStreamer): bilgisayardaki bir pencereyi tırın
GPS ya da gösterge ekranına yansıtan SCS eklentisi. Oyunda Ctrl+F8 menüsüyle ekran ve pencere seçilir.

- **Dosyalar:** `prism\` klasöründekiler `ARC.DriveAssist.dll` içine gömülüdür (EmbeddedResource). `PrismManager` 5 sn'de bir
  her oyun kurulumuna (ETS2 ve ATS) uygular: açıkken DLL `bin\win_x64\plugins`'e, doku klasörü Belgeler'e konur; kapalıyken
  DLL `.arc_kapali` adıyla devre dışı kalır. Oyun açıkken dosyaya dokunulmaz, oyun kapanınca uygulanır.
- **Korumalar:** kullanıcının elle koyduğu farklı sürüm `.arc_eski` olarak yedeklenir; Belgeler'deki dokular yalnız eksikse
  yazılır. `PrismOn` hiç kaydedilmemişse eklenti oyunda kuruluysa açık başlar (elle kurulmuş eklenti kapatılmaz).
- **Sürüm:** gömülü DLL, yazarın deposundan (`ucuncu_taraf\prism_kaynak`, 1.1.1, 2026-08-01) ARC yamasıyla derlenir. Yama:
  "Add Screen Custom"un varsayılan boş yolları (`.tobj`, boyut 0) oyunu çökertiyordu; eksik Custom ekranı kancalar işlemez,
  Apply kapalı kalır (`screens.h` `screen_is_usable`). Test: `ucuncu_taraf\prism_test\derle.bat`. Derleme:
  `MSBuild PrismTextureStreamerFB.sln -p:Configuration=Release -p:Platform=x64 -p:PostBuildEventUseInBuild=false
  -p:WindowsTargetPlatformVersion=10.0.26100.0`, çıktıyı `prism\` içine kopyala, `ARC.DriveAssist`'i derle.
- **Dağıtım:** depoda lisans belirtilmemiştir; ARC'ın eklentiyi dağıtması yazarın iznine dayanır.
- **Bilinen:** eklenti DirectX 11 ve DirectInput'a kanca takar. TruckersMP'deki durumu doğrulanmadı.
