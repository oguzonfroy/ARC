using System.Diagnostics;
using System.IO.MemoryMappedFiles;

using ETS2LA.Audio;
using ETS2LA.Backend.Events;
using ETS2LA.Game;
using ETS2LA.Game.Output;
using ETS2LA.Game.SDK;
using ETS2LA.Game.Telemetry;
using ETS2LA.Logging;
using ETS2LA.Shared;
using ETS2LA.State;
using SharpDX.DirectInput;

namespace ARC.DriveAssist;

/// <summary>
///  ARC Sürüş Ayarları: direksiyon hassasiyeti, direksiyon kullananlar için ayar değiştirmeden sürüş,
///  işaretli konumda (GPS rotasının sonunda) durma.
/// </summary>
public class DriveAssistPlugin : Plugin
{
    public const string PluginId = "arc.driveassist";

    public override PluginInformation Info => new PluginInformation
    {
        Id = PluginId,
        Name = "ARC Sürüş Ayarları",
        Description = "Direksiyon hassasiyeti, direksiyon modu ve işaretli konumda durma.",
        Version = "1.0.0",
        AuthorName = "ARC Studio",
    };

    public override float TickRate => 0.1f;

    public static DriveAssistPlugin? Current { get; private set; }

    public DriveConfig Config = DriveConfig.Load();
    public readonly StopController Stop = new();
    public bool WheelFound { get; private set; }
    public string WheelName { get; private set; } = "";
    public bool DirectOutput { get; private set; }
    public float RouteDistance { get; private set; }

    GameTelemetryData? _telemetry;
    DateTime _phoneRetry = DateTime.MinValue;
    Guid _wheelGuid, _joystickGuid;
    DirectInput? _directInput;
    Joystick? _joystick;
    readonly WheelTakeover _takeover = new();
    readonly TollGate _toll = new();
    readonly GasAxisLearner _gasLearner = new();
    bool _ffbOn, _ffbInvert = true;
    DriveHud? _hud;
    OvertakeNotice? _notice;
    readonly PrismTemizleyici _prism = new();
    volatile bool _closing;
    float _statusIn;
    NavigationData? _nav;
    NavigationData? _navSeen;
    string _routeKey = "";
    List<(float Left, System.Numerics.Vector3 At)> _routeNodes = new();
    float _diagIn;
    float _lastGoodRaw;
    readonly RouteScale _routeScale = new();
    System.Numerics.Vector3? _dest;
    DateTime _configRead = DateTime.MinValue;

    public override void Init()
    {
        base.Init();
        Current = this;
        if (!File.Exists(DriveConfig.FilePath)) Config.Save();
        Task.Run(Run);
    }

    /// <summary>Kapanışta döngüyü durdurur.</summary>
    public override void Shutdown()
    {
        _closing = true;
        base.Shutdown();
    }

    async Task Run()
    {
        await Task.Delay(TimeSpan.FromSeconds(3));
        GameTelemetry.Current.ReadTrailerData = true;
        Events.Current.Subscribe(GameTelemetry.Current.EventString, (GameTelemetryData d) => _telemetry = d);
        Events.Current.Subscribe(NavigationProvider.Current.EventString, (NavigationData d) => _nav = d);

        var clock = Stopwatch.StartNew();
        var last = clock.Elapsed;
        var checkedAt = TimeSpan.FromHours(-1);
        var phoneAt = TimeSpan.FromHours(-1);
        while (!_closing)
        {
            await Task.Delay(33);
            var now = clock.Elapsed;
            var dt = (float)(now - last).TotalSeconds;
            last = now;
            try
            {
                if (now - checkedAt > TimeSpan.FromSeconds(5))
                {
                    checkedAt = now;
                    CheckOutputs();
                    _prism.Tick();
                }
                ReloadConfig();
                TickStop(dt);
                TickToll(dt);
                TickWheel(dt);
                if (now - phoneAt > TimeSpan.FromSeconds(1))
                {
                    phoneAt = now;
                    TickPhone();
                }
                _notice ??= new OvertakeNotice();
                _notice.Tick();
                _hud ??= new DriveHud();
                _hud.Tick(Config.HudLabelSize);
            }
            catch (Exception e)
            {
                Logger.Warn($"ARC Sürüş Ayarları: {e.Message}");
            }
        }
    }

    /// <summary>
    ///  Direksiyon takılıysa gaz ve fren de doğrudan oyuna yazılır. Böylece oyunda direksiyon ayarları olduğu
    ///  gibi kalır, klavyeye geçmek gerekmez.
    /// </summary>
    void CheckOutputs()
    {
        DirectOutput = MappingExists("Local\\ETS2LAPluginInput");
        FindWheel();
        ReadFfbState();
        UndoAutoFfb();
        Events.Current.Publish("ARC.DriveAssist.Wheel", WheelFound ? WheelName : "");
        var wanted = Config.Wheel == WheelMode.On || (Config.Wheel == WheelMode.Auto && WheelFound);
        var settings = GameSettings.Current;
        if (settings.EnableModernOutputForPedals != wanted)
        {
            settings.EnableModernOutputForPedals = wanted;
            settings.Save();
            Logger.Info($"ARC Sürüş Ayarları: gaz ve fren doğrudan çıkışı {(wanted ? "açık" : "kapalı")}.");
        }
    }

    static bool MappingExists(string name)
    {
        try
        {
            using var map = MemoryMappedFile.OpenExisting(name);
            return true;
        }
        catch
        {
            return false;
        }
    }

    void FindWheel()
    {
        try
        {
            using var input = new DirectInput();
            foreach (var device in input.GetDevices(DeviceClass.GameControl, DeviceEnumerationFlags.AttachedOnly))
            {
                var name = device.ProductName ?? "";
                if (device.Type == DeviceType.Driving || device.Type == DeviceType.FirstPerson && LooksLikeWheel(name) || LooksLikeWheel(name))
                {
                    WheelFound = true;
                    WheelName = name.Trim();
                    _wheelGuid = device.InstanceGuid;
                    return;
                }
            }
        }
        catch { }
        WheelFound = false;
        WheelName = "";
        _wheelGuid = Guid.Empty;
    }

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    static extern nint GetDesktopWindow();

    /// <summary>Direksiyonu okur (yalnızca okuma, oyunun ve güç geri bildiriminin erişimini engellemez).</summary>
    bool ReadWheel(out float x, out float[] pedals)
    {
        x = 0f;
        pedals = Array.Empty<float>();
        if (_wheelGuid == Guid.Empty) return false;
        try
        {
            if (_joystick == null || _joystickGuid != _wheelGuid)
            {
                _joystick?.Dispose();
                _directInput ??= new DirectInput();
                _joystick = new Joystick(_directInput, _wheelGuid);
                _joystick.SetCooperativeLevel(GetDesktopWindow(), CooperativeLevel.Background | CooperativeLevel.NonExclusive);
                _joystick.Acquire();
                _joystickGuid = _wheelGuid;
            }
            _joystick.Poll();
            var s = _joystick.GetCurrentState();
            static float N(int v) => (v - 32767.5f) / 32767.5f;
            x = N(s.X);
            pedals = new[] { N(s.Y), N(s.Z), N(s.RotationX), N(s.RotationY), N(s.RotationZ), N(s.Sliders[0]), N(s.Sliders[1]) };
            return true;
        }
        catch
        {
            try { _joystick?.Dispose(); } catch { }
            _joystick = null;
            return false;
        }
    }

    /// <summary>Güç geri bildirimi açıksa direksiyonun olması gereken konum.</summary>
    float? ExpectedWheel(GameTelemetryData t)
    {
        if (!_ffbOn) return null;
        var angle = Math.Clamp(t.truckFloat.gameSteer, -1f, 1f);
        return _ffbInvert ? -angle : angle;
    }

    void ReadFfbState()
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ETS2LA");
        try
        {
            using var states = System.Text.Json.JsonDocument.Parse(File.ReadAllText(Path.Combine(dir, "ArcPluginStates.json")));
            _ffbOn = states.RootElement.GetProperty("Enabled").TryGetProperty("zkhan4509.realforcefeedback", out var v) && v.GetBoolean();
        }
        catch { _ffbOn = false; }
        try
        {
            using var ffb = System.Text.Json.JsonDocument.Parse(File.ReadAllText(Path.Combine(dir, "realffb_settings.json")));
            _ffbInvert = !ffb.RootElement.TryGetProperty("InvertSteering", out var v) || v.GetBoolean();
        }
        catch { _ffbInvert = true; }
    }

    /// <summary>
    ///  Gerçek zamanlı direksiyon dönüşü artık kullanıcının seçimi. Eski sürüm kendiliğinden açtıysa bir kez kapatılır;
    ///  kullanıcının kendi açtığına dokunulmaz.
    /// </summary>
    void UndoAutoFfb()
    {
        if (!Config.FfbAutoDone || Config.FfbAutoUndone) return;
        var handler = ETS2LA.Backend.PluginBackend.Current.PluginHandler;
        var plugin = handler?.LoadedPlugins.FirstOrDefault(p => p.Info.Id == "zkhan4509.realforcefeedback");
        if (handler == null || plugin == null) return;
        if (plugin._IsRunning) handler.DisablePlugin(plugin);
        Config.FfbAutoUndone = true;
        Config.Save();
        Logger.Info("ARC direksiyon seti: kendiliğinden açılan direksiyon dönüşü kapatıldı, ayarlardan açılabilir.");
    }

    /// <summary>Telefon Auto Drive'ın parçası: onunla açılır, onunla kapanır; karttan kapatılabilir.</summary>
    void TickPhone()
    {
        var exe = Path.Combine(AppContext.BaseDirectory, "Telefon", "ARC Truck Phone.exe");
        if (!File.Exists(exe)) return;
        var running = Process.GetProcessesByName("ARC Truck Phone");
        if (Config.PhoneOn && running.Length == 0 && DateTime.UtcNow > _phoneRetry)
        {
            _phoneRetry = DateTime.UtcNow.AddSeconds(5);
            Process.Start(new ProcessStartInfo(exe, $"--ust {Environment.ProcessId}") { WorkingDirectory = Path.GetDirectoryName(exe), UseShellExecute = false });
        }
        else if (!Config.PhoneOn)
        {
            foreach (var p in running)
            {
                if (!p.CloseMainWindow() || !p.WaitForExit(2000)) p.Kill();
            }
        }
    }

    void TickWheel(float dt)
    {
        var t = _telemetry;
        if (t == null) return;
        var state = ApplicationState.Current;
        if (Config.Wheel == WheelMode.Off || !ReadWheel(out var x, out var pedals))
        {
            _takeover.Reset();
            return;
        }
        if (!state.EnableAssists && !t.paused
            && _gasLearner.Observe(pedals, t.truckFloat.userThrottle, t.truckFloat.userBrake, t.truckFloat.userClutch) is int gasAxis
            && gasAxis != Config.GasAxisFor(WheelName))
        {
            Config.GasAxis = gasAxis;
            Config.GasAxisDevice = WheelName;
            Config.Save();
            Logger.Info($"ARC direksiyon seti: gaz pedalı ekseni {gasAxis} olarak öğrenildi.");
        }
        var active = state.EnableAssists && !t.paused && !Stop.Finishing;
        // Güç geri bildirimi direksiyonu gecikmeli takip eder; bu gecikme müdahale sanılmasın.
        var limit = Config.TakeoverPercent / 100f;
        if (_ffbOn) limit = MathF.Max(limit * 2.5f, 0.25f);
        var who = _takeover.Update(active, dt, x, pedals, ExpectedWheel(t), limit, Config.TakeoverWheel, Config.TakeoverPedal, Config.GasAxisFor(WheelName));
        if (who == null) return;
        Logger.Info($"ARC direksiyon seti: {who} ile müdahale edildi, otopilot kapatıldı.");
        AudioHandler.Current.Play(DefaultAudio.PreAlert);
        state.SetAssistsEnabled(false);
    }

    static bool LooksLikeWheel(string name) =>
        new[] { "wheel", "direksiyon", "g29", "g920", "g923", "g27", "g25", "t300", "t150", "t248", "tmx", "t500", "t-gt", "fanatec", "moza", "simucube", "driving force" }
            .Any(k => name.Contains(k, StringComparison.OrdinalIgnoreCase));

    /// <summary>Ayarlar sayfası dosyayı değiştirdiyse hemen geçerli olur.</summary>
    void ReloadConfig()
    {
        try
        {
            var written = File.GetLastWriteTimeUtc(DriveConfig.FilePath);
            if (written == _configRead) return;
            _configRead = written;
            Config = DriveConfig.Load();
        }
        catch { }
    }

    /// <summary>
    ///  Rotanın düğümlerini ve hedef noktayı haritadan alır. Oyunun rota mesafesi rota açıkken de 0 gelebildiği için
    ///  asıl kaynak budur. Dizide 6000 kayıt vardır; boş olanların kimliği 0'dır.
    /// </summary>
    void UpdateRoute()
    {
        var nav = _nav;
        if (nav == null || ReferenceEquals(nav, _navSeen)) return;
        _navSeen = nav;
        var live = nav.entries.Where(e => e.nodeUid != 0).ToArray();
        if (live.Length == 0)
        {
            _routeNodes.Clear();
            _routeKey = "";
            return;
        }
        var key = string.Join(",", live.Select(e => $"{e.nodeUid}:{e.distanceToEnd:0}"));
        if (key == _routeKey) return;
        var map = ApplicationState.Current.RunningGame?.GetMapData();
        if (map == null) return;
        var nodes = new List<(float Left, System.Numerics.Vector3 At)>();
        foreach (var e in live)
            if (map.Nodes.TryGetValue(e.nodeUid, out var node)) nodes.Add((e.distanceToEnd, node.Position));
        if (nodes.Count == 0) return;
        _routeKey = key;
        _routeNodes = nodes;
        _dest = nodes.MinBy(n => n.Left).At;
    }

    static float Flat(System.Numerics.Vector3 a, System.Numerics.Vector3 b) =>
        MathF.Sqrt((a.X - b.X) * (a.X - b.X) + (a.Z - b.Z) * (a.Z - b.Z));

    /// <summary>Kalan rota: önündeki düğüme uzaklık artı o düğümden hedefe kalan yol. Rota bilinmiyorsa negatif.</summary>
    float RouteLeft(System.Numerics.Vector3 at) => _routeNodes.Count == 0 ? -1f : _routeNodes.Min(n => n.Left + Flat(at, n.At));

    string StatusText(bool assists)
    {
        if (!Config.StopAtMarker) return "Kapalı";
        var left = Stop.RemainingToStop;
        return Stop.Phase switch
        {
            StopPhase.Done => "Durdu, yeni rota bekleniyor",
            StopPhase.Holding => "Duruyor",
            StopPhase.Braking => $"Yavaşlıyor, {left:0} m",
            StopPhase.Approach => $"Hedefe {left:0} m",
            _ => !assists ? "Sürüş başlayınca devreye girer" : RouteDistance > 0.5f ? "Hedef alınıyor" : "Rota bekleniyor, haritadan hedef seç",
        };
    }

    void TickToll(float dt)
    {
        var t = _telemetry;
        if (t == null) return;
        var at = t.truckPlacement.coordinate;
        var gates = new List<GateView>();
        foreach (var s in SemaphoreProvider.Current.GetCurrentData()?.semaphores ?? [])
        {
            if (s.type != SemaphoreType.GATE) continue;
            var w = s.GetWorldCoordinates();
            gates.Add(TollGate.View((float)(w.X - at.X), (float)(w.Z - at.Z), t.truckPlacement.rotation.X, s.state));
        }
        if (!_toll.Update(ApplicationState.Current.EnableAssists && !t.paused, t.truckFloat.speed, gates, dt)) return;
        Logger.Info("ARC gişe: kapalı kapının önünde durdu, Enter (etkinleştir) gönderildi.");
        Events.Current.Publish(GameOutput.Current.EventString, new ControlEvent
        {
            ChannelDefinition = new ControlChannelDefinition { Id = "ARC.DriveAssist.Toll", Timeout = 0.1f },
            Properties = new ControlProperties { BooleanType = ControlBooleanType.TrueToToggle },
            Variables = new ControlVariables { activate = true },
        });
    }

    void TickStop(float dt)
    {
        var t = _telemetry;
        if (t == null) return;
        var state = ApplicationState.Current;
        Stop.Margin = Config.StopMargin;
        // Otopilot duruşa yakın kapatılır, fren durana kadar devam eder.
        var active = Config.StopAtMarker && Config.StopAccepted && !t.paused && (state.EnableAssists || Stop.Finishing);
        var before = Stop.Phase;
        UpdateRoute();
        var at = t.truckPlacement.coordinate.ToVector3();
        var straight = _dest is { } dest ? Flat(at, dest) : -1f;
        var left = RouteLeft(at);
        var raw = t.truckFloat.routeDistance;
        // Oyunun değeri sürerken gerçek yol uzunluğudur. Sürerken 0 olması rotanın bittiğini gösterir; yakınsa hedef
        // noktasına (straight) yavaşlanır, uzaksa iptal sayılır. Düğüm toplamı düz çizgi olduğu için yalnızca kayıtta gösterilir.
        // Değer tır dururken 0 olur (ışıkta, trafikte): o zaman son geçerli değer tutulur, rota silinmiş sayılmaz.
        var slow = MathF.Abs(t.truckFloat.speed) < 2f;
        // Oyunun değeri gerçek metre değildir; ölçek ölçülerek gerçek kalan yola çevrilir.
        if (raw > 0.5f) _lastGoodRaw = _routeScale.Update(raw, at.X, at.Z, straight);
        else if (!slow) _lastGoodRaw = 0f;
        RouteDistance = _lastGoodRaw > 0.5f ? _lastGoodRaw : 0f;
        var o = Stop.Update(new StopInput(active, t.truckFloat.speed, RouteDistance, t.truckBool.parkingBrake, dt, straight));
        _diagIn -= dt;
        if (Config.StopAtMarker && _diagIn <= 0f)
        {
            _diagIn = 5f;
            Logger.Info($"ARC hedefte durma: {Stop.Phase}, oyun {raw:0}, ölçek {_routeScale.Scale:0.0}, hedefe düz {straight:0} m, gerçek kalan {RouteDistance:0} m, durmaya {Stop.RemainingToStop:0} m, {t.truckFloat.speed * 3.6f:0} km/sa, sürüş {(state.EnableAssists ? "açık" : "kapalı")}.");
        }
        if (before == StopPhase.Idle && Stop.Phase != StopPhase.Idle)
            Logger.Info($"ARC hedefte durma: hedef alındı, durma noktasına {Stop.RemainingToStop:0} m.");
        if (before == StopPhase.Done && Stop.Phase != StopPhase.Done)
            Logger.Info("ARC hedefte durma: yeni rota alındı, tekrar devrede.");

        if (before != StopPhase.Braking && Stop.Phase == StopPhase.Braking)
            Logger.Info($"ARC hedefte durma: frenleme başladı, kalan {Stop.RemainingToStop:0} m, hız {t.truckFloat.speed * 3.6f:0} km/sa.");

        if (o.Brake is float brake)
        {
            // ACC ile aynı kanal ve işaret: negatif fren. Ağırlık, ACC'nin isteğini bastırır.
            Events.Current.Publish(GameOutput.Current.EventString, new ControlEvent
            {
                ChannelDefinition = new ControlChannelDefinition { Id = "ARC.DriveAssist.Stop", Timeout = 0.25f },
                Properties = new ControlProperties { Weight = 1000f },
                Variables = new ControlVariables { abackward = -brake },
            });
        }

        if (o.ToggleParkingBrake)
        {
            Events.Current.Publish(GameOutput.Current.EventString, new ControlEvent
            {
                ChannelDefinition = new ControlChannelDefinition { Id = "ARC.DriveAssist.Park", Timeout = 0.1f },
                Properties = new ControlProperties { BooleanType = ControlBooleanType.TrueToToggle },
                Variables = new ControlVariables { parkingbrake = true },
            });
        }

        if (o.DisengageAssists)
        {
            Logger.Info($"ARC hedefte durma: duruşa yakın otopilot kapatıldı ({t.truckFloat.speed * 3.6f:0.0} km/sa).");
            AudioHandler.Current.Play(DefaultAudio.PreAlert);
            state.SetAssistsEnabled(false);
        }

        if (before != StopPhase.Done && Stop.Phase == StopPhase.Done)
            Logger.Info("ARC hedefte durma: tır durdu, el freni çekildi.");

        _statusIn -= dt;
        if (_statusIn <= 0f)
        {
            _statusIn = 0.5f;
            Events.Current.Publish("ARC.DriveAssist.Status", StatusText(state.EnableAssists));
        }
    }
}
