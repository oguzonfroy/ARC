namespace ARC.DriveAssist;

public enum StopPhase { Idle, Approach, Braking, Holding, Done }

public readonly record struct StopInput(
    bool Active,        // özellik açık, uyarı kabul edilmiş, sürüş devrede, oyun duraklatılmamış
    float Speed,        // m/sn
    float RouteDistance,// GPS rotasının kalan uzunluğu (m), rota yoksa 0
    bool ParkingBrake,
    float Dt,
    float Straight = -1f); // rota sonuna düz çizgi mesafesi (m), bilinmiyorsa negatif

public readonly record struct StopOutput(float? Brake, bool ToggleParkingBrake, bool DisengageAssists);

/// <summary>
///  Oyunun rota mesafesi harita ölçeğiyle büyütülmüştür (yolda yaklaşık 19 kat, şehirde daha az). Değerin azalma hızı
///  tırın gerçekte aldığı yolla karşılaştırılarak ölçek bulunur ve mesafe gerçek metreye çevrilir.
/// </summary>
public sealed class RouteScale
{
    public float Scale { get; private set; } = 19f;
    float _x, _z, _raw;
    bool _started;

    /// <summary>Kalan gerçek yol (m). Yol, hedefe düz çizgiden (straight) kısa olamaz.</summary>
    public float Update(float raw, float x, float z, float straight)
    {
        if (!_started)
        {
            (_x, _z, _raw, _started) = (x, z, raw, true);
        }
        var moved = MathF.Sqrt((x - _x) * (x - _x) + (z - _z) * (z - _z));
        if (moved >= 20f)
        {
            if (_raw > 0.5f && raw > 0.5f)
            {
                var measured = (_raw - raw) / moved;
                if (measured is > 0.5f and < 40f) Scale += (measured - Scale) * 0.35f;
            }
            (_x, _z, _raw) = (x, z, raw);
        }
        var left = raw / Scale;
        return straight >= 0f ? MathF.Max(left, straight) : left;
    }
}

/// <summary>
///  GPS rotasının sonunda tırı durdurur. Saf hesap: oyun nesnesi tutmaz, bu yüzden oyunsuz denenebilir.
///  Veri kaybolursa ya da emin olunamazsa sonuç her zaman frenlemedir, hızlanma isteği üretmez.
/// </summary>
public sealed class StopController
{
    /// <summary>Normal yaklaşma yavaşlaması (m/sn²): yüklü tırda bile rahat ve güvenli.</summary>
    public const float ComfortDecel = 0.9f;
    /// <summary>Tam fren pedalının yaklaşık yavaşlatması (m/sn²).</summary>
    public const float FullBrakeDecel = 5.0f;
    /// <summary>Bu kadar uzaktan görülen rota sonu hedef sayılır (m).</summary>
    public const float ArmDistance = 40f;
    /// <summary>Otopilotun bırakıldığı hız (m/sn, yaklaşık 5 km/sa): direksiyonu buraya kadar otopilot tutar.</summary>
    public const float ReleaseSpeed = 1.5f;

    public float Margin { get; set; } = 6f;
    public StopPhase Phase { get; private set; } = StopPhase.Idle;
    /// <summary>Tahmini kalan mesafe (ekran için), hedef yoksa negatif.</summary>
    public float RemainingToStop { get; private set; } = -1f;

    float _estimated = -1f;
    float _lastRaw;
    float _lastSpeed;
    float _decel;
    float _still;
    float _toggleWait;
    bool _hadRoute;
    float _doneRaw;
    bool _doneSawEmpty;
    bool _released;
    bool _doneSawInactive;
    bool _ignoreRoute;

    /// <summary>Otopilot duruşa yakın bırakıldı; fren durana kadar buradan sürer.</summary>
    public bool Finishing => _released && Phase != StopPhase.Done;

    public void Reset()
    {
        Phase = StopPhase.Idle;
        _estimated = -1f;
        _lastRaw = 0f;
        _decel = 0f;
        _still = 0f;
        _toggleWait = 0f;
        _hadRoute = false;
        _doneRaw = 0f;
        _doneSawEmpty = false;
        _released = false;
        _doneSawInactive = false;
        _ignoreRoute = false;
        RemainingToStop = -1f;
    }

    public StopOutput Update(StopInput i)
    {
        // Durduktan sonra kilit: rota silinip yenisi girildiyse ya da rota belirgin uzadıysa (uzunluğu ne olursa
        // olsun yeni hedef) açılır. Eskiden yalnızca 150 m'den uzun rota açıyordu, ikinci durma çalışmıyordu.
        if (Phase == StopPhase.Done)
        {
            if (!i.Active) _doneSawInactive = true;
            if (i.RouteDistance <= 0.5f) _doneSawEmpty = true;
            else if (_doneSawEmpty || i.RouteDistance > _doneRaw + 25f) Reset();
            // Sürüş yeniden başlatıldı ve rotanın devamı var: sıradaki hedefe göre tekrar devreye girer.
            else if (i.Active && _doneSawInactive && i.RouteDistance >= Margin + ArmDistance) Reset();
            if (Phase == StopPhase.Done) return default;
        }

        if (!i.Active)
        {
            Reset();
            return default;
        }

        var v = Math.Abs(i.Speed);
        if (i.Dt > 0f)
        {
            var measured = (_lastSpeed - v) / i.Dt;
            _decel += (Math.Clamp(measured, -3f, 8f) - _decel) * Math.Min(1f, i.Dt / 0.3f);
        }
        _lastSpeed = v;

        Track(i.RouteDistance, v, i.Dt, i.Straight);

        if (!_hadRoute)
        {
            RemainingToStop = -1f;
            return default;
        }

        var d = MathF.Max(0f, _estimated - Margin);
        RemainingToStop = d;

        if (Phase == StopPhase.Holding || d <= 0.15f || _released)
        {
            Phase = StopPhase.Holding;
            return Release(Hold(i, v), v, d);
        }

        var allowed = MathF.Sqrt(2f * ComfortDecel * d);
        if (v <= allowed + 0.15f)
        {
            // Zarfın altında: hızı ACC yönetir. Son metrelerde bile sürünerek yaklaşabilsin diye zorlanmaz.
            Phase = StopPhase.Approach;
            return default;
        }

        Phase = StopPhase.Braking;
        var wanted = MathF.Min(v * v / (2f * MathF.Max(d, 0.5f)), FullBrakeDecel);
        var brake = wanted / FullBrakeDecel + 0.35f * (wanted - _decel) / FullBrakeDecel;
        return Release(new StopOutput(Math.Clamp(brake, 0.05f, 1f), false, false), v, d);
    }

    /// <summary>Tır neredeyse durduğunda otopilot bir kez kapatılır; fren ve el freni buradan tamamlanır.</summary>
    StopOutput Release(StopOutput o, float v, float d)
    {
        if (_released || v >= ReleaseSpeed || (Phase != StopPhase.Holding && d >= 2.5f)) return o;
        _released = true;
        return o with { DisengageAssists = true };
    }

    void Track(float raw, float v, float dt, float straight)
    {
        // İşaretli ara hedefe varıldı, rota sıradakine geçti: burada durulur, rota artık dinlenmez.
        if (_ignoreRoute)
        {
            _estimated -= v * dt;
            return;
        }

        var hasRoute = raw > 0.5f;
        if (hasRoute)
        {
            // Yeniden rota: mesafe belirgin arttıysa hedef değişmiştir, baştan alınır.
            if (_hadRoute && raw > _estimated + 50f)
            {
                // Hedefe çok yakınken rotanın birden uzaması, ara hedefe varıldığı anlamına gelir.
                if (_estimated < Margin + 150f)
                {
                    _ignoreRoute = true;
                    _estimated -= v * dt;
                    return;
                }
                _hadRoute = false;
                Phase = StopPhase.Idle;
            }

            if (!_hadRoute)
            {
                // Hedefe yakın başlatılsa da devreye girer; duran tır için kısa kalıntı rota hedef sayılmaz.
                if (raw >= ArmDistance || (raw >= Margin + 3f && v > 0.5f))
                {
                    _hadRoute = true;
                    _estimated = raw;
                }
                _lastRaw = raw;
                return;
            }

            // Oyun değeri seyrek güncellerse araya yol hesabı girer; ama asla oyunun söylediğinden uzak sanılmaz.
            _estimated = MathF.Abs(raw - _lastRaw) > 0.01f ? MathF.Min(raw, _estimated) : _estimated - v * dt;
            _estimated = MathF.Min(_estimated, raw);
            _lastRaw = raw;
            return;
        }

        // Rota yakınken silindiyse varılmıştır: sadece yol hesabıyla kapanır, sonra fren tutulur.
        if (_hadRoute)
        {
            // Oyun rotayı hedefe varmadan silebilir: bilinen hedef noktasına kadar yavaşlayarak devam edilir.
            if (_lastRaw < 200f) _estimated = MathF.Min(_estimated - v * dt, straight >= 0f ? straight : Margin);
            else _hadRoute = false; // Uzaktayken iptal: kullanıcı rotayı kaldırmış.
        }
    }

    StopOutput Hold(in StopInput i, float v)
    {
        if (v < 0.25f) _still += i.Dt; else _still = 0f;
        _toggleWait -= i.Dt;

        var toggle = false;
        if (_still > 0.8f && !i.ParkingBrake && _toggleWait <= 0f)
        {
            toggle = true;
            _toggleWait = 1.5f;
        }

        // El freni oyundan onaylanmasa da sonsuza kadar frende beklenmez.
        if ((_still > 0.8f && i.ParkingBrake) || _still > 6f)
        {
            Phase = StopPhase.Done;
            _doneRaw = i.RouteDistance;
            _doneSawEmpty = i.RouteDistance <= 0.5f;
            return new StopOutput(0.6f, false, false);
        }

        var brake = v > 0.5f ? MathF.Min(1f, 0.45f + v * 0.12f) : 0.7f;
        return new StopOutput(brake, toggle, false);
    }
}
