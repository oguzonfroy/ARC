using System.Diagnostics;

using ETS2LA.Game;
using ETS2LA.Logging;

namespace ARC.DriveAssist;

/// <summary>Eski sürümlerin oyuna kurduğu ekran yansıtma eklentisini, oyun kapalıyken bir kez temizler (bkz. <see cref="PrismKaldirma"/>).</summary>
public sealed class PrismTemizleyici
{
    bool _bitti;

    public void Tick()
    {
        if (_bitti || GameRunning()) return;
        try
        {
            var games = GameHandler.Current.Installations.ToList();
            foreach (var game in games)
            {
                var plugins = Path.Combine(game.Path, "bin", "win_x64", "plugins");
                if (PrismKaldirma.Kaldir(plugins))
                    Logger.Info($"ARC: ekran yansıtma eklentisi oyundan kaldırıldı ({game.Type}).");
            }
            _bitti = games.Count > 0;  // oyunlar henüz bulunmadıysa sonra yeniden bakılır
        }
        catch (Exception e)
        {
            Logger.Warn("ARC: ekran yansıtma eklentisi kaldırılamadı, oyun kapalıyken yeniden denenecek: " + e.Message);
        }
    }

    static bool GameRunning()
    {
        foreach (var name in new[] { "eurotrucks2", "amtrucks" })
        {
            var list = Process.GetProcessesByName(name);
            foreach (var p in list) p.Dispose();
            if (list.Length > 0) return true;
        }
        return false;
    }
}
