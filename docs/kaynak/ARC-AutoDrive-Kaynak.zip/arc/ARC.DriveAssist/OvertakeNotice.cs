using System.Numerics;

using ETS2LA.Backend.Events;
using ETS2LA.Overlay;
using ETS2LA.Overlay.AR;
using Hexa.NET.ImGui;

namespace ARC.DriveAssist;

/// <summary>Sollanırken ya da dönüş yönünde araç varken ekranın üst ortasında birkaç saniyelik uyarı gösterir.</summary>
public sealed class OvertakeNotice
{
    const string Name = "ARC Sollama Uyarisi";
    const string OvertakeText = "Sollanıyorsunuz, hız düşürüldü";

    readonly NoticeTimer _overtake = new(), _side = new(), _auto = new();
    string _sideText = "", _autoText = "";
    ARRenderer? _registered;

    public OvertakeNotice()
    {
        Events.Current.Subscribe("ARC.Pathfinding.OvertakeYield", (float _) => _overtake.Show(Environment.TickCount64));
        Events.Current.Subscribe("ARC.Pathfinding.AutoOvertake", (float side) =>
        {
            if (_auto.Show(Environment.TickCount64)) _autoText = AutoText(side);
        });
        Events.Current.Subscribe("ARC.Pathfinding.SideVehicle", (float code) =>
        {
            if (_side.Show(Environment.TickCount64)) _sideText = SideText(code);
        });
    }

    /// <summary>code: işaret yön (eksi sol, artı sağ); 2 ise arkada araç var, yavaşlanamaz.</summary>
    public static string SideText(float code) =>
        (code < 0f ? "Solda" : "Sağda") + (MathF.Abs(code) > 1.5f ? " araç var, dikkat!" : " araç var, yol veriliyor");

    public static string AutoText(float side) =>
        "Sollama başlıyor, birkaç saniye içinde " + (side < 0f ? "sola" : "sağa") + " geçiliyor";

    /// <summary>Çizim katmanı ilk karede oluştuğu için kayıt hazır olunca yapılır.</summary>
    public void Tick()
    {
        var ar = OverlayHandler.Current.AR;
        if (ar == null || ar == _registered) return;
        ar.UnregisterRenderCallback(Name);
        ar.RegisterRenderCallback(new ARRenderCallback
        {
            Definition = new ARRendererDefinition { Name = Name },
            Render3D = Render
        });
        _registered = ar;
    }

    void Render()
    {
        var now = Environment.TickCount64;
        var autoAlpha = _auto.Alpha(now);
        var sideAlpha = _side.Alpha(now);
        var alpha = autoAlpha > 0f ? autoAlpha : sideAlpha > 0f ? sideAlpha : _overtake.Alpha(now);
        if (alpha <= 0f) return;
        var text = autoAlpha > 0f ? _autoText : sideAlpha > 0f ? _sideText : OvertakeText;

        var width = OverlayHandler.Current.OverlayWidth;
        var height = OverlayHandler.Current.OverlayHeight;
        var fontSize = MathF.Max(26f, height / 36f);
        var font = ImGui.GetFont();
        var size = ImGui.CalcTextSize(text) * (fontSize / ImGui.GetFontSize());
        var pad = new Vector2(fontSize * 1.1f, fontSize * 0.6f);
        var icon = fontSize * 1.3f;
        var gap = fontSize * 0.55f;
        var left = (width - icon - gap - size.X) / 2f;
        var at = new Vector2(left + icon + gap, height * 0.12f);
        var min = new Vector2(left, at.Y) - pad;
        var max = at + size + pad;

        var draw = ImGui.GetForegroundDrawList();
        draw.AddRectFilled(min, max, Color(12, 9, 20, 225, alpha), fontSize * 0.4f);
        draw.AddRect(min, max, Color(250, 204, 21, 255, alpha), fontSize * 0.4f, ImDrawFlags.None, 2.5f);
        var amber = Color(250, 204, 21, 255, alpha);
        var mark = Color(12, 9, 20, 255, alpha);
        var center = new Vector2(left + icon / 2f, at.Y + size.Y / 2f);
        draw.AddTriangleFilled(center + new Vector2(0f, -icon * 0.52f), center + new Vector2(icon * 0.58f, icon * 0.46f), center + new Vector2(-icon * 0.58f, icon * 0.46f), amber);
        draw.AddRectFilled(center + new Vector2(-icon * 0.06f, -icon * 0.2f), center + new Vector2(icon * 0.06f, icon * 0.14f), mark);
        draw.AddCircleFilled(center + new Vector2(0f, icon * 0.28f), icon * 0.08f, mark);
        unsafe { draw.AddText(font, fontSize, at, Color(255, 255, 255, 255, alpha), text); }
    }

    static uint Color(int r, int g, int b, int a, float alpha) =>
        (uint)(a * alpha) << 24 | (uint)b << 16 | (uint)g << 8 | (uint)r;
}
