using System.Text;
using System.Text.Json;

namespace ARC.DriveAssist;

public enum WheelMode { Auto, On, Off }

/// <summary>Sürüş ayarları: <c>%APPDATA%\ETS2LA\arc.driveassist.json</c>. Şerit takibi de hassasiyeti buradan okur.</summary>
public sealed class DriveConfig
{
    public float SteeringGain { get; set; } = 1f;
    public WheelMode Wheel { get; set; } = WheelMode.Auto;
    public bool StopAtMarker { get; set; }
    public bool StopAccepted { get; set; }
    public float StopMargin { get; set; } = 6f;
    /// <summary>Oyun içi araç etiketlerinin boyutu (1: eski 18 piksellik yazı).</summary>
    public float HudLabelSize { get; set; } = 0.7f;
    public bool TakeoverWheel { get; set; } = true;
    public float TakeoverPercent { get; set; } = 8f;
    public bool TakeoverPedal { get; set; } = true;
    /// <summary>Direksiyon setinde gazın ekseni; sürücü elle giderken öğrenilir (-1: henüz bilinmiyor).</summary>
    public int GasAxis { get; set; } = -1;
    public string GasAxisDevice { get; set; } = "";
    /// <summary>Öğrenilen gaz ekseni yalnız öğrenildiği sette geçerlidir; başka sette o numara fren olabilir.</summary>
    public int GasAxisFor(string device) => device == GasAxisDevice ? GasAxis : -1;
    public bool FfbAutoDone { get; set; }
    public bool FfbAutoUndone { get; set; }
    public bool PhoneOn { get; set; } = true;

    static readonly JsonSerializerOptions Json = new() { WriteIndented = true };
    static readonly object Lock = new();

    public static string FilePath
    {
        get
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ETS2LA");
            Directory.CreateDirectory(dir);
            return Path.Combine(dir, "arc.driveassist.json");
        }
    }

    public static DriveConfig Load()
    {
        try
        {
            var c = JsonSerializer.Deserialize<DriveConfig>(File.ReadAllText(FilePath)) ?? new DriveConfig();
            c.SteeringGain = Math.Clamp(c.SteeringGain, 0.4f, 2.5f);
            c.StopMargin = Math.Clamp(c.StopMargin, 2f, 40f);
            return c;
        }
        catch
        {
            return new DriveConfig();
        }
    }

    public void Save()
    {
        lock (Lock)
        {
            try
            {
                var temp = FilePath + ".yeni";
                File.WriteAllText(temp, JsonSerializer.Serialize(this, Json), new UTF8Encoding(false));
                File.Move(temp, FilePath, true);
            }
            catch { }
        }
    }
}
