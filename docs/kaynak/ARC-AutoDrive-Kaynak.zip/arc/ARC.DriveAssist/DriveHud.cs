using System.IO.MemoryMappedFiles;
using System.Numerics;

using ETS2LA.Backend.Events;
using ETS2LA.Game.SDK;
using ETS2LA.Logging;
using ETS2LA.Overlay;
using ETS2LA.Overlay.AR;

namespace ARC.DriveAssist;

/// <summary>
///  Sürüş göstergesinin verisi: şerit, yol okları ve araç etiketleri, oyunun içinde çizen arclight'a
///  <c>Local\ARCHud</c> paylaşılan belleğiyle gider. Ayrı pencere yok; çizim oyunun kendi karesinde ve o karenin
///  kamerasıyla yapılır.
/// </summary>
public sealed class DriveHud
{
    const uint Magic = 0x48554441;
    const int Size = 256 * 1024, Header = 48, MaxPoints = 2000, PointFloats = 10, MaxQuads = 512, QuadFloats = 16, MaxLabels = 64, LabelFloats = 6;
    const int PointsAt = Header;
    const int QuadsAt = PointsAt + MaxPoints * PointFloats * 4;
    const int LabelsAt = QuadsAt + MaxQuads * QuadFloats * 4;
    const int LeadAt = LabelsAt + MaxLabels * LabelFloats * 4;

    readonly MemoryMappedFile _map = MemoryMappedFile.CreateOrOpen("Local\\ARCHud", Size);
    readonly MemoryMappedViewAccessor _view;
    float[] _ribbon = Array.Empty<float>(), _arrows = Array.Empty<float>();
    DateTime _ribbonAt, _arrowsAt, _unregisteredAt = DateTime.MinValue;
    Vector3 _lastPosition, _heading;
    uint _seq;

    public DriveHud()
    {
        _view = _map.CreateViewAccessor(0, Size);
        _view.Write(0, Magic);
        Events.Current.Subscribe("ARC.Hud.Ribbon", (float[] d) => { _ribbon = d; _ribbonAt = DateTime.UtcNow; });
        Events.Current.Subscribe("ARC.Hud.Arrows", (float[] d) => { _arrows = d; _arrowsAt = DateTime.UtcNow; });
    }

    /// <summary>Üstte pencere olarak çizilen eski göstergeyi kapatır (arayüz yüklendikçe yeniden denenir).</summary>
    void DisableOverlayVersion()
    {
        if ((DateTime.UtcNow - _unregisteredAt).TotalSeconds < 5) return;
        _unregisteredAt = DateTime.UtcNow;
        try
        {
            OverlayHandler.Current.AR.UnregisterRenderCallback("ARC Drive HUD");
            // ACC'nin üstte pencere olarak çizdiği işaret: öndeki araç artık oyunun içinde çiziliyor, bu da hata üretiyordu.
            OverlayHandler.Current.AR.UnregisterRenderCallback("ACC Leading Vehicle Visualization");
        }
        catch (Exception e) { Logger.Warn($"ARC gösterge: {e.Message}"); }
    }

    public void Tick(float labelSize)
    {
        DisableOverlayVersion();
        var now = DateTime.UtcNow;
        var ribbon = (now - _ribbonAt).TotalSeconds < 0.5 ? _ribbon : Array.Empty<float>();
        var arrows = (now - _arrowsAt).TotalSeconds < 0.5 ? _arrows : Array.Empty<float>();
        // Şeridin ilk iki değeri: öndeki hedefe uzaklık ve ikinci renk.
        var target = ribbon.Length >= 2 ? ribbon[0] : 0f;
        var second = ribbon.Length >= 2 ? BitConverter.SingleToUInt32Bits(ribbon[1]) : 0u;
        ribbon = ribbon.Length >= 2 ? ribbon[2..] : Array.Empty<float>();
        var points = Math.Min(ribbon.Length / PointFloats, MaxPoints);
        var quads = Math.Min(arrows.Length / QuadFloats, MaxQuads);

        var labels = new List<float>();
        var lead = new List<float>();
        if (OverlaySettingsHandler.Current.GetSettings().ShowDriveHud)
            Vehicles(ribbon, labels, lead);

        _seq++;
        _view.Write(4, _seq | 1u);
        if (points > 0) _view.WriteArray(PointsAt, ribbon, 0, points * PointFloats);
        if (quads > 0) _view.WriteArray(QuadsAt, arrows, 0, quads * QuadFloats);
        var labelCount = Math.Min(labels.Count / LabelFloats, MaxLabels);
        if (labelCount > 0) _view.WriteArray(LabelsAt, labels.ToArray(), 0, labelCount * LabelFloats);
        if (lead.Count == 12) _view.WriteArray(LeadAt, lead.ToArray(), 0, 12);
        _view.Write(8, points);
        _view.Write(12, quads);
        _view.Write(16, labelCount);
        _view.Write(20, lead.Count == 12 ? 4 : 0);
        _view.Write(40, labelSize);
        _view.Write(32, target);
        _view.Write(36, second);
        _view.Write(24, (double)DateTimeOffset.UtcNow.ToUnixTimeMilliseconds());
        _seq++;
        _view.Write(4, _seq & ~1u);
    }

    void Vehicles(float[] ribbon, List<float> labels, List<float> leadOut)
    {
        var truck = CameraProvider.Current.GetCurrentData().truckPosition;
        var moved = truck - _lastPosition;
        moved.Y = 0f;
        if (moved.Length() >= 0.5f)
        {
            _lastPosition = truck;
            if (moved.Length() < 50f) _heading = Vector3.Normalize(moved);
        }
        var vehicles = TrafficProvider.Current.GetCurrentTrafficData()?.vehicles;
        if (vehicles == null || _heading == Vector3.Zero) return;

        TrafficVehicle? lead = null;
        var nearest = float.MaxValue;
        foreach (var v in vehicles)
        {
            if (v.Position == Vector3.Zero || v.isTrailer) continue;
            var to = v.Position - truck;
            to.Y = 0f;
            var ahead = Vector3.Dot(to, _heading);
            if (ahead < 3f || ahead > 150f || (to - _heading * ahead).Length() > 15f) continue;
            var inLane = InLane(ribbon, v.Position, to, ahead);
            if (inLane && ahead < nearest)
            {
                nearest = ahead;
                lead = v;
            }
            labels.AddRange(new[] { v.Position.X, v.Position.Y + v.Size.Y / 2f + 0.5f, v.Position.Z, v.speed * 3.6f, ahead, 0f });
        }
        if (lead == null) return;
        // Öndeki aracın etiketi vurgulu.
        for (var i = 0; i + LabelFloats <= labels.Count; i += LabelFloats)
            if (labels[i] == lead.Position.X && labels[i + 2] == lead.Position.Z) labels[i + 5] = 1f;
        foreach (var c in lead.GetCornersOnGround().Take(4))
            leadOut.AddRange(new[] { c.X, c.Y, c.Z });
    }

    bool InLane(float[] ribbon, Vector3 position, Vector3 to, float ahead)
    {
        if (ribbon.Length < PointFloats * 2) return (to - _heading * ahead).Length() < 3f;
        for (var i = 0; i + PointFloats <= ribbon.Length; i += PointFloats)
        {
            var dx = ribbon[i + 3] - position.X;
            var dz = ribbon[i + 5] - position.Z;
            if (dx * dx + dz * dz < 9f) return true;
        }
        return false;
    }
}
