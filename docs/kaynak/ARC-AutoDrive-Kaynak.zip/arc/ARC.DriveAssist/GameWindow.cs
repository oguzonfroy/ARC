using System.Diagnostics;
using System.Runtime.InteropServices;

namespace ARC.DriveAssist;

/// <summary>
///  Oyun penceresinin yerini ve ekran modunu belgelenmiş Windows API'leriyle okur: pencere dikdörtgeni, monitör,
///  SHQueryUserNotificationState (QUNS_RUNNING_D3D_FULL_SCREEN = özel tam ekran Direct3D). Oyuna hiçbir şey yazmaz.
/// </summary>
/// <param name="exe">Süreç adı; ETS2LA.Game/Program.cs'e göre bin\win_x64\eurotrucks2.exe. Testler başka süreç verir.</param>
public sealed class GameWindow(string exe = "eurotrucks2")
{
    const long LookupMs = 2000;
    const int QunsRunningD3dFullScreen = 3;

    IntPtr _hwnd;
    long _lookedAt = long.MinValue;

    public GameScreen Read(long now, float overlayW, float overlayH)
    {
        if (_hwnd == IntPtr.Zero || !IsWindow(_hwnd))
        {
            if (_lookedAt != long.MinValue && now - _lookedAt < LookupMs) return default;
            _lookedAt = now;
            _hwnd = Find();
            if (_hwnd == IntPtr.Zero) return default;
        }

        if (IsIconic(_hwnd)) return new GameScreen(true, true, false, null);
        bool exclusive = GetForegroundWindow() == _hwnd
            && SHQueryUserNotificationState(out var state) == 0 && state == QunsRunningD3dFullScreen;

        if (!GetClientRect(_hwnd, out var client)) return new GameScreen(true, false, exclusive, null);
        var origin = new POINT();
        ClientToScreen(_hwnd, ref origin);
        var info = new MONITORINFO { cbSize = Marshal.SizeOf<MONITORINFO>() };
        if (!GetMonitorInfoW(MonitorFromPoint(new POINT(), 1 /* MONITOR_DEFAULTTOPRIMARY */), ref info))
            return new GameScreen(true, false, exclusive, null);

        var m = info.rcMonitor;
        var area = GameArea.Map(
            new ScreenArea(origin.X, origin.Y, client.Right - client.Left, client.Bottom - client.Top),
            new ScreenArea(m.Left, m.Top, m.Right - m.Left, m.Bottom - m.Top),
            overlayW, overlayH);
        return new GameScreen(true, false, exclusive, area);
    }

    IntPtr Find()
    {
        foreach (var p in Process.GetProcessesByName(exe))
        {
            using (p)
            {
                try { if (p.MainWindowHandle != IntPtr.Zero) return p.MainWindowHandle; }
                catch { }
            }
        }
        return IntPtr.Zero;
    }

    [StructLayout(LayoutKind.Sequential)] struct RECT { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] struct POINT { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] struct MONITORINFO { public int cbSize; public RECT rcMonitor, rcWork; public uint dwFlags; }

    [DllImport("user32.dll")] static extern bool IsWindow(IntPtr hWnd);
    [DllImport("user32.dll")] static extern bool IsIconic(IntPtr hWnd);
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern bool GetClientRect(IntPtr hWnd, out RECT rect);
    [DllImport("user32.dll")] static extern bool ClientToScreen(IntPtr hWnd, ref POINT point);
    [DllImport("user32.dll")] static extern IntPtr MonitorFromPoint(POINT pt, uint flags);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool GetMonitorInfoW(IntPtr monitor, ref MONITORINFO info);
    [DllImport("shell32.dll")] static extern int SHQueryUserNotificationState(out int state);
}
