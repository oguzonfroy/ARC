namespace ARC.DriveAssist;

/// <summary>Kapının tıra göre konumu (metre) ve oyundaki durumu (GateStates: 0 kapanıyor, 1 kapalı, 2 açılıyor, 3 açık).</summary>
public readonly record struct GateView(float Ahead, float Side, int State);

/// <summary>
///  Gişe ve sınır kapısı: ACC kapalı kapının önünde durdurur (PathSemaphoreConstraint), bazı gişeler ise ödeme için
///  "etkinleştir" (Enter) ister. Tır kapalı kapının önünde durunca bir kez basar, kapı açılmazsa birkaç kez yeniler.
/// </summary>
public sealed class TollGate
{
    public const int MaxTries = 3;
    public const float Reach = 15f;      // ACC kapıdan 5 m önce durur; daha gerisi kuyruktur, ödeme alanı değildir
    public const float SideMax = 4f;     // ACC'nin kapıyı rotada sayma sınırı (PathSemaphoreConstraint)
    public const float StopSpeed = 0.5f; // m/s
    public const float Settle = 1f;      // durduktan sonra bekleme (s)
    public const float Retry = 4f;       // açılmayan kapıda yeniden basma aralığı (s)

    float _still, _sinceLast = Retry;
    int _tries;

    /// <summary>Dünya farkını (kapı - tır) tırın yönüne çevirir. heading SCS biçimindedir (0..1 tur, 0 = -Z).</summary>
    public static GateView View(float dx, float dz, double heading, int state)
    {
        var a = heading * 2.0 * Math.PI;
        float sin = (float)Math.Sin(a), cos = (float)Math.Cos(a);
        return new GateView(-dx * sin - dz * cos, dx * cos - dz * sin, state);
    }

    /// <returns>Bu adımda Enter basılmalıysa true.</returns>
    public bool Update(bool active, float speed, IReadOnlyList<GateView> gates, float dt)
    {
        // Gişede kapılar 4-5 m arayla dizilir: yalnız şeridimizin (yana en yakın) kapısı sayılır.
        GateView? ours = null;
        foreach (var g in gates)
            if (g.Ahead > 0f && g.Ahead < Reach && MathF.Abs(g.Side) < SideMax && (ours is not { } o || MathF.Abs(g.Side) < MathF.Abs(o.Side)))
                ours = g;
        var closed = ours is { State: 0 or 1 };
        if (!closed) _tries = 0;
        if (!active || !closed || MathF.Abs(speed) > StopSpeed)
        {
            _still = 0f;
            return false;
        }
        _still += dt;
        _sinceLast += dt;
        if (_still < Settle || _tries >= MaxTries || (_tries > 0 && _sinceLast < Retry)) return false;
        _tries++;
        _sinceLast = 0f;
        return true;
    }
}
