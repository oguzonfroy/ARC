namespace ARC.DriveAssist;

/// <summary>
///  Direksiyon setinde elle müdahaleyi anlar: direksiyon beklenen yerinden ayrılırsa ya da bir pedala basılırsa
///  otopilot bırakılır. Saf hesap: cihaz okumaz, bu yüzden direksiyonsuz denenebilir.
/// </summary>
public sealed class WheelTakeover
{
    const float SettleSeconds = 0.6f;
    const int HoldFrames = 3;
    public const float PedalThreshold = 0.35f;

    float _settle;
    float _baseX;
    float[]? _basePedals;
    int _wheelFrames, _pedalFrames;

    public void Reset()
    {
        _settle = 0f;
        _basePedals = null;
        _wheelFrames = _pedalFrames = 0;
    }

    /// <param name="active">Otopilot devrede.</param>
    /// <param name="x">Direksiyon konumu, -1..1.</param>
    /// <param name="pedals">Direksiyon dışındaki eksenler, -1..1.</param>
    /// <param name="expected">Güç geri bildirimi direksiyonu döndürüyorsa beklenen konum; yoksa null.</param>
    /// <param name="threshold">Sapma eşiği, 0..1.</param>
    /// <param name="gasAxis">Gaz pedalının ekseni; bu eksene basmak otopilotu kapatmaz. Bilinmiyorsa -1.</param>
    /// <returns>Kullanıcı müdahale etti mi, ve hangi yolla.</returns>
    public string? Update(bool active, float dt, float x, float[] pedals, float? expected, float threshold, bool watchWheel, bool watchPedals, int gasAxis = -1)
    {
        if (!active)
        {
            Reset();
            return null;
        }

        // Başlarken eksenlerin durduğu yer öğrenilir; ayak pedalda başlatılsa da yanlış alarm olmasın diye bekler.
        if (_settle < SettleSeconds || _basePedals == null || _basePedals.Length != pedals.Length)
        {
            _settle += dt;
            _baseX = x;
            _basePedals = (float[])pedals.Clone();
            return null;
        }

        var reference = expected ?? _baseX;
        _wheelFrames = watchWheel && MathF.Abs(x - reference) > threshold ? _wheelFrames + 1 : 0;
        if (_wheelFrames >= HoldFrames) return "direksiyon";

        var pressed = false;
        if (watchPedals)
            for (var i = 0; i < pedals.Length; i++)
                pressed |= i != gasAxis && MathF.Abs(pedals[i] - _basePedals[i]) > PedalThreshold;
        _pedalFrames = pressed ? _pedalFrames + 1 : 0;
        return _pedalFrames >= HoldFrames ? "pedal" : null;
    }
}

/// <summary>
///  Sürücü elle giderken hangi eksenin gaz olduğunu oyunun gaz verisinden öğrenir; markaya göre eksenler değiştiği için
///  sabit yazılamaz. Otopilot devredeyken çağrılmaz: o sırada oyunun gaz verisini otopilot da değiştirir.
/// </summary>
public sealed class GasAxisLearner
{
    const float Quiet = 0.05f;
    const float Pressed = WheelTakeover.PedalThreshold;
    const int NeededFrames = 6;

    float[]? _rest;
    int _candidate = -1, _frames;

    /// <returns>Gaz ekseni kesinleştiyse numarası; değilse null.</returns>
    public int? Observe(float[] pedals, float gas, float brake, float clutch)
    {
        if (_rest != null && _rest.Length != pedals.Length) _rest = null;
        if (gas < Quiet && brake < Quiet && clutch < Quiet)
        {
            _rest = (float[])pedals.Clone();
            Clear();
            return null;
        }
        if (_rest == null || brake >= Quiet || clutch >= Quiet)
        {
            Clear();
            return null;
        }
        if (gas < Pressed) return null;

        var moved = -1;
        for (var i = 0; i < pedals.Length; i++)
        {
            if (MathF.Abs(pedals[i] - _rest[i]) <= Pressed) continue;
            if (moved >= 0)
            {
                Clear();
                return null;
            }
            moved = i;
        }
        if (moved < 0)
        {
            Clear();
            return null;
        }
        _frames = moved == _candidate ? _frames + 1 : 1;
        _candidate = moved;
        return _frames >= NeededFrames ? moved : null;
    }

    void Clear()
    {
        _candidate = -1;
        _frames = 0;
    }
}
